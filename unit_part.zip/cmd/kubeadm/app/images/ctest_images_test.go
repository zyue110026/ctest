package images

import (
	"fmt"
	"strings"
	"testing"

	"github.com/stretchr/testify/assert"
	kubeadmapi "k8s.io/kubernetes/cmd/kubeadm/app/apis/kubeadm"
	kubeadmapiv1 "k8s.io/kubernetes/cmd/kubeadm/app/apis/kubeadm/v1beta4"
	"k8s.io/kubernetes/cmd/kubeadm/app/constants"

	ctest "k8s.io/kubernetes/test/ctest"
	ctestglobals "k8s.io/kubernetes/test/ctest/ctestglobals"
	ctestutils "k8s.io/kubernetes/test/ctest/utils"
)

//-------------------- Test GetKubernetesImage --------------------

func TestCtestGetKubernetesImage(t *testing.T) {
	fmt.Println(ctestglobals.StartSeparator)
	hardcoded := getHardCodedConfigInfoKubernetesImage()
	item, found := ctestutils.GetItemByExactTestInfo(hardcoded, "kubernetes-image-config")
	if !found {
		t.Fatalf("hardcoded config not found")
	}
	configObjs, configJson, err := ctest.GenerateEffectiveConfigReturnType[*kubeadmapi.ClusterConfiguration](item, ctest.OverrideOnly)
	if err != nil {
		t.Fatalf("failed to generate config: %v", err)
	}
	fmt.Println(ctestglobals.DebugPrefix(), "New Json Test Configs:", string(configJson))
	fmt.Println(ctestglobals.DebugPrefix(), "Num of Test Cases:", len(configObjs))

	if configObjs == nil {
		fmt.Println(ctestglobals.DebugPrefix(), "Skipping test execution. No new configurations generated.")
		return
	}
	images := []string{
		constants.KubeAPIServer,
		constants.KubeControllerManager,
		constants.KubeScheduler,
		constants.KubeProxy,
	}
	for i, cfg := range configObjs {
		fmt.Printf("Running %d th test case.\n", i)
		fmt.Println(ctestglobals.DebugPrefix(), cfg)
		for _, img := range images {
			expected := GetGenericImage(cfg.ImageRepository, img, cfg.KubernetesVersion)
			actual := GetKubernetesImage(img, cfg)
			if actual != expected {
				t.Errorf("GetKubernetesImage mismatch for image %s (repo=%s, version=%s): expected %s, got %s",
					img, cfg.ImageRepository, cfg.KubernetesVersion, expected, actual)
			}
		}
	}
	fmt.Println(ctestglobals.EndSeparator)
}

//-------------------- Test GetEtcdImage --------------------

func TestCtestGetEtcdImage(t *testing.T) {
	fmt.Println(ctestglobals.StartSeparator)
	hardcoded := getHardCodedConfigInfoEtcdImage()
	item, found := ctestutils.GetItemByExactTestInfo(hardcoded, "etcd-image-config")
	if !found {
		t.Fatalf("hardcoded config not found")
	}
	configObjs, configJson, err := ctest.GenerateEffectiveConfigReturnType[*kubeadmapi.ClusterConfiguration](item, ctest.OverrideOnly)
	if err != nil {
		t.Fatalf("failed to generate config: %v", err)
	}
	fmt.Println(ctestglobals.DebugPrefix(), "New Json Test Configs:", string(configJson))
	fmt.Println(ctestglobals.DebugPrefix(), "Num of Test Cases:", len(configObjs))

	if configObjs == nil {
		fmt.Println(ctestglobals.DebugPrefix(), "Skipping test execution. No new configurations generated.")
		return
	}
	for i, cfg := range configObjs {
		fmt.Printf("Running %d th test case.\n", i)
		fmt.Println(ctestglobals.DebugPrefix(), cfg)

		// Determine expected etcd version
		etcdVer, _, _ := constants.EtcdSupportedVersion(constants.SupportedEtcdVersion, cfg.KubernetesVersion)

		var expected string
		if cfg.Etcd.Local != nil && cfg.Etcd.Local.ImageMeta.ImageTag != "" {
			expected = fmt.Sprintf("%s/etcd:%s", cfg.ImageRepository, cfg.Etcd.Local.ImageMeta.ImageTag)
		} else if cfg.Etcd.Local != nil && cfg.Etcd.Local.ImageMeta.ImageRepository != "" {
			expected = fmt.Sprintf("%s/etcd:%s", cfg.Etcd.Local.ImageMeta.ImageRepository, etcdVer.String())
		} else {
			expected = fmt.Sprintf("%s/etcd:%s", cfg.ImageRepository, etcdVer.String())
		}
		actual := GetEtcdImage(cfg)
		if actual != expected {
			t.Errorf("GetEtcdImage mismatch: expected %s, got %s (repo=%s)", expected, actual, cfg.ImageRepository)
		}
	}
	fmt.Println(ctestglobals.EndSeparator)
}

//-------------------- Test GetPauseImage --------------------

func TestCtestGetPauseImage(t *testing.T) {
	fmt.Println(ctestglobals.StartSeparator)
	hardcoded := getHardCodedConfigInfoPauseImage()
	item, found := ctestutils.GetItemByExactTestInfo(hardcoded, "pause-image-config")
	if !found {
		t.Fatalf("hardcoded config not found")
	}
	configObjs, configJson, err := ctest.GenerateEffectiveConfigReturnType[*kubeadmapi.ClusterConfiguration](item, ctest.OverrideOnly)
	if err != nil {
		t.Fatalf("failed to generate config: %v", err)
	}
	fmt.Println(ctestglobals.DebugPrefix(), "New Json Test Configs:", string(configJson))
	fmt.Println(ctestglobals.DebugPrefix(), "Num of Test Cases:", len(configObjs))

	if configObjs == nil {
		fmt.Println(ctestglobals.DebugPrefix(), "Skipping test execution. No new configurations generated.")
		return
	}
	for i, cfg := range configObjs {
		fmt.Printf("Running %d th test case.\n", i)
		fmt.Println(ctestglobals.DebugPrefix(), cfg)

		expected := fmt.Sprintf("%s/pause:%s", cfg.ImageRepository, constants.PauseVersion)
		actual := GetPauseImage(cfg)
		if actual != expected {
			t.Errorf("GetPauseImage mismatch: expected %s, got %s", expected, actual)
		}
	}
	fmt.Println(ctestglobals.EndSeparator)
}

//-------------------- Test GetAllImages (Control Plane Images) --------------------

func TestCtestGetAllImages(t *testing.T) {
	fmt.Println(ctestglobals.StartSeparator)
	hardcoded := getHardCodedConfigInfoAllImages()
	item, found := ctestutils.GetItemByExactTestInfo(hardcoded, "all-images-config")
	if !found {
		t.Fatalf("hardcoded config not found")
	}
	configObjs, configJson, err := ctest.GenerateEffectiveConfigReturnType[*kubeadmapi.ClusterConfiguration](item, ctest.OverrideOnly)
	if err != nil {
		t.Fatalf("failed to generate config: %v", err)
	}
	fmt.Println(ctestglobals.DebugPrefix(), "New Json Test Configs:", string(configJson))
	fmt.Println(ctestglobals.DebugPrefix(), "Num of Test Cases:", len(configObjs))

	if configObjs == nil {
		fmt.Println(ctestglobals.DebugPrefix(), "Skipping test execution. No new configurations generated.")
		return
	}
	for i, cfg := range configObjs {
		fmt.Printf("Running %d th test case.\n", i)
		fmt.Println(ctestglobals.DebugPrefix(), cfg)

		actual := GetControlPlaneImages(cfg)

		// Build expected slice dynamically based on cfg
		var expected []string
		prefix := cfg.ImageRepository
		if cfg.CIImageRepository != "" {
			prefix = cfg.CIImageRepository
		}
		if prefix != "" {
			expected = append(expected,
				fmt.Sprintf("%s/kube-apiserver:", prefix),
				fmt.Sprintf("%s/kube-controller-manager:", prefix),
				fmt.Sprintf("%s/kube-scheduler:", prefix),
				fmt.Sprintf("%s/kube-proxy:", prefix),
			)
		}
		if cfg.DNS.Disabled {
			// skip coredns
		} else {
			expected = append(expected, fmt.Sprintf("%s/coredns:%s", prefix, constants.CoreDNSVersion))
		}
		expected = append(expected, fmt.Sprintf("%s/pause:%s", prefix, constants.PauseVersion))

		if cfg.Etcd.Local != nil {
			etcdVer, _, _ := constants.EtcdSupportedVersion(constants.SupportedEtcdVersion, cfg.KubernetesVersion)
			if cfg.Etcd.Local.ImageMeta.ImageTag != "" {
				expected = append(expected, fmt.Sprintf("%s/etcd:%s", cfg.ImageRepository, cfg.Etcd.Local.ImageMeta.ImageTag))
			} else if cfg.Etcd.Local.ImageMeta.ImageRepository != "" {
				expected = append(expected, fmt.Sprintf("%s/etcd:%s", cfg.Etcd.Local.ImageMeta.ImageRepository, etcdVer.String()))
			} else {
				expected = append(expected, fmt.Sprintf("%s/etcd:%s", cfg.ImageRepository, etcdVer.String()))
			}
		}

		if cfg.Proxy.Disabled {
			// remove kube-proxy entry
			newExp := []string{}
			for _, img := range expected {
				if strings.Contains(img, "kube-proxy") {
					continue
				}
				newExp = append(newExp, img)
			}
			expected = newExp
		}
		assert.Equal(t, expected, actual)
	}
	fmt.Println(ctestglobals.EndSeparator)
}

//-------------------- Test GetDNSImage --------------------

func TestCtestGetDNSImage(t *testing.T) {
	fmt.Println(ctestglobals.StartSeparator)
	hardcoded := getHardCodedConfigInfoDNSImage()
	item, found := ctestutils.GetItemByExactTestInfo(hardcoded, "dns-image-config")
	if !found {
		t.Fatalf("hardcoded config not found")
	}
	configObjs, configJson, err := ctest.GenerateEffectiveConfigReturnType[*kubeadmapi.ClusterConfiguration](item, ctest.OverrideOnly)
	if err != nil {
		t.Fatalf("failed to generate config: %v", err)
	}
	fmt.Println(ctestglobals.DebugPrefix(), "New Json Test Configs:", string(configJson))
	fmt.Println(ctestglobals.DebugPrefix(), "Num of Test Cases:", len(configObjs))

	if configObjs == nil {
		fmt.Println(ctestglobals.DebugPrefix(), "Skipping test execution. No new configurations generated.")
		return
	}
	for i, cfg := range configObjs {
		fmt.Printf("Running %d th test case.\n", i)
		fmt.Println(ctestglobals.DebugPrefix(), cfg)

		var repo, tag string
		if cfg.DNS.ImageMeta.ImageRepository != "" {
			repo = cfg.DNS.ImageMeta.ImageRepository
		} else {
			repo = cfg.ImageRepository
		}
		if cfg.DNS.ImageMeta.ImageTag != "" {
			tag = cfg.DNS.ImageMeta.ImageTag
		} else {
			tag = constants.CoreDNSVersion
		}
		expected := fmt.Sprintf("%s/coredns:%s", repo, tag)

		actual := GetDNSImage(cfg)
		if actual != expected {
			t.Errorf("GetDNSImage mismatch: expected %s, got %s", expected, actual)
		}
	}
	fmt.Println(ctestglobals.EndSeparator)
}

//-------------------- Hardcoded Config Definitions --------------------

func getHardCodedConfigInfoKubernetesImage() ctestglobals.HardcodedConfig {
	return ctestglobals.HardcodedConfig{
		{
			FixtureFileName: "test_fixture.json",
			TestInfo:        []string{"kubernetes-image-config"},
			Field:           "ClusterConfiguration",
			K8sObjects:      []string{"pods"},
			HardcodedConfig: &kubeadmapi.ClusterConfiguration{
				ImageRepository:   gcrPrefix,
				KubernetesVersion: testVersion,
			},
		},
		{
			FixtureFileName: "test_fixture.json",
			TestInfo:        []string{"kubernetes-image-config-empty-repo"},
			Field:           "ClusterConfiguration",
			K8sObjects:      []string{"pods"},
			HardcodedConfig: &kubeadmapi.ClusterConfiguration{
				ImageRepository:   "",
				KubernetesVersion: testVersion,
			},
		},
		{
			FixtureFileName: "test_fixture.json",
			TestInfo:        []string{"kubernetes-image-config-empty-version"},
			Field:           "ClusterConfiguration",
			K8sObjects:      []string{"pods"},
			HardcodedConfig: &kubeadmapi.ClusterConfiguration{
				ImageRepository:   gcrPrefix,
				KubernetesVersion: "",
			},
		},
	}
}

func getHardCodedConfigInfoEtcdImage() ctestglobals.HardcodedConfig {
	return ctestglobals.HardcodedConfig{
		{
			FixtureFileName: "test_fixture.json",
			TestInfo:        []string{"etcd-image-config"},
			Field:           "ClusterConfiguration",
			K8sObjects:      []string{"pods"},
			HardcodedConfig: &kubeadmapi.ClusterConfiguration{
				ImageRepository:   "real.repo",
				KubernetesVersion: testVersion,
				Etcd: kubeadmapi.Etcd{
					Local: &kubeadmapi.LocalEtcd{},
				},
			},
		},
		{
			FixtureFileName: "test_fixture.json",
			TestInfo:        []string{"etcd-image-config-override-tag"},
			Field:           "ClusterConfiguration",
			K8sObjects:      []string{"pods"},
			HardcodedConfig: &kubeadmapi.ClusterConfiguration{
				ImageRepository:   "real.repo",
				KubernetesVersion: testVersion,
				Etcd: kubeadmapi.Etcd{
					Local: &kubeadmapi.LocalEtcd{
						ImageMeta: kubeadmapi.ImageMeta{
							ImageTag: "override",
						},
					},
				},
			},
		},
		{
			FixtureFileName: "test_fixture.json",
			TestInfo:        []string{"etcd-image-config-override-repo"},
			Field:           "ClusterConfiguration",
			K8sObjects:      []string{"pods"},
			HardcodedConfig: &kubeadmapi.ClusterConfiguration{
				ImageRepository:   "real.repo",
				KubernetesVersion: testVersion,
				Etcd: kubeadmapi.Etcd{
					Local: &kubeadmapi.LocalEtcd{
						ImageMeta: kubeadmapi.ImageMeta{
							ImageRepository: "override",
						},
					},
				},
			},
		},
	}
}

func getHardCodedConfigInfoPauseImage() ctestglobals.HardcodedConfig {
	return ctestglobals.HardcodedConfig{
		{
			FixtureFileName: "test_fixture.json",
			TestInfo:        []string{"pause-image-config"},
			Field:           "ClusterConfiguration",
			K8sObjects:      []string{"pods"},
			HardcodedConfig: &kubeadmapi.ClusterConfiguration{
				ImageRepository: "test.repo",
			},
		},
	}
}

func getHardCodedConfigInfoAllImages() ctestglobals.HardcodedConfig {
	return ctestglobals.HardcodedConfig{
		{
			FixtureFileName: "test_fixture.json",
			TestInfo:        []string{"all-images-config"},
			Field:           "ClusterConfiguration",
			K8sObjects: []string{
				"deployments", "statefulsets", "daemonsets", "replicasets", "pods"},
			HardcodedConfig: &kubeadmapi.ClusterConfiguration{
				CIImageRepository: "test.repo",
			},
		},
		{
			FixtureFileName: "test_fixture.json",
			TestInfo:        []string{"all-images-config-default-repo"},
			Field:           "ClusterConfiguration",
			K8sObjects: []string{
				"deployments", "statefulsets", "daemonsets", "replicasets", "pods"},
			HardcodedConfig: &kubeadmapi.ClusterConfiguration{
				ImageRepository: "real.repo",
			},
		},
		{
			FixtureFileName: "test_fixture.json",
			TestInfo:        []string{"all-images-config-etcd-local"},
			Field:           "ClusterConfiguration",
			K8sObjects: []string{
				"deployments", "statefulsets", "daemonsets", "replicasets", "pods"},
			HardcodedConfig: &kubeadmapi.ClusterConfiguration{
				Etcd: kubeadmapi.Etcd{
					Local: &kubeadmapi.LocalEtcd{},
				},
			},
		},
		{
			FixtureFileName: "test_fixture.json",
			TestInfo:        []string{"all-images-config-dns-disabled"},
			Field:           "ClusterConfiguration",
			K8sObjects: []string{
				"deployments", "statefulsets", "daemonsets", "replicasets", "pods"},
			HardcodedConfig: &kubeadmapi.ClusterConfiguration{
				DNS: kubeadmapi.DNS{
					Disabled: true,
				},
			},
		},
		{
			FixtureFileName: "test_fixture.json",
			TestInfo:        []string{"all-images-config-proxy-disabled"},
			Field:           "ClusterConfiguration",
			K8sObjects: []string{
				"deployments", "statefulsets", "daemonsets", "replicasets", "pods"},
			HardcodedConfig: &kubeadmapi.ClusterConfiguration{
				Proxy: kubeadmapi.Proxy{
					Disabled: true,
				},
			},
		},
	}
}

func getHardCodedConfigInfoDNSImage() ctestglobals.HardcodedConfig {
	return ctestglobals.HardcodedConfig{
		{
			FixtureFileName: "test_fixture.json",
			TestInfo:        []string{"dns-image-config"},
			Field:           "ClusterConfiguration",
			K8sObjects:      []string{"pods"},
			HardcodedConfig: &kubeadmapi.ClusterConfiguration{
				ImageRepository: "foo.io",
				DNS:             kubeadmapi.DNS{},
			},
		},
		{
			FixtureFileName: "test_fixture.json",
			TestInfo:        []string{"dns-image-config-default"},
			Field:           "ClusterConfiguration",
			K8sObjects:      []string{"pods"},
			HardcodedConfig: &kubeadmapi.ClusterConfiguration{
				ImageRepository: kubeadmapiv1.DefaultImageRepository,
				DNS:             kubeadmapi.DNS{},
			},
		},
		{
			FixtureFileName: "test_fixture.json",
			TestInfo:        []string{"dns-image-config-override-repo"},
			Field:           "ClusterConfiguration",
			K8sObjects:      []string{"pods"},
			HardcodedConfig: &kubeadmapi.ClusterConfiguration{
				ImageRepository: "foo.io",
				DNS: kubeadmapi.DNS{
					ImageMeta: kubeadmapi.ImageMeta{
						ImageRepository: "foo.io/coredns",
					},
				},
			},
		},
		{
			FixtureFileName: "test_fixture.json",
			TestInfo:        []string{"dns-image-config-override-tag"},
			Field:           "ClusterConfiguration",
			K8sObjects:      []string{"pods"},
			HardcodedConfig: &kubeadmapi.ClusterConfiguration{
				ImageRepository: "foo.io/coredns",
				DNS: kubeadmapi.DNS{
					ImageMeta: kubeadmapi.ImageMeta{
						ImageTag: constants.CoreDNSVersion,
					},
				},
			},
		},
	}
}
