package componentconfigs

import (
	// "context"
	"fmt"
	"path/filepath"
	"reflect"
	"testing"

	kubeletconfig "k8s.io/kubelet/config/v1beta1"
	"k8s.io/utils/ptr"

	ctest "k8s.io/kubernetes/test/ctest"
	ctestglobals "k8s.io/kubernetes/test/ctest/ctestglobals"
	ctestutils "k8s.io/kubernetes/test/ctest/utils"
	// "github.com/onsi/ginkgo/v2"
)

// Rewritten test with dynamic configuration and added edge cases.
func TestCtestMutatePaths(t *testing.T) {
	const drive = "C:"
	fmt.Println(ctestglobals.StartSeparator)

	// ---- Retrieve base configurations from hard‑coded fixtures ----
	baseInfos := []string{
		"valid: all fields are absolute paths",
		"valid: some fields are not absolute paths",
	}
	baseConfigs := map[string][]kubeletconfig.KubeletConfiguration{}
	for _, info := range baseInfos {
		objs, err := getConfigFromFixtureOverrideMode(info)
		if err != nil {
			t.Fatalf("failed to get config for %q: %v", info, err)
		}
		if objs != nil {
			baseConfigs[info] = objs
		} else {
			fmt.Println(ctestglobals.DebugPrefix(), "Skipping test execution. No new configurations generated for", info)
		}
	}

	// ---- Construct test cases (original + edge) ----
	type testCase struct {
		name     string
		cfg      *kubeletconfig.KubeletConfiguration
		expected *kubeletconfig.KubeletConfiguration
	}

	var testCases []testCase

	// Original cases
	if cfgs, ok := baseConfigs["valid: all fields are absolute paths"]; ok && len(cfgs) > 0 {
		origCfg := cfgs[0]
		expected := kubeletconfig.KubeletConfiguration{
			ResolverConfig: ptr.To(""),
			StaticPodPath:  filepath.Join(drive, "/foo/staticpods"),
			Authentication: kubeletconfig.KubeletAuthentication{
				X509: kubeletconfig.KubeletX509Authentication{
					ClientCAFile: filepath.Join(drive, "/foo/ca.crt"),
				},
			},
		}
		// copy to avoid mutation side‑effects
		c := origCfg
		testCases = append(testCases, testCase{
			name:     "valid: all fields are absolute paths",
			cfg:      &c,
			expected: &expected,
		})
	}
	if cfgs, ok := baseConfigs["valid: some fields are not absolute paths"]; ok && len(cfgs) > 0 {
		origCfg := cfgs[0]
		expected := kubeletconfig.KubeletConfiguration{
			ResolverConfig: ptr.To(""),
			StaticPodPath:  "./foo/staticpods",
			Authentication: kubeletconfig.KubeletAuthentication{
				X509: kubeletconfig.KubeletX509Authentication{
					ClientCAFile: filepath.Join(drive, "/foo/ca.crt"),
				},
			},
		}
		c := origCfg
		testCases = append(testCases, testCase{
			name:     "valid: some fields are not absolute paths",
			cfg:      &c,
			expected: &expected,
		})
	}

	// ---- Edge cases ----
	// Edge 1: nil ResolverConfig
	if cfgs, ok := baseConfigs["valid: all fields are absolute paths"]; ok && len(cfgs) > 0 {
		c := cfgs[0]
		c.ResolverConfig = nil
		expected := kubeletconfig.KubeletConfiguration{
			ResolverConfig: ptr.To(""),
			StaticPodPath:  filepath.Join(drive, "/foo/staticpods"),
			Authentication: kubeletconfig.KubeletAuthentication{
				X509: kubeletconfig.KubeletX509Authentication{
					ClientCAFile: filepath.Join(drive, "/foo/ca.crt"),
				},
			},
		}
		testCases = append(testCases, testCase{
			name:     "edge: nil ResolverConfig",
			cfg:      &c,
			expected: &expected,
		})
	}
	// Edge 2: empty StaticPodPath
	if cfgs, ok := baseConfigs["valid: all fields are absolute paths"]; ok && len(cfgs) > 0 {
		c := cfgs[0]
		c.StaticPodPath = ""
		expected := kubeletconfig.KubeletConfiguration{
			ResolverConfig: ptr.To(""),
			StaticPodPath:  "",
			Authentication: kubeletconfig.KubeletAuthentication{
				X509: kubeletconfig.KubeletX509Authentication{
					ClientCAFile: filepath.Join(drive, "/foo/ca.crt"),
				},
			},
		}
		testCases = append(testCases, testCase{
			name:     "edge: empty StaticPodPath",
			cfg:      &c,
			expected: &expected,
		})
	}
	// Edge 3: already Windows‑style absolute path (should remain unchanged)
	if cfgs, ok := baseConfigs["valid: some fields are not absolute paths"]; ok && len(cfgs) > 0 {
		c := cfgs[0]
		c.StaticPodPath = filepath.Join(drive, "/already/abs")
		c.Authentication.X509.ClientCAFile = filepath.Join(drive, "/already/ca.crt")
		expected := kubeletconfig.KubeletConfiguration{
			ResolverConfig: ptr.To(""),
			StaticPodPath:  filepath.Join(drive, "/already/abs"),
			Authentication: kubeletconfig.KubeletAuthentication{
				X509: kubeletconfig.KubeletX509Authentication{
					ClientCAFile: filepath.Join(drive, "/already/ca.crt"),
				},
			},
		}
		testCases = append(testCases, testCase{
			name:     "edge: already Windows absolute paths",
			cfg:      &c,
			expected: &expected,
		})
	}

	// ---- Execute test cases ----
	for i, tc := range testCases {
		fmt.Printf("Running %d th test case.\n", i)
		fmt.Println(ctestglobals.DebugPrefix(), "Test case:", tc.name)
		t.Run(tc.name, func(t *testing.T) {
			mutatePaths(tc.cfg, drive)
			if !reflect.DeepEqual(tc.cfg, tc.expected) {
				t.Errorf("Mismatch between expected and got:\nExpected:\n%+v\n---\nGot:\n%+v",
					tc.expected, tc.cfg)
			}
		})
	}
	fmt.Println(ctestglobals.EndSeparator)
}

// ---- Hard‑coded fixture information ----
func getHardCodedConfigInfoMutatePaths() ctestglobals.HardcodedConfig {
	return ctestglobals.HardcodedConfig{
		{
			FixtureFileName: "test_fixture.json",
			TestInfo:        []string{"valid: all fields are absolute paths"},
			Field:           "staticPodPath",
			K8sObjects:      []string{"pods"},
			HardcodedConfig: &kubeletconfig.KubeletConfiguration{
				ResolverConfig: ptr.To("/foo/resolver"),
				StaticPodPath:  "/foo/staticpods",
				Authentication: kubeletconfig.KubeletAuthentication{
					X509: kubeletconfig.KubeletX509Authentication{
						ClientCAFile: "/foo/ca.crt",
					},
				},
			},
		},
		{
			FixtureFileName: "test_fixture.json",
			TestInfo:        []string{"valid: some fields are not absolute paths"},
			Field:           "staticPodPath",
			K8sObjects:      []string{"pods"},
			HardcodedConfig: &kubeletconfig.KubeletConfiguration{
				ResolverConfig: ptr.To("/foo/resolver"),
				StaticPodPath:  "./foo/staticpods",
				Authentication: kubeletconfig.KubeletAuthentication{
					X509: kubeletconfig.KubeletX509Authentication{
						ClientCAFile: "/foo/ca.crt",
					},
				},
			},
		},
	}
}

// ---- Helper to generate effective config from fixture (override mode) ----
func getConfigFromFixtureOverrideMode(testinfo string) ([]kubeletconfig.KubeletConfiguration, error) {
	hardcodedConfig := getHardCodedConfigInfoMutatePaths()
	item, found := ctestutils.GetItemByExactTestInfo(hardcodedConfig, testinfo)
	if !found {
		fmt.Println(ctestglobals.DebugPrefix(), "Failed to find config item by TestInfo")
		return nil, fmt.Errorf("hardcoded config not found for %s", testinfo)
	}
	fmt.Println(ctestglobals.DebugPrefix(), "get default configs:", item)
	fmt.Println(ctestglobals.StartOverrideModeSeparator)
	configObjs, configJson, err := ctest.GenerateEffectiveConfigReturnType[kubeletconfig.KubeletConfiguration](item, ctest.OverrideOnly)
	if err != nil {
		fmt.Println(ctestglobals.DebugPrefix(), "Failed to get matched fixtures: %v", err)
		return nil, err
	}
	if configObjs != nil {
		fmt.Println(ctestglobals.DebugPrefix(), "New Json Test Configs:", string(configJson))
		fmt.Println(ctestglobals.DebugPrefix(), "Num of Test Cases:", len(configObjs))
		return configObjs, nil
	}
	return nil, nil
}
