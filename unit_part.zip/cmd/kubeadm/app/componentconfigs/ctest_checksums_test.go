package componentconfigs

import (
	"fmt"
	"testing"

	v1 "k8s.io/api/core/v1"
	metav1 "k8s.io/apimachinery/pkg/apis/meta/v1"
	"k8s.io/kubernetes/cmd/kubeadm/app/constants"

	ctest "k8s.io/kubernetes/test/ctest"
	ctestglobals "k8s.io/kubernetes/test/ctest/ctestglobals"
	ctestutils "k8s.io/kubernetes/test/ctest/utils"
)

// ---------- Hardcoded Config Definitions ----------

// checksumTestConfig bundles a ConfigMap with its expected checksum.
type checksumTestConfig struct {
	ConfigMap v1.ConfigMap
	Checksum  string
}

// signTestConfig bundles a ConfigMap with its expected checksum for signing tests.
type signTestConfig struct {
	ConfigMap v1.ConfigMap
	Checksum  string
}

// verifyTestConfig bundles a ConfigMap with the expected verification result.
type verifyTestConfig struct {
	ConfigMap v1.ConfigMap
	ExpectErr bool
}

// getHardCodedConfigInfoChecksum returns hard‑coded ConfigMap data for checksum tests.
func getHardCodedConfigInfoChecksum() ctestglobals.HardcodedConfig {
	return ctestglobals.HardcodedConfig{
		{
			FixtureFileName: "test_fixture.json",
			TestInfo:        []string{"checksum case 1"},
			Field:           "data",
			K8sObjects:      []string{"configmaps"},
			HardcodedConfig: checksumTestConfig{
				ConfigMap: v1.ConfigMap{
					Data: map[string]string{
						"foo": "bar",
					},
					BinaryData: map[string][]byte{
						"bar": []byte("baz"),
					},
				},
				Checksum: "sha256:c8f8b724728a6d6684106e5e64e94ce811c9965d19dd44dd073cf86cf43bc238",
			},
		},
		{
			FixtureFileName: "test_fixture.json",
			TestInfo:        []string{"checksum case 2"},
			Field:           "data",
			K8sObjects:      []string{"configmaps"},
			HardcodedConfig: checksumTestConfig{
				ConfigMap: v1.ConfigMap{
					Data: map[string]string{
						"foo2": "bar",
					},
					BinaryData: map[string][]byte{
						"bar2": []byte("baz"),
					},
				},
				Checksum: "sha256:c8f8b724728a6d6684106e5e64e94ce811c9965d19dd44dd073cf86cf43bc238",
			},
		},
		{
			FixtureFileName: "test_fixture.json",
			TestInfo:        []string{"checksum case 3"},
			Field:           "data",
			K8sObjects:      []string{"configmaps"},
			HardcodedConfig: checksumTestConfig{
				ConfigMap: v1.ConfigMap{
					ObjectMeta: metav1.ObjectMeta{
						Name:      "le-config",
						Namespace: "le-namespace",
						Labels: map[string]string{
							"label1": "value1",
							"label2": "value2",
						},
						Annotations: map[string]string{
							"annotation1": "value1",
							"annotation2": "value2",
						},
					},
					Data: map[string]string{
						"foo": "bar",
					},
					BinaryData: map[string][]byte{
						"bar": []byte("baz"),
					},
				},
				Checksum: "sha256:c8f8b724728a6d6684106e5e64e94ce811c9965d19dd44dd073cf86cf43bc238",
			},
		},
		{
			FixtureFileName: "test_fixture.json",
			TestInfo:        []string{"checksum case 4"},
			Field:           "data",
			K8sObjects:      []string{"configmaps"},
			HardcodedConfig: checksumTestConfig{
				ConfigMap: v1.ConfigMap{
					Data: map[string]string{
						"foo": "bar",
					},
				},
				Checksum: "sha256:fcde2b2edba56bf408601fb721fe9b5c338d10ee429ea04fae5511b68fbf8fb9",
			},
		},
		{
			FixtureFileName: "test_fixture.json",
			TestInfo:        []string{"checksum case 5"},
			Field:           "binaryData",
			K8sObjects:      []string{"configmaps"},
			HardcodedConfig: checksumTestConfig{
				ConfigMap: v1.ConfigMap{
					BinaryData: map[string][]byte{
						"bar": []byte("baz"),
					},
				},
				Checksum: "sha256:baa5a0964d3320fbc0c6a922140453c8513ea24ab8fd0577034804a967248096",
			},
		},
		// Edge cases
		{
			FixtureFileName: "test_fixture.json",
			TestInfo:        []string{"checksum empty both"},
			Field:           "data",
			K8sObjects:      []string{"configmaps"},
			HardcodedConfig: checksumTestConfig{
				ConfigMap: v1.ConfigMap{},
				Checksum:  "sha256:e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855", // sha256 of empty string
			},
		},
	}
}

// getHardCodedConfigInfoSign returns hard‑coded ConfigMap data for signing tests.
func getHardCodedConfigInfoSign() ctestglobals.HardcodedConfig {
	return ctestglobals.HardcodedConfig{
		{
			FixtureFileName: "test_fixture.json",
			TestInfo:        []string{"sign case 1"},
			Field:           "data",
			K8sObjects:      []string{"configmaps"},
			HardcodedConfig: signTestConfig{
				ConfigMap: v1.ConfigMap{
					Data: map[string]string{
						"foo": "bar",
					},
					BinaryData: map[string][]byte{
						"bar": []byte("baz"),
					},
				},
				Checksum: "sha256:c8f8b724728a6d6684106e5e64e94ce811c9965d19dd44dd073cf86cf43bc238",
			},
		},
		{
			FixtureFileName: "test_fixture.json",
			TestInfo:        []string{"sign empty data"},
			Field:           "data",
			K8sObjects:      []string{"configmaps"},
			HardcodedConfig: signTestConfig{
				ConfigMap: v1.ConfigMap{},
				Checksum:  "sha256:e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855",
			},
		},
	}
}

// getHardCodedConfigInfoVerify returns hard‑coded ConfigMap data for verification tests.
func getHardCodedConfigInfoVerify() ctestglobals.HardcodedConfig {
	return ctestglobals.HardcodedConfig{
		{
			FixtureFileName: "test_fixture.json",
			TestInfo:        []string{"verify correct"},
			Field:           "annotations",
			K8sObjects:      []string{"configmaps"},
			HardcodedConfig: verifyTestConfig{
				ConfigMap: v1.ConfigMap{
					ObjectMeta: metav1.ObjectMeta{
						Name:      "le-config",
						Namespace: "le-namespace",
						Annotations: map[string]string{
							constants.ComponentConfigHashAnnotationKey: "sha256:c8f8b724728a6d6684106e5e64e94ce811c9965d19dd44dd073cf86cf43bc238",
						},
					},
					Data: map[string]string{
						"foo": "bar",
					},
					BinaryData: map[string][]byte{
						"bar": []byte("baz"),
					},
				},
				ExpectErr: false,
			},
		},
		{
			FixtureFileName: "test_fixture.json",
			TestInfo:        []string{"verify wrong"},
			Field:           "annotations",
			K8sObjects:      []string{"configmaps"},
			HardcodedConfig: verifyTestConfig{
				ConfigMap: v1.ConfigMap{
					ObjectMeta: metav1.ObjectMeta{
						Name:      "le-config",
						Namespace: "le-namespace",
						Annotations: map[string]string{
							constants.ComponentConfigHashAnnotationKey: "sha256:invalidchecksum",
						},
					},
					Data: map[string]string{
						"foo": "bar",
					},
					BinaryData: map[string][]byte{
						"bar": []byte("baz"),
					},
				},
				ExpectErr: true,
			},
		},
		{
			FixtureFileName: "test_fixture.json",
			TestInfo:        []string{"verify missing"},
			Field:           "annotations",
			K8sObjects:      []string{"configmaps"},
			HardcodedConfig: verifyTestConfig{
				ConfigMap: v1.ConfigMap{
					ObjectMeta: metav1.ObjectMeta{
						Name:      "le-config",
						Namespace: "le-namespace",
						Annotations: map[string]string{
							"some-other": "value",
						},
					},
					Data: map[string]string{
						"foo": "bar",
					},
					BinaryData: map[string][]byte{
						"bar": []byte("baz"),
					},
				},
				ExpectErr: true,
			},
		},
	}
}

// ---------- Rewritten Tests ----------

func TestCtestChecksumForConfigMap(t *testing.T) {
	fmt.Println(ctestglobals.StartExtendModeSeparator)
	hc := getHardCodedConfigInfoChecksum()
	item, found := ctestutils.GetItemByExactTestInfo(hc, "checksum case 1")
	if !found {
		t.Fatalf("hardcoded config not found")
	}
	fmt.Println(ctestglobals.DebugPrefix(), "matched config:", item)
	configObjs, configJson, err := ctest.GenerateEffectiveConfigReturnType[checksumTestConfig](item, ctest.ExtendOnly)
	if err != nil {
		t.Fatalf("generate config error: %v", err)
	}
	if configObjs == nil {
		fmt.Println(ctestglobals.DebugPrefix(), "Skipping test execution. No new configurations generated.")
		return
	}
	fmt.Println(ctestglobals.DebugPrefix(), "New Json Test Configs:", string(configJson))
	fmt.Println(ctestglobals.DebugPrefix(), "Number of test cases:", len(configObjs))
	for i, cfg := range configObjs {
		fmt.Printf("Running %d th test case.\n", i)
		fmt.Println(cfg)
		got := ChecksumForConfigMap(&cfg.ConfigMap)
		if got != cfg.Checksum {
			t.Errorf("checksum mismatch - got %q, expected %q", got, cfg.Checksum)
		}
	}
	fmt.Println(ctestglobals.EndSeparator)
}

func TestCtestSignConfigMap(t *testing.T) {
	fmt.Println(ctestglobals.StartExtendModeSeparator)
	hc := getHardCodedConfigInfoSign()
	item, found := ctestutils.GetItemByExactTestInfo(hc, "sign case 1")
	if !found {
		t.Fatalf("hardcoded config not found")
	}
	fmt.Println(ctestglobals.DebugPrefix(), "matched config:", item)
	configObjs, configJson, err := ctest.GenerateEffectiveConfigReturnType[signTestConfig](item, ctest.ExtendOnly)
	if err != nil {
		t.Fatalf("generate config error: %v", err)
	}
	if configObjs == nil {
		fmt.Println(ctestglobals.DebugPrefix(), "Skipping test execution. No new configurations generated.")
		return
	}
	fmt.Println(ctestglobals.DebugPrefix(), "New Json Test Configs:", string(configJson))
	fmt.Println(ctestglobals.DebugPrefix(), "Number of test cases:", len(configObjs))
	for i, cfg := range configObjs {
		fmt.Printf("Running %d th test case.\n", i)
		target := cfg.ConfigMap.DeepCopy()
		SignConfigMap(target)

		sig, ok := target.Annotations[constants.ComponentConfigHashAnnotationKey]
		if !ok {
			t.Errorf("no %s annotation found in the config map", constants.ComponentConfigHashAnnotationKey)
			continue
		}
		if sig != cfg.Checksum {
			t.Errorf("unexpected checksum - got %q, expected %q", sig, cfg.Checksum)
		}
		expectedAnnotationCount := 1 + len(cfg.ConfigMap.Annotations)
		if len(target.Annotations) != expectedAnnotationCount {
			t.Errorf("unexpected number of annotations - got %d, expected %d", len(target.Annotations), expectedAnnotationCount)
		}
	}
	fmt.Println(ctestglobals.EndSeparator)
}

func TestCtestVerifyConfigMapSignature(t *testing.T) {
	fmt.Println(ctestglobals.StartExtendModeSeparator)
	hc := getHardCodedConfigInfoVerify()
	// Iterate over all defined verify cases
	for _, testInfo := range []string{"verify correct", "verify wrong", "verify missing"} {
		item, found := ctestutils.GetItemByExactTestInfo(hc, testInfo)
		if !found {
			t.Fatalf("hardcoded config not found for %s", testInfo)
		}
		fmt.Println(ctestglobals.DebugPrefix(), "matched config:", item)
		configObjs, configJson, err := ctest.GenerateEffectiveConfigReturnType[verifyTestConfig](item, ctest.ExtendOnly)
		if err != nil {
			t.Fatalf("generate config error: %v", err)
		}
		if configObjs == nil {
			fmt.Println(ctestglobals.DebugPrefix(), "Skipping test execution. No new configurations generated.")
			continue
		}
		fmt.Println(ctestglobals.DebugPrefix(), "New Json Test Configs:", string(configJson))
		fmt.Println(ctestglobals.DebugPrefix(), "Number of test cases:", len(configObjs))
		for i, cfg := range configObjs {
			fmt.Printf("Running %d th test case.\n", i)
			result := VerifyConfigMapSignature(&cfg.ConfigMap)
			if result != !cfg.ExpectErr {
				t.Errorf("unexpected result for %s - got %t, expected %t", testInfo, result, !cfg.ExpectErr)
			}
		}
	}
	fmt.Println(ctestglobals.EndSeparator)
}