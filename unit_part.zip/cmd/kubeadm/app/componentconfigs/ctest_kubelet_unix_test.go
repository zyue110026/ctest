package componentconfigs

import (
	"errors"
	"k8s.io/klog/v2"
	"reflect"
	"testing"

	kubeletconfig "k8s.io/kubelet/config/v1beta1"
	"k8s.io/utils/ptr"
)

func TestCtestMutateResolverConfig(t *testing.T) {
	var fooResolverConfig = "/foo/resolver"

	tests := []struct {
		name                string
		cfg                 *kubeletconfig.KubeletConfiguration
		isServiceActiveFunc func(string) (bool, error)
		expectErr           bool
		expected            *kubeletconfig.KubeletConfiguration
	}{
		{
			name: "the resolver config should not be mutated when it was set already even if systemd-resolved is active",
			cfg: &kubeletconfig.KubeletConfiguration{
				ResolverConfig: ptr.To(fooResolverConfig),
			},
			isServiceActiveFunc: func(string) (bool, error) { return true, nil },
			expectErr:           false,
			expected: &kubeletconfig.KubeletConfiguration{
				ResolverConfig: ptr.To(fooResolverConfig),
			},
		},
		{
			name: "the resolver config should be set when systemd-resolved is active",
			cfg: &kubeletconfig.KubeletConfiguration{
				ResolverConfig: nil,
			},
			isServiceActiveFunc: func(string) (bool, error) { return true, nil },
			expectErr:           false,
			expected: &kubeletconfig.KubeletConfiguration{
				ResolverConfig: ptr.To(kubeletSystemdResolverConfig),
			},
		},
		{
			name: "the resolver config should not be set when systemd-resolved is not active",
			cfg: &kubeletconfig.KubeletConfiguration{
				ResolverConfig: nil,
			},
			isServiceActiveFunc: func(string) (bool, error) { return false, nil },
			expectErr:           false,
			expected: &kubeletconfig.KubeletConfiguration{
				ResolverConfig: nil,
			},
		},
		{
			name: "edge: empty string resolver config should remain unchanged when service is active",
			cfg: &kubeletconfig.KubeletConfiguration{
				ResolverConfig: ptr.To(""),
			},
			isServiceActiveFunc: func(string) (bool, error) { return true, nil },
			expectErr:           false,
			expected: &kubeletconfig.KubeletConfiguration{
				ResolverConfig: ptr.To(""),
			},
		},
		{
			name: "edge: service check returns error, mutation should propagate error",
			cfg: &kubeletconfig.KubeletConfiguration{
				ResolverConfig: nil,
			},
			isServiceActiveFunc: func(string) (bool, error) { return false, errors.New("service check failed") },
			expectErr:           true,
			expected:            nil, // expected config is irrelevant when error is expected
		},
	}

	for _, test := range tests {
		t.Run(test.name, func(t *testing.T) {
			err := mutateResolverConfigCtest(test.cfg, test.isServiceActiveFunc)
			if test.expectErr {
				if err == nil {
					t.Fatalf("expected error but got nil")
				}
				// when error is expected, no further deep‑equal check
				return
			}
			if err != nil {
				t.Fatalf("unexpected error from mutateResolverConfig: %v", err)
			}
			if !reflect.DeepEqual(test.cfg, test.expected) {
				t.Errorf("Mismatch between expected and got:\nExpected:\n%+v\n---\nGot:\n%+v",
					test.expected, test.cfg)
			}
		})
	}
}

// mutateResolverConfig mutates the ResolverConfig in the kubeletConfig dynamically.
func mutateResolverConfigCtest(cfg *kubeletconfig.KubeletConfiguration, isServiceActiveFunc func(string) (bool, error)) error {
	ok, err := isServiceActiveFunc("systemd-resolved")
	if err != nil {
		klog.Warningf("cannot determine if systemd-resolved is active: %v", err)
	}
	if ok {
		if cfg.ResolverConfig == nil {
			cfg.ResolverConfig = ptr.To(kubeletSystemdResolverConfig)
		} else if *cfg.ResolverConfig != kubeletSystemdResolverConfig {
			warnDefaultComponentConfigValue("KubeletConfiguration", "resolvConf",
				kubeletSystemdResolverConfig, *cfg.ResolverConfig)
		}

	}
	return nil
}
