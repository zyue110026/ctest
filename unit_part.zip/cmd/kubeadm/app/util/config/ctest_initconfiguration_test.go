package config

import (
	"fmt"
	"testing"

	"github.com/google/go-cmp/cmp"
	"github.com/google/go-cmp/cmp/cmpopts"
	// "k8s.io/apimachinery/pkg/util/uuid"
	"k8s.io/kubernetes/test/ctest"
	ctestglobals "k8s.io/kubernetes/test/ctest/ctestglobals"
	// ctestutils "k8s.io/kubernetes/test/ctest/utils"

	"k8s.io/api/core/v1"
	metav1 "k8s.io/apimachinery/pkg/apis/meta/v1"
	"k8s.io/utils/ptr"

	kubeadmapi "k8s.io/kubernetes/cmd/kubeadm/app/apis/kubeadm"
	kubeadmapiv1 "k8s.io/kubernetes/cmd/kubeadm/app/apis/kubeadm/v1beta4"
	"k8s.io/kubernetes/cmd/kubeadm/app/constants"
)

func TestCtestDefaultTaintsMarshaling(t *testing.T) {
	fmt.Println(ctestglobals.StartExtendModeSeparator)

	hardcoded := getHardCodedConfigInfoDefaultTaints()
	// iterate over each hardcoded entry
	for i, item := range hardcoded {
		fmt.Printf("Running %d th test case.\n", i)
		fmt.Println(item)

		configObjs, configJson, err := ctest.GenerateEffectiveConfigReturnType[kubeadmapiv1.InitConfiguration](item, ctest.ExtendOnly)
		if err != nil {
			fmt.Println(ctestglobals.DebugPrefix(), "Failed to generate config:", err)
			continue
		}
		if configObjs == nil {
			fmt.Println(ctestglobals.DebugPrefix(), "Skipping test execution. No new configurations generated.")
			continue
		}
		fmt.Println(ctestglobals.DebugPrefix(), "New Json Test Configs:", string(configJson))
		fmt.Println(ctestglobals.DebugPrefix(), "Num of Test Cases:", len(configObjs))

		for _, cfg := range configObjs {
			expected := 1 // default expected when taints nil
			if cfg.NodeRegistration.Taints != nil {
				expected = len(cfg.NodeRegistration.Taints)
			}
			for _, format := range formats {
				t.Run(fmt.Sprintf("case_%d_%s", i, format.name), func(t *testing.T) {
					b, err := format.marshal(cfg)
					if err != nil {
						t.Fatalf("unexpected error while marshalling to %s: %v", format.name, err)
					}
					decoded, err := BytesToInitConfiguration(b, true)
					if err != nil {
						t.Fatalf("unexpected error of BytesToInitConfiguration: %v\nconfig: %s", err, string(b))
					}
					if expected != len(decoded.NodeRegistration.Taints) {
						t.Fatalf("unexpected taints count\nexpected: %d\ngot: %d\ntaints: %v", expected, len(decoded.NodeRegistration.Taints), decoded.NodeRegistration.Taints)
					}
				})
			}
		}
	}
	fmt.Println(ctestglobals.EndSeparator)
}

// Edge case: empty format list (no formats) – handled by existing loop; just ensures test runs even if formats is empty.

func TestCtestBytesToInitConfiguration(t *testing.T) {
	fmt.Println(ctestglobals.StartExtendModeSeparator)

	hardcoded := getHardCodedConfigInfoBytesToInit()
	for i, item := range hardcoded {
		fmt.Printf("Running %d th test case.\n", i)
		fmt.Println(item)

		configObjs, configJson, err := ctest.GenerateEffectiveConfigReturnType[kubeadmapiv1.InitConfiguration](item, ctest.ExtendOnly)
		if err != nil {
			fmt.Println(ctestglobals.DebugPrefix(), "Failed to generate config:", err)
			continue
		}
		if configObjs == nil {
			fmt.Println(ctestglobals.DebugPrefix(), "Skipping test execution. No new configurations generated.")
			continue
		}
		fmt.Println(ctestglobals.DebugPrefix(), "New Json Test Configs:", string(configJson))
		fmt.Println(ctestglobals.DebugPrefix(), "Num of Test Cases:", len(configObjs))

		for _, cfg := range configObjs {
			// Determine expected outcome based on the type of cfg
			var expectedCfg kubeadmapi.InitConfiguration
			expectedError := false
			switch cfg.Kind {
			case constants.InitConfigurationKind:
				// Build expected config similar to original test expectations
				expectedCfg = kubeadmapi.InitConfiguration{
					LocalAPIEndpoint: kubeadmapi.APIEndpoint{
						AdvertiseAddress: "",
						BindPort:         0,
					},
					NodeRegistration: kubeadmapi.NodeRegistrationOptions{
						CRISocket: "unix:///var/run/containerd/containerd.sock",
						Name:      cfg.NodeRegistration.Name,
						Taints: []v1.Taint{
							{
								Key:    "node-role.kubernetes.io/control-plane",
								Effect: "NoSchedule",
							},
						},
						ImagePullPolicy: "IfNotPresent",
						ImagePullSerial: ptr.To(true),
					},
					ClusterConfiguration: kubeadmapi.ClusterConfiguration{
						Etcd: kubeadmapi.Etcd{
							Local: &kubeadmapi.LocalEtcd{
								DataDir: "/var/lib/etcd",
							},
						},
						KubernetesVersion:   "stable-1",
						ImageRepository:     kubeadmapiv1.DefaultImageRepository,
						ClusterName:         kubeadmapiv1.DefaultClusterName,
						EncryptionAlgorithm: kubeadmapi.EncryptionAlgorithmType(kubeadmapiv1.DefaultEncryptionAlgorithm),
						Networking: kubeadmapi.Networking{
							ServiceSubnet: "10.96.0.0/12",
							DNSDomain:     "cluster.local",
						},
						CertificatesDir: "/etc/kubernetes/pki",
					},
				}
				// Adjust expected config for partial custom case
				if cfg.NodeRegistration.Name != "" {
					expectedCfg.NodeRegistration.Name = cfg.NodeRegistration.Name
				}
			default:
				// Any non-InitConfiguration kind is expected to error
				expectedError = true
			}

			for _, format := range formats {
				t.Run(fmt.Sprintf("case_%d_%s", i, format.name), func(t *testing.T) {
					b, err := format.marshal(cfg)
					if err != nil {
						t.Fatalf("unexpected error marshaling %s: %v", format.name, err)
					}
					gotCfg, err := BytesToInitConfiguration(b, true)
					if (err != nil) != expectedError {
						t.Fatalf("expected error: %v, got error: %v\nError: %v", expectedError, err != nil, err)
					}
					if expectedError {
						return
					}
					// Ignore dynamic fields that may be set during defaulting
					diffOpts := []cmp.Option{
						cmpopts.IgnoreFields(kubeadmapi.NodeRegistrationOptions{}, "Name"),
						cmpopts.IgnoreFields(kubeadmapi.InitConfiguration{}, "Timeouts", "BootstrapTokens", "LocalAPIEndpoint"),
						cmpopts.IgnoreFields(kubeadmapi.APIServer{}, "TimeoutForControlPlane"),
						cmpopts.IgnoreFields(kubeadmapi.ClusterConfiguration{}, "ComponentConfigs", "KubernetesVersion",
							"CertificateValidityPeriod", "CACertificateValidityPeriod"),
					}
					if diff := cmp.Diff(*gotCfg, expectedCfg, diffOpts...); diff != "" {
						t.Fatalf("unexpected configuration difference (-want +got):\n%s", diff)
					}
				})
			}
		}
	}
	fmt.Println(ctestglobals.EndSeparator)
}

// Hardcoded configurations for TestCtestDefaultTaintsMarshaling
func getHardCodedConfigInfoDefaultTaints() ctestglobals.HardcodedConfig {
	return ctestglobals.HardcodedConfig{
		{
			FixtureFileName: "test_fixture.json",
			TestInfo:        []string{"uninitialized nodeRegistration"},
			Field:           "nodeRegistration.taints",
			K8sObjects:      []string{},
			HardcodedConfig: kubeadmapiv1.InitConfiguration{
				NodeRegistration: kubeadmapiv1.NodeRegistrationOptions{},
			},
		},
		{
			FixtureFileName: "test_fixture.json",
			TestInfo:        []string{"empty taints slice"},
			Field:           "nodeRegistration.taints",
			K8sObjects:      []string{},
			HardcodedConfig: kubeadmapiv1.InitConfiguration{
				NodeRegistration: kubeadmapiv1.NodeRegistrationOptions{
					Taints: []v1.Taint{},
				},
			},
		},
		{
			FixtureFileName: "test_fixture.json",
			TestInfo:        []string{"custom taints"},
			Field:           "nodeRegistration.taints",
			K8sObjects:      []string{},
			HardcodedConfig: kubeadmapiv1.InitConfiguration{
				NodeRegistration: kubeadmapiv1.NodeRegistrationOptions{
					Taints: []v1.Taint{
						{Key: "taint1"},
						{Key: "taint2"},
					},
				},
			},
		},
	}
}

// Hardcoded configurations for TestCtestBytesToInitConfiguration
func getHardCodedConfigInfoBytesToInit() ctestglobals.HardcodedConfig {
	return ctestglobals.HardcodedConfig{
		{
			FixtureFileName: "test_fixture.json",
			TestInfo:        []string{"default config is set correctly"},
			Field:           "initConfiguration",
			K8sObjects:      []string{},
			HardcodedConfig: kubeadmapiv1.InitConfiguration{
				TypeMeta: metav1.TypeMeta{
					APIVersion: kubeadmapiv1.SchemeGroupVersion.String(),
					Kind:       constants.InitConfigurationKind,
				},
			},
		},
		{
			FixtureFileName: "test_fixture.json",
			TestInfo:        []string{"partial config with custom values"},
			Field:           "initConfiguration",
			K8sObjects:      []string{},
			HardcodedConfig: kubeadmapiv1.InitConfiguration{
				TypeMeta: metav1.TypeMeta{
					APIVersion: kubeadmapiv1.SchemeGroupVersion.String(),
					Kind:       constants.InitConfigurationKind,
				},
				NodeRegistration: kubeadmapiv1.NodeRegistrationOptions{
					Name:      "test-node",
					CRISocket: "unix:///var/run/containerd/containerd.sock",
				},
			},
		},
		{
			FixtureFileName: "test_fixture.json",
			TestInfo:        []string{"invalid configuration type"},
			Field:           "upgradeConfiguration",
			K8sObjects:      []string{},
			HardcodedConfig: kubeadmapiv1.UpgradeConfiguration{
				TypeMeta: metav1.TypeMeta{
					APIVersion: kubeadmapiv1.SchemeGroupVersion.String(),
					Kind:       constants.UpgradeConfigurationKind,
				},
			},
		},
	}
}
