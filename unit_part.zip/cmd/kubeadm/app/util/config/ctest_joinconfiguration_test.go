package config

import (
	"fmt"
	"os"
	"path/filepath"
	"testing"

	"github.com/google/go-cmp/cmp"
	"github.com/google/go-cmp/cmp/cmpopts"
	"github.com/lithammer/dedent"
	"k8s.io/utils/ptr"

	ctest "k8s.io/kubernetes/test/ctest"
	ctestglobals "k8s.io/kubernetes/test/ctest/ctestglobals"
	ctestutils "k8s.io/kubernetes/test/ctest/utils"

	metav1 "k8s.io/apimachinery/pkg/apis/meta/v1"

	kubeadmapi "k8s.io/kubernetes/cmd/kubeadm/app/apis/kubeadm"
	kubeadmapiv1 "k8s.io/kubernetes/cmd/kubeadm/app/apis/kubeadm/v1beta4"
	"k8s.io/kubernetes/cmd/kubeadm/app/constants"
)

// -----------------------------------------------------------------------------
// TestBytesToJoinConfiguration with dynamic configuration and edge cases
// -----------------------------------------------------------------------------
func TestCtestBytesToJoinConfiguration(t *testing.T) {
	fmt.Println(ctestglobals.DebugPrefix(), "Start TestCtestBytesToJoinConfiguration")
	options := LoadOrDefaultConfigurationOptions{}

	// Define test scenarios (hard‑coded identifiers only)
	testInfos := []struct {
		name    string
		testKey string // matches TestInfo in fixture
		want    *kubeadmapi.JoinConfiguration
	}{
		{
			name:    "Normal configuration",
			testKey: "normal join config",
			want: &kubeadmapi.JoinConfiguration{
				NodeRegistration: kubeadmapi.NodeRegistrationOptions{
					Name:            "node-1",
					CRISocket:       "unix:///var/run/crio/crio.sock",
					ImagePullPolicy: "IfNotPresent",
					ImagePullSerial: ptr.To(true),
				},
				CACertPath: "/some/cert.crt",
				Discovery: kubeadmapi.Discovery{
					BootstrapToken: &kubeadmapi.BootstrapTokenDiscovery{
						Token:             "abcdef.1234567890123456",
						APIServerEndpoint: "1.2.3.4:6443",
						CACertHashes:      []string{"aaaa"},
					},
					TLSBootstrapToken: "abcdef.1234567890123456",
				},
				ControlPlane: nil,
			},
		},
		{
			name:    "Only contains Discovery configuration",
			testKey: "discovery only join config",
			want: &kubeadmapi.JoinConfiguration{
				NodeRegistration: kubeadmapi.NodeRegistrationOptions{
					CRISocket:       "unix:///var/run/containerd/containerd.sock",
					ImagePullPolicy: "IfNotPresent",
					ImagePullSerial: ptr.To(true),
				},
				CACertPath: "/etc/kubernetes/pki/ca.crt",
				Discovery: kubeadmapi.Discovery{
					BootstrapToken: &kubeadmapi.BootstrapTokenDiscovery{
						Token:             "abcdef.1234567890123456",
						APIServerEndpoint: "1.2.3.4:6443",
						CACertHashes:      []string{"aaaa"},
					},
					TLSBootstrapToken: "abcdef.1234567890123456",
				},
				ControlPlane: nil,
			},
		},
		// Edge case: empty NodeRegistration (should get defaults)
		{
			name:    "Edge – empty NodeRegistration",
			testKey: "edge empty nodereg",
			want: &kubeadmapi.JoinConfiguration{
				NodeRegistration: kubeadmapi.NodeRegistrationOptions{
					CRISocket:       "unix:///var/run/containerd/containerd.sock",
					ImagePullPolicy: "IfNotPresent",
					ImagePullSerial: ptr.To(true),
				},
				CACertPath: "/etc/kubernetes/pki/ca.crt",
				Discovery: kubeadmapi.Discovery{
					BootstrapToken: &kubeadmapi.BootstrapTokenDiscovery{
						Token:             "abcdef.1234567890123456",
						APIServerEndpoint: "1.2.3.4:6443",
						CACertHashes:      []string{"aaaa"},
					},
					TLSBootstrapToken: "abcdef.1234567890123456",
				},
				ControlPlane: nil,
			},
		},
		// Edge case: nil Discovery (should result in defaults + empty Discovery)
		{
			name:    "Edge – nil Discovery",
			testKey: "edge nil discovery",
			want: &kubeadmapi.JoinConfiguration{
				NodeRegistration: kubeadmapi.NodeRegistrationOptions{
					CRISocket:       "unix:///var/run/containerd/containerd.sock",
					ImagePullPolicy: "IfNotPresent",
					ImagePullSerial: ptr.To(true),
				},
				CACertPath:   "/etc/kubernetes/pki/ca.crt",
				Discovery:    kubeadmapi.Discovery{},
				ControlPlane: nil,
			},
		},
	}

	hardcodedConfig := getHardCodedConfigInfoJoinConfiguration()

	for i, tt := range testInfos {
		fmt.Printf("Running %d th test case: %s\n", i, tt.name)

		// Find fixture entry
		item, found := ctestutils.GetItemByExactTestInfo(hardcodedConfig, tt.testKey)
		if !found {
			fmt.Println(ctestglobals.DebugPrefix(), "Missing fixture for", tt.testKey)
			continue
		}
		fmt.Println(ctestglobals.DebugPrefix(), "matched fixture:", item)

		// Generate effective config (ExtendOnly – we may add extra fields later)
		configObjs, configJson, err := ctest.GenerateEffectiveConfigReturnType[*kubeadmapiv1.JoinConfiguration](item, ctest.ExtendOnly)
		if err != nil {
			fmt.Println(ctestglobals.DebugPrefix(), "GenerateEffectiveConfig error:", err)
			t.Fatalf("GenerateEffectiveConfig error: %v", err)
		}
		if configObjs == nil {
			fmt.Println(ctestglobals.DebugPrefix(), "Skipping test execution. No new configurations generated.")
			continue
		}
		fmt.Println(ctestglobals.DebugPrefix(), "New Json Test Configs:", string(configJson))
		fmt.Println(ctestglobals.DebugPrefix(), "Num of Test Cases:", len(configObjs))

		for j, cfg := range configObjs {
			fmt.Printf("Running %d th sub‑test config %d\n", i, j)
			fmt.Println(ctestglobals.DebugPrefix(), cfg)

			// Run through all supported formats
			for _, format := range formats {
				bytes, err := format.marshal(cfg)
				if err != nil {
					t.Fatalf("Could not marshal test config: %v", err)
				}
				got, _ := BytesToJoinConfiguration(bytes, options)

				if diff := cmp.Diff(got, tt.want,
					cmpopts.IgnoreFields(kubeadmapi.JoinConfiguration{}, "Timeouts"),
					cmpopts.IgnoreFields(kubeadmapi.Discovery{}, "Timeout"),
					cmpopts.IgnoreFields(kubeadmapi.NodeRegistrationOptions{}, "Name")); diff != "" {
					t.Errorf("Test %q format %q diff (-want,+got):\n%s", tt.name, format.name, diff)
				}
			}
		}
	}
	fmt.Println(ctestglobals.EndSeparator)
}

// -----------------------------------------------------------------------------
// TestLoadJoinConfigurationFromFile with dynamic configuration and edge cases
// -----------------------------------------------------------------------------
func TestCtestLoadJoinConfigurationFromFile(t *testing.T) {
	fmt.Println(ctestglobals.DebugPrefix(), "Start TestCtestLoadJoinConfigurationFromFile")
	// Temporary directory
	tmpdir, err := os.MkdirTemp("", "")
	if err != nil {
		t.Fatalf("Couldn't create tmpdir: %v", err)
	}
	defer func() {
		if err := os.RemoveAll(tmpdir); err != nil {
			t.Fatalf("Couldn't remove tmpdir: %v", err)
		}
	}()

	filename := "kubeadmConfig"
	filePath := filepath.Join(tmpdir, filename)
	options := LoadOrDefaultConfigurationOptions{}

	// Test descriptors – only identifiers are hard‑coded
	testDescriptors := []struct {
		name        string
		cfgPathKey  string // matches TestInfo for file path fixture
		fileKey     string // matches TestInfo for file contents fixture
		wantErr     bool
		prepareFile bool
	}{
		{
			name:        "Config file does not exist",
			cfgPathKey:  "nonexistent path",
			wantErr:     true,
			prepareFile: false,
		},
		{
			name:        "Valid kubeadm config",
			cfgPathKey:  "valid path",
			fileKey:     "valid yaml",
			wantErr:     false,
			prepareFile: true,
		},
		{
			name:        "Edge – empty file",
			cfgPathKey:  "empty file path",
			fileKey:     "empty yaml",
			wantErr:     true,
			prepareFile: true,
		},
		{
			name:        "Edge – malformed yaml",
			cfgPathKey:  "malformed file path",
			fileKey:     "malformed yaml",
			wantErr:     true,
			prepareFile: true,
		},
	}

	// Fixtures for file paths and contents
	pathFixture := getHardCodedConfigInfoFilePath()
	contentFixture := getHardCodedConfigInfoFileContent()

	for i, tt := range testDescriptors {
		fmt.Printf("Running %d th file test case: %s\n", i, tt.name)

		// Resolve path
		var cfgPath string
		if tt.prepareFile {
			// Get file content from fixture
			itemC, foundC := ctestutils.GetItemByExactTestInfo(contentFixture, tt.fileKey)
			if !foundC {
				fmt.Println(ctestglobals.DebugPrefix(), "Missing content fixture for", tt.fileKey)
				continue
			}
			contentObjs, _, err := ctest.GenerateEffectiveConfigReturnType[string](itemC, ctest.OverrideOnly)
			if err != nil {
				t.Fatalf("GenerateEffectiveConfig for content error: %v", err)
			}
			if len(contentObjs) == 0 {
				fmt.Println(ctestglobals.DebugPrefix(), "No content generated")
				continue
			}
			// Write content to filePath
			if err := os.WriteFile(filePath, []byte(contentObjs[0]), 0644); err != nil {
				t.Fatalf("Couldn't write content to file: %v", err)
			}
			defer os.Remove(filePath)

			// Resolve path using path fixture (just reuse the real path)
			itemP, foundP := ctestutils.GetItemByExactTestInfo(pathFixture, tt.cfgPathKey)
			if !foundP {
				fmt.Println(ctestglobals.DebugPrefix(), "Missing path fixture for", tt.cfgPathKey)
				cfgPath = filePath // fallback
			} else {
				fmt.Println(ctestglobals.DebugPrefix(), "matched path fixture:", itemP)
				paths, _, err := ctest.GenerateEffectiveConfigReturnType[string](itemP, ctest.OverrideOnly)
				if err != nil {
					t.Fatalf("GenerateEffectiveConfig for path error: %v", err)
				}
				if len(paths) > 0 {
					cfgPath = paths[0]
				} else {
					cfgPath = filePath
				}
			}
		} else {
			// Non‑existent path case
			cfgPath = filepath.Join(tmpdir, "nonexistent")
		}

		_, err = LoadJoinConfigurationFromFile(cfgPath, options)
		if (err != nil) != tt.wantErr {
			t.Errorf("LoadJoinConfigurationFromFile() error = %v, wantErr %v", err, tt.wantErr)
		}
	}
	fmt.Println(ctestglobals.EndSeparator)
}

// -----------------------------------------------------------------------------
// Fixture helpers
// -----------------------------------------------------------------------------
func getHardCodedConfigInfoJoinConfiguration() ctestglobals.HardcodedConfig {
	return ctestglobals.HardcodedConfig{
		{
			FixtureFileName: "test_fixture.json",
			TestInfo:        []string{"normal join config"},
			Field:           "joinConfiguration",
			K8sObjects:      []string{"pods"},
			HardcodedConfig: &kubeadmapiv1.JoinConfiguration{
				TypeMeta: metav1.TypeMeta{
					APIVersion: kubeadmapiv1.SchemeGroupVersion.String(),
					Kind:       constants.JoinConfigurationKind,
				},
				NodeRegistration: kubeadmapiv1.NodeRegistrationOptions{
					Name:      "node-1",
					CRISocket: "unix:///var/run/crio/crio.sock",
				},
				CACertPath: "/some/cert.crt",
				Discovery: kubeadmapiv1.Discovery{
					BootstrapToken: &kubeadmapiv1.BootstrapTokenDiscovery{
						Token:             "abcdef.1234567890123456",
						APIServerEndpoint: "1.2.3.4:6443",
						CACertHashes:      []string{"aaaa"},
					},
					TLSBootstrapToken: "abcdef.1234567890123456",
				},
			},
		},
		{
			FixtureFileName: "test_fixture.json",
			TestInfo:        []string{"discovery only join config"},
			Field:           "joinConfiguration",
			K8sObjects:      []string{"pods"},
			HardcodedConfig: &kubeadmapiv1.JoinConfiguration{
				TypeMeta: metav1.TypeMeta{
					APIVersion: kubeadmapiv1.SchemeGroupVersion.String(),
					Kind:       constants.JoinConfigurationKind,
				},
				Discovery: kubeadmapiv1.Discovery{
					BootstrapToken: &kubeadmapiv1.BootstrapTokenDiscovery{
						Token:             "abcdef.1234567890123456",
						APIServerEndpoint: "1.2.3.4:6443",
						CACertHashes:      []string{"aaaa"},
					},
					TLSBootstrapToken: "abcdef.1234567890123456",
				},
			},
		},
		{
			FixtureFileName: "test_fixture.json",
			TestInfo:        []string{"edge empty nodereg"},
			Field:           "joinConfiguration",
			K8sObjects:      []string{"pods"},
			HardcodedConfig: &kubeadmapiv1.JoinConfiguration{
				TypeMeta: metav1.TypeMeta{
					APIVersion: kubeadmapiv1.SchemeGroupVersion.String(),
					Kind:       constants.JoinConfigurationKind,
				},
				Discovery: kubeadmapiv1.Discovery{
					BootstrapToken: &kubeadmapiv1.BootstrapTokenDiscovery{
						Token:             "abcdef.1234567890123456",
						APIServerEndpoint: "1.2.3.4:6443",
						CACertHashes:      []string{"aaaa"},
					},
					TLSBootstrapToken: "abcdef.1234567890123456",
				},
			},
		},
		{
			FixtureFileName: "test_fixture.json",
			TestInfo:        []string{"edge nil discovery"},
			Field:           "joinConfiguration",
			K8sObjects:      []string{"pods"},
			HardcodedConfig: &kubeadmapiv1.JoinConfiguration{
				TypeMeta: metav1.TypeMeta{
					APIVersion: kubeadmapiv1.SchemeGroupVersion.String(),
					Kind:       constants.JoinConfigurationKind,
				},
				NodeRegistration: kubeadmapiv1.NodeRegistrationOptions{
					Name:      "node-1",
					CRISocket: "unix:///var/run/crio/crio.sock",
				},
				CACertPath: "/some/cert.crt",
				// Discovery left nil intentionally
			},
		},
	}
}

func getHardCodedConfigInfoFilePath() ctestglobals.HardcodedConfig {
	return ctestglobals.HardcodedConfig{
		{
			FixtureFileName: "test_fixture.json",
			TestInfo:        []string{"valid path"},
			Field:           "filePath",
			K8sObjects:      []string{"pods"},
			HardcodedConfig: "/tmp/valid/kubeadmConfig",
		},
		{
			FixtureFileName: "test_fixture.json",
			TestInfo:        []string{"nonexistent path"},
			Field:           "filePath",
			K8sObjects:      []string{"pods"},
			HardcodedConfig: "/tmp/nonexistent",
		},
		{
			FixtureFileName: "test_fixture.json",
			TestInfo:        []string{"empty file path"},
			Field:           "filePath",
			K8sObjects:      []string{"pods"},
			HardcodedConfig: "/tmp/empty",
		},
		{
			FixtureFileName: "test_fixture.json",
			TestInfo:        []string{"malformed file path"},
			Field:           "filePath",
			K8sObjects:      []string{"pods"},
			HardcodedConfig: "/tmp/malformed",
		},
	}
}

func getHardCodedConfigInfoFileContent() ctestglobals.HardcodedConfig {
	return ctestglobals.HardcodedConfig{
		{
			FixtureFileName: "test_fixture.json",
			TestInfo:        []string{"valid yaml"},
			Field:           "fileContent",
			K8sObjects:      []string{"pods"},
			HardcodedConfig: dedent.Dedent(`
apiVersion: kubeadm.k8s.io/v1beta4
discovery:
  bootstrapToken:
    apiServerEndpoint: 1.2.3.4:6443
    caCertHashes:
    - aaaa
    token: abcdef.1234567890123456
  tlsBootstrapToken: abcdef.1234567890123456
kind: JoinConfiguration`),
		},
		{
			FixtureFileName: "test_fixture.json",
			TestInfo:        []string{"empty yaml"},
			Field:           "fileContent",
			K8sObjects:      []string{"pods"},
			HardcodedConfig: "",
		},
		{
			FixtureFileName: "test_fixture.json",
			TestInfo:        []string{"malformed yaml"},
			Field:           "fileContent",
			K8sObjects:      []string{"pods"},
			HardcodedConfig: "apiVersion: ???\n: malformed",
		},
	}
}
