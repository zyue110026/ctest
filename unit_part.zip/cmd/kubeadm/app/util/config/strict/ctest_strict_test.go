package strict_test

import (
	"fmt"
	"os"
	"path/filepath"
	"testing"

	"k8s.io/apimachinery/pkg/runtime"
	"k8s.io/apimachinery/pkg/runtime/schema"
	kubeproxyconfigv1alpha1 "k8s.io/kube-proxy/config/v1alpha1"
	kubeletconfigv1beta1 "k8s.io/kubelet/config/v1beta1"

	kubeadmscheme "k8s.io/kubernetes/cmd/kubeadm/app/apis/kubeadm/scheme"
	kubeadmapiv1 "k8s.io/kubernetes/cmd/kubeadm/app/apis/kubeadm/v1beta4"
	"k8s.io/kubernetes/cmd/kubeadm/app/componentconfigs"
	"k8s.io/kubernetes/cmd/kubeadm/app/constants"
	"k8s.io/kubernetes/cmd/kubeadm/app/util/config/strict"

	ctestglobals "k8s.io/kubernetes/test/ctest/ctestglobals"
)

func TestCtestVerifyUnmarshalStrict(t *testing.T) {
	const (
		pathTestData = "testdata/"
	)

	var schemes = []*runtime.Scheme{kubeadmscheme.Scheme, componentconfigs.Scheme}
	// original test cases
	var baseTestFiles = []struct {
		fileName      string
		kind          string
		groupVersion  schema.GroupVersion
		expectedError bool
	}{
		{fileName: "invalid_casesensitive_field.yaml", kind: constants.ClusterConfigurationKind, groupVersion: kubeadmapiv1.SchemeGroupVersion, expectedError: true},
		{fileName: "invalid_duplicate_field_clustercfg.yaml", kind: constants.InitConfigurationKind, groupVersion: kubeadmapiv1.SchemeGroupVersion, expectedError: true},
		{fileName: "invalid_duplicate_field_joincfg.yaml", kind: constants.JoinConfigurationKind, groupVersion: kubeadmapiv1.SchemeGroupVersion, expectedError: true},
		{fileName: "invalid_duplicate_field_kubeletcfg.yaml", kind: "KubeletConfiguration", groupVersion: kubeletconfigv1beta1.SchemeGroupVersion, expectedError: true},
		{fileName: "invalid_duplicate_field_kubeproxycfg.yaml", kind: "KubeProxyConfiguration", groupVersion: kubeproxyconfigv1alpha1.SchemeGroupVersion, expectedError: true},
		{fileName: "invalid_unknown_field_clustercfg.yaml", kind: constants.ClusterConfigurationKind, groupVersion: kubeadmapiv1.SchemeGroupVersion, expectedError: true},
		{fileName: "invalid_unknown_field_initcfg.yaml", kind: constants.InitConfigurationKind, groupVersion: kubeadmapiv1.SchemeGroupVersion, expectedError: true},
		{fileName: "invalid_unknown_field_joincfg.yaml", kind: constants.JoinConfigurationKind, groupVersion: kubeadmapiv1.SchemeGroupVersion, expectedError: true},
		{fileName: "invalid_unknown_field_kubeletcfg.yaml", kind: "KubeletConfiguration", groupVersion: kubeletconfigv1beta1.SchemeGroupVersion, expectedError: true},
		{fileName: "invalid_unknown_field_kubeproxycfg.yaml", kind: "KubeProxyConfiguration", groupVersion: kubeproxyconfigv1alpha1.SchemeGroupVersion, expectedError: true},
		// unknown groupVersion/kind
		{fileName: "valid_clustercfg.yaml", kind: constants.ClusterConfigurationKind, groupVersion: schema.GroupVersion{Group: "someGroup", Version: "v1"}, expectedError: true},
		{fileName: "valid_clustercfg.yaml", kind: "SomeUnknownKind", groupVersion: kubeadmapiv1.SchemeGroupVersion, expectedError: true},
		// valid cases
		{fileName: "valid_clustercfg.yaml", kind: constants.ClusterConfigurationKind, groupVersion: kubeadmapiv1.SchemeGroupVersion, expectedError: false},
		{fileName: "valid_initcfg.yaml", kind: constants.InitConfigurationKind, groupVersion: kubeadmapiv1.SchemeGroupVersion, expectedError: false},
		{fileName: "valid_joincfg.yaml", kind: constants.JoinConfigurationKind, groupVersion: kubeadmapiv1.SchemeGroupVersion, expectedError: false},
		{fileName: "valid_kubeletcfg.yaml", kind: "KubeletConfiguration", groupVersion: kubeletconfigv1beta1.SchemeGroupVersion, expectedError: false},
		{fileName: "valid_kubeproxycfg.yaml", kind: "KubeProxyConfiguration", groupVersion: kubeproxyconfigv1alpha1.SchemeGroupVersion, expectedError: false},
	}

	// edge / invalid test cases
	var edgeTestFiles = []struct {
		fileName      string
		kind          string
		groupVersion  schema.GroupVersion
		expectedError bool
	}{
		// empty file name (should cause read error -> fatal, we skip by expecting fatal in test harness)
		{fileName: "", kind: constants.ClusterConfigurationKind, groupVersion: kubeadmapiv1.SchemeGroupVersion, expectedError: true},
		// empty kind
		{fileName: "valid_clustercfg.yaml", kind: "", groupVersion: kubeadmapiv1.SchemeGroupVersion, expectedError: true},
		// zero GroupVersion
		{fileName: "valid_clustercfg.yaml", kind: constants.ClusterConfigurationKind, groupVersion: schema.GroupVersion{}, expectedError: true},
		// nil kind with unknown group
		{fileName: "valid_initcfg.yaml", kind: "NonExistentKind", groupVersion: schema.GroupVersion{Group: "unknownGroup", Version: "v1"}, expectedError: true},
		// duplicate entry with contradictory expectedError
		{fileName: "valid_kubeletcfg.yaml", kind: "KubeletConfiguration", groupVersion: kubeletconfigv1beta1.SchemeGroupVersion, expectedError: true},
	}

	fmt.Println(ctestglobals.DebugPrefix(), "Start strict unmarshal verification test")
	allTests := append(baseTestFiles, edgeTestFiles...)
	fmt.Println(ctestglobals.DebugPrefix(), "total test cases:", len(allTests))

	for idx, test := range allTests {
		t.Run(fmt.Sprintf("%d-%s", idx, test.fileName), func(t *testing.T) {
			fmt.Println(ctestglobals.DebugPrefix(), "Running test case:", test)
			bytes, err := os.ReadFile(filepath.Join(pathTestData, test.fileName))
			if err != nil {
				// If the file cannot be read, treat this as an expected error scenario.
				if !test.expectedError {
					t.Fatalf("couldn't read test data for %s: %v", test.fileName, err)
				}
				// Expected error due to missing/invalid file.
				fmt.Println(ctestglobals.DebugPrefix(), "expected read error:", err)
				return
			}
			gvk := schema.GroupVersionKind{
				Group:   test.groupVersion.Group,
				Version: test.groupVersion.Version,
				Kind:    test.kind,
			}
			err = strict.VerifyUnmarshalStrict(schemes, gvk, bytes)
			if (err != nil) != test.expectedError {
				t.Errorf("expected error %v, got %v, error: %v", test.expectedError, err != nil, err)
			}
		})
	}
	fmt.Println(ctestglobals.EndSeparator)
}