package features

import (
	"reflect"
	"testing"

	"k8s.io/apimachinery/pkg/util/version"
	"k8s.io/component-base/featuregate"
)

// TestCtestKnownFeatures verifies that KnownFeatures returns the expected formatted strings.
// No dynamic configuration is required for this test.
func TestCtestKnownFeatures(t *testing.T) {
	var someFeatures = FeatureList{
		"feature2": {FeatureSpec: featuregate.FeatureSpec{Default: true, PreRelease: featuregate.Alpha}},
		"feature1": {FeatureSpec: featuregate.FeatureSpec{Default: false, PreRelease: featuregate.Beta}},
		"feature3": {FeatureSpec: featuregate.FeatureSpec{Default: false, PreRelease: featuregate.GA}},
		"hidden":   {FeatureSpec: featuregate.FeatureSpec{Default: false, PreRelease: featuregate.GA}, HiddenInHelpText: true},
	}

	r := KnownFeatures(&someFeatures)

	if len(r) != 3 {
		t.Errorf("KnownFeatures returned %d values, expected 3", len(r))
	}

	// check the first value is feature1 (the list should be sorted); prerelease and default should be present
	f1 := "feature1=true|false (BETA - default=false)"
	if r[0] != f1 {
		t.Errorf("KnownFeatures returned %s values, expected %s", r[0], f1)
	}
	// check the second value is feature2; prerelease and default should be present
	f2 := "feature2=true|false (ALPHA - default=true)"
	if r[1] != f2 {
		t.Errorf("KnownFeatures returned %s values, expected %s", r[1], f2)
	}
	// check the third value is feature3; prerelease should not be shown for GA features; default should be present
	f3 := "feature3=true|false (default=false)"
	if r[2] != f3 {
		t.Errorf("KnownFeatures returned %s values, expected %s", r[2], f3)
	}
}

// TestCtestNewFeatureGate validates parsing of feature gate strings, including additional edge cases.
func TestCtestNewFeatureGate(t *testing.T) {
	var someFeatures = FeatureList{
		"feature1":   {FeatureSpec: featuregate.FeatureSpec{Default: false, PreRelease: featuregate.Beta}},
		"feature2":   {FeatureSpec: featuregate.FeatureSpec{Default: true, PreRelease: featuregate.Alpha}},
		"deprecated": {FeatureSpec: featuregate.FeatureSpec{Default: true, PreRelease: featuregate.Deprecated}},
	}

	var tests = []struct {
		value                string
		expectedError        bool
		expectedFeaturesGate map[string]bool
	}{
		{ //invalid value (missing =)
			value:         "invalidValue",
			expectedError: true,
		},
		{ //invalid value (missing =)
			value:         "feature1=true,invalidValue",
			expectedError: true,
		},
		{ //invalid value (not a boolean)
			value:         "feature1=notABoolean",
			expectedError: true,
		},
		{ //invalid value (not a boolean)
			value:         "feature1=true,feature2=notABoolean",
			expectedError: true,
		},
		{ //unrecognized feature-gate key
			value:         "unknownFeature=false",
			expectedError: true,
		},
		{ //unrecognized feature-gate key mixed with known
			value:         "feature1=true,unknownFeature=false",
			expectedError: true,
		},
		{ //deprecated feature-gate key
			value:                "deprecated=true",
			expectedError:        false,
			expectedFeaturesGate: map[string]bool{"deprecated": true},
		},
		{ //one feature
			value:                "feature1=true",
			expectedError:        false,
			expectedFeaturesGate: map[string]bool{"feature1": true},
		},
		{ //two features
			value:                "feature1=true,feature2=false",
			expectedError:        false,
			expectedFeaturesGate: map[string]bool{"feature1": true, "feature2": false},
		},
		// Edge cases
		{ // empty string (treated as no flags)
			value:         "",
			expectedError: false,
			expectedFeaturesGate: map[string]bool{},
		},
		{ // trailing comma
			value:         "feature1=true,",
			expectedError: true,
		},
		{ // duplicate key, last wins
			value:                "feature1=true,feature1=false",
			expectedError:        false,
			expectedFeaturesGate: map[string]bool{"feature1": false},
		},
		{ // key with empty value
			value:         "feature1=",
			expectedError: true,
		},
		{ // value with extra spaces
			value:         " feature1 = true ",
			expectedError: true,
		},
		{ // very long value string (still valid)
			value:         "feature1=true,feature2=false,deprecated=true",
			expectedError: false,
			expectedFeaturesGate: map[string]bool{"feature1": true, "feature2": false, "deprecated": true},
		},
	}

	for _, test := range tests {
		t.Run(test.value, func(t *testing.T) {
			r, err := NewFeatureGate(&someFeatures, test.value)

			if !test.expectedError && err != nil {
				t.Errorf("NewFeatureGate failed when not expected: %v", err)
				return
			} else if test.expectedError && err == nil {
				t.Error("NewFeatureGate didn't fail when expected")
				return
			}

			if !test.expectedError && !reflect.DeepEqual(r, test.expectedFeaturesGate) {
				t.Errorf("NewFeatureGate returned unexpected value, got %v, want %v", r, test.expectedFeaturesGate)
			}
		})
	}
}

// TestCtestValidateVersion checks version validation logic and adds edge scenarios.
func TestCtestValidateVersion(t *testing.T) {
	var someFeatures = FeatureList{
		"feature1": {FeatureSpec: featuregate.FeatureSpec{Default: false, PreRelease: featuregate.Beta}},
		"feature2": {FeatureSpec: featuregate.FeatureSpec{Default: true, PreRelease: featuregate.Alpha}, MinimumVersion: version.MustParseSemantic("v1.17.0").WithPreRelease("alpha.1")},
	}

	var tests = []struct {
		name               string
		requestedVersion   string
		requestedFeatures  map[string]bool
		expectedError      bool
	}{
		{
			name:              "no min version",
			requestedFeatures: map[string]bool{"feature1": true},
			expectedError:     false,
		},
		{
			name:              "min version but correct value given",
			requestedFeatures: map[string]bool{"feature2": true},
			requestedVersion:  "v1.17.0",
			expectedError:     false,
		},
		{
			name:              "min version and incorrect value given",
			requestedFeatures: map[string]bool{"feature2": true},
			requestedVersion:  "v1.11.2",
			expectedError:     true,
		},
		// Edge cases
		{
			name:              "invalid version format",
			requestedFeatures: map[string]bool{"feature2": true},
			requestedVersion:  "invalid-version",
			expectedError:     true,
		},
		{
			name:              "empty version string (treated as no version)",
			requestedFeatures: map[string]bool{"feature2": true},
			requestedVersion:  "",
			expectedError:     true,
		},
		{
			name:              "feature not defined in FeatureList",
			requestedFeatures: map[string]bool{"unknownFeature": true},
			requestedVersion:  "v1.17.0",
			expectedError:     true,
		},
		{
			name:              "nil feature map",
			requestedFeatures: nil,
			requestedVersion:  "v1.17.0",
			expectedError:     false,
		},
	}

	for _, test := range tests {
		t.Run(test.name, func(t *testing.T) {
			err := ValidateVersion(someFeatures, test.requestedFeatures, test.requestedVersion)
			if !test.expectedError && err != nil {
				t.Errorf("ValidateVersion failed when not expected: %v", err)
				return
			} else if test.expectedError && err == nil {
				t.Error("ValidateVersion didn't fail when expected")
				return
			}
		})
	}
}

// TestCtestEnabledDefaults ensures that Enabled returns default values when no flags are set.
func TestCtestEnabledDefaults(t *testing.T) {
	for featureName, feature := range InitFeatureGates {
		featureList := make(map[string]bool)

		enabled := Enabled(featureList, featureName)
		if enabled != feature.Default {
			t.Errorf("Enabled returned %v instead of default value %v for feature %s", enabled, feature.Default, featureName)
		}
	}
}

// TestCtestCheckDeprecatedFlags validates deprecated flag handling and adds edge scenarios.
func TestCtestCheckDeprecatedFlags(t *testing.T) {
	dummyMessage := "dummy message"
	var someFeatures = FeatureList{
		"feature1":   {FeatureSpec: featuregate.FeatureSpec{Default: false, PreRelease: featuregate.Beta}},
		"deprecated": {FeatureSpec: featuregate.FeatureSpec{Default: true, PreRelease: featuregate.Deprecated}, DeprecationMessage: dummyMessage},
	}

	var tests = []struct {
		name        string
		features    map[string]bool
		expectedMsg map[string]string
	}{
		{
			name:        "deprecated feature",
			features:    map[string]bool{"deprecated": true},
			expectedMsg: map[string]string{"deprecated": dummyMessage},
		},
		{
			name:        "valid feature",
			features:    map[string]bool{"feature1": true},
			expectedMsg: map[string]string{},
		},
		{
			name:        "invalid feature",
			features:    map[string]bool{"feature2": true},
			expectedMsg: map[string]string{"feature2": "Unknown feature gate flag: feature2"},
		},
		// Edge cases
		{
			name:        "nil feature map",
			features:    nil,
			expectedMsg: map[string]string{},
		},
		{
			name:        "empty feature map",
			features:    map[string]bool{},
			expectedMsg: map[string]string{},
		},
	}

	for _, test := range tests {
		t.Run(test.name, func(t *testing.T) {
			msg := CheckDeprecatedFlags(&someFeatures, test.features)
			if !reflect.DeepEqual(test.expectedMsg, msg) {
				t.Errorf("CheckDeprecatedFlags() = %v, want %v", msg, test.expectedMsg)
			}
		})
	}
}

// TestCtestSupports checks feature support detection and adds an edge case for empty name.
func TestCtestSupports(t *testing.T) {
	tests := []struct {
		name        string
		featureName string
		want        bool
	}{
		{
			name:        "the feature is not supported",
			featureName: "foo",
			want:        false,
		},
		{
			name:        "the feature is supported",
			featureName: PublicKeysECDSA,
			want:        true,
		},
		{
			name:        "empty feature name",
			featureName: "",
			want:        false,
		},
	}
	for _, test := range tests {
		t.Run(test.name, func(t *testing.T) {
			if got := Supports(InitFeatureGates, test.featureName); got != test.want {
				t.Errorf("Supports() = %v, want %v", got, test.want)
			}
		})
	}
}