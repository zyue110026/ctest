package kubeadm

import (
	"reflect"
	"testing"
)

func TestCtestAPIEndpointFromString(t *testing.T) {
	var tests = []struct {
		apiEndpoint      string
		expectedEndpoint APIEndpoint
		expectedErr      bool
	}{
		// Original test cases
		{apiEndpoint: "1.2.3.4:1234", expectedEndpoint: APIEndpoint{AdvertiseAddress: "1.2.3.4", BindPort: 1234}},
		{apiEndpoint: "1.2.3.4:-1", expectedErr: true},
		{apiEndpoint: "1.2.3.::1234", expectedErr: true},
		{apiEndpoint: "1.2.3.4:65536", expectedErr: true},
		{apiEndpoint: "1.2.3.456:1234", expectedErr: true},
		{apiEndpoint: "[::1]:1234", expectedEndpoint: APIEndpoint{AdvertiseAddress: "::1", BindPort: 1234}},
		{apiEndpoint: "[::1]:-1", expectedErr: true},
		{apiEndpoint: "[::1]:65536", expectedErr: true},
		{apiEndpoint: "[::1:1234", expectedErr: true},
		{apiEndpoint: "[::g]:1234", expectedErr: true},
		// Edge / additional cases
		{apiEndpoint: "", expectedErr: true},
		{apiEndpoint: "localhost", expectedErr: true},
		{apiEndpoint: "1.2.3.4", expectedErr: true},               // missing port
		{apiEndpoint: "1.2.3.4:", expectedErr: true},              // empty port
		{apiEndpoint: "1.2.3.4:0", expectedEndpoint: APIEndpoint{AdvertiseAddress: "1.2.3.4", BindPort: 0}},
		{apiEndpoint: "[::1]", expectedErr: true},                 // missing port for IPv6
		{apiEndpoint: "[::1]:", expectedErr: true},                // empty port for IPv6
		{apiEndpoint: "[::1]:0", expectedEndpoint: APIEndpoint{AdvertiseAddress: "::1", BindPort: 0}},
	}
	for _, rt := range tests {
		t.Run(rt.apiEndpoint, func(t *testing.T) {
			apiEndpoint, err := APIEndpointFromString(rt.apiEndpoint)
			if (err != nil) != rt.expectedErr {
				t.Errorf("expected error %v, got %v, error: %v", rt.expectedErr, err != nil, err)
			}
			if !rt.expectedErr && !reflect.DeepEqual(apiEndpoint, rt.expectedEndpoint) {
				t.Errorf("expected API endpoint: %v; got: %v", rt.expectedEndpoint, apiEndpoint)
			}
		})
	}
}

func TestCtestString(t *testing.T) {
	var tests = []struct {
		name        string
		apiEndpoint APIEndpoint
		expected    string
	}{
		// Original test cases
		{name: "ipv4 and port", apiEndpoint: APIEndpoint{AdvertiseAddress: "1.2.3.4", BindPort: 1234}, expected: "1.2.3.4:1234"},
		{name: "ipv6 and port", apiEndpoint: APIEndpoint{AdvertiseAddress: "::1", BindPort: 1234}, expected: "[::1]:1234"},
		// Edge / additional cases
		{name: "ipv4 zero port", apiEndpoint: APIEndpoint{AdvertiseAddress: "10.0.0.1", BindPort: 0}, expected: "10.0.0.1:0"},
		{name: "ipv6 zero port", apiEndpoint: APIEndpoint{AdvertiseAddress: "::1", BindPort: 0}, expected: "[::1]:0"},
		{name: "empty address", apiEndpoint: APIEndpoint{AdvertiseAddress: "", BindPort: 8080}, expected: ":8080"},
	}
	for _, rt := range tests {
		t.Run(rt.name, func(t *testing.T) {
			apiEndpointString := rt.apiEndpoint.String()
			if apiEndpointString != rt.expected {
				t.Errorf(
					"failed String:\n\texpected: %s\n\t  actual: %s",
					rt.expected,
					apiEndpointString,
				)
			}
		})
	}
}