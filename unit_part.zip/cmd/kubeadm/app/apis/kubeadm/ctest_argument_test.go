package kubeadm

import (
	"fmt"
	"reflect"
	"testing"

	ctestglobals "k8s.io/kubernetes/test/ctest/ctestglobals"
)

func TestCtestGetArgValue(t *testing.T) {
	fmt.Println(ctestglobals.StartSeparator)

	var tests = []struct {
		testName      string
		args          []Arg
		name          string
		expectedValue string
		startIdx      int
		expectedIdx   int
	}{
		{
			testName:      "argument exists with non-empty value",
			args:          []Arg{{Name: "a", Value: "a1"}, {Name: "b", Value: "b1"}, {Name: "c", Value: "c1"}},
			name:          "b",
			expectedValue: "b1",
			expectedIdx:   1,
			startIdx:      -1,
		},
		{
			testName:      "argument exists with non-empty value (offset index)",
			args:          []Arg{{Name: "a", Value: "a1"}, {Name: "b", Value: "b1"}, {Name: "c", Value: "c1"}},
			name:          "a",
			expectedValue: "a1",
			expectedIdx:   0,
			startIdx:      0,
		},
		{
			testName:      "argument exists with empty value",
			args:          []Arg{{Name: "foo1", Value: ""}, {Name: "foo2", Value: ""}},
			name:          "foo2",
			expectedValue: "",
			expectedIdx:   1,
			startIdx:      -1,
		},
		{
			testName:      "argument does not exists",
			args:          []Arg{{Name: "foo", Value: "bar"}},
			name:          "z",
			expectedValue: "",
			expectedIdx:   -1,
			startIdx:      -1,
		},
		// Edge / invalid cases
		{
			testName:      "empty args slice",
			args:          []Arg{},
			name:          "any",
			expectedValue: "",
			expectedIdx:   -1,
			startIdx:      -1,
		},
		{
			testName:      "startIdx beyond slice length",
			args:          []Arg{{Name: "a", Value: "a1"}},
			name:          "a",
			expectedValue: "",
			expectedIdx:   -1,
			startIdx:      10,
		},
		{
			testName:      "name empty string with match",
			args:          []Arg{{Name: "", Value: "emptyName"}},
			name:          "",
			expectedValue: "emptyName",
			expectedIdx:   0,
			startIdx:      -1,
		},
		{
			testName:      "multiple matching names, startIdx selects second",
			args:          []Arg{{Name: "dup", Value: "first"}, {Name: "dup", Value: "second"}},
			name:          "dup",
			expectedValue: "second",
			expectedIdx:   1,
			startIdx:      1,
		},
	}

	for i, rt := range tests {
		fmt.Printf("Running %d th test case: %s\n", i, rt.testName)
		t.Run(rt.testName, func(t *testing.T) {
			value, idx := GetArgValue(rt.args, rt.name, rt.startIdx)
			if idx != rt.expectedIdx {
				t.Errorf("expected index: %v, got: %v", rt.expectedIdx, idx)
			}
			if value != rt.expectedValue {
				t.Errorf("expected value: %s, got: %s", rt.expectedValue, value)
			}
		})
	}
	fmt.Println(ctestglobals.EndSeparator)
}

func TestCtestSetArgValues(t *testing.T) {
	fmt.Println(ctestglobals.StartSeparator)

	var tests = []struct {
		testName     string
		args         []Arg
		name         string
		value        string
		nArgs        int
		expectedArgs []Arg
	}{
		{
			testName:     "update 1 argument",
			args:         []Arg{{Name: "foo", Value: "bar1"}, {Name: "foo", Value: "bar2"}},
			name:         "foo",
			value:        "zz",
			nArgs:        1,
			expectedArgs: []Arg{{Name: "foo", Value: "bar1"}, {Name: "foo", Value: "zz"}},
		},
		{
			testName:     "update all arguments",
			args:         []Arg{{Name: "foo", Value: "bar1"}, {Name: "foo", Value: "bar2"}},
			name:         "foo",
			value:        "zz",
			nArgs:        -1,
			expectedArgs: []Arg{{Name: "foo", Value: "zz"}, {Name: "foo", Value: "zz"}},
		},
		{
			testName:     "add new argument",
			args:         []Arg{{Name: "foo", Value: "bar1"}, {Name: "foo", Value: "bar2"}},
			name:         "z",
			value:        "zz",
			nArgs:        -1,
			expectedArgs: []Arg{{Name: "foo", Value: "bar1"}, {Name: "foo", Value: "bar2"}, {Name: "z", Value: "zz"}},
		},
		// Edge / invalid cases
		{
			testName:     "no matching arguments, nArgs=0 (no change)",
			args:         []Arg{{Name: "a", Value: "1"}, {Name: "b", Value: "2"}},
			name:         "c",
			value:        "new",
			nArgs:        0,
			expectedArgs: []Arg{{Name: "a", Value: "1"}, {Name: "b", Value: "2"}},
		},
		{
			testName:     "empty args slice, add new argument",
			args:         []Arg{},
			name:         "newArg",
			value:        "val",
			nArgs:        -1,
			expectedArgs: []Arg{{Name: "newArg", Value: "val"}},
		},
		{
			testName:     "negative nArgs other than -1 (treated as all)",
			args:         []Arg{{Name: "x", Value: "old"}},
			name:         "x",
			value:        "new",
			nArgs:        -5,
			expectedArgs: []Arg{{Name: "x", Value: "new"}},
		},
		{
			testName:     "multiple matching names, nArgs=2 updates first two",
			args:         []Arg{{Name: "dup", Value: "first"}, {Name: "dup", Value: "second"}, {Name: "dup", Value: "third"}},
			name:         "dup",
			value:        "updated",
			nArgs:        2,
			expectedArgs: []Arg{{Name: "dup", Value: "updated"}, {Name: "dup", Value: "updated"}, {Name: "dup", Value: "third"}},
		},
	}

	for i, rt := range tests {
		fmt.Printf("Running %d th test case: %s\n", i, rt.testName)
		t.Run(rt.testName, func(t *testing.T) {
			args := SetArgValues(rt.args, rt.name, rt.value, rt.nArgs)
			if !reflect.DeepEqual(args, rt.expectedArgs) {
				t.Errorf("expected args: %#v, got: %#v", rt.expectedArgs, args)
			}
		})
	}
	fmt.Println(ctestglobals.EndSeparator)
}