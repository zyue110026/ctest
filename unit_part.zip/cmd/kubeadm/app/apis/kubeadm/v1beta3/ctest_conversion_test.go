package v1beta3

import (
	"fmt"
	"reflect"
	"testing"

	ctestglobals "k8s.io/kubernetes/test/ctest/ctestglobals"

	kubeadmapi "k8s.io/kubernetes/cmd/kubeadm/app/apis/kubeadm"
)

func TestCtestConvertToArgs(t *testing.T) {
	fmt.Println(ctestglobals.DebugPrefix(), "Start TestCtestConvertToArgs")
	var tests = []struct {
		name         string
		args         map[string]string
		expectedArgs []kubeadmapi.Arg
	}{
		{
			name:         "nil map returns nil args",
			args:         nil,
			expectedArgs: nil,
		},
		{
			name: "empty map returns nil args",
			args: map[string]string{},
			// The conversion function returns nil when there are no entries.
			expectedArgs: nil,
		},
		{
			name: "valid args are parsed (sorted)",
			args: map[string]string{"c": "d", "a": "b"},
			expectedArgs: []kubeadmapi.Arg{
				{Name: "a", Value: "b"},
				{Name: "c", Value: "d"},
			},
		},
	}
	fmt.Println(ctestglobals.DebugPrefix(), "Number of test cases:", len(tests))
	for i, tc := range tests {
		fmt.Printf("Running %d th test case.\n", i)
		fmt.Println(tc)
		t.Run(tc.name, func(t *testing.T) {
			actual := convertToArgs(tc.args)
			if !reflect.DeepEqual(tc.expectedArgs, actual) {
				t.Fatalf("expected args: %v\n\t got: %v\n\t", tc.expectedArgs, actual)
			}
		})
	}
}

func TestCtestConvertFromArgs(t *testing.T) {
	fmt.Println(ctestglobals.DebugPrefix(), "Start TestCtestConvertFromArgs")
	var tests = []struct {
		name         string
		args         []kubeadmapi.Arg
		expectedArgs map[string]string
	}{
		{
			name:         "nil args return nil map",
			args:         nil,
			expectedArgs: nil,
		},
		{
			name:         "empty args return nil map",
			args:         []kubeadmapi.Arg{},
			expectedArgs: nil,
		},
		{
			name: "valid args are parsed",
			args: []kubeadmapi.Arg{
				{Name: "a", Value: "b"},
				{Name: "c", Value: "d"},
			},
			expectedArgs: map[string]string{"a": "b", "c": "d"},
		},
		{
			name: "duplicates are dropped",
			args: []kubeadmapi.Arg{
				{Name: "a", Value: "b"},
				{Name: "c", Value: "d1"},
				{Name: "c", Value: "d2"},
			},
			expectedArgs: map[string]string{"a": "b", "c": "d2"},
		},
	}
	fmt.Println(ctestglobals.DebugPrefix(), "Number of test cases:", len(tests))
	for i, tc := range tests {
		fmt.Printf("Running %d th test case.\n", i)
		fmt.Println(tc)
		t.Run(tc.name, func(t *testing.T) {
			actual := convertFromArgs(tc.args)
			if !reflect.DeepEqual(tc.expectedArgs, actual) {
				t.Fatalf("expected args: %v\n\t got: %v\n\t", tc.expectedArgs, actual)
			}
		})
	}
}