package cmd

import (
	"bytes"
	"fmt"
	"os"
	"path/filepath"
	"strings"
	"testing"

	"github.com/google/go-cmp/cmp"
	"github.com/google/go-cmp/cmp/cmpopts"

	v1 "k8s.io/api/core/v1"
	metav1 "k8s.io/apimachinery/pkg/apis/meta/v1"
	"k8s.io/apimachinery/pkg/util/sets"
	"k8s.io/klog/v2"
	"k8s.io/utils/ptr"

	kubeadmapi "k8s.io/kubernetes/cmd/kubeadm/app/apis/kubeadm"
	kubeadmapiv1 "k8s.io/kubernetes/cmd/kubeadm/app/apis/kubeadm/v1beta4"
	"k8s.io/kubernetes/cmd/kubeadm/app/cmd/options"
	"k8s.io/kubernetes/cmd/kubeadm/app/constants"
	kubeconfigutil "k8s.io/kubernetes/cmd/kubeadm/app/util/kubeconfig"

	ctest "k8s.io/kubernetes/test/ctest"
	ctestglobals "k8s.io/kubernetes/test/ctest/ctestglobals"
	ctestutils "k8s.io/kubernetes/test/ctest/utils"
)

func TestCtestNewJoinData(t *testing.T) {
	// create temp directory
	tmpDir, err := os.MkdirTemp("", "kubeadm-join-test")
	if err != nil {
		t.Fatalf("Unable to create temporary directory: %v", err)
	}
	defer os.RemoveAll(tmpDir)

	// create kubeconfig
	kubeconfigFilePath := filepath.Join(tmpDir, "test-kubeconfig-file")
	kubeconfig := kubeconfigutil.CreateBasic("", "", "", []byte{})
	kubeconfigutil.WriteToDisk(kubeconfigFilePath, kubeconfig)

	// create valid config file
	configFilePath := filepath.Join(tmpDir, "test-config-file")
	cfgFile, err := os.Create(configFilePath)
	if err != nil {
		t.Fatalf("Unable to create file %q: %v", configFilePath, err)
	}
	if _, err = cfgFile.WriteString(testJoinConfig); err != nil {
		t.Fatalf("Unable to write file %q: %v", configFilePath, err)
	}
	cfgFile.Close()

	// create invalid config file
	invalidConfigFilePath := filepath.Join(tmpDir, "invalid-config-file")
	invalidCfgFile, err := os.Create(invalidConfigFilePath)
	if err != nil {
		t.Fatalf("Unable to create file %q: %v", invalidConfigFilePath, err)
	}
	if _, err = invalidCfgFile.WriteString("::: not yaml :::"); err != nil {
		t.Fatalf("Unable to write invalid config file: %v", err)
	}
	invalidCfgFile.Close()

	// retrieve hardcoded config for the config‑file test
	fmt.Println(ctestglobals.StartOverrideModeSeparator)
	hc := getHardCodedConfigInfoJoin()
	item, found := ctestutils.GetItemByExactTestInfo(hc, "join config file")
	if !found {
		fmt.Println(ctestglobals.DebugPrefix(), "Hardcoded join config not found")
	}
	var generatedJoinCfg *kubeadmapi.JoinConfiguration
	if found {
		configObjs, jsonBytes, err := ctest.GenerateEffectiveConfigReturnType[*kubeadmapi.JoinConfiguration](item, ctest.OverrideOnly)
		if err != nil {
			t.Fatalf("failed to generate effective config: %v", err)
		}
		fmt.Println(ctestglobals.DebugPrefix(), "New Json Test Configs:", string(jsonBytes))
		if len(configObjs) > 0 {
			generatedJoinCfg = configObjs[0]
			fmt.Println(ctestglobals.DebugPrefix(), "Generated join config:", generatedJoinCfg)
		}
	}
	fmt.Println(ctestglobals.EndSeparator)

	testCases := []struct {
		name        string
		args        []string
		flags       map[string]string
		validate    func(*testing.T, *joinData)
		expectError bool
		expectWarn  bool
	}{
		{
			name:        "fails if no discovery method set",
			expectError: true,
		},
		{
			name: "fails if both file and bootstrap discovery methods set",
			args: []string{"1.2.3.4:6443"},
			flags: map[string]string{
				options.FileDiscovery:            "https://foo",
				options.TokenDiscovery:           "abcdef.0123456789abcdef",
				options.TokenDiscoverySkipCAHash: "true",
			},
			expectError: true,
		},
		{
			name: "pass if file discovery is set",
			flags: map[string]string{
				options.FileDiscovery: "https://foo",
			},
			validate: func(t *testing.T, data *joinData) {
				if data.cfg.Discovery.File == nil || data.cfg.Discovery.File.KubeConfigPath != "https://foo" {
					t.Error("Invalid data.cfg.Discovery.File")
				}
			},
		},
		{
			name: "pass if bootstrap discovery is set",
			args: []string{"1.2.3.4:6443", "5.6.7.8:6443"},
			flags: map[string]string{
				options.TokenDiscovery:           "abcdef.0123456789abcdef",
				options.TokenDiscoverySkipCAHash: "true",
			},
			validate: func(t *testing.T, data *joinData) {
				if data.cfg.Discovery.BootstrapToken == nil ||
					data.cfg.Discovery.BootstrapToken.APIServerEndpoint != "1.2.3.4:6443" ||
					data.cfg.Discovery.BootstrapToken.Token != "abcdef.0123456789abcdef" ||
					data.cfg.Discovery.BootstrapToken.UnsafeSkipCAVerification != true {
					t.Error("Invalid data.cfg.Discovery.BootstrapToken")
				}
			},
		},
		{
			name: "--token sets TLSBootstrapToken and BootstrapToken.Token if unset",
			args: []string{"1.2.3.4:6443"},
			flags: map[string]string{
				options.TokenStr:                 "abcdef.0123456789abcdef",
				options.TokenDiscoverySkipCAHash: "true",
			},
			validate: func(t *testing.T, data *joinData) {
				if data.cfg.Discovery.TLSBootstrapToken != "abcdef.0123456789abcdef" ||
					data.cfg.Discovery.BootstrapToken == nil ||
					data.cfg.Discovery.BootstrapToken.Token != "abcdef.0123456789abcdef" {
					t.Error("Invalid TLSBootstrapToken or BootstrapToken.Token")
				}
			},
		},
		{
			name: "--token doesn't override TLSBootstrapToken and BootstrapToken.Token if set",
			args: []string{"1.2.3.4:6443"},
			flags: map[string]string{
				options.TokenStr:                 "aaaaaa.0123456789aaaaaa",
				options.TLSBootstrapToken:        "abcdef.0123456789abcdef",
				options.TokenDiscovery:           "defghi.0123456789defghi",
				options.TokenDiscoverySkipCAHash: "true",
			},
			validate: func(t *testing.T, data *joinData) {
				if data.cfg.Discovery.TLSBootstrapToken != "abcdef.0123456789abcdef" ||
					data.cfg.Discovery.BootstrapToken == nil ||
					data.cfg.Discovery.BootstrapToken.Token != "defghi.0123456789defghi" {
					t.Error("Invalid TLSBootstrapToken or BootstrapToken.Token")
				}
			},
		},
		{
			name: "control plane setting are preserved if --control-plane flag is set",
			flags: map[string]string{
				options.ControlPlane:              "true",
				options.APIServerAdvertiseAddress: "1.2.3.4",
				options.APIServerBindPort:         "1234",
				options.FileDiscovery:             "https://foo",
			},
			validate: func(t *testing.T, data *joinData) {
				if data.cfg.ControlPlane == nil ||
					data.cfg.ControlPlane.LocalAPIEndpoint.AdvertiseAddress != "1.2.3.4" ||
					data.cfg.ControlPlane.LocalAPIEndpoint.BindPort != 1234 {
					t.Error("Invalid ControlPlane")
				}
			},
		},
		{
			name: "control plane setting are cleaned up if --control-plane flag is not set",
			flags: map[string]string{
				options.ControlPlane:              "false",
				options.APIServerAdvertiseAddress: "1.2.3.4",
				options.APIServerBindPort:         "1.2.3.4",
				options.FileDiscovery:             "https://foo",
			},
			validate: func(t *testing.T, data *joinData) {
				if data.cfg.ControlPlane != nil {
					t.Error("Invalid ControlPlane")
				}
			},
			expectWarn: true,
		},
		{
			name: "fails if invalid preflight checks are provided",
			flags: map[string]string{
				options.IgnorePreflightErrors: "all,something-else",
			},
			expectError: true,
		},
		{
			name: "Pass with config from file",
			flags: map[string]string{
				options.CfgPath: configFilePath,
			},
			// validate will be overridden dynamically using generated config
		},
		{
			name: "--node-name flags override config from file",
			flags: map[string]string{
				options.CfgPath:  configFilePath,
				options.NodeName: "anotherName",
			},
			validate: func(t *testing.T, data *joinData) {
				if data.cfg.NodeRegistration.Name != "anotherName" {
					t.Error("Invalid NodeRegistration.Name")
				}
			},
		},
		{
			name: "fail if mixedArguments are passed",
			flags: map[string]string{
				options.CfgPath:                   configFilePath,
				options.APIServerAdvertiseAddress: "1.2.3.4",
			},
			expectError: true,
		},
		{
			name: "pre-flights errors from CLI args only",
			flags: map[string]string{
				options.IgnorePreflightErrors: "a,b",
				options.FileDiscovery:         "https://foo",
			},
			validate: expectedJoinIgnorePreflightErrors(sets.New("a", "b")),
		},
		{
			name: "pre-flights errors from JoinConfiguration only",
			flags: map[string]string{
				options.CfgPath: configFilePath,
			},
			validate: expectedJoinIgnorePreflightErrors(sets.New("c", "d")),
		},
		{
			name: "pre-flights errors from both CLI args and JoinConfiguration",
			flags: map[string]string{
				options.CfgPath:               configFilePath,
				options.IgnorePreflightErrors: "a,b",
			},
			validate: expectedJoinIgnorePreflightErrors(sets.New("a", "b", "c", "d")),
		},
		{
			name: "warn if --control-plane flag is not set",
			flags: map[string]string{
				options.APIServerBindPort: "8888",
				options.FileDiscovery:     "https://foo",
			},
			expectWarn: true,
		},
		{
			name: "no warn if --control-plane flag is set",
			flags: map[string]string{
				options.APIServerBindPort: "8888",
				options.FileDiscovery:     "https://bar",
				options.ControlPlane:      "true",
			},
		},
		{
			name: "fails if config file is invalid yaml",
			flags: map[string]string{
				options.CfgPath: invalidConfigFilePath,
			},
			expectError: true,
		},
	}
	for i, tc := range testCases {
		// Dynamically replace validation for the config‑file happy path
		if tc.name == "Pass with config from file" && generatedJoinCfg != nil {
			tc.validate = func(t *testing.T, data *joinData) {
				if diff := cmp.Diff(generatedJoinCfg, data.cfg, cmpopts.IgnoreUnexported(kubeadmapi.JoinConfiguration{})); diff != "" {
					t.Fatalf("join config diff (-want,+got):\n%s", diff)
				}
			}
		}
		t.Run(tc.name, func(t *testing.T) {
			joinOptions := newJoinOptions()
			joinOptions.skipCRIDetect = true
			cmd := newCmdJoin(nil, joinOptions)

			var buffer bytes.Buffer
			klog.SetOutput(&buffer)
			klog.LogToStderr(false)
			defer klog.LogToStderr(true)

			for f, v := range tc.flags {
				cmd.Flags().Set(f, v)
			}

			data, err := newJoinData(cmd, tc.args, joinOptions, nil, kubeconfigFilePath)
			klog.Flush()
			msg := "WARNING: --control-plane is also required when passing control-plane"
			if tc.expectWarn {
				if !strings.Contains(buffer.String(), msg) {
					t.Errorf("expected warning %q, got %q", msg, buffer.String())
				}
			} else {
				if strings.Contains(buffer.String(), msg) {
					t.Errorf("unexpected warning %q", msg)
				}
			}
			if err != nil && !tc.expectError {
				t.Fatalf("newJoinData returned unexpected error: %v", err)
			}
			if err == nil && tc.expectError {
				t.Fatal("newJoinData didn't return error when expected")
			}
			if tc.validate != nil {
				tc.validate(t, data)
			}
		})
		_ = i // silence unused warning if needed
	}
}

// getHardCodedConfigInfoJoin returns the hard‑coded JoinConfiguration used in the “Pass with config from file” test.
func getHardCodedConfigInfoJoin() ctestglobals.HardcodedConfig {
	return ctestglobals.HardcodedConfig{
		{
			FixtureFileName: "test_fixture.json",
			TestInfo:        []string{"join config file"},
			Field:           "cfg",
			K8sObjects:      []string{},
			HardcodedConfig: &kubeadmapi.JoinConfiguration{
				TypeMeta: metav1.TypeMeta{Kind: "", APIVersion: ""},
				NodeRegistration: kubeadmapi.NodeRegistrationOptions{
					Name:                  "somename",
					CRISocket:             expectedCRISocket,
					IgnorePreflightErrors: []string{"c", "d"},
					ImagePullPolicy:       "IfNotPresent",
					ImagePullSerial:       ptr.To(true),
					Taints:                []v1.Taint{{Key: "node-role.kubernetes.io/control-plane", Effect: "NoSchedule"}},
				},
				CACertPath: kubeadmapiv1.DefaultCACertPath,
				Discovery: kubeadmapi.Discovery{
					BootstrapToken: &kubeadmapi.BootstrapTokenDiscovery{
						Token:                    "abcdef.0123456789abcdef",
						APIServerEndpoint:        "1.2.3.4:6443",
						UnsafeSkipCAVerification: true,
					},
					TLSBootstrapToken: "abcdef.0123456789abcdef",
					Timeout:           &metav1.Duration{Duration: constants.DiscoveryTimeout},
				},
				ControlPlane: &kubeadmapi.JoinControlPlane{
					CertificateKey: "c39a18bae4a72e71b178661f437363da218a3efb83ddb03f1cd91d9ae1da41bd",
				},
			},
		},
	}
}
