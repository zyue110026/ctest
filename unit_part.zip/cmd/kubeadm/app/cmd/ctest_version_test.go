package cmd

import (
	"bytes"
	"encoding/json"
	"fmt"
	"testing"

	"sigs.k8s.io/yaml"

	"k8s.io/kubernetes/cmd/kubeadm/app/util/errors"
	"k8s.io/kubernetes/test/ctest/ctestglobals"
)

func TestCtestNewCmdVersion(t *testing.T) {
	var buf bytes.Buffer
	cmd := newCmdVersion(&buf)
	if err := cmd.Execute(); err != nil {
		t.Errorf("Cannot execute version command: %v", err)
	}
}

func TestCtestRunVersion(t *testing.T) {
	var buf bytes.Buffer
	iface := make(map[string]interface{})
	flagNameOutput := "output"
	cmd := newCmdVersion(&buf)

	originalTestCases := []struct {
		name              string
		flag              string
		expectedError     bool
		shouldBeValidYAML bool
		shouldBeValidJSON bool
	}{
		{
			name: "valid: run without flags",
		},
		{
			name: "valid: run with flag 'short'",
			flag: "short",
		},
		{
			name:              "valid: run with flag 'yaml'",
			flag:              "yaml",
			shouldBeValidYAML: true,
		},
		{
			name:              "valid: run with flag 'json'",
			flag:              "json",
			shouldBeValidJSON: true,
		},
		{
			name:          "invalid: run with unsupported flag",
			flag:          "unsupported-flag",
			expectedError: true,
		},
	}

	// Edge and invalid cases to extend coverage
	edgeTestCases := []struct {
		name              string
		flag              string
		expectedError     bool
		shouldBeValidYAML bool
		shouldBeValidJSON bool
	}{
		{
			name:          "invalid: empty flag string (explicit)",
			flag:          "",
			expectedError: false, // same as no flag, should succeed
		},
		{
			name:          "invalid: whitespace flag",
			flag:          " ",
			expectedError: true,
		},
		{
			name:          "invalid: excessively long flag",
			flag:          string(make([]byte, 1024)),
			expectedError: true,
		},
		{
			name:          "invalid: numeric flag",
			flag:          "12345",
			expectedError: true,
		},
		{
			name:          "invalid: flag with newline",
			flag:          "json\n",
			expectedError: true,
		},
	}

	// Combine original and edge cases
	testCases := append(originalTestCases, edgeTestCases...)

	fmt.Println(ctestglobals.StartSeparator)
	fmt.Println(ctestglobals.DebugPrefix(), "Running TestCtestRunVersion with", len(testCases), "cases")
	for i, tc := range testCases {
		fmt.Printf("Running %d th test case: %s\n", i, tc.name)
		fmt.Println(ctestglobals.DebugPrefix(), tc)
		t.Run(tc.name, func(t *testing.T) {
			var err error
			if len(tc.flag) > 0 {
				if err = cmd.Flags().Set(flagNameOutput, tc.flag); err != nil {
					goto error
				}
			}
			buf.Reset()
			if err = RunVersion(&buf, cmd); err != nil {
				goto error
			}
			if buf.String() == "" {
				err = errors.New("empty output")
				goto error
			}
			if tc.shouldBeValidYAML {
				err = yaml.Unmarshal(buf.Bytes(), &iface)
			} else if tc.shouldBeValidJSON {
				err = json.Unmarshal(buf.Bytes(), &iface)
			}
		error:
			if (err != nil) != tc.expectedError {
				t.Errorf("Test case %q: RunVersion expected error: %v, saw: %v; %v", tc.name, tc.expectedError, err != nil, err)
			}
		})
	}
	fmt.Println(ctestglobals.EndSeparator)
}