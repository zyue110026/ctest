package upgrade

import (
	"bytes"
	"reflect"
	"testing"

	outputapischeme "k8s.io/kubernetes/cmd/kubeadm/app/apis/output/scheme"
	outputapiv1alpha3 "k8s.io/kubernetes/cmd/kubeadm/app/apis/output/v1alpha3"
	"k8s.io/kubernetes/cmd/kubeadm/app/phases/upgrade"
	"k8s.io/kubernetes/cmd/kubeadm/app/util/output"
)

// Extended test cases for sortedSliceFromStringStringArrayMap covering edge conditions.
func TestCtestSortedSliceFromStringStringArrayMap(t *testing.T) {
	var tests = []struct {
		name          string
		strMap        map[string][]string
		expectedSlice []string
	}{
		{
			name:          "the returned slice should be alphabetically sorted based on the string keys in the map",
			strMap:        map[string][]string{"foo": {"1"}, "bar": {"1", "2"}},
			expectedSlice: []string{"bar", "foo"},
		},
		{
			name:          "the int value should not affect this func",
			strMap:        map[string][]string{"foo": {"1", "2"}, "bar": {"1"}},
			expectedSlice: []string{"bar", "foo"},
		},
		{
			name:          "slice with 4 keys and different values",
			strMap:        map[string][]string{"b": {"1", "2"}, "a": {"1"}, "cb": {}, "ca": {"1", "2", "3"}},
			expectedSlice: []string{"a", "b", "ca", "cb"},
		},
		{
			name:          "this should work for version numbers as well; and the lowest version should come first",
			strMap:        map[string][]string{"v1.7.0": {"1"}, "v1.6.1": {"1"}, "v1.6.2": {"1"}, "v1.8.0": {"1"}, "v1.8.0-alpha.1": {"1"}},
			expectedSlice: []string{"v1.6.1", "v1.6.2", "v1.7.0", "v1.8.0", "v1.8.0-alpha.1"},
		},
		// Edge cases
		{
			name:          "empty map returns empty slice",
			strMap:        map[string][]string{},
			expectedSlice: []string{},
		},
		{
			name:          "nil map returns empty slice",
			strMap:        nil,
			expectedSlice: []string{},
		},
		{
			name:          "map with empty slice values",
			strMap:        map[string][]string{"alpha": {}, "beta": {}},
			expectedSlice: []string{"alpha", "beta"},
		},
	}
	for _, rt := range tests {
		t.Run(rt.name, func(t *testing.T) {
			actualSlice := sortedSliceFromStringStringArrayMap(rt.strMap)
			if !reflect.DeepEqual(actualSlice, rt.expectedSlice) {
				t.Errorf(
					"failed sortedSliceFromStringStringArrayMap:\n\texpected: %v\n\t  actual: %v",
					rt.expectedSlice,
					actualSlice,
				)
			}
		})
	}
}

// Edge case test for PrintUpgradePlan when no upgrades or version states are provided.
func TestPrintUpgradePlan_EmptyInputs(t *testing.T) {
	buf := bytes.NewBufferString("")
	outputFlags := output.NewOutputFlags(&upgradePlanTextPrintFlags{}).WithTypeSetter(outputapischeme.Scheme).WithDefaultOutput(output.TextOutput)
	printer, err := outputFlags.ToPrinter()
	if err != nil {
		t.Fatalf("failed ToPrinter, err: %+v", err)
	}

	plan := genUpgradePlan([]upgrade.Upgrade{}, []outputapiv1alpha3.ComponentConfigVersionState{}, true)
	if err := printer.PrintObj(plan, buf); err != nil {
		t.Fatalf("unexpected error when printing empty plan: %v", err)
	}

	if buf.Len() == 0 {
		t.Fatalf("expected non-empty output for empty upgrade plan, got empty")
	}
}
