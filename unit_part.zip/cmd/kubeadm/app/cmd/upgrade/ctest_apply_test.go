package upgrade

import (
	// "fmt"
	"os"
	"path/filepath"
	"strings"
	"testing"

	// kubeadmapiv1 "k8s.io/kubernetes/cmd/kubeadm/app/apis/kubeadm/v1beta4"
	"k8s.io/kubernetes/cmd/kubeadm/app/cmd/options"
	kubeadmconstants "k8s.io/kubernetes/cmd/kubeadm/app/constants"
)

func TestCtestNewApplyData(t *testing.T) {
	// create temp directory
	tmpDir, err := os.MkdirTemp("", "kubeadm-upgrade-apply-test")
	if err != nil {
		t.Errorf("Unable to create temporary directory: %v", err)
	}
	defer func() {
		_ = os.RemoveAll(tmpDir)
	}()

	// create config file
	configFilePath := filepath.Join(tmpDir, "test-config-file")
	cfgFile, err := os.Create(configFilePath)
	if err != nil {
		t.Errorf("Unable to create file %q: %v", configFilePath, err)
	}
	defer func() {
		_ = cfgFile.Close()
	}()
	if _, err = cfgFile.WriteString(testApplyConfig); err != nil {
		t.Fatalf("Unable to write file %q: %v", configFilePath, err)
	}

	testCases := []struct {
		name          string
		args          []string
		flags         map[string]string
		validate      func(*testing.T, *applyData)
		expectedError string
	}{
		{
			name: "fails if no upgrade version set",
			flags: map[string]string{
				options.CfgPath: configFilePath,
			},
			expectedError: "missing one or more required arguments. Required arguments: [version]",
		},
		{
			name: "fails if invalid preflight checks are provided",
			args: []string{"v1.1.0"},
			flags: map[string]string{
				options.IgnorePreflightErrors: "all,something-else",
			},
			expectedError: "ignore-preflight-errors: Invalid value",
		},
		{
			name: "fails if kubeconfig file doesn't exists",
			args: []string{"v1.1.0"},
			flags: map[string]string{
				options.CfgPath:        configFilePath,
				options.KubeconfigPath: "invalid-kubeconfig-path",
			},
			expectedError: "couldn't create a Kubernetes client from file",
		},
		// Edge case: unknown flag provided
		{
			name: "fails if unknown flag is provided",
			args: []string{"v1.1.0"},
			flags: map[string]string{
				"unknown-flag": "value",
			},
			expectedError: "unknown flag",
		},
		// Edge case: empty config file
		{
			name: "fails if config file is empty",
			flags: map[string]string{
				options.CfgPath: configFilePath,
			},
			validate: func(t *testing.T, data *applyData) {
				// ensure that data is nil when config is empty
				if data != nil {
					t.Fatalf("expected nil applyData for empty config, got %#v", data)
				}
			},
			expectedError: "failed to read config file",
		},
	}
	for _, tc := range testCases {
		t.Run(tc.name, func(t *testing.T) {
			// Initialize an external apply flags and inject it to the apply cmd.
			apf := &applyPlanFlags{
				kubeConfigPath:            kubeadmconstants.GetAdminKubeConfigPath(),
				cfgPath:                   "",
				featureGatesString:        "",
				allowExperimentalUpgrades: false,
				allowRCUpgrades:           false,
				printConfig:               false,
				etcdUpgrade:               true,
				out:                       os.Stdout,
			}

			// For the empty config edge case, recreate the config file as empty.
			if tc.name == "fails if config file is empty" {
				emptyPath := filepath.Join(tmpDir, "empty-config")
				if err := os.WriteFile(emptyPath, []byte{}, 0644); err != nil {
					t.Fatalf("unable to create empty config file: %v", err)
				}
				// Override the flag to point to the empty config.
				if tc.flags == nil {
					tc.flags = map[string]string{}
				}
				tc.flags[options.CfgPath] = emptyPath
			}

			cmd := newCmdApply(apf)

			// Sets cmd flags (that will be reflected on the init options).
			for f, v := range tc.flags {
				_ = cmd.Flags().Set(f, v)
			}

			flags := &applyFlags{
				applyPlanFlags: apf,
				renewCerts:     true,
			}

			// Test newApplyData method.
			data, err := newApplyData(cmd, tc.args, flags)
			if err == nil && len(tc.expectedError) != 0 {
				t.Error("Expected error, but got success")
			}
			if err != nil && (len(tc.expectedError) == 0 || !strings.Contains(err.Error(), tc.expectedError)) {
				t.Fatalf("newApplyData returned unexpected error, expected: %s, got %v", tc.expectedError, err)
			}

			// Exec additional validation on the returned value.
			if tc.validate != nil {
				tc.validate(t, data)
			}
		})
	}
}
