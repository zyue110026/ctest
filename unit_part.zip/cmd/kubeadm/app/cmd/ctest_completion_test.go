package cmd

import (
	"bytes"
	"testing"

	"github.com/spf13/cobra"
)

func TestCtestNewCmdCompletion(t *testing.T) {
	var out bytes.Buffer
	shells := GetSupportedShells()
	if len(shells) == 0 {
		t.Error(shellsError)
	}
	// test newCmdCompletion with a valid shell.
	// use a dummy parent command as newCmdCompletion needs it.
	parentCmd := &cobra.Command{}
	args := []string{"completion", shells[0]}
	parentCmd.SetArgs(args)
	cmd := newCmdCompletion(&out, "")
	parentCmd.AddCommand(cmd)
	if err := parentCmd.Execute(); err != nil {
		t.Errorf("Cannot execute newCmdCompletion: %v", err)
	}
}

// Extended edge cases for completion command
func TestCtestRunCompletion(t *testing.T) {
	var out bytes.Buffer
	type TestCase struct {
		name          string
		args          []string
		expectedError bool
	}

	// Base test cases (invalid inputs)
	baseCases := []TestCase{
		{
			name:          "invalid: missing argument",
			args:          []string{},
			expectedError: true,
		},
		{
			name:          "invalid: too many arguments",
			args:          []string{"", ""},
			expectedError: true,
		},
		{
			name:          "invalid: unsupported shell name",
			args:          []string{"unsupported"},
			expectedError: true,
		},
		{
			name:          "invalid: empty string argument",
			args:          []string{""},
			expectedError: true,
		},
		{
			name:          "invalid: excessively long shell name",
			args:          []string{string(make([]byte, 1024))},
			expectedError: true,
		},
		{
			name:          "invalid: special characters in shell name",
			args:          []string{"$%^&*"},
			expectedError: true,
		},
	}

	// test all supported shells and add valid cases
	shells := GetSupportedShells()
	if len(shells) == 0 {
		t.Error(shellsError)
	}
	for _, shell := range shells {
		test := TestCase{
			name: "valid: test shell " + shell,
			args: []string{shell},
		}
		baseCases = append(baseCases, test)
	}

	// use dummy cobra commands
	parentCmd := &cobra.Command{}
	cmd := &cobra.Command{}
	parentCmd.AddCommand(cmd)

	for _, tc := range baseCases {
		t.Run(tc.name, func(t *testing.T) {
			if err := RunCompletion(&out, "", cmd, tc.args); (err != nil) != tc.expectedError {
				t.Errorf("Test case %q: RunCompletion expected error: %v, saw: %v", tc.name, tc.expectedError, (err != nil))
			}
		})
	}
}
