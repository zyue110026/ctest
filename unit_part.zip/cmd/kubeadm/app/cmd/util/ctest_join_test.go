package util

import (
	// "encoding/base64"
	"os"
	"path/filepath"
	"strings"
	"testing"

	"github.com/stretchr/testify/require"

	"k8s.io/client-go/tools/clientcmd"
	clientcmdapi "k8s.io/client-go/tools/clientcmd/api"
)

func TestCtestGetJoinCommand(t *testing.T) {
	edgeToken := strings.Repeat("a", 2000)

	tests := []struct {
		name         string
		kubeConfig   *clientcmdapi.Config
		expectError  bool
		errorMessage string
		token        string
		expectRes    string
	}{
		{
			name:        "Success with valid kubeconfig and token",
			kubeConfig:  generateValidKubeConfig(),
			token:       "test-token",
			expectError: false,
			expectRes:   "kubeadm join test-server:6443 --token <value withheld> \\\n\t--discovery-token-ca-cert-hash",
		},
		{
			name:        "Success with valid kubeconfig and empty token",
			kubeConfig:  generateValidKubeConfig(),
			token:       "",
			expectError: false,
			expectRes:   "kubeadm join test-server:6443 --token <value withheld> \\\n\t--discovery-token-ca-cert-hash",
		},
		{
			name:        "Success with valid kubeconfig and very long token",
			kubeConfig:  generateValidKubeConfig(),
			token:       edgeToken,
			expectError: false,
			expectRes:   "kubeadm join test-server:6443 --token <value withheld> \\\n\t--discovery-token-ca-cert-hash",
		},
		{
			name:         "Error to load kubeconfig",
			kubeConfig:   nil,
			token:        "test-token",
			expectError:  true,
			errorMessage: "failed to load kubeconfig",
		},
		{
			name:         "Error to get default cluster config",
			kubeConfig:   &clientcmdapi.Config{},
			token:        "test-token",
			expectError:  true,
			errorMessage: "the current context is invalid",
		},
		{
			name:         "Error when CA certificate is invalid",
			kubeConfig:   generateInvalidCAKubeConfig(),
			expectError:  true,
			errorMessage: "failed to parse CA certificate from kubeconfig",
		},
		{
			name:         "Error when CA certificate file path is invalid",
			kubeConfig:   generateInvalidFilePathKubeConfig(),
			token:        "test-token",
			expectError:  true,
			errorMessage: "failed to load CA certificate referenced by kubeconfig",
		},
		{
			name:         "Error when CA certificate is missing",
			kubeConfig:   generateMissingCAKubeConfig(),
			token:        "test-token",
			expectError:  true,
			errorMessage: "no CA certificates found in kubeconfig",
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			tmpDir, err := os.MkdirTemp("", "kubeadm-join-test")
			if err != nil {
				t.Fatalf("Unable to create temporary directory: %v", err)
			}
			defer func() {
				err := os.RemoveAll(tmpDir)
				if err != nil {
					t.Fatalf("Unable to remove temporary directory: %v", err)
				}
			}()

			configFilePath := filepath.Join(tmpDir, "test-config-file")
			if tt.kubeConfig != nil {
				configBytes, err := clientcmd.Write(*tt.kubeConfig)
				if err != nil {
					t.Fatalf("Failed to clientcmd.Write: %v", err)
				}
				err = os.WriteFile(configFilePath, configBytes, 0644)
				if err != nil {
					t.Fatalf("Failed to os.WriteFile: %v", err)
				}
			}

			res, err := getJoinCommand(configFilePath, tt.token, "", true, true, true)

			if tt.expectError {
				require.Error(t, err)
				require.Contains(t, err.Error(), tt.errorMessage)
			} else {
				require.NoError(t, err)
			}
			require.Contains(t, res, tt.expectRes)
		})
	}
}
