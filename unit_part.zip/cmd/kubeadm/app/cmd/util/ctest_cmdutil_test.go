package util

import (
	"fmt"
	"testing"

	"github.com/spf13/pflag"

	"k8s.io/client-go/tools/clientcmd"
)

func TestCtestValidateExactArgNumber(t *testing.T) {
	var tests = []struct {
		name                string
		args, supportedArgs []string
		expectedErr         bool
	}{
		{
			name:          "one arg given and one arg expected",
			args:          []string{"my-node-1234"},
			supportedArgs: []string{"node-name"},
			expectedErr:   false,
		},
		{
			name:          "two args given and two args expected",
			args:          []string{"my-node-1234", "foo"},
			supportedArgs: []string{"node-name", "second-toplevel-arg"},
			expectedErr:   false,
		},
		{
			name:          "too few supplied args",
			args:          []string{},
			supportedArgs: []string{"node-name"},
			expectedErr:   true,
		},
		{
			name:          "too few non-empty args",
			args:          []string{""},
			supportedArgs: []string{"node-name"},
			expectedErr:   true,
		},
		{
			name:          "too many args",
			args:          []string{"my-node-1234", "foo"},
			supportedArgs: []string{"node-name"},
			expectedErr:   true,
		},
		// edge / invalid cases
		{
			name:          "nil args slice",
			args:          nil,
			supportedArgs: []string{"node-name"},
			expectedErr:   true,
		},
		{
			name:          "nil supportedArgs slice",
			args:          []string{"my-node-1234"},
			supportedArgs: nil,
			expectedErr:   true,
		},
		{
			name:          "args with whitespace",
			args:          []string{"   "},
			supportedArgs: []string{"node-name"},
			expectedErr:   true,
		},
		{
			name:          "supportedArgs contains empty string",
			args:          []string{"my-node-1234"},
			supportedArgs: []string{""},
			expectedErr:   true,
		},
	}
	for _, rt := range tests {
		t.Run(rt.name, func(t *testing.T) {
			actual := ValidateExactArgNumber(rt.args, rt.supportedArgs)
			if (actual != nil) != rt.expectedErr {
				t.Errorf(
					"failed ValidateExactArgNumber:\n\texpected error: %t\n\t  actual error: %t",
					rt.expectedErr,
					(actual != nil),
				)
			}
		})
	}
}

func TestCtestGetKubeConfigPath(t *testing.T) {
	var tests = []struct {
		name     string
		file     string
		expected string
	}{
		{
			name:     "provide an empty value",
			file:     "",
			expected: clientcmd.NewDefaultClientConfigLoadingRules().GetDefaultFilename(),
		},
		{
			name:     "provide a non-empty value",
			file:     "kubelet.kubeconfig",
			expected: "kubelet.kubeconfig",
		},
		// edge / invalid cases
		{
			name:     "provide whitespace only",
			file:     "   ",
			expected: "   ",
		},
		{
			name:     "provide path with tilde (user home expansion not performed)",
			file:     "~/myconfig",
			expected: "~/myconfig",
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			actualResult := GetKubeConfigPath(tt.file)
			if actualResult != tt.expected {
				t.Errorf(
					"failed GetKubeConfigPath:\n\texpected: %s\n\t  actual: %s",
					tt.expected,
					actualResult,
				)
			}
		})
	}
}

func TestCtestValueFromFlagsOrConfig(t *testing.T) {
	var tests = []struct {
		name      string
		flag      string
		cfg       interface{}
		flagValue interface{}
		expected  interface{}
	}{
		{
			name:      "string: config is overridden by the flag",
			flag:      "foo",
			cfg:       "foo_cfg",
			flagValue: "foo_flag",
			expected:  "foo_flag",
		},
		{
			name:      "bool: config is overridden by the flag",
			flag:      "bar",
			cfg:       true,
			flagValue: false,
			expected:  false,
		},
		{
			name:      "nil bool is converted to false",
			cfg:       (*bool)(nil),
			flagValue: false,
			expected:  false,
		},
		// edge / invalid cases
		{
			name:      "no flag provided, config retained (string)",
			flag:      "",
			cfg:       "default_cfg",
			flagValue: "",
			expected:  "default_cfg",
		},
		{
			name:      "no flag provided, config retained (bool true)",
			flag:      "",
			cfg:       true,
			flagValue: false,
			expected:  true,
		},
		{
			name:      "flag provided with zero value for int (unsupported type)",
			flag:      "baz",
			cfg:       42,
			flagValue: 0,
			expected:  42,
		},
	}
	for _, tt := range tests {
		type options struct {
			foo string
			bar bool
		}
		fakeOptions := &options{}
		fs := pflag.FlagSet{}
		fs.StringVar(&fakeOptions.foo, "foo", "", "")
		fs.BoolVar(&fakeOptions.bar, "bar", false, "")

		t.Run(tt.name, func(t *testing.T) {
			if tt.flag != "" {
				if err := fs.Set(tt.flag, fmt.Sprintf("%v", tt.flagValue)); err != nil {
					t.Fatalf("failed to set the value of the flag %v", tt.flagValue)
				}
			}
			actualResult := ValueFromFlagsOrConfig(&fs, tt.flag, tt.cfg, tt.flagValue)
			if result, ok := actualResult.(*bool); ok {
				actualResult = *result
			}
			if actualResult != tt.expected {
				t.Errorf(
					"failed ValueFromFlagsOrConfig:\n\texpected: %v\n\t  actual: %v",
					tt.expected,
					actualResult,
				)
			}
		})
	}
}