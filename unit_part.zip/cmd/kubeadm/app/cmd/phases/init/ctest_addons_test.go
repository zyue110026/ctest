package phases

import (
	"fmt"
	"reflect"
	"testing"

	"k8s.io/kubernetes/cmd/kubeadm/app/cmd/options"

	// "github.com/onsi/ginkgo/v2"
	"k8s.io/kubernetes/test/ctest/ctestglobals"
)

func TestCtestGetAddonPhaseFlags(t *testing.T) {
	fmt.Println(ctestglobals.StartSeparator)
	tests := []struct {
		name string
		want []string
	}{
		{
			name: "all",
			want: []string{
				options.CfgPath,
				options.KubeconfigPath,
				options.KubernetesVersion,
				options.ImageRepository,
				options.DryRun,
				options.APIServerAdvertiseAddress,
				options.ControlPlaneEndpoint,
				options.APIServerBindPort,
				options.NetworkingPodSubnet,
				options.FeatureGatesString,
				options.NetworkingDNSDomain,
				options.NetworkingServiceSubnet,
			},
		},
		{
			name: "kube-proxy",
			want: []string{
				options.CfgPath,
				options.KubeconfigPath,
				options.KubernetesVersion,
				options.ImageRepository,
				options.DryRun,
				options.APIServerAdvertiseAddress,
				options.ControlPlaneEndpoint,
				options.APIServerBindPort,
				options.NetworkingPodSubnet,
			},
		},
		{
			name: "coredns",
			want: []string{
				options.CfgPath,
				options.KubeconfigPath,
				options.KubernetesVersion,
				options.ImageRepository,
				options.DryRun,
				options.FeatureGatesString,
				options.NetworkingDNSDomain,
				options.NetworkingServiceSubnet,
			},
		},
		{
			name: "invalid_name",
			want: []string{
				options.CfgPath,
				options.KubeconfigPath,
				options.KubernetesVersion,
				options.ImageRepository,
				options.DryRun,
			},
		},
		// edge cases
		{
			name: "",
			want: []string{
				options.CfgPath,
				options.KubeconfigPath,
				options.KubernetesVersion,
				options.ImageRepository,
				options.DryRun,
			},
		},
		{
			name: "   ",
			want: []string{
				options.CfgPath,
				options.KubeconfigPath,
				options.KubernetesVersion,
				options.ImageRepository,
				options.DryRun,
			},
		},
		{
			name: "unknown-addon",
			want: []string{
				options.CfgPath,
				options.KubeconfigPath,
				options.KubernetesVersion,
				options.ImageRepository,
				options.DryRun,
			},
		},
		{
			name: "extremely-long-addon-name-aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa",
			want: []string{
				options.CfgPath,
				options.KubeconfigPath,
				options.KubernetesVersion,
				options.ImageRepository,
				options.DryRun,
			},
		},
	}
	for i, tt := range tests {
		fmt.Printf("Running %d th test case: %s\n", i, tt.name)
		t.Run(tt.name, func(t *testing.T) {
			got := getAddonPhaseFlags(tt.name)
			if ok := reflect.DeepEqual(got, tt.want); !ok {
				t.Errorf("phase init addons.getAddonPhaseFlags() = %v, want %v", got, tt.want)
			}
		})
	}
	fmt.Println(ctestglobals.EndSeparator)
}
