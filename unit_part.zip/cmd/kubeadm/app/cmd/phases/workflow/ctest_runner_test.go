package workflow

import (
	// "fmt"
	"reflect"
	// "strings"
	"testing"

	"github.com/spf13/cobra"
	// "github.com/spf13/pflag"
	// "k8s.io/kubernetes/cmd/kubeadm/app/util/errors"
)

func TestCtestComputePhaseRunFlags(t *testing.T) {
	var usecases = []struct {
		name          string
		options       RunnerOptions
		expected      map[string]bool
		expectedError bool
	}{
		{
			name:     "no options > all phases",
			options:  RunnerOptions{},
			expected: map[string]bool{"foo": true, "foo/bar": true, "foo/baz": true, "qux": true},
		},
		{
			name:     "options can filter phases",
			options:  RunnerOptions{FilterPhases: []string{"foo/baz", "qux"}},
			expected: map[string]bool{"foo": false, "foo/bar": false, "foo/baz": true, "qux": true},
		},
		{
			name:     "options can filter phases - hierarchy is considered",
			options:  RunnerOptions{FilterPhases: []string{"foo"}},
			expected: map[string]bool{"foo": true, "foo/bar": true, "foo/baz": true, "qux": false},
		},
		{
			name:     "options can skip phases",
			options:  RunnerOptions{SkipPhases: []string{"foo/bar", "qux"}},
			expected: map[string]bool{"foo": true, "foo/bar": false, "foo/baz": true, "qux": false},
		},
		{
			name:     "options can skip phases - hierarchy is considered",
			options:  RunnerOptions{SkipPhases: []string{"foo"}},
			expected: map[string]bool{"foo": false, "foo/bar": false, "foo/baz": false, "qux": true},
		},
		{
			name: "skip options have higher precedence than filter options",
			options: RunnerOptions{
				FilterPhases: []string{"foo"},
				SkipPhases:   []string{"foo/bar"},
			},
			expected: map[string]bool{"foo": true, "foo/bar": false, "foo/baz": true, "qux": false},
		},
		{
			name:          "invalid filter option",
			options:       RunnerOptions{FilterPhases: []string{"invalid"}},
			expectedError: true,
		},
		{
			name:          "invalid skip option",
			options:       RunnerOptions{SkipPhases: []string{"invalid"}},
			expectedError: true,
		},
		// Edge / additional cases
		{
			name:     "empty filter and skip slices should behave like no options",
			options:  RunnerOptions{FilterPhases: []string{}, SkipPhases: []string{}},
			expected: map[string]bool{"foo": true, "foo/bar": true, "foo/baz": true, "qux": true},
		},
		{
			name:     "duplicate filter entries are ignored",
			options:  RunnerOptions{FilterPhases: []string{"foo/baz", "foo/baz"}},
			expected: map[string]bool{"foo": false, "foo/bar": false, "foo/baz": true, "qux": false},
		},
		{
			name:          "mixed valid and invalid filter entries should error",
			options:       RunnerOptions{FilterPhases: []string{"invalid", "foo/baz"}},
			expectedError: true,
		},
		{
			name:          "mixed valid and invalid skip entries should error",
			options:       RunnerOptions{SkipPhases: []string{"invalid", "foo/bar"}},
			expectedError: true,
		},
	}
	for _, u := range usecases {
		t.Run(u.name, func(t *testing.T) {
			var w = Runner{
				Phases: []Phase{
					phaseBuilder("foo",
						phaseBuilder("bar"),
						phaseBuilder("baz"),
					),
					phaseBuilder("qux"),
				},
			}

			w.prepareForExecution()
			w.Options = u.options
			actual, err := w.computePhaseRunFlags()
			if (err != nil) != u.expectedError {
				t.Errorf("Unexpected error: %v", err)
			}
			if err != nil {
				return
			}
			if !reflect.DeepEqual(actual, u.expected) {
				t.Errorf("\nactual:\n\t%v\nexpected:\n\t%v\n", actual, u.expected)
			}
		})
	}
}

func TestCtestRunOrderAndConditions(t *testing.T) {
	var w = Runner{
		Phases: []Phase{
			phaseBuilder1("foo", nil,
				phaseBuilder1("bar", runConditionTrue),
				phaseBuilder1("baz", runConditionFalse),
			),
			phaseBuilder1("qux", runConditionTrue),
		},
	}

	var usecases = []struct {
		name          string
		options       RunnerOptions
		expectedOrder []string
	}{
		{
			name:          "Run respect runCondition",
			expectedOrder: []string{"foo", "bar", "qux"},
		},
		{
			name:          "Run takes options into account",
			options:       RunnerOptions{FilterPhases: []string{"foo"}, SkipPhases: []string{"foo/baz"}},
			expectedOrder: []string{"foo", "bar"},
		},
		{
			name:          "explicit empty filters and skips behave as default",
			options:       RunnerOptions{FilterPhases: []string{}, SkipPhases: []string{}},
			expectedOrder: []string{"foo", "bar", "qux"},
		},
	}
	for _, u := range usecases {
		t.Run(u.name, func(t *testing.T) {
			callstack = []string{}
			w.Options = u.options
			err := w.Run([]string{})
			if err != nil {
				t.Errorf("Unexpected error: %v", err)
			}
			if !reflect.DeepEqual(callstack, u.expectedOrder) {
				t.Errorf("\ncallstack:\n\t%v\nexpected:\n\t%v\n", callstack, u.expectedOrder)
			}
		})
	}
}

func TestCtestRunHandleErrors(t *testing.T) {
	var w = Runner{
		Phases: []Phase{
			phaseBuilder2("foo", runConditionPass, runPass),
			phaseBuilder2("bar", runConditionPass, runFails),
			phaseBuilder2("baz", runConditionFails, runPass),
		},
	}

	var usecases = []struct {
		name          string
		options       RunnerOptions
		expectedError bool
	}{
		{
			name:    "no errors",
			options: RunnerOptions{FilterPhases: []string{"foo"}},
		},
		{
			name:          "run fails",
			options:       RunnerOptions{FilterPhases: []string{"bar"}},
			expectedError: true,
		},
		{
			name:          "run condition fails",
			options:       RunnerOptions{FilterPhases: []string{"baz"}},
			expectedError: true,
		},
		{
			name:          "empty filters should succeed (no errors)",
			options:       RunnerOptions{},
			expectedError: false,
		},
	}
	for _, u := range usecases {
		t.Run(u.name, func(t *testing.T) {
			w.Options = u.options
			err := w.Run([]string{})
			if (err != nil) != u.expectedError {
				t.Errorf("Unexpected error: %v", err)
			}
		})
	}
}

func TestCtestBindToCommandArgRequirements(t *testing.T) {

	var usecases = []struct {
		name      string
		runner    Runner
		testCases map[string]argTest
		cmd       *cobra.Command
	}{
		{
			name: "leaf command, no defined args, follow parent",
			runner: Runner{
				Phases: []Phase{phaseBuilder("foo")},
			},
			testCases: map[string]argTest{
				"phase foo": {
					pass: []string{"one", "two", "three"},
					fail: []string{"one", "two"},
					args: cobra.ExactArgs(3),
				},
			},
			cmd: &cobra.Command{
				Use:  "init",
				Args: cobra.ExactArgs(3),
			},
		},
		{
			name: "container cmd expect none, custom arg check for leaf",
			runner: Runner{
				Phases: []Phase{phaseBuilder6("foo", cobra.NoArgs,
					phaseBuilder6("bar", cobra.ExactArgs(1)),
					phaseBuilder6("baz", customArgs),
				)},
			},
			testCases: map[string]argTest{
				"phase foo": {
					pass: []string{},
					fail: []string{"one"},
					args: cobra.NoArgs,
				},
				"phase foo bar": {
					pass: []string{"one"},
					fail: []string{"one", "two"},
					args: cobra.ExactArgs(1),
				},
				"phase foo baz": {
					pass: []string{"qux"},
					fail: []string{"one"},
					args: customArgs,
				},
				"phase foo baz empty": {
					pass: []string{},
					fail: []string{"qux"},
					args: customArgs,
				},
			},
			cmd: &cobra.Command{
				Use:  "init",
				Args: cobra.NoArgs,
			},
		},
	}

	for _, rt := range usecases {
		t.Run(rt.name, func(t *testing.T) {

			rt.runner.BindToCommand(rt.cmd)

			// Checks that cmd gets a new phase subcommand
			phaseCmd := getCmd(rt.cmd, "phase")
			if phaseCmd == nil {
				t.Error("cmd didn't have phase subcommand\n")
				return
			}

			for c, args := range rt.testCases {

				cCmd := getCmd(rt.cmd, c)
				if cCmd == nil {
					t.Errorf("cmd didn't have %s subcommand\n", c)
					continue
				}

				// Test passing argument set
				err := cCmd.Args(cCmd, args.pass)
				if err != nil {
					t.Errorf("command %s should validate the args: %v\n %v", cCmd.Name(), args.pass, err)
				}

				// Test failing argument set
				err = cCmd.Args(cCmd, args.fail)

				if err == nil {
					t.Errorf("command %s should fail to validate the args: %v\n %v", cCmd.Name(), args.pass, err)
				}
			}

		})
	}
}
