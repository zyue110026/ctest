package phases

import (
	"fmt"
	"os"
	"path/filepath"
	"testing"

	"github.com/lithammer/dedent"

	// "github.com/onsi/ginkgo/v2"

	"k8s.io/kubernetes/cmd/kubeadm/app/apis/kubeadm"
	// "k8s.io/kubernetes/cmd/kubeadm/app/phases"

	"k8s.io/api/core/v1"

	// ctest "k8s.io/kubernetes/test/ctest"
	ctestglobals "k8s.io/kubernetes/test/ctest/ctestglobals"
	// ctestutils "k8s.io/kubernetes/test/ctest/utils"

	"sigs.k8s.io/yaml"
)

func TestCtestGetEtcdDataDir(t *testing.T) {
	fmt.Println(ctestglobals.StartSeparator)

	hardConfigs := getHardCodedConfigInfoEtcdDataDir()
	if len(hardConfigs) == 0 {
		fmt.Println(ctestglobals.DebugPrefix(), "Skipping test execution. No new configurations generated.")
		return
	}
	// Build a slice of v1.Pod from all hard‑coded entries
	var allPods []v1.Pod
	for _, hc := range hardConfigs {
		if pod, ok := hc.HardcodedConfig.(v1.Pod); ok {
			allPods = append(allPods, pod)
		}
	}
	if len(allPods) == 0 {
		fmt.Println(ctestglobals.DebugPrefix(), "Skipping test execution. No pod configs generated.")
		return
	}
	// Marshal pods to YAML strings for later substitution
	yamls := make([]string, len(allPods))
	for i, p := range allPods {
		b, err := yaml.Marshal(p)
		if err != nil {
			t.Fatalf("failed to marshal pod config: %v", err)
		}
		yamls[i] = string(b)
	}
	// Map known test names to the corresponding pod yaml index
	nameToIdx := map[string]int{
		"return etcd data dir":              0, // valid pod with data volume
		"invalid etcd pod":                  2, // invalid pod (empty spec)
		"etcd pod spec without data volume": 1, // pod without data volume
	}

	// Original test cases
	tests := map[string]struct {
		dataDir       string
		podYaml       string
		expectErr     bool
		writeManifest bool
		validConfig   bool
	}{
		"non-existent file returns default data dir": {
			expectErr:     false,
			writeManifest: false,
			validConfig:   true,
			dataDir:       "/var/lib/etcd",
		},
		"return etcd data dir": {
			dataDir:       "/path/to/etcd",
			expectErr:     false,
			writeManifest: true,
			validConfig:   true,
		},
		"invalid etcd pod": {
			expectErr:     true,
			writeManifest: true,
			validConfig:   true,
		},
		"etcd pod spec without data volume": {
			expectErr:     true,
			writeManifest: true,
			validConfig:   true,
		},
		"kubeconfig file doesn't exist": {
			dataDir:       "/path/to/etcd",
			expectErr:     false,
			writeManifest: true,
			validConfig:   false,
		},
		// Edge case: empty pod yaml string
		"empty pod yaml": {
			podYaml:       "",
			expectErr:     true,
			writeManifest: true,
			validConfig:   true,
		},
		// Edge case: nil manifest (writeManifest false)
		"no manifest written": {
			expectErr:     true,
			writeManifest: false,
			validConfig:   true,
		},
	}

	// Override podYaml for cases that rely on hard‑coded pod specs
	for name, test := range tests {
		if idx, ok := nameToIdx[name]; ok && test.writeManifest {
			test.podYaml = yamls[idx]
			tests[name] = test
		}
	}
	// Log configuration info
	fmt.Println(ctestglobals.DebugPrefix(), "Prepared pod yaml configurations for test cases")
	fmt.Println(ctestglobals.DebugPrefix(), "Number of test cases:", len(tests))

	for name, test := range tests {
		t.Run(name, func(t *testing.T) {
			tmpdir := t.TempDir()
			manifestPath := filepath.Join(tmpdir, "etcd.yaml")
			if test.writeManifest {
				podYAML := test.podYaml
				if podYAML == "" {
					// use empty string for explicit edge case
					podYAML = ""
				}
				if err := os.WriteFile(manifestPath, []byte(podYAML), 0644); err != nil {
					t.Fatalf(dedent.Dedent("failed to write pod manifest\n%s\n\tfatal error: %v"), name, err)
				}
			}
			var dataDir string
			var err error
			if test.validConfig {
				cfg := &kubeadm.InitConfiguration{}
				dataDir, err = getEtcdDataDir(manifestPath, cfg)
			} else {
				dataDir, err = getEtcdDataDir(manifestPath, nil)
			}
			if (err != nil) != test.expectErr {
				t.Fatalf(dedent.Dedent(
					"getEtcdDataDir failed\n%s\nexpected error: %t\n\tgot: %t\nerror: %v"),
					name,
					test.expectErr,
					(err != nil),
					err,
				)
			}
			if dataDir != test.dataDir {
				t.Fatalf(dedent.Dedent("getEtcdDataDir failed\n%s\n\texpected: %s\ngot: %s"), name, test.dataDir, dataDir)
			}
		})
	}
	fmt.Println(ctestglobals.EndSeparator)
}

// getHardCodedConfigInfoEtcdDataDir returns the minimal pod specifications used by TestCtestGetEtcdDataDir.
func getHardCodedConfigInfoEtcdDataDir() ctestglobals.HardcodedConfig {
	return ctestglobals.HardcodedConfig{
		{
			FixtureFileName: "test_fixture.json",
			TestInfo:        []string{"valid etcd pod with data volume"},
			Field:           "volumes",
			K8sObjects:      []string{"pods"},
			HardcodedConfig: v1.Pod{
				Spec: v1.PodSpec{
					Volumes: []v1.Volume{
						{
							Name: "etcd-data",
							VolumeSource: v1.VolumeSource{
								HostPath: &v1.HostPathVolumeSource{
									Path: "/path/to/etcd",
									Type: func() *v1.HostPathType { t := v1.HostPathDirectoryOrCreate; return &t }(),
								},
							},
						},
						{
							Name: "etcd-certs",
							VolumeSource: v1.VolumeSource{
								HostPath: &v1.HostPathVolumeSource{
									Path: "/etc/kubernetes/pki/etcd",
									Type: func() *v1.HostPathType { t := v1.HostPathDirectoryOrCreate; return &t }(),
								},
							},
						},
					},
				},
			},
		},
		{
			FixtureFileName: "test_fixture.json",
			TestInfo:        []string{"etcd pod without data volume"},
			Field:           "volumes",
			K8sObjects:      []string{"pods"},
			HardcodedConfig: v1.Pod{
				Spec: v1.PodSpec{
					Volumes: []v1.Volume{
						{
							Name: "etcd-certs",
							VolumeSource: v1.VolumeSource{
								HostPath: &v1.HostPathVolumeSource{
									Path: "/etc/kubernetes/pki/etcd",
									Type: func() *v1.HostPathType { t := v1.HostPathDirectoryOrCreate; return &t }(),
								},
							},
						},
					},
				},
			},
		},
		{
			FixtureFileName: "test_fixture.json",
			TestInfo:        []string{"invalid etcd pod"},
			Field:           "volumes",
			K8sObjects:      []string{"pods"},
			HardcodedConfig: v1.Pod{
				// Intentionally empty / invalid spec
				Spec: v1.PodSpec{},
			},
		},
	}
}
