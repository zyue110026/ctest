package phases

import (
	"fmt"
	"strings"
	"testing"

	"k8s.io/component-base/version"
	"k8s.io/kubernetes/cmd/kubeadm/app/apis/kubeadm/v1beta4"
	"k8s.io/kubernetes/test/ctest/ctestglobals"
)

func TestCtestSetKubernetesVersion(t *testing.T) {
	fmt.Println(ctestglobals.StartSeparator)

	ver := version.Get().String()

	tests := []struct {
		name   string
		input  string
		output string
	}{
		{
			name:   "empty version is processed",
			input:  "",
			output: ver,
		},
		{
			name:   "default version is processed",
			input:  v1beta4.DefaultKubernetesVersion,
			output: ver,
		},
		{
			name:   "any other version is skipped",
			input:  "v1.12.0",
			output: "v1.12.0",
		},
		// Edge and invalid cases
		{
			name:   "whitespace version is treated as non-empty",
			input:  "   ",
			output: "   ",
		},
		{
			name:   "malformed version string is skipped",
			input:  "invalid-version",
			output: "invalid-version",
		},
		{
			name:   "very long version string is skipped",
			input:  "v" + "1." + strings.Repeat("0", 1000),
			output: "v" + "1." + strings.Repeat("0", 1000),
		},
		{
			name:   "pre-release version is skipped",
			input:  "v1.21.0-alpha.0",
			output: "v1.21.0-alpha.0",
		},
		{
			name:   "zero version is processed as empty after trim",
			input:  "v0.0.0",
			output: "v0.0.0",
		},
	}

	for i, tc := range tests {
		fmt.Printf("Running test case %d: %s\n", i, tc.name)
		t.Run(tc.name, func(t *testing.T) {
			cfg := &v1beta4.ClusterConfiguration{KubernetesVersion: tc.input}
			SetKubernetesVersion(cfg)
			if cfg.KubernetesVersion != tc.output {
				t.Fatalf("expected %q, got %q", tc.output, cfg.KubernetesVersion)
			}
		})
	}

	fmt.Println(ctestglobals.EndSeparator)
}
