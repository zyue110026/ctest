package cmd

import (
	"bytes"
	"fmt"
	"os"
	"path/filepath"
	"testing"
	"time"

	metav1 "k8s.io/apimachinery/pkg/apis/meta/v1"
	"k8s.io/client-go/tools/clientcmd"
	"sigs.k8s.io/yaml"

	kubeadmapiv1 "k8s.io/kubernetes/cmd/kubeadm/app/apis/kubeadm/v1beta4"
	kubeadmconstants "k8s.io/kubernetes/cmd/kubeadm/app/constants"
	kubeadmutil "k8s.io/kubernetes/cmd/kubeadm/app/util"
	"k8s.io/kubernetes/cmd/kubeadm/app/util/pkiutil"
	testutil "k8s.io/kubernetes/cmd/kubeadm/test"
	kubeconfigtestutil "k8s.io/kubernetes/cmd/kubeadm/test/kubeconfig"

	// "github.com/onsi/ginkgo/v2"
	// "github.com/onsi/gomega"

	ctest "k8s.io/kubernetes/test/ctest"
	ctestglobals "k8s.io/kubernetes/test/ctest/ctestglobals"
	ctestutils "k8s.io/kubernetes/test/ctest/utils"
)

// kubeadmConfigSpec contains only the fields that were hard‑coded in the original test.
// Additional fields (certificatesDir, clusterName) are supplied at call‑time.
type kubeadmConfigSpec struct {
	AdvertiseAddress string
	BindPort         int32
}

// generateTestKubeadmConfigFromSpec writes a temporary kubeadm config file
// using the supplied spec together with the dynamic certDir and clusterName.
func generateTestKubeadmConfigFromSpec(dir, id, certDir, clusterName string, spec kubeadmConfigSpec) (string, error) {
	cfgPath := filepath.Join(dir, id)

	initCfg := kubeadmapiv1.InitConfiguration{
		TypeMeta: metav1.TypeMeta{
			APIVersion: kubeadmapiv1.SchemeGroupVersion.String(),
			Kind:       "InitConfiguration",
		},
		LocalAPIEndpoint: kubeadmapiv1.APIEndpoint{
			AdvertiseAddress: spec.AdvertiseAddress,
			BindPort:         spec.BindPort,
		},
	}
	clusterCfg := kubeadmapiv1.ClusterConfiguration{
		TypeMeta: metav1.TypeMeta{
			APIVersion: kubeadmapiv1.SchemeGroupVersion.String(),
			Kind:       "ClusterConfiguration",
		},
		CertificatesDir:   certDir,
		ClusterName:       clusterName,
		KubernetesVersion: kubeadmconstants.MinimumControlPlaneVersion.String(),
	}

	var buf bytes.Buffer
	data, err := yaml.Marshal(&initCfg)
	if err != nil {
		return "", err
	}
	buf.Write(data)
	buf.WriteString("---\n")
	data, err = yaml.Marshal(&clusterCfg)
	if err != nil {
		return "", err
	}
	buf.Write(data)

	err = os.WriteFile(cfgPath, buf.Bytes(), 0644)
	return cfgPath, err
}

// getHardCodedConfigInfoKubeadmConfig returns the minimal hard‑coded init configuration.
// The returned HardcodedConfig is used by the ctest framework to generate extended/override
// configurations for the test.
func getHardCodedConfigInfoKubeadmConfig() ctestglobals.HardcodedConfig {
	return ctestglobals.HardcodedConfig{
		{
			FixtureFileName: "test_fixture.json",
			TestInfo:        []string{"default kubeadm config spec"},
			Field:           "kubeadmConfigSpec",
			K8sObjects:      []string{"pods"}, // objects that may reference the config (none in this test, placeholder)
			HardcodedConfig: kubeadmConfigSpec{
				AdvertiseAddress: "1.2.3.4",
				BindPort:         1234,
			},
		},
	}
}

func TestCtestKubeConfigSubCommandsThatWritesToOut(t *testing.T) {
	fmt.Println(ctestglobals.StartSeparator)

	// Retrieve the hard‑coded config info and obtain effective configs.
	item, found := ctestutils.GetItemByExactTestInfo(getHardCodedConfigInfoKubeadmConfig(), "default kubeadm config spec")
	if !found {
		fmt.Println(ctestglobals.DebugPrefix(), "Failed to find config item by TestInfo")
		t.Fatalf("Could not find hard‑coded config")
	}
	fmt.Println(ctestglobals.DebugPrefix(), "get default configs:", item)

	fmt.Println(ctestglobals.StartExtendModeSeparator)
	configObjs, configJson, err := ctest.GenerateEffectiveConfigReturnType[kubeadmConfigSpec](item, ctest.ExtendOnly)
	if err != nil {
		fmt.Println(ctestglobals.DebugPrefix(), "Failed to get matched fixtures: %v", err)
		t.Fatalf("GenerateEffectiveConfigReturnType failed: %v", err)
	}
	if configObjs == nil {
		fmt.Println(ctestglobals.DebugPrefix(), "Skipping test execution. No new configurations generated. ")
		fmt.Println(ctestglobals.EndSeparator)
		return
	}
	fmt.Println(ctestglobals.DebugPrefix(), "New Json Test Configs:", string(configJson))
	fmt.Println(ctestglobals.DebugPrefix(), "Number of test cases:", len(configObjs))

	// Original test cases
	originalTests := []struct {
		name                   string
		command                string
		clusterName            string
		withClientCert         bool
		withToken              bool
		additionalFlags        []string
		expectedValidityPeriod time.Duration
	}{
		{
			name:           "user subCommand withClientCert",
			command:        "user",
			withClientCert: true,
		},
		{
			name:           "user subCommand withClientCert",
			command:        "user",
			withClientCert: true,
			clusterName:    "my-cluster",
		},
		{
			name:            "user subCommand withToken",
			withToken:       true,
			command:         "user",
			additionalFlags: []string{"--token=123456"},
		},
		{
			name:            "user subCommand withToken",
			withToken:       true,
			command:         "user",
			clusterName:     "my-cluster-with-token",
			additionalFlags: []string{"--token=123456"},
		},
		{
			name:                   "user subCommand with validity period",
			withClientCert:         true,
			command:                "user",
			additionalFlags:        []string{"--validity-period=12h"},
			expectedValidityPeriod: 12 * time.Hour,
		},
	}

	// Edge / invalid variations (these only modify the kubeadm config spec)
	edgeConfigs := []kubeadmConfigSpec{
		// Empty advertise address
		{AdvertiseAddress: "", BindPort: 1234},
		// Zero bind port
		{AdvertiseAddress: "1.2.3.4", BindPort: 0},
		// Negative bind port (int32 allows negative values, but kubeadm will reject)
		{AdvertiseAddress: "1.2.3.4", BindPort: -1},
	}

	// Combine hard‑coded (extended/overridden) configs with edge configs
	allConfigs := append(configObjs, edgeConfigs...)

	// Temporary folders for the test case
	tmpdir := t.TempDir()
	pkidir := testutil.SetupPkiDirWithCertificateAuthority(t, tmpdir)

	caCert, _, err := pkiutil.TryLoadCertAndKeyFromDisk(pkidir, kubeadmconstants.CACertAndKeyBaseName)
	if err != nil {
		t.Fatalf("couldn't retrieve ca cert: %v", err)
	}

	for cfgIdx, cfgSpec := range allConfigs {
		for testIdx, test := range originalTests {
			t.Run(fmt.Sprintf("%s-config-%d-test-%d", test.name, cfgIdx, testIdx), func(t *testing.T) {
				buf := new(bytes.Buffer)
				cmd := newCmdUserKubeConfig(buf)

				// Use the test name as a unique identifier for the config file.
				cfgPath, err := generateTestKubeadmConfigFromSpec(tmpdir, fmt.Sprintf("%s-%d-%d", test.name, cfgIdx, testIdx), pkidir, test.clusterName, cfgSpec)
				if err != nil {
					t.Fatalf("Failed to generate kubeadm config: %v", err)
				}

				commonFlags := []string{
					"--client-name=myUser",
					fmt.Sprintf("--config=%s", cfgPath),
				}
				allFlags := append(commonFlags, test.additionalFlags...)
				cmd.SetArgs(allFlags)
				if err := cmd.Execute(); err != nil {
					t.Fatalf("Could not execute subcommand: %v", err)
				}

				config, err := clientcmd.Load(buf.Bytes())
				if err != nil {
					t.Fatalf("couldn't read kubeconfig file from buffer: %v", err)
				}

				kubeconfigtestutil.AssertKubeConfigCurrentCluster(t, config, fmt.Sprintf("https://%s:%d", cfgSpec.AdvertiseAddress, cfgSpec.BindPort), caCert)

				if test.withClientCert {
					if test.expectedValidityPeriod == 0 {
						test.expectedValidityPeriod = kubeadmconstants.CertificateValidityPeriod
					}
					startTime := kubeadmutil.StartTimeUTC()
					notAfter := startTime.Add(test.expectedValidityPeriod)
					kubeconfigtestutil.AssertKubeConfigCurrentAuthInfoWithClientCert(t, config, caCert, notAfter, "myUser")
				}

				if test.withToken {
					kubeconfigtestutil.AssertKubeConfigCurrentAuthInfoWithToken(t, config, "myUser", "123456")
				}

				if len(test.clusterName) > 0 {
					kubeconfigtestutil.AssertKubeConfigCurrentContextWithClusterName(t, config, test.clusterName)
				}
			})
		}
	}

	fmt.Println(ctestglobals.EndSeparator)
}
