//go:build windows
// +build windows

/*
Copyright 2019 The Kubernetes Authors.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
*/

package constants

const (
	// CRISocketContainerd is the containerd CRI endpoint
	CRISocketContainerd = "npipe:////./pipe/containerd-containerd"
	// CRISocketCRIO is the cri-o CRI endpoint
	// NOTE: this is a placeholder as CRI-O does not support Windows
	CRISocketCRIO = "npipe:////./pipe/cri-o"
	// CRISocketDocker is the cri-dockerd CRI endpoint
	CRISocketDocker = "npipe:////./pipe/cri-dockerd"

	// DefaultCRISocket defines the default CRI socket
	DefaultCRISocket = CRISocketContainerd
)
