package discovery

import (
	"fmt"
	"testing"
	"time"

	metav1 "k8s.io/apimachinery/pkg/apis/meta/v1"
	fakeclient "k8s.io/client-go/kubernetes/fake"
	"k8s.io/kubernetes/cmd/kubeadm/app/apis/kubeadm"

	ctest "k8s.io/kubernetes/test/ctest"
	ctestglobals "k8s.io/kubernetes/test/ctest/ctestglobals"
	ctestutils "k8s.io/kubernetes/test/ctest/utils"
)

func TestCtestFor(t *testing.T) {
	fmt.Println(ctestglobals.StartSeparator)

	tests := []struct {
		name      string
		testInfo  string
		expectNil bool // expect actual == nil
	}{
		{
			name:      "default Discovery",
			testInfo:  "default Discovery",
			expectNil: false,
		},
		{
			name:      "file Discovery with a path",
			testInfo:  "file Discovery with a path",
			expectNil: false,
		},
		{
			name:      "file Discovery with an url",
			testInfo:  "file Discovery with an url",
			expectNil: false,
		},
		{
			name:      "BootstrapTokenDiscovery",
			testInfo:  "BootstrapTokenDiscovery",
			expectNil: false,
		},
		// Edge / invalid cases
		{
			name:      "file Discovery empty path",
			testInfo:  "file Discovery empty path",
			expectNil: false,
		},
		{
			name:      "BootstrapToken empty token",
			testInfo:  "BootstrapToken empty token",
			expectNil: false,
		},
		{
			name:      "BootstrapToken nil discovery",
			testInfo:  "BootstrapToken nil discovery",
			expectNil: false,
		},
	}

	for _, tc := range tests {
		t.Run(tc.name, func(t *testing.T) {
			// Retrieve the hardcoded config for this test case
			item, found := ctestutils.GetItemByExactTestInfo(getHardCodedConfigInfoDiscovery(), tc.testInfo)
			if !found {
				fmt.Println(ctestglobals.DebugPrefix(), "Config item not found for:", tc.testInfo)
				t.Fatalf("hardcoded config missing for %s", tc.testInfo)
			}
			fmt.Println(ctestglobals.DebugPrefix(), "Matched config item:", item)

			// Generate effective config (ExtendOnly mode)
			configObjs, configJson, err := ctest.GenerateEffectiveConfigReturnType[kubeadm.JoinConfiguration](item, ctest.ExtendOnly)
			if err != nil {
				fmt.Println(ctestglobals.DebugPrefix(), "Generate config error:", err)
				t.Fatalf("failed to generate config for %s: %v", tc.testInfo, err)
			}
			if configObjs == nil || len(configObjs) == 0 {
				fmt.Println(ctestglobals.DebugPrefix(), "Skipping test execution. No new configurations generated.")
				return
			}
			fmt.Println(ctestglobals.DebugPrefix(), "New Json Test Configs:", string(configJson))
			fmt.Println(ctestglobals.DebugPrefix(), "Number of test cases:", len(configObjs))

			// Use the first (and only) generated config for this test case
			cfg := configObjs[0]
			fmt.Printf("Running test case \"%s\"\n", tc.testInfo)
			fmt.Println(cfg)

			// Set mandatory Timeout field (original test logic)
			cfg.Timeouts = &kubeadm.Timeouts{
				Discovery: &metav1.Duration{Duration: 1 * time.Minute},
			}
			client := fakeclient.NewSimpleClientset()
			_, actual := For(client, &cfg)

			// Original semantics: expect false => actual != nil, expect true => actual == nil
			if (actual == nil) != tc.expectNil {
				t.Errorf(
					"failed For for %s:\n\texpected nil: %t\n\tactual nil: %t",
					tc.name,
					tc.expectNil,
					actual == nil,
				)
			}
		})
	}
	fmt.Println(ctestglobals.EndSeparator)
}

// Hardcoded configurations for discovery tests.
// Each entry corresponds to a TestInfo used in the rewritten test above.
func getHardCodedConfigInfoDiscovery() ctestglobals.HardcodedConfig {
	return ctestglobals.HardcodedConfig{
		{
			FixtureFileName: "test_fixture.json",
			TestInfo:        []string{"default Discovery"},
			Field:           "discovery",
			K8sObjects:      []string{"pods"},
			HardcodedConfig: kubeadm.JoinConfiguration{},
		},
		{
			FixtureFileName: "test_fixture.json",
			TestInfo:        []string{"file Discovery with a path"},
			Field:           "discovery",
			K8sObjects:      []string{"pods"},
			HardcodedConfig: kubeadm.JoinConfiguration{
				Discovery: kubeadm.Discovery{
					File: &kubeadm.FileDiscovery{
						KubeConfigPath: "notnil",
					},
				},
			},
		},
		{
			FixtureFileName: "test_fixture.json",
			TestInfo:        []string{"file Discovery with an url"},
			Field:           "discovery",
			K8sObjects:      []string{"pods"},
			HardcodedConfig: kubeadm.JoinConfiguration{
				Discovery: kubeadm.Discovery{
					File: &kubeadm.FileDiscovery{
						KubeConfigPath: "https://localhost",
					},
				},
			},
		},
		{
			FixtureFileName: "test_fixture.json",
			TestInfo:        []string{"BootstrapTokenDiscovery"},
			Field:           "discovery",
			K8sObjects:      []string{"pods"},
			HardcodedConfig: kubeadm.JoinConfiguration{
				Discovery: kubeadm.Discovery{
					BootstrapToken: &kubeadm.BootstrapTokenDiscovery{
						Token: "foo.bar@foobar",
					},
				},
			},
		},
		// Edge / invalid configurations
		{
			FixtureFileName: "test_fixture.json",
			TestInfo:        []string{"file Discovery empty path"},
			Field:           "discovery",
			K8sObjects:      []string{"pods"},
			HardcodedConfig: kubeadm.JoinConfiguration{
				Discovery: kubeadm.Discovery{
					File: &kubeadm.FileDiscovery{
						KubeConfigPath: "",
					},
				},
			},
		},
		{
			FixtureFileName: "test_fixture.json",
			TestInfo:        []string{"BootstrapToken empty token"},
			Field:           "discovery",
			K8sObjects:      []string{"pods"},
			HardcodedConfig: kubeadm.JoinConfiguration{
				Discovery: kubeadm.Discovery{
					BootstrapToken: &kubeadm.BootstrapTokenDiscovery{
						Token: "",
					},
				},
			},
		},
		{
			FixtureFileName: "test_fixture.json",
			TestInfo:        []string{"BootstrapToken nil discovery"},
			Field:           "discovery",
			K8sObjects:      []string{"pods"},
			HardcodedConfig: kubeadm.JoinConfiguration{
				Discovery: kubeadm.Discovery{
					BootstrapToken: nil,
				},
			},
		},
	}
}