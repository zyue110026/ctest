package markcontrolplane

import (
	"bytes"
	"encoding/json"
	"fmt"
	"net/http"
	"net/http/httptest"
	"testing"

	v1 "k8s.io/api/core/v1"
	metav1 "k8s.io/apimachinery/pkg/apis/meta/v1"
	clientset "k8s.io/client-go/kubernetes"
	restclient "k8s.io/client-go/rest"

	kubeadmconstants "k8s.io/kubernetes/cmd/kubeadm/app/constants"

	ctest "k8s.io/kubernetes/test/ctest"
	ctestglobals "k8s.io/kubernetes/test/ctest/ctestglobals"
	ctestutils "k8s.io/kubernetes/test/ctest/utils"
)

type markControlPlaneTestConfig struct {
	existingLabels []string
	existingTaints []v1.Taint
	newTaints      []v1.Taint
	expectedPatch  string
}

func TestCtestMarkControlPlane(t *testing.T) {
	fmt.Println(ctestglobals.StartUnionModeSeparator)

	// Load hard‑coded base configurations
	hardcoded := getHardCodedConfigInfoMarkControlPlane()
	item, found := ctestutils.GetItemByExactTestInfo(hardcoded, "markcontrolplane base configs")
	if !found {
		fmt.Println(ctestglobals.DebugPrefix(), "Failed to find config item by TestInfo")
		t.Fatalf("hardcoded config not found")
	}
	fmt.Println(ctestglobals.DebugPrefix(), "get default configs:", item)

	configObjs, configJson, err := ctest.GenerateEffectiveConfigReturnType[markControlPlaneTestConfig](item, ctest.Union)
	if err != nil {
		fmt.Println(ctestglobals.DebugPrefix(), "Failed to get matched fixtures:", err)
		t.Fatalf("fixture generation error: %v", err)
	}
	if configObjs == nil {
		fmt.Println(ctestglobals.DebugPrefix(), "Skipping test execution. No new configurations generated.")
		return
	}
	fmt.Println(ctestglobals.DebugPrefix(), "New Json Test Configs:", string(configJson))
	fmt.Println(ctestglobals.DebugPrefix(), "Num of Test Cases:", len(configObjs))

	// Edge / invalid cases
	edgeConfigs := []markControlPlaneTestConfig{
		{
			existingLabels: []string{""},
			existingTaints: []v1.Taint{{Key: "", Effect: v1.TaintEffectNoSchedule}},
			newTaints:      []v1.Taint{{Key: "", Effect: ""}},
			expectedPatch:  `{"metadata":{"labels":{"node-role.kubernetes.io/control-plane":""}}}`,
		},
		{
			existingLabels: []string{"nonexistent-label"},
			existingTaints: nil,
			newTaints:      nil,
			expectedPatch:  `{}`,
		},
	}
	// Append edge cases to the list
	configObjs = append(configObjs, edgeConfigs...)

	fmt.Println(ctestglobals.DebugPrefix(), "Total Test Cases after adding edges:", len(configObjs))

	for i, cfg := range configObjs {
		fmt.Printf("Running %d th test case.\n", i)
		fmt.Println(cfg)

		nodename := "node01"
		controlPlaneNode := &v1.Node{
			ObjectMeta: metav1.ObjectMeta{
				Name: nodename,
				Labels: map[string]string{
					v1.LabelHostname: nodename,
				},
			},
		}

		// Apply existing labels from config
		for _, label := range cfg.existingLabels {
			controlPlaneNode.ObjectMeta.Labels[label] = ""
		}
		// Apply existing taints from config
		if cfg.existingTaints != nil {
			controlPlaneNode.Spec.Taints = cfg.existingTaints
		}

		jsonNode, err := json.Marshal(controlPlaneNode)
		if err != nil {
			t.Fatalf("unexpected encoding error: %v", err)
		}

		var patchRequest string
		s := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, req *http.Request) {
			w.Header().Set("Content-Type", "application/json")
			if req.URL.Path != "/api/v1/nodes/"+nodename {
				t.Errorf("request for unexpected HTTP resource: %v", req.URL.Path)
				http.Error(w, "", http.StatusNotFound)
				return
			}
			switch req.Method {
			case "GET":
			case "PATCH":
				buf := new(bytes.Buffer)
				_, _ = buf.ReadFrom(req.Body)
				patchRequest = buf.String()
			default:
				t.Errorf("request for unexpected HTTP verb: %v", req.Method)
				http.Error(w, "", http.StatusNotFound)
				return
			}
			w.WriteHeader(http.StatusOK)
			_, _ = w.Write(jsonNode)
		}))
		defer s.Close()

		cs, err := clientset.NewForConfig(&restclient.Config{Host: s.URL})
		if err != nil {
			t.Fatalf("unexpected error building clientset: %v", err)
		}

		if err := MarkControlPlane(cs, nodename, cfg.newTaints); err != nil {
			t.Errorf("unexpected error: %v", err)
		}
		if cfg.expectedPatch != patchRequest {
			t.Errorf("unexpected patch: wanted %v, got %v", cfg.expectedPatch, patchRequest)
		}
	}
	fmt.Println(ctestglobals.EndSeparator)
}

func getHardCodedConfigInfoMarkControlPlane() ctestglobals.HardcodedConfig {
	return ctestglobals.HardcodedConfig{
		{
			FixtureFileName: "test_fixture.json",
			TestInfo:        []string{"markcontrolplane base configs"},
			Field:           "node",
			K8sObjects:      []string{"nodes"},
			HardcodedConfig: []markControlPlaneTestConfig{
				{
					existingLabels: []string{""},
					existingTaints: nil,
					newTaints:      nil,
					expectedPatch:  `{"metadata":{"labels":{"node-role.kubernetes.io/control-plane":"","node.kubernetes.io/exclude-from-external-load-balancers":""}}}`,
				},
				{
					existingLabels: []string{
						kubeadmconstants.LabelNodeRoleControlPlane,
						kubeadmconstants.LabelExcludeFromExternalLB,
					},
					existingTaints: nil,
					newTaints:      []v1.Taint{kubeadmconstants.ControlPlaneTaint},
					expectedPatch:  `{"spec":{"taints":[{"effect":"NoSchedule","key":"node-role.kubernetes.io/control-plane"}]}}`,
				},
				{
					existingLabels: []string{
						kubeadmconstants.LabelNodeRoleControlPlane,
						kubeadmconstants.LabelExcludeFromExternalLB,
					},
					existingTaints: []v1.Taint{kubeadmconstants.ControlPlaneTaint},
					newTaints:      []v1.Taint{kubeadmconstants.ControlPlaneTaint},
					expectedPatch:  `{}`,
				},
				{
					existingLabels: []string{
						kubeadmconstants.LabelNodeRoleControlPlane,
						kubeadmconstants.LabelExcludeFromExternalLB,
					},
					existingTaints: []v1.Taint{
						{
							Key:    "node.cloudprovider.kubernetes.io/uninitialized",
							Effect: v1.TaintEffectNoSchedule,
						},
					},
					newTaints:     nil,
					expectedPatch: `{}`,
				},
				{
					existingLabels: []string{
						kubeadmconstants.LabelNodeRoleControlPlane,
						kubeadmconstants.LabelExcludeFromExternalLB,
					},
					existingTaints: []v1.Taint{
						{
							Key:    "node.cloudprovider.kubernetes.io/uninitialized",
							Effect: v1.TaintEffectNoSchedule,
						},
					},
					newTaints:     []v1.Taint{kubeadmconstants.ControlPlaneTaint},
					expectedPatch: `{"spec":{"taints":[{"effect":"NoSchedule","key":"node-role.kubernetes.io/control-plane"},{"effect":"NoSchedule","key":"node.cloudprovider.kubernetes.io/uninitialized"}]}}`,
				},
			},
		},
	}
}