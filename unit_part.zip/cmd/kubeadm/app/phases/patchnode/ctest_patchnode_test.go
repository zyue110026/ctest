package patchnode

import (
	"bytes"
	"encoding/json"
	"fmt"
	"net/http"
	"net/http/httptest"
	"testing"

	v1 "k8s.io/api/core/v1"
	metav1 "k8s.io/apimachinery/pkg/apis/meta/v1"
	clientset "k8s.io/client-go/kubernetes"
	restclient "k8s.io/client-go/rest"

	kubeadmconstants "k8s.io/kubernetes/cmd/kubeadm/app/constants"

	ctest "k8s.io/kubernetes/test/ctest"
	ctestglobals "k8s.io/kubernetes/test/ctest/ctestglobals"
	ctestutils "k8s.io/kubernetes/test/ctest/utils"
)

func TestCtestAnnotateCRISocket(t *testing.T) {
	fmt.Println(ctestglobals.StartSeparator)

	// Retrieve dynamic node configurations (override mode)
	hardcodedConfig := getHardCodedConfigInfoPatchNode()
	item, found := ctestutils.GetItemByExactTestInfo(hardcodedConfig, "default node")
	if !found {
		fmt.Println(ctestglobals.DebugPrefix(), "Failed to find config item by TestInfo")
		t.Fatalf("Get default hardcoded config failed.")
	}
	fmt.Println(ctestglobals.DebugPrefix(), "get default configs:", item)

	fmt.Println(ctestglobals.StartOverrideModeSeparator)
	configObjs, configJson, err := ctest.GenerateEffectiveConfigReturnType[v1.Node](item, ctest.OverrideOnly)
	if err != nil {
		fmt.Println(ctestglobals.DebugPrefix(), "Failed to get matched fixtures:", err)
		t.Fatalf("Failed to get matched fixtures: %v", err)
	}
	if configObjs == nil {
		fmt.Println(ctestglobals.DebugPrefix(), "Skipping test execution. No new configurations generated.")
		fmt.Println(ctestglobals.EndSeparator)
		return
	}
	fmt.Println(ctestglobals.DebugPrefix(), "New Json Test Configs:", string(configJson))
	fmt.Println(ctestglobals.DebugPrefix(), "Num of Test Cases:", len(configObjs))

	// Base test cases from original test
	baseTests := []struct {
		name                       string
		currentCRISocketAnnotation string
		newCRISocketAnnotation     string
		expectedPatch              string
	}{
		{
			name:                       "CRI-socket annotation missing",
			currentCRISocketAnnotation: "",
			newCRISocketAnnotation:     "unix:///run/containerd/containerd.sock",
			expectedPatch:              `{"metadata":{"annotations":{"kubeadm.alpha.kubernetes.io/cri-socket":"unix:///run/containerd/containerd.sock"}}}`,
		},
		{
			name:                       "CRI-socket annotation already exists",
			currentCRISocketAnnotation: "unix:///run/containerd/containerd.sock",
			newCRISocketAnnotation:     "unix:///run/containerd/containerd.sock",
			expectedPatch:              `{}`,
		},
		{
			name:                       "CRI-socket annotation needs to be updated",
			currentCRISocketAnnotation: "unix:///foo/bar",
			newCRISocketAnnotation:     "unix:///run/containerd/containerd.sock",
			expectedPatch:              `{"metadata":{"annotations":{"kubeadm.alpha.kubernetes.io/cri-socket":"unix:///run/containerd/containerd.sock"}}}`,
		},
	}
	// Edge / invalid test cases
	edgeTests := []struct {
		name                       string
		currentCRISocketAnnotation string
		newCRISocketAnnotation     string
		expectedPatch              string
	}{
		{
			name:                       "empty new CRI socket annotation",
			currentCRISocketAnnotation: "",
			newCRISocketAnnotation:     "",
			expectedPatch:              `{}`,
		},
		{
			name:                       "invalid format new CRI socket annotation",
			currentCRISocketAnnotation: "",
			newCRISocketAnnotation:     "invalid_format",
			expectedPatch:              `{"metadata":{"annotations":{"kubeadm.alpha.kubernetes.io/cri-socket":"invalid_format"}}}`,
		},
		{
			name:                       "excessively long CRI socket annotation",
			currentCRISocketAnnotation: "",
			newCRISocketAnnotation:     "unix:///run/containerd/" + string(make([]byte, 5000)),
			expectedPatch:              `{"metadata":{"annotations":{"kubeadm.alpha.kubernetes.io/cri-socket":"unix:///run/containerd/` + string(make([]byte, 5000)) + `"}}}`,
		},
	}

	// Merge base and edge tests
	tests := append(baseTests, edgeTests...)

	for cfgIdx, cfgNode := range configObjs {
		fmt.Printf("Running %d th config object.\n", cfgIdx)
		fmt.Println(cfgNode)

		for testIdx, tc := range tests {
			fmt.Printf("Running %d th test case: %s\n", testIdx, tc.name)
			t.Run(tc.name, func(t *testing.T) {
				nodename := "node01"
				// Clone the config node to avoid mutation across iterations
				node := cfgNode.DeepCopy()
				node.ObjectMeta.Name = nodename
				if node.ObjectMeta.Labels == nil {
					node.ObjectMeta.Labels = map[string]string{}
				}
				node.ObjectMeta.Labels[v1.LabelHostname] = nodename
				if node.ObjectMeta.Annotations == nil {
					node.ObjectMeta.Annotations = map[string]string{}
				}
				if tc.currentCRISocketAnnotation != "" {
					node.ObjectMeta.Annotations[kubeadmconstants.AnnotationKubeadmCRISocket] = tc.currentCRISocketAnnotation
				}

				jsonNode, err := json.Marshal(node)
				if err != nil {
					t.Fatalf("unexpected encoding error: %v", err)
				}

				var patchRequest string
				s := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, req *http.Request) {
					w.Header().Set("Content-Type", "application/json")
					if req.URL.Path != "/api/v1/nodes/"+nodename {
						t.Errorf("request for unexpected HTTP resource: %v", req.URL.Path)
						http.Error(w, "", http.StatusNotFound)
						return
					}
					switch req.Method {
					case "GET":
						// no body needed
					case "PATCH":
						buf := new(bytes.Buffer)
						buf.ReadFrom(req.Body)
						patchRequest = buf.String()
					default:
						t.Errorf("request for unexpected HTTP verb: %v", req.Method)
						http.Error(w, "", http.StatusNotFound)
						return
					}
					w.WriteHeader(http.StatusOK)
					w.Write(jsonNode)
				}))
				defer s.Close()

				cs, err := clientset.NewForConfig(&restclient.Config{Host: s.URL})
				if err != nil {
					t.Fatalf("unexpected error building clientset: %v", err)
				}

				if err := AnnotateCRISocket(cs, nodename, tc.newCRISocketAnnotation); err != nil {
					t.Errorf("unexpected error: %v", err)
				}
				if tc.expectedPatch != patchRequest {
					t.Errorf("expected patch %v, got %v", tc.expectedPatch, patchRequest)
				}
			})
		}
	}
	fmt.Println(ctestglobals.EndSeparator)
}

// Hardcoded configuration for a Node used in TestCtestAnnotateCRISocket.
// Only the metadata fields relevant to the test are provided.
func getHardCodedConfigInfoPatchNode() ctestglobals.HardcodedConfig {
	return ctestglobals.HardcodedConfig{
		{
			FixtureFileName: "test_fixture.json",
			TestInfo:        []string{"default node"},
			Field:           "annotations",
			K8sObjects:      []string{"nodes"},
			HardcodedConfig: v1.Node{
				ObjectMeta: metav1.ObjectMeta{
					Annotations: map[string]string{},
					Labels:      map[string]string{},
				},
			},
		},
	}
}