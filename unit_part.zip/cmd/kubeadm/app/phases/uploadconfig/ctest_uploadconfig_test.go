package uploadconfig

import (
	"context"
	"fmt"
	"reflect"
	"strconv"
	"testing"

	metav1 "k8s.io/apimachinery/pkg/apis/meta/v1"
	"k8s.io/apimachinery/pkg/runtime"
	clientsetfake "k8s.io/client-go/kubernetes/fake"

	kubeadmapi "k8s.io/kubernetes/cmd/kubeadm/app/apis/kubeadm"
	kubeadmscheme "k8s.io/kubernetes/cmd/kubeadm/app/apis/kubeadm/scheme"
	kubeadmconstants "k8s.io/kubernetes/cmd/kubeadm/app/constants"
	configutil "k8s.io/kubernetes/cmd/kubeadm/app/util/config"

	ctest "k8s.io/kubernetes/test/ctest"
	ctestglobals "k8s.io/kubernetes/test/ctest/ctestglobals"
	ctestutils "k8s.io/kubernetes/test/ctest/utils"
)

func TestCtestUploadConfiguration(t *testing.T) {
	fmt.Println(ctestglobals.DebugPrefix(), "Start TestCtestUploadConfiguration")
	hardcoded := getHardCodedConfigInfoUploadconfig()
	item, found := ctestutils.GetItemByExactTestInfo(hardcoded, "default cluster config")
	if !found {
		fmt.Println(ctestglobals.DebugPrefix(), "No hardcoded config found, skipping test")
		t.Skip("hardcoded config not found")
		return
	}
	fmt.Println(ctestglobals.DebugPrefix(), "Matched config:", item)
	fmt.Println(ctestglobals.StartOverrideModeSeparator)
	configObjs, configJson, err := ctest.GenerateEffectiveConfigReturnType[kubeadmapi.ClusterConfiguration](item, ctest.OverrideOnly)
	if err != nil {
		t.Fatalf("Failed to generate config: %v", err)
	}
	if configObjs == nil {
		fmt.Println(ctestglobals.DebugPrefix(), "Skipping test execution. No new configurations generated.")
		return
	}
	fmt.Println(ctestglobals.DebugPrefix(), "New Json Test Configs:", string(configJson))
	fmt.Println(ctestglobals.DebugPrefix(), "Number of test cases:", len(configObjs))

	testCases := []struct {
		name           string
		updateExisting bool
		verifyResult   bool
	}{
		{name: "basic validation with correct key", verifyResult: true},
		{name: "update existing should report no error", updateExisting: true, verifyResult: true},
		{name: "skip verification", verifyResult: false},
		{name: "update existing without verification", updateExisting: true, verifyResult: false},
	}

	for i, cfg := range configObjs {
		fmt.Printf("Running config #%d\n", i)
		fmt.Println(cfg)
		for i, tt := range testCases {
			tt := tt
			t.Run(fmt.Sprintf("%s-%d", tt.name, i), func(t2 *testing.T) {
				initCfg, err := configutil.DefaultedStaticInitConfiguration()
				if err != nil {
					t2.Fatalf("DefaultedStaticInitConfiguration error = %v", err)
				}
				initCfg.ClusterConfiguration = cfg
				initCfg.ComponentConfigs = kubeadmapi.ComponentConfigMap{}
				initCfg.NodeRegistration.Name = "node-" + strconv.Itoa(i)
				initCfg.NodeRegistration.CRISocket = kubeadmconstants.DefaultCRISocket

				client := clientsetfake.NewSimpleClientset()
				if err := UploadConfiguration(initCfg, client); err != nil {
					t2.Fatalf("UploadConfiguration error = %v", err)
				}
				if tt.updateExisting {
					if err := UploadConfiguration(initCfg, client); err != nil {
						t2.Fatalf("UploadConfiguration (update) error = %v", err)
					}
				}
				if tt.verifyResult {
					cm, err := client.CoreV1().ConfigMaps(metav1.NamespaceSystem).Get(context.TODO(), kubeadmconstants.KubeadmConfigConfigMap, metav1.GetOptions{})
					if err != nil {
						t2.Fatalf("Get ConfigMap error = %v", err)
					}
					data := cm.Data[kubeadmconstants.ClusterConfigurationConfigMapKey]
					if data == "" {
						t2.Fatal("ClusterConfigurationConfigMapKey data missing")
					}
					decoded := &kubeadmapi.ClusterConfiguration{}
					if err := runtime.DecodeInto(kubeadmscheme.Codecs.UniversalDecoder(), []byte(data), decoded); err != nil {
						t2.Fatalf("Decode error = %v", err)
					}
					decoded.ComponentConfigs = kubeadmapi.ComponentConfigMap{}
					if !reflect.DeepEqual(decoded, &initCfg.ClusterConfiguration) {
						t2.Errorf("decoded config does not match initial config: %#v vs %#v", decoded, &initCfg.ClusterConfiguration)
					}
				}
			})
		}
	}
	fmt.Println(ctestglobals.EndSeparator)
}

func getHardCodedConfigInfoUploadconfig() ctestglobals.HardcodedConfig {
	return ctestglobals.HardcodedConfig{
		{
			FixtureFileName: "test_fixture.json",
			TestInfo:        []string{"default cluster config"},
			Field:           "kubernetesVersion",
			K8sObjects:      []string{"configmaps"},
			HardcodedConfig: &kubeadmapi.ClusterConfiguration{
				KubernetesVersion: kubeadmconstants.MinimumControlPlaneVersion.WithPatch(10).String(),
			},
		},
	}
}
