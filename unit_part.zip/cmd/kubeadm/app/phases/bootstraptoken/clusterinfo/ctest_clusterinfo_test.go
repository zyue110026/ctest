package clusterinfo

import (
	"bytes"
	"context"
	"fmt"
	"testing"
	// "text/template"
	"time"

	rbac "k8s.io/api/rbac/v1"
	apierrors "k8s.io/apimachinery/pkg/api/errors"
	metav1 "k8s.io/apimachinery/pkg/apis/meta/v1"
	"k8s.io/apimachinery/pkg/runtime"
	"k8s.io/apimachinery/pkg/runtime/schema"
	"k8s.io/apiserver/pkg/authentication/user"
	clientsetfake "k8s.io/client-go/kubernetes/fake"
	core "k8s.io/client-go/testing"
	"k8s.io/client-go/tools/clientcmd"
	bootstrapapi "k8s.io/cluster-bootstrap/token/api"

	kubeadmapi "k8s.io/kubernetes/cmd/kubeadm/app/apis/kubeadm"

	ctest "k8s.io/kubernetes/test/ctest"
	ctestglobals "k8s.io/kubernetes/test/ctest/ctestglobals"
	ctestutils "k8s.io/kubernetes/test/ctest/utils"
)

func TestCtestCreateBootstrapConfigMapIfNotExists(t *testing.T) {
	fmt.Println(ctestglobals.StartExtendModeSeparator)
	tests := []struct {
		name      string
		createErr error
		expectErr bool
	}{
		{
			name:      "successful case should have no error",
			createErr: nil,
			expectErr: false,
		},
		{
			name:      "if configmap already exists, return error",
			createErr: apierrors.NewAlreadyExists(schema.GroupResource{Resource: "configmaps"}, "test"),
			expectErr: true,
		},
		{
			name:      "unexpected error should be returned",
			createErr: apierrors.NewUnauthorized("go away!"),
			expectErr: true,
		},
		{
			name:      "unexpected nil error should be treated as success",
			createErr: nil,
			expectErr: false,
		},
	}

	servers := []struct {
		Server string
	}{
		{Server: "https://10.128.0.6:6443"},
		{Server: "https://[2001:db8::6]:3446"},
		{Server: ""}, // edge case: empty server URL
	}

	for _, server := range servers {
		var buf bytes.Buffer

		if err := testConfigTempl.Execute(&buf, server); err != nil {
			t.Fatalf("could not write to tempfile: %v", err)
		}

		// Override the default timeouts to be shorter
		defaultTimeouts := kubeadmapi.GetActiveTimeouts()
		defaultAPICallTimeout := defaultTimeouts.KubernetesAPICall
		defaultTimeouts.KubernetesAPICall = &metav1.Duration{Duration: time.Microsecond * 500}
		defer func() {
			defaultTimeouts.KubernetesAPICall = defaultAPICallTimeout
		}()

		for _, tc := range tests {
			t.Run(tc.name, func(t *testing.T) {
				client := clientsetfake.NewSimpleClientset()
				if tc.createErr != nil {
					client.PrependReactor("create", "configmaps", func(action core.Action) (bool, runtime.Object, error) {
						return true, nil, tc.createErr
					})
				}
				kubeconfig, err := clientcmd.Load(buf.Bytes())
				if err != nil {
					t.Fatal(err)
				}
				err = CreateBootstrapConfigMapIfNotExists(client, kubeconfig)
				if tc.expectErr && err == nil {
					t.Errorf("CreateBootstrapConfigMapIfNotExists(%s) wanted error, got nil", tc.name)
				} else if !tc.expectErr && err != nil {
					t.Errorf("CreateBootstrapConfigMapIfNotExists(%s) returned unexpected error: %v", tc.name, err)
				}
			})
		}
	}
	fmt.Println(ctestglobals.EndSeparator)
}

func TestCtestCreateClusterInfoRBACRules(t *testing.T) {
	fmt.Println(ctestglobals.StartExtendModeSeparator)
	tests := []struct {
		name   string
		client *clientsetfake.Clientset
	}{
		{
			name:   "the RBAC rules already exist",
			client: newMockClientForCTest(t),
		},
		{
			name:   "the RBAC rules do not exist",
			client: clientsetfake.NewSimpleClientset(),
		},
		{
			name:   "client with nil namespace (edge case)",
			client: clientsetfake.NewSimpleClientset(),
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			if err := CreateClusterInfoRBACRules(tt.client); err != nil {
				t.Errorf("CreateClusterInfoRBACRules() hits unexpected error: %v", err)
			}
		})
	}
	fmt.Println(ctestglobals.EndSeparator)
}

func newMockClientForCTest(t *testing.T) *clientsetfake.Clientset {
	fmt.Println(ctestglobals.DebugPrefix(), "Generating hardcoded RBAC role from fixture")
	hardcoded := getHardCodedConfigInfoClusterInfoRBAC()
	item, found := ctestutils.GetItemByExactTestInfo(hardcoded, "default rbac role")
	if !found {
		fmt.Println(ctestglobals.DebugPrefix(), "Failed to find hardcoded RBAC config")
		t.Fatalf("hardcoded RBAC config not found")
	}
	fmt.Println(ctestglobals.DebugPrefix(), "Matched config item:", item)

	configObjs, configJson, err := ctest.GenerateEffectiveConfigReturnType[rbac.Role](item, ctest.ExtendOnly)
	if err != nil {
		fmt.Println(ctestglobals.DebugPrefix(), "Failed to generate effective config:", err)
		t.Fatalf("config generation error: %v", err)
	}
	fmt.Println(ctestglobals.DebugPrefix(), "New Json Test Configs:", string(configJson))

	var role *rbac.Role
	if configObjs != nil && len(configObjs) > 0 {
		role = &configObjs[0]
	} else {
		// Fallback to the original hardcoded definition
		role = &rbac.Role{
			ObjectMeta: metav1.ObjectMeta{
				Name:      BootstrapSignerClusterRoleName,
				Namespace: metav1.NamespacePublic,
			},
			Rules: []rbac.PolicyRule{
				{
					Verbs:         []string{"get"},
					APIGroups:     []string{""},
					Resources:     []string{"Secret"},
					ResourceNames: []string{bootstrapapi.ConfigMapClusterInfo},
				},
			},
		}
	}
	client := clientsetfake.NewSimpleClientset()

	_, err = client.RbacV1().Roles(metav1.NamespacePublic).Create(context.TODO(), role, metav1.CreateOptions{})
	if err != nil {
		t.Fatalf("error creating role: %v", err)
	}

	_, err = client.RbacV1().RoleBindings(metav1.NamespacePublic).Create(context.TODO(), &rbac.RoleBinding{
		ObjectMeta: metav1.ObjectMeta{
			Name:      BootstrapSignerClusterRoleName,
			Namespace: metav1.NamespacePublic,
		},
		RoleRef: rbac.RoleRef{
			APIGroup: rbac.GroupName,
			Kind:     "Role",
			Name:     BootstrapSignerClusterRoleName,
		},
		Subjects: []rbac.Subject{
			{
				Kind: rbac.UserKind,
				Name: user.Anonymous,
			},
		},
	}, metav1.CreateOptions{})
	if err != nil {
		t.Fatalf("error creating rolebinding: %v", err)
	}

	return client
}

func getHardCodedConfigInfoClusterInfoRBAC() ctestglobals.HardcodedConfig {
	return ctestglobals.HardcodedConfig{{
		FixtureFileName: "test_fixture.json",
		TestInfo:        []string{"default rbac role"},
		Field:           "rules",
		K8sObjects: []string{
			"roles",
			"rolebindings",
		},
		HardcodedConfig: rbac.Role{
			ObjectMeta: metav1.ObjectMeta{
				Name:      BootstrapSignerClusterRoleName,
				Namespace: metav1.NamespacePublic,
			},
			Rules: []rbac.PolicyRule{
				{
					Verbs:         []string{"get"},
					APIGroups:     []string{""},
					Resources:     []string{"Secret"},
					ResourceNames: []string{bootstrapapi.ConfigMapClusterInfo},
				},
			},
		},
	}}
}
