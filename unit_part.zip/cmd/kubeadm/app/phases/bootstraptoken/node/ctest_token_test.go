package node

import (
	"context"
	"fmt"
	"testing"

	v1 "k8s.io/api/core/v1"
	metav1 "k8s.io/apimachinery/pkg/apis/meta/v1"
	clientsetfake "k8s.io/client-go/kubernetes/fake"

	bootstraptokenv1 "k8s.io/kubernetes/cmd/kubeadm/app/apis/bootstraptoken/v1"

	ctest "k8s.io/kubernetes/test/ctest"
	ctestglobals "k8s.io/kubernetes/test/ctest/ctestglobals"
	ctestutils "k8s.io/kubernetes/test/ctest/utils"
)

func TestCtestUpdateOrCreateTokens(t *testing.T) {
	fmt.Println(ctestglobals.StartSeparator)

	hardcodedConfig := getHardCodedConfigInfoBootstrapTokenSecret()
	item, found := ctestutils.GetItemByExactTestInfo(hardcodedConfig, "default bootstrap secret")
	if !found {
		t.Fatalf("hardcoded config not found")
	}
	fmt.Println(ctestglobals.DebugPrefix(), "get default configs:", item)

	fmt.Println(ctestglobals.StartOverrideModeSeparator)
	secretObjs, secretJson, err := ctest.GenerateEffectiveConfigReturnType[v1.Secret](item, ctest.OverrideOnly)
	if err != nil {
		t.Fatalf("error generating effective config: %v", err)
	}
	if secretObjs == nil {
		fmt.Println(ctestglobals.DebugPrefix(), "Skipping test execution. No new configurations generated.")
		fmt.Println(ctestglobals.EndSeparator)
		return
	}
	fmt.Println(ctestglobals.DebugPrefix(), "New Json Test Configs:", string(secretJson))
	fmt.Println(ctestglobals.DebugPrefix(), "Number of Test Cases:", len(secretObjs))

	// original test cases
	originalTests := []struct {
		name         string
		failIfExists bool
		tokens       []bootstraptokenv1.BootstrapToken
		wantErr      bool
	}{
		{
			name:         "token is nil",
			failIfExists: true,
			tokens:       []bootstraptokenv1.BootstrapToken{},
			wantErr:      false,
		},
		{
			name:         "create secret which does not exist",
			failIfExists: true,
			tokens: []bootstraptokenv1.BootstrapToken{
				{
					Token: &bootstraptokenv1.BootstrapTokenString{
						ID:     "token1",
						Secret: "token1data",
					},
				},
			},
			wantErr: false,
		},
		{
			name:         "create multiple secrets which do not exist",
			failIfExists: true,
			tokens: []bootstraptokenv1.BootstrapToken{
				{
					Token: &bootstraptokenv1.BootstrapTokenString{
						ID:     "token1",
						Secret: "token1data",
					},
				},
				{
					Token: &bootstraptokenv1.BootstrapTokenString{
						ID:     "token2",
						Secret: "token2data",
					},
				},
				{
					Token: &bootstraptokenv1.BootstrapTokenString{
						ID:     "token3",
						Secret: "token3data",
					},
				},
			},
			wantErr: false,
		},
		{
			name:         "create secret which exists, failIfExists is false",
			failIfExists: false,
			tokens: []bootstraptokenv1.BootstrapToken{
				{
					Token: &bootstraptokenv1.BootstrapTokenString{
						ID:     "foo",
						Secret: "bar",
					},
				},
			},
			wantErr: false,
		},
		{
			name:         "create secret which exists, failIfExists is true",
			failIfExists: true,
			tokens: []bootstraptokenv1.BootstrapToken{
				{
					Token: &bootstraptokenv1.BootstrapTokenString{
						ID:     "foo",
						Secret: "bar",
					},
				},
			},
			wantErr: true,
		},
	}

	// edge and invalid test cases
	edgeTests := []struct {
		name         string
		failIfExists bool
		tokens       []bootstraptokenv1.BootstrapToken
		wantErr      bool
	}{
		{
			name:         "nil token slice",
			failIfExists: true,
			tokens:       nil,
			wantErr:      false,
		},
		{
			name:         "token with nil Token pointer",
			failIfExists: true,
			tokens: []bootstraptokenv1.BootstrapToken{
				{Token: nil},
			},
			wantErr: true,
		},
		{
			name:         "token with empty ID",
			failIfExists: true,
			tokens: []bootstraptokenv1.BootstrapToken{
				{
					Token: &bootstraptokenv1.BootstrapTokenString{
						ID:     "",
						Secret: "data",
					},
				},
			},
			wantErr: true,
		},
		{
			name:         "token with empty Secret",
			failIfExists: true,
			tokens: []bootstraptokenv1.BootstrapToken{
				{
					Token: &bootstraptokenv1.BootstrapTokenString{
						ID:     "id1",
						Secret: "",
					},
				},
			},
			wantErr: true,
		},
		{
			name:         "duplicate token IDs",
			failIfExists: false,
			tokens: []bootstraptokenv1.BootstrapToken{
				{
					Token: &bootstraptokenv1.BootstrapTokenString{
						ID:     "dup",
						Secret: "s1",
					},
				},
				{
					Token: &bootstraptokenv1.BootstrapTokenString{
						ID:     "dup",
						Secret: "s2",
					},
				},
			},
			wantErr: true,
		},
	}

	// combine all test cases
	allTests := append(originalTests, edgeTests...)

	for i, sec := range secretObjs {
		fmt.Printf("Running %d th test cases.\n", i)
		fmt.Println(sec)

		for _, tc := range allTests {
			tc := tc // capture range variable
			t.Run(tc.name, func(t *testing.T) {
				// fresh client per sub-test
				client := clientsetfake.NewSimpleClientset()
				_, err := client.CoreV1().Secrets(metav1.NamespaceSystem).Create(context.TODO(), &sec, metav1.CreateOptions{})
				if err != nil {
					t.Fatalf("error creating secret: %v", err)
				}
				if err := UpdateOrCreateTokens(client, tc.failIfExists, tc.tokens); (err != nil) != tc.wantErr {
					t.Fatalf("UpdateOrCreateTokens() error = %v, wantErr %v", err, tc.wantErr)
				}
			})
		}
	}
	fmt.Println(ctestglobals.EndSeparator)
}

// getHardCodedConfigInfoBootstrapTokenSecret returns minimal hardcoded secret configuration used by the test.
func getHardCodedConfigInfoBootstrapTokenSecret() ctestglobals.HardcodedConfig {
	return ctestglobals.HardcodedConfig{{
		FixtureFileName: "test_fixture.json",
		TestInfo:        []string{"default bootstrap secret"},
		Field:           "data",
		K8sObjects:      []string{"secrets"},
		HardcodedConfig: v1.Secret{
			TypeMeta: metav1.TypeMeta{
				Kind:       "Secret",
				APIVersion: "v1",
			},
			ObjectMeta: metav1.ObjectMeta{
				Name:      "bootstrap-token-foo",
				Labels:    map[string]string{"app": "foo"},
				Namespace: metav1.NamespaceSystem,
			},
			Data: map[string][]byte{"foo": {'f', 'o', 'o'}},
		},
	}}
}