package node

import (
	// "context"
	"fmt"
	"testing"

	rbac "k8s.io/api/rbac/v1"
	metav1 "k8s.io/apimachinery/pkg/apis/meta/v1"
	clientset "k8s.io/client-go/kubernetes"
	clientsetfake "k8s.io/client-go/kubernetes/fake"

	"k8s.io/kubernetes/cmd/kubeadm/app/constants"

	ctest "k8s.io/kubernetes/test/ctest"
	ctestglobals "k8s.io/kubernetes/test/ctest/ctestglobals"
	ctestutils "k8s.io/kubernetes/test/ctest/utils"
)

func TestCtestAllowBootstrapTokensToPostCSRs(t *testing.T) {
	fmt.Println(ctestglobals.StartExtendModeSeparator)
	hc := getHardCodedConfigInfoAllowBootstrapTokens()
	item, found := ctestutils.GetItemByExactTestInfo(hc, "existing binding")
	if !found {
		t.Fatalf("hardcoded config not found")
	}
	fmt.Println(ctestglobals.DebugPrefix(), "get default configs:", item)
	configObjs, configJson, err := ctest.GenerateEffectiveConfigReturnType[*rbac.ClusterRoleBinding](item, ctest.ExtendOnly)
	if err != nil {
		t.Fatalf("GenerateEffectiveConfigReturnType error: %v", err)
	}
	fmt.Println(ctestglobals.DebugPrefix(), "New Json Test Configs:", string(configJson))
	fmt.Println(ctestglobals.DebugPrefix(), "Num of config objs:", len(configObjs))

	tests := []struct {
		name   string
		client clientset.Interface
	}{
		{
			name:   "ClusterRoleBindings is empty",
			client: clientsetfake.NewSimpleClientset(),
		},
	}

	// use generated configs
	for i, cfg := range configObjs {
		client := newMockClusterRoleBinddingClientForTest(t, cfg)
		tests = append(tests, struct {
			name   string
			client clientset.Interface
		}{
			name:   fmt.Sprintf("generated config %d", i),
			client: client,
		})
	}

	// edge case: empty name
	edgeEmptyName := &rbac.ClusterRoleBinding{
		ObjectMeta: metav1.ObjectMeta{
			Name: "",
		},
		RoleRef: rbac.RoleRef{
			APIGroup: rbac.GroupName,
			Kind:     "ClusterRole",
			Name:     constants.NodeBootstrapperClusterRoleName,
		},
		Subjects: []rbac.Subject{
			{Kind: rbac.GroupKind, Name: constants.NodeBootstrapTokenAuthGroup},
		},
	}
	tests = append(tests, struct {
		name   string
		client clientset.Interface
	}{
		name:   "edge empty name",
		client: newMockClusterRoleBinddingClientForTest(t, edgeEmptyName),
	})

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			if err := AllowBootstrapTokensToPostCSRs(tt.client); err != nil {
				t.Errorf("AllowBootstrapTokensToPostCSRs() return error = %v", err)
			}
		})
	}
	fmt.Println(ctestglobals.EndSeparator)
}

func TestCtestAutoApproveNodeBootstrapTokens(t *testing.T) {
	fmt.Println(ctestglobals.StartExtendModeSeparator)
	hc := getHardCodedConfigInfoAutoApproveBootstrapTokens()
	item, found := ctestutils.GetItemByExactTestInfo(hc, "existing binding")
	if !found {
		t.Fatalf("hardcoded config not found")
	}
	fmt.Println(ctestglobals.DebugPrefix(), "get default configs:", item)
	configObjs, configJson, err := ctest.GenerateEffectiveConfigReturnType[*rbac.ClusterRoleBinding](item, ctest.ExtendOnly)
	if err != nil {
		t.Fatalf("GenerateEffectiveConfigReturnType error: %v", err)
	}
	fmt.Println(ctestglobals.DebugPrefix(), "New Json Test Configs:", string(configJson))
	fmt.Println(ctestglobals.DebugPrefix(), "Num of config objs:", len(configObjs))

	tests := []struct {
		name   string
		client clientset.Interface
	}{
		{
			name:   "ClusterRoleBindings is empty",
			client: clientsetfake.NewSimpleClientset(),
		},
	}
	for i, cfg := range configObjs {
		client := newMockClusterRoleBinddingClientForTest(t, cfg)
		tests = append(tests, struct {
			name   string
			client clientset.Interface
		}{
			name:   fmt.Sprintf("generated config %d", i),
			client: client,
		})
	}
	// edge: missing RoleRef name
	edgeMissingRoleRef := &rbac.ClusterRoleBinding{
		ObjectMeta: metav1.ObjectMeta{
			Name: constants.NodeAutoApproveBootstrapClusterRoleBinding,
		},
		RoleRef: rbac.RoleRef{
			APIGroup: rbac.GroupName,
			Kind:     "ClusterRole",
			Name:     "",
		},
		Subjects: []rbac.Subject{
			{Kind: rbac.GroupKind, Name: constants.NodeBootstrapTokenAuthGroup},
		},
	}
	tests = append(tests, struct {
		name   string
		client clientset.Interface
	}{
		name:   "edge missing roleRef name",
		client: newMockClusterRoleBinddingClientForTest(t, edgeMissingRoleRef),
	})

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			if err := AutoApproveNodeBootstrapTokens(tt.client); err != nil {
				t.Errorf("AutoApproveNodeBootstrapTokens() return error = %v", err)
			}
		})
	}
	fmt.Println(ctestglobals.EndSeparator)
}

func TestCtestAutoApproveNodeCertificateRotation(t *testing.T) {
	fmt.Println(ctestglobals.StartExtendModeSeparator)
	hc := getHardCodedConfigInfoAutoApproveNodeCertRotation()
	item, found := ctestutils.GetItemByExactTestInfo(hc, "existing binding")
	if !found {
		t.Fatalf("hardcoded config not found")
	}
	fmt.Println(ctestglobals.DebugPrefix(), "get default configs:", item)
	configObjs, configJson, err := ctest.GenerateEffectiveConfigReturnType[*rbac.ClusterRoleBinding](item, ctest.ExtendOnly)
	if err != nil {
		t.Fatalf("GenerateEffectiveConfigReturnType error: %v", err)
	}
	fmt.Println(ctestglobals.DebugPrefix(), "New Json Test Configs:", string(configJson))
	fmt.Println(ctestglobals.DebugPrefix(), "Num of config objs:", len(configObjs))

	tests := []struct {
		name   string
		client clientset.Interface
	}{
		{
			name:   "ClusterRoleBindings is empty",
			client: clientsetfake.NewSimpleClientset(),
		},
	}
	for i, cfg := range configObjs {
		client := newMockClusterRoleBinddingClientForTest(t, cfg)
		tests = append(tests, struct {
			name   string
			client clientset.Interface
		}{
			name:   fmt.Sprintf("generated config %d", i),
			client: client,
		})
	}
	// edge: nil subjects
	edgeNilSubjects := &rbac.ClusterRoleBinding{
		ObjectMeta: metav1.ObjectMeta{
			Name: constants.NodeAutoApproveCertificateRotationClusterRoleBinding,
		},
		RoleRef: rbac.RoleRef{
			APIGroup: rbac.GroupName,
			Kind:     "ClusterRole",
			Name:     constants.NodeSelfCSRAutoApprovalClusterRoleName,
		},
		Subjects: nil,
	}
	tests = append(tests, struct {
		name   string
		client clientset.Interface
	}{
		name:   "edge nil subjects",
		client: newMockClusterRoleBinddingClientForTest(t, edgeNilSubjects),
	})

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			if err := AutoApproveNodeCertificateRotation(tt.client); err != nil {
				t.Errorf("AutoApproveNodeCertificateRotation() return error = %v", err)
			}
		})
	}
	fmt.Println(ctestglobals.EndSeparator)
}

func TestCtestAllowBootstrapTokensToGetNodes(t *testing.T) {
	fmt.Println(ctestglobals.StartExtendModeSeparator)
	hc := getHardCodedConfigInfoAllowBootstrapTokensGetNodes()
	item, found := ctestutils.GetItemByExactTestInfo(hc, "existing RBAC")
	if !found {
		t.Fatalf("hardcoded config not found")
	}
	fmt.Println(ctestglobals.DebugPrefix(), "get default configs:", item)
	configObjs, configJson, err := ctest.GenerateEffectiveConfigReturnType[*rbac.ClusterRoleBinding](item, ctest.ExtendOnly)
	if err != nil {
		t.Fatalf("GenerateEffectiveConfigReturnType error: %v", err)
	}
	fmt.Println(ctestglobals.DebugPrefix(), "New Json Test Configs:", string(configJson))
	fmt.Println(ctestglobals.DebugPrefix(), "Num of config objs:", len(configObjs))

	tests := []struct {
		name   string
		client clientset.Interface
	}{
		{
			name:   "RBAC rules are empty",
			client: clientsetfake.NewSimpleClientset(),
		},
	}
	for i, cfg := range configObjs {
		client := newMockRbacClientForTest(t,
			&rbac.ClusterRole{
				ObjectMeta: metav1.ObjectMeta{
					Name: constants.GetNodesClusterRoleName,
				},
				Rules: []rbac.PolicyRule{
					{
						Verbs:     []string{"get"},
						APIGroups: []string{""},
						Resources: []string{"nodes"},
					},
				},
			},
			cfg,
		)
		tests = append(tests, struct {
			name   string
			client clientset.Interface
		}{
			name:   fmt.Sprintf("generated config %d", i),
			client: client,
		})
	}
	// edge: rule with unknown verb
	edgeUnknownVerb := &rbac.ClusterRoleBinding{
		ObjectMeta: metav1.ObjectMeta{
			Name: constants.GetNodesClusterRoleName,
		},
		RoleRef: rbac.RoleRef{
			APIGroup: rbac.GroupName,
			Kind:     "ClusterRole",
			Name:     constants.GetNodesClusterRoleName,
		},
		Subjects: []rbac.Subject{
			{Kind: rbac.GroupKind, Name: constants.NodeBootstrapTokenAuthGroup},
		},
	}
	tests = append(tests, struct {
		name   string
		client clientset.Interface
	}{
		name: "edge unknown verb",
		client: newMockRbacClientForTest(t,
			&rbac.ClusterRole{
				ObjectMeta: metav1.ObjectMeta{
					Name: constants.GetNodesClusterRoleName,
				},
				Rules: []rbac.PolicyRule{
					{
						Verbs:     []string{"unknown"},
						APIGroups: []string{""},
						Resources: []string{"nodes"},
					},
				},
			},
			edgeUnknownVerb,
		),
	})

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			if err := AllowBootstrapTokensToGetNodes(tt.client); err != nil {
				t.Errorf("AllowBootstrapTokensToGetNodes() return error = %v", err)
			}
		})
	}
	fmt.Println(ctestglobals.EndSeparator)
}

/* Hardcoded config generators */

func getHardCodedConfigInfoAllowBootstrapTokens() ctestglobals.HardcodedConfig {
	return ctestglobals.HardcodedConfig{
		{
			FixtureFileName: "test_fixture.json",
			TestInfo:        []string{"existing binding"},
			Field:           "",
			K8sObjects:      []string{"clusterrolebindings"},
			HardcodedConfig: &rbac.ClusterRoleBinding{
				ObjectMeta: metav1.ObjectMeta{
					Name: constants.NodeKubeletBootstrap,
				},
				RoleRef: rbac.RoleRef{
					APIGroup: rbac.GroupName,
					Kind:     "ClusterRole",
					Name:     constants.NodeBootstrapperClusterRoleName,
				},
				Subjects: []rbac.Subject{
					{Kind: rbac.GroupKind, Name: constants.NodeBootstrapTokenAuthGroup},
				},
			},
		},
		{
			FixtureFileName: "test_fixture.json",
			TestInfo:        []string{"create new binding"},
			Field:           "",
			K8sObjects:      []string{"clusterrolebindings"},
			HardcodedConfig: &rbac.ClusterRoleBinding{
				ObjectMeta: metav1.ObjectMeta{
					Name: constants.NodeKubeletBootstrap,
				},
				RoleRef: rbac.RoleRef{
					APIGroup: rbac.GroupName,
					Kind:     "ClusterRole",
					Name:     constants.NodeBootstrapperClusterRoleName,
				},
				Subjects: []rbac.Subject{
					{Kind: rbac.GroupKind, Name: constants.KubeProxyClusterRoleName},
				},
			},
		},
	}
}

func getHardCodedConfigInfoAutoApproveBootstrapTokens() ctestglobals.HardcodedConfig {
	return ctestglobals.HardcodedConfig{
		{
			FixtureFileName: "test_fixture.json",
			TestInfo:        []string{"existing binding"},
			Field:           "",
			K8sObjects:      []string{"clusterrolebindings"},
			HardcodedConfig: &rbac.ClusterRoleBinding{
				ObjectMeta: metav1.ObjectMeta{
					Name: constants.NodeAutoApproveBootstrapClusterRoleBinding,
				},
				RoleRef: rbac.RoleRef{
					APIGroup: rbac.GroupName,
					Kind:     "ClusterRole",
					Name:     constants.CSRAutoApprovalClusterRoleName,
				},
				Subjects: []rbac.Subject{
					{Kind: rbac.GroupKind, Name: constants.NodeBootstrapTokenAuthGroup},
				},
			},
		},
		{
			FixtureFileName: "test_fixture.json",
			TestInfo:        []string{"create new binding"},
			Field:           "",
			K8sObjects:      []string{"clusterrolebindings"},
			HardcodedConfig: &rbac.ClusterRoleBinding{
				ObjectMeta: metav1.ObjectMeta{
					Name: constants.NodeAutoApproveBootstrapClusterRoleBinding,
				},
				RoleRef: rbac.RoleRef{
					APIGroup: rbac.GroupName,
					Kind:     "ClusterRole",
					Name:     constants.NodeSelfCSRAutoApprovalClusterRoleName,
				},
				Subjects: []rbac.Subject{
					{Kind: rbac.GroupKind, Name: constants.NodeBootstrapTokenAuthGroup},
				},
			},
		},
	}
}

func getHardCodedConfigInfoAutoApproveNodeCertRotation() ctestglobals.HardcodedConfig {
	return ctestglobals.HardcodedConfig{
		{
			FixtureFileName: "test_fixture.json",
			TestInfo:        []string{"existing binding"},
			Field:           "",
			K8sObjects:      []string{"clusterrolebindings"},
			HardcodedConfig: &rbac.ClusterRoleBinding{
				ObjectMeta: metav1.ObjectMeta{
					Name: constants.NodeAutoApproveCertificateRotationClusterRoleBinding,
				},
				RoleRef: rbac.RoleRef{
					APIGroup: rbac.GroupName,
					Kind:     "ClusterRole",
					Name:     constants.NodeSelfCSRAutoApprovalClusterRoleName,
				},
				Subjects: []rbac.Subject{
					{Kind: rbac.GroupKind, Name: constants.NodesGroup},
				},
			},
		},
		{
			FixtureFileName: "test_fixture.json",
			TestInfo:        []string{"create new binding"},
			Field:           "",
			K8sObjects:      []string{"clusterrolebindings"},
			HardcodedConfig: &rbac.ClusterRoleBinding{
				ObjectMeta: metav1.ObjectMeta{
					Name: constants.NodeAutoApproveCertificateRotationClusterRoleBinding,
				},
				RoleRef: rbac.RoleRef{
					APIGroup: rbac.GroupName,
					Kind:     "ClusterRole",
					Name:     constants.NodeSelfCSRAutoApprovalClusterRoleName,
				},
				Subjects: []rbac.Subject{
					{Kind: rbac.GroupKind, Name: constants.NodeBootstrapTokenAuthGroup},
				},
			},
		},
	}
}

func getHardCodedConfigInfoAllowBootstrapTokensGetNodes() ctestglobals.HardcodedConfig {
	return ctestglobals.HardcodedConfig{
		{
			FixtureFileName: "test_fixture.json",
			TestInfo:        []string{"existing RBAC"},
			Field:           "",
			K8sObjects:      []string{"clusterrolebindings"},
			HardcodedConfig: &rbac.ClusterRoleBinding{
				ObjectMeta: metav1.ObjectMeta{
					Name: constants.GetNodesClusterRoleName,
				},
				RoleRef: rbac.RoleRef{
					APIGroup: rbac.GroupName,
					Kind:     "ClusterRole",
					Name:     constants.GetNodesClusterRoleName,
				},
				Subjects: []rbac.Subject{
					{Kind: rbac.GroupKind, Name: constants.NodeBootstrapTokenAuthGroup},
				},
			},
		},
	}
}

// helper functions (unchanged)
