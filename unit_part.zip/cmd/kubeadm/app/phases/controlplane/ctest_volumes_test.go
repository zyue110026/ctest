package controlplane

import (
	"os"
	// "path/filepath"
	"reflect"
	"testing"

	v1 "k8s.io/api/core/v1"
	kubeadmapi "k8s.io/kubernetes/cmd/kubeadm/app/apis/kubeadm"
	kubeadmconstants "k8s.io/kubernetes/cmd/kubeadm/app/constants"
)

func TestCtestGetEtcdCertVolumes_EdgeCases(t *testing.T) {
	hostPathDirectoryOrCreate := v1.HostPathDirectoryOrCreate
	k8sCertificatesDir := "/etc/kubernetes/pki"

	edgeTests := []struct {
		name, ca, cert, key string
		expVol              []v1.Volume
		expVolMount         []v1.VolumeMount
	}{
		{
			name:        "empty paths should return no volumes",
			ca:          "",
			cert:        "",
			key:         "",
			expVol:      []v1.Volume{},
			expVolMount: []v1.VolumeMount{},
		},
		{
			name:        "only ca path present",
			ca:          "/var/lib/certs/etcd/ca.crt",
			cert:        "",
			key:         "",
			expVol:      []v1.Volume{},
			expVolMount: []v1.VolumeMount{},
		},
		{
			name: "ca and cert in same dir, key outside",
			ca:   "/var/lib/certs/etcd/ca.crt",
			cert: "/var/lib/certs/etcd/cert.crt",
			key:  "/outside/key.key",
			expVol: []v1.Volume{
				{
					Name: "etcd-certs-0",
					VolumeSource: v1.VolumeSource{
						HostPath: &v1.HostPathVolumeSource{
							Path: "/var/lib/certs/etcd",
							Type: &hostPathDirectoryOrCreate,
						},
					},
				},
			},
			expVolMount: []v1.VolumeMount{
				{
					Name:      "etcd-certs-0",
					MountPath: "/var/lib/certs/etcd",
					ReadOnly:  true,
				},
			},
		},
		{
			name:        "certs located in kubeadm certificates dir should be ignored",
			ca:          k8sCertificatesDir + "/ca/my-etcd-ca.crt",
			cert:        k8sCertificatesDir + "/my-etcd.crt",
			key:         k8sCertificatesDir + "/my-etcd.key",
			expVol:      []v1.Volume{},
			expVolMount: []v1.VolumeMount{},
		},
	}

	for _, tt := range edgeTests {
		t.Run(tt.name, func(t *testing.T) {
			actualVol, actualVolMount := getEtcdCertVolumes(&kubeadmapi.ExternalEtcd{
				CAFile:   tt.ca,
				CertFile: tt.cert,
				KeyFile:  tt.key,
			}, k8sCertificatesDir)

			if !reflect.DeepEqual(actualVol, tt.expVol) {
				t.Errorf("Unexpected volumes.\nExpected: %v\nActual:   %v", tt.expVol, actualVol)
			}
			if !reflect.DeepEqual(actualVolMount, tt.expVolMount) {
				t.Errorf("Unexpected volume mounts.\nExpected: %v\nActual:   %v", tt.expVolMount, actualVolMount)
			}
		})
	}
}

func TestCtestGetHostPathVolumesForTheControlPlane_EdgeCases(t *testing.T) {
	// hostPathDirectoryOrCreate := v1.HostPathDirectoryOrCreate
	// hostPathFileOrCreate := v1.HostPathFileOrCreate
	// controllerManagerConfig := filepath.FromSlash("/etc/kubernetes/controller-manager.conf")
	// schedulerConfig := filepath.FromSlash("/etc/kubernetes/scheduler.conf")

	// Prepare a temporary directory to simulate certificates directory
	tmpDir, err := os.MkdirTemp("", "edge-certs")
	if err != nil {
		t.Fatalf("failed to create temp dir: %v", err)
	}
	defer os.RemoveAll(tmpDir)

	// Edge case: nil ClusterConfiguration
	edgeCfgNil := (*kubeadmapi.ClusterConfiguration)(nil)

	// Edge case: empty CertificatesDir with no etcd external config
	edgeCfgEmpty := &kubeadmapi.ClusterConfiguration{
		CertificatesDir: "",
		Etcd:            kubeadmapi.Etcd{},
	}

	// Edge case: valid CertificatesDir but etcd external certs located in ignored directories
	edgeCfgIgnoredEtcd := &kubeadmapi.ClusterConfiguration{
		CertificatesDir: tmpDir,
		Etcd: kubeadmapi.Etcd{
			External: &kubeadmapi.ExternalEtcd{
				CAFile:   "/etc/ssl/certs/ca.crt",
				CertFile: "/etc/ssl/certs/cert.crt",
				KeyFile:  "/etc/ssl/certs/key.key",
			},
		},
	}

	tests := []struct {
		name string
		cfg  *kubeadmapi.ClusterConfiguration
		exp  struct {
			vol      map[string]map[string]v1.Volume
			volMount map[string]map[string]v1.VolumeMount
		}
	}{
		{
			name: "nil config should produce empty maps",
			cfg:  edgeCfgNil,
			exp: struct {
				vol      map[string]map[string]v1.Volume
				volMount map[string]map[string]v1.VolumeMount
			}{vol: map[string]map[string]v1.Volume{}, volMount: map[string]map[string]v1.VolumeMount{}},
		},
		{
			name: "empty certs dir without etcd external produces base maps",
			cfg:  edgeCfgEmpty,
			exp: struct {
				vol      map[string]map[string]v1.Volume
				volMount map[string]map[string]v1.VolumeMount
			}{
				vol: map[string]map[string]v1.Volume{
					kubeadmconstants.KubeAPIServer:         {},
					kubeadmconstants.KubeControllerManager: {},
					kubeadmconstants.KubeScheduler:         {},
				},
				volMount: map[string]map[string]v1.VolumeMount{
					kubeadmconstants.KubeAPIServer:         {},
					kubeadmconstants.KubeControllerManager: {},
					kubeadmconstants.KubeScheduler:         {},
				},
			},
		},
		{
			name: "etcd external certs in ignored dir should be ignored",
			cfg:  edgeCfgIgnoredEtcd,
			exp: struct {
				vol      map[string]map[string]v1.Volume
				volMount map[string]map[string]v1.VolumeMount
			}{
				vol: map[string]map[string]v1.Volume{
					kubeadmconstants.KubeAPIServer:         {},
					kubeadmconstants.KubeControllerManager: {},
					kubeadmconstants.KubeScheduler:         {},
				},
				volMount: map[string]map[string]v1.VolumeMount{
					kubeadmconstants.KubeAPIServer:         {},
					kubeadmconstants.KubeControllerManager: {},
					kubeadmconstants.KubeScheduler:         {},
				},
			},
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			mounts := getHostPathVolumesForTheControlPlane(tt.cfg)

			// Remove flexvolume entry that may be present in normal maps
			if mounts.volumes != nil {
				delete(mounts.volumes[kubeadmconstants.KubeControllerManager], flexvolumeDirVolumeName)
			}
			if mounts.volumeMounts != nil {
				delete(mounts.volumeMounts[kubeadmconstants.KubeControllerManager], flexvolumeDirVolumeName)
			}

			if !reflect.DeepEqual(mounts.volumes, tt.exp.vol) {
				t.Errorf("Unexpected volumes map.\nExpected: %v\nActual:   %v", tt.exp.vol, mounts.volumes)
			}
			if !reflect.DeepEqual(mounts.volumeMounts, tt.exp.volMount) {
				t.Errorf("Unexpected volumeMounts map.\nExpected: %v\nActual:   %v", tt.exp.volMount, mounts.volumeMounts)
			}
		})
	}
}

func TestCtestAddExtraHostPathMounts_EdgeCases(t *testing.T) {
	mounts := newControlPlaneHostPathMounts()
	hostPathDirectoryOrCreate := v1.HostPathDirectoryOrCreate
	// hostPathFileOrCreate := v1.HostPathFileOrCreate

	// Edge case: mismatched lengths (more volumes than mounts)
	vols := []v1.Volume{
		{
			Name: "extra-vol-1",
			VolumeSource: v1.VolumeSource{
				HostPath: &v1.HostPathVolumeSource{
					Path: "/tmp/extra1",
					Type: &hostPathDirectoryOrCreate,
				},
			},
		},
	}
	volMounts := []v1.VolumeMount{
		{
			Name:      "extra-vol-1",
			MountPath: "/tmp/extra1",
			ReadOnly:  true,
		},
		{
			Name:      "extra-vol-2",
			MountPath: "/tmp/extra2",
			ReadOnly:  false,
		},
	}
	// The function under test does not return an error; it will ignore unmatched entries.
	mounts.AddHostPathMounts("edge-component", vols, volMounts)

	if _, ok := mounts.volumes["edge-component"]["extra-vol-1"]; !ok {
		t.Errorf("Expected volume \"extra-vol-1\" to be added")
	}
	if _, ok := mounts.volumeMounts["edge-component"]["extra-vol-1"]; !ok {
		t.Errorf("Expected volume mount \"extra-vol-1\" to be added")
	}
	// Ensure that the extra unmatched mount does not cause a panic or entry.
	if _, ok := mounts.volumeMounts["edge-component"]["extra-vol-2"]; ok {
		t.Errorf("Did not expect volume mount \"extra-vol-2\" to be added when no matching volume exists")
	}

	// Edge case: HostPath type nil (should default to Directory)
	volsNilType := []v1.Volume{
		{
			Name: "nil-type",
			VolumeSource: v1.VolumeSource{
				HostPath: &v1.HostPathVolumeSource{
					Path: "/tmp/niltype",
					Type: nil,
				},
			},
		},
	}
	volMountsNilType := []v1.VolumeMount{
		{
			Name:      "nil-type",
			MountPath: "/tmp/niltype",
			ReadOnly:  true,
		},
	}
	mounts.AddHostPathMounts("nil-type-component", volsNilType, volMountsNilType)
	if vol, ok := mounts.volumes["nil-type-component"]["nil-type"]; !ok {
		t.Errorf("Expected volume \"nil-type\" to be added")
	} else {
		if vol.HostPath.Type != nil && *vol.HostPath.Type != v1.HostPathDirectory {
			t.Errorf("Expected default HostPath type to be Directory when nil, got %v", *vol.HostPath.Type)
		}
	}
}
