package kubelet

import (
	"fmt"
	"os"
	"reflect"
	"strings"
	"testing"

	"github.com/stretchr/testify/assert"

	v1 "k8s.io/api/core/v1"
	kubeadmapi "k8s.io/kubernetes/cmd/kubeadm/app/apis/kubeadm"

	ctestglobals "k8s.io/kubernetes/test/ctest/ctestglobals"
)

func TestCtestBuildKubeletArgs(t *testing.T) {
	fmt.Println(ctestglobals.StartExtendModeSeparator)
	tests := []struct {
		name     string
		opts     kubeletFlagsOpts
		expected []kubeadmapi.Arg
	}{
		{
			name: "hostname override",
			opts: kubeletFlagsOpts{
				nodeRegOpts: &kubeadmapi.NodeRegistrationOptions{
					KubeletExtraArgs: []kubeadmapi.Arg{
						{Name: "hostname-override", Value: "override-name"},
					},
				},
				criSocket: "unix:///var/run/containerd/containerd.sock",
			},
			expected: []kubeadmapi.Arg{
				{Name: "container-runtime-endpoint", Value: "unix:///var/run/containerd/containerd.sock"},
				{Name: "hostname-override", Value: "override-name"},
			},
		},
		{
			name: "register with taints",
			opts: kubeletFlagsOpts{
				nodeRegOpts: &kubeadmapi.NodeRegistrationOptions{
					Taints: []v1.Taint{
						{
							Key:    "foo",
							Value:  "bar",
							Effect: "baz",
						},
						{
							Key:    "key",
							Value:  "val",
							Effect: "eff",
						},
					},
				},
				criSocket:                "unix:///var/run/containerd/containerd.sock",
				registerTaintsUsingFlags: true,
			},
			expected: []kubeadmapi.Arg{
				{Name: "container-runtime-endpoint", Value: "unix:///var/run/containerd/containerd.sock"},
				{Name: "register-with-taints", Value: "foo=bar:baz,key=val:eff"},
			},
		},
		{
			name: "pause image is set",
			opts: kubeletFlagsOpts{
				nodeRegOpts: &kubeadmapi.NodeRegistrationOptions{},
				criSocket:   "unix:///var/run/containerd/containerd.sock",
				pauseImage:  "registry.k8s.io/pause:ver",
			},
			expected: []kubeadmapi.Arg{
				{Name: "container-runtime-endpoint", Value: "unix:///var/run/containerd/containerd.sock"},
				{Name: "pod-infra-container-image", Value: "registry.k8s.io/pause:ver"},
			},
		},
		// Edge / invalid cases
		{
			name: "nil nodeRegOpts and empty criSocket",
			opts: kubeletFlagsOpts{
				nodeRegOpts: nil,
				criSocket:   "",
			},
			expected: []kubeadmapi.Arg{},
		},
		{
			name: "nodeRegOpts with empty extra args",
			opts: kubeletFlagsOpts{
				nodeRegOpts: &kubeadmapi.NodeRegistrationOptions{
					KubeletExtraArgs: []kubeadmapi.Arg{},
				},
				criSocket: "unix:///var/run/containerd/containerd.sock",
			},
			expected: []kubeadmapi.Arg{
				{Name: "container-runtime-endpoint", Value: "unix:///var/run/containerd/containerd.sock"},
			},
		},
		{
			name: "unknown extra arg ignored",
			opts: kubeletFlagsOpts{
				nodeRegOpts: &kubeadmapi.NodeRegistrationOptions{
					KubeletExtraArgs: []kubeadmapi.Arg{
						{Name: "unknown-flag", Value: "somevalue"},
					},
				},
				criSocket: "unix:///var/run/containerd/containerd.sock",
			},
			expected: []kubeadmapi.Arg{
				{Name: "container-runtime-endpoint", Value: "unix:///var/run/containerd/containerd.sock"},
				{Name: "unknown-flag", Value: "somevalue"},
			},
		},
	}
	fmt.Println(ctestglobals.DebugPrefix(), "Number of test cases:", len(tests))
	for i, test := range tests {
		fmt.Printf("Running test case %d: %s\n", i, test.name)
		actual := buildKubeletArgs(test.opts)
		if !reflect.DeepEqual(actual, test.expected) {
			t.Errorf(
				"failed buildKubeletArgs for %s:\n\texpected: %v\n\t  actual: %v",
				test.name,
				test.expected,
				actual,
			)
		}
	}
	fmt.Println(ctestglobals.EndSeparator)
}

func TestCtestGetNodeNameAndHostname(t *testing.T) {
	fmt.Println(ctestglobals.StartExtendModeSeparator)
	hostname, err := os.Hostname()
	if err != nil {
		t.Fatalf("unexpected error getting hostname: %v", err)
	}
	testCases := []struct {
		name             string
		opts             kubeletFlagsOpts
		expectedNodeName string
		expectedHostName string
	}{
		{
			name: "overridden hostname",
			opts: kubeletFlagsOpts{
				nodeRegOpts: &kubeadmapi.NodeRegistrationOptions{
					KubeletExtraArgs: []kubeadmapi.Arg{
						{Name: "hostname-override", Value: "override-name"},
					},
				},
			},
			expectedNodeName: "override-name",
			expectedHostName: strings.ToLower(hostname),
		},
		{
			name: "overridden hostname uppercase",
			opts: kubeletFlagsOpts{
				nodeRegOpts: &kubeadmapi.NodeRegistrationOptions{
					KubeletExtraArgs: []kubeadmapi.Arg{
						{Name: "hostname-override", Value: "OVERRIDE-NAME"},
					},
				},
			},
			expectedNodeName: "OVERRIDE-NAME",
			expectedHostName: strings.ToLower(hostname),
		},
		{
			name: "hostname contains only spaces",
			opts: kubeletFlagsOpts{
				nodeRegOpts: &kubeadmapi.NodeRegistrationOptions{
					KubeletExtraArgs: []kubeadmapi.Arg{
						{Name: "hostname-override", Value: " "},
					},
				}},
			expectedNodeName: " ",
			expectedHostName: strings.ToLower(hostname),
		},
		{
			name: "empty parameter",
			opts: kubeletFlagsOpts{
				nodeRegOpts: &kubeadmapi.NodeRegistrationOptions{
					KubeletExtraArgs: []kubeadmapi.Arg{
						{Name: "hostname-override", Value: ""},
					},
				},
			},
			expectedNodeName: "",
			expectedHostName: strings.ToLower(hostname),
		},
		{
			name: "nil parameter",
			opts: kubeletFlagsOpts{
				nodeRegOpts: &kubeadmapi.NodeRegistrationOptions{
					KubeletExtraArgs: nil,
				},
			},
			expectedNodeName: strings.ToLower(hostname),
			expectedHostName: strings.ToLower(hostname),
		},
		// Edge / invalid cases
		{
			name: "nil nodeRegOpts",
			opts: kubeletFlagsOpts{
				nodeRegOpts: nil,
			},
			expectedNodeName: strings.ToLower(hostname),
			expectedHostName: strings.ToLower(hostname),
		},
		{
			name: "nodeRegOpts with empty extra args slice",
			opts: kubeletFlagsOpts{
				nodeRegOpts: &kubeadmapi.NodeRegistrationOptions{
					KubeletExtraArgs: []kubeadmapi.Arg{},
				},
			},
			expectedNodeName: strings.ToLower(hostname),
			expectedHostName: strings.ToLower(hostname),
		},
	}
	fmt.Println(ctestglobals.DebugPrefix(), "Number of test cases:", len(testCases))
	for i, tc := range testCases {
		fmt.Printf("Running %dth test case: %s\n", i, tc.name)
		nodeName, host, err := GetNodeNameAndHostname(tc.opts.nodeRegOpts)
		if err != nil {
			t.Errorf("unexpected error in %s: %v", tc.name, err)
			continue
		}
		if nodeName != tc.expectedNodeName {
			t.Errorf("%s: expected nodeName %v, got %v", tc.name, tc.expectedNodeName, nodeName)
		}
		if host != tc.expectedHostName {
			t.Errorf("%s: expected hostname %v, got %v", tc.name, tc.expectedHostName, host)
		}
	}
	fmt.Println(ctestglobals.EndSeparator)
}

func TestCtestReadKubeadmFlags(t *testing.T) {
	fmt.Println(ctestglobals.StartExtendModeSeparator)
	tests := []struct {
		name          string
		fileContent   string
		expectedValue []string
		expectError   bool
	}{
		{
			name:          "valid kubeadm flags with container-runtime-endpoint",
			fileContent:   `KUBELET_KUBEADM_ARGS="--container-runtime-endpoint=unix:///var/run/containerd/containerd.sock --pod-infra-container-image=registry.k8s.io/pause:1.0"`,
			expectedValue: []string{"--container-runtime-endpoint=unix:///var/run/containerd/containerd.sock", "--pod-infra-container-image=registry.k8s.io/pause:1.0"},
			expectError:   false,
		},
		{
			name:          "no container-runtime-endpoint found",
			fileContent:   `KUBELET_KUBEADM_ARGS="--pod-infra-container-image=registry.k8s.io/pause:1.0"`,
			expectedValue: []string{"--pod-infra-container-image=registry.k8s.io/pause:1.0"},
			expectError:   true,
		},
		{
			name:          "no KUBELET_KUBEADM_ARGS line",
			fileContent:   `# This is a comment, no args here`,
			expectedValue: nil,
			expectError:   true,
		},
		{
			name:          "invalid file format",
			fileContent:   "",
			expectedValue: nil,
			expectError:   true,
		},
		{
			name:          "multiple flags with mixed equals and no equals",
			fileContent:   `KUBELET_KUBEADM_ARGS="--container-runtime-endpoint=unix:///var/run/containerd/containerd.sock --foo bar --baz=qux"`,
			expectedValue: []string{"--container-runtime-endpoint=unix:///var/run/containerd/containerd.sock", "--foo=bar", "--baz=qux"},
			expectError:   false,
		},
		{
			name:          "multiple flags with no equals",
			fileContent:   `KUBELET_KUBEADM_ARGS="--container-runtime-endpoint unix:///var/run/containerd/containerd.sock --foo bar --baz qux"`,
			expectedValue: []string{"--container-runtime-endpoint=unix:///var/run/containerd/containerd.sock", "--foo=bar", "--baz=qux"},
			expectError:   false,
		},
		{
			name:          "invalid prefix",
			fileContent:   `"--foo bar"`,
			expectedValue: nil,
			expectError:   true,
		},
		// Edge / invalid cases
		{
			name:          "empty file content with whitespace",
			fileContent:   "   \n   ",
			expectedValue: nil,
			expectError:   true,
		},
		{
			name: "multiple KUBELET_KUBEADM_ARGS lines, last one wins",
			fileContent: `KUBELET_KUBEADM_ARGS="--foo=bar"
KUBELET_KUBEADM_ARGS="--baz=qux"`,
			expectedValue: []string{"--baz=qux"},
			expectError:   false,
		},
		{
			name:          "malformed line without quotes",
			fileContent:   `KUBELET_KUBEADM_ARGS=--foo=bar`,
			expectedValue: nil,
			expectError:   true,
		},
	}
	fmt.Println(ctestglobals.DebugPrefix(), "Number of test cases:", len(tests))
	for i, tt := range tests {
		fmt.Printf("Running %dth test case: %s\n", i, tt.name)
		tmpFile, err := os.CreateTemp("", "kubeadm-flags-*.env")
		if err != nil {
			t.Fatalf("Error creating temporary file: %v", err)
		}
		func() {
			defer func() {
				_ = os.Remove(tmpFile.Name())
				_ = tmpFile.Close()
			}()

			if _, err = tmpFile.WriteString(tt.fileContent); err != nil {
				t.Fatalf("Error writing to temp file: %v", err)
			}
		}()

		value, err := ReadKubeletDynamicEnvFile(tmpFile.Name())
		if !tt.expectError && err != nil {
			t.Errorf("%s: unexpected error: %v", tt.name, err)
			return
		}
		if tt.expectError && err == nil {
			t.Errorf("%s: expected error but got none", tt.name)
			return
		}
		assert.Equal(t, tt.expectedValue, value, tt.name)
	}
	fmt.Println(ctestglobals.EndSeparator)
}
