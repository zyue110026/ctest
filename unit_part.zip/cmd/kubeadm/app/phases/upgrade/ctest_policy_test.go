package upgrade

import (
	"fmt"
	"testing"

	"k8s.io/apimachinery/pkg/util/version"
	ctestglobals "k8s.io/kubernetes/test/ctest/ctestglobals"
)

func TestCtestEnforceVersionPolicies(t *testing.T) {
	minimumKubeletVersion := version.MustParseSemantic("v1.3.0")
	minimumControlPlaneVersion := version.MustParseSemantic("v1.3.0")
	currentKubernetesVersion := version.MustParseSemantic("v1.4.0")

	// Original test cases
	tests := []struct {
		name                        string
		vg                          *fakeVersionGetter
		expectedMandatoryErrs       int
		expectedSkippableErrs       int
		allowExperimental, allowRCs bool
		newK8sVersion               string
	}{
		{
			name: "minor upgrade",
			vg: &fakeVersionGetter{
				clusterVersion: minimumControlPlaneVersion.WithPatch(3).String(),
				kubeletVersion: minimumControlPlaneVersion.WithPatch(3).String(),
				kubeadmVersion: minimumControlPlaneVersion.WithPatch(5).String(),
			},
			newK8sVersion: minimumControlPlaneVersion.WithPatch(5).String(),
		},
		{
			name: "major upgrade",
			vg: &fakeVersionGetter{
				clusterVersion: minimumControlPlaneVersion.WithPatch(3).String(),
				kubeletVersion: minimumControlPlaneVersion.WithPatch(2).String(),
				kubeadmVersion: currentKubernetesVersion.WithPatch(1).String(),
			},
			newK8sVersion: currentKubernetesVersion.String(),
		},
		{
			name: "downgrade",
			vg: &fakeVersionGetter{
				clusterVersion: minimumControlPlaneVersion.WithPatch(3).String(),
				kubeletVersion: minimumKubeletVersion.String(),
				kubeadmVersion: minimumControlPlaneVersion.WithPatch(3).String(),
			},
			newK8sVersion: minimumControlPlaneVersion.WithPatch(2).String(),
		},
		{
			name: "same version upgrade",
			vg: &fakeVersionGetter{
				clusterVersion: minimumControlPlaneVersion.WithPatch(3).String(),
				kubeletVersion: minimumKubeletVersion.WithPatch(3).String(),
				kubeadmVersion: minimumControlPlaneVersion.WithPatch(3).String(),
			},
			newK8sVersion: minimumControlPlaneVersion.WithPatch(3).String(),
		},
		{
			name: "new version must be higher than v1.12.0",
			vg: &fakeVersionGetter{
				clusterVersion: "v1.12.3",
				kubeletVersion: "v1.12.3",
				kubeadmVersion: "v1.12.3",
			},
			newK8sVersion:         "v1.10.10",
			expectedMandatoryErrs: 1,
			expectedSkippableErrs: 1,
		},
		{
			name: "upgrading two minor versions in one go is not supported",
			vg: &fakeVersionGetter{
				clusterVersion: "v1.11.3",
				kubeletVersion: "v1.11.3",
				kubeadmVersion: "v1.13.0",
			},
			newK8sVersion:         "v1.13.0",
			expectedMandatoryErrs: 1,
		},
		{
			name: "upgrading with n-3 kubelet is supported",
			vg: &fakeVersionGetter{
				clusterVersion: "v1.14.3",
				kubeletVersion: "v1.12.3",
				kubeadmVersion: "v1.15.0",
			},
			newK8sVersion: "v1.15.0",
		},
		{
			name: "upgrading with n-4 kubelet is not supported",
			vg: &fakeVersionGetter{
				clusterVersion: "v1.14.3",
				kubeletVersion: "v1.11.3",
				kubeadmVersion: "v1.15.0",
			},
			newK8sVersion:         "v1.15.0",
			expectedSkippableErrs: 1,
		},
		{
			name: "downgrading two minor versions in one go is not supported",
			vg: &fakeVersionGetter{
				clusterVersion: currentKubernetesVersion.WithMinor(currentKubernetesVersion.Minor() + 2).String(),
				kubeletVersion: currentKubernetesVersion.WithMinor(currentKubernetesVersion.Minor() + 2).String(),
				kubeadmVersion: currentKubernetesVersion.String(),
			},
			newK8sVersion:         currentKubernetesVersion.String(),
			expectedMandatoryErrs: 1,
		},
		{
			name: "kubeadm version must be higher than the new kube version. However, patch version skews may be forced",
			vg: &fakeVersionGetter{
				clusterVersion: minimumControlPlaneVersion.WithPatch(3).String(),
				kubeletVersion: minimumKubeletVersion.WithPatch(3).String(),
				kubeadmVersion: minimumControlPlaneVersion.WithPatch(3).String(),
			},
			newK8sVersion:         minimumControlPlaneVersion.WithPatch(5).String(),
			expectedSkippableErrs: 1,
		},
		{
			name: "kubeadm version must be higher than the new kube version. Trying to upgrade k8s to a higher minor version than kubeadm itself should never be supported",
			vg: &fakeVersionGetter{
				clusterVersion: minimumControlPlaneVersion.WithPatch(3).String(),
				kubeletVersion: minimumKubeletVersion.WithPatch(3).String(),
				kubeadmVersion: minimumControlPlaneVersion.WithPatch(3).String(),
			},
			newK8sVersion:         currentKubernetesVersion.String(),
			expectedMandatoryErrs: 1,
		},
		{
			name: "the maximum skew between the cluster version and the kubelet versions should be three minor version.",
			vg: &fakeVersionGetter{
				clusterVersion: "v1.13.0",
				kubeletVersion: "v1.10.8",
				kubeadmVersion: "v1.13.0",
			},
			newK8sVersion: "v1.13.0",
		},
		{
			name: "the maximum skew between the cluster version and the kubelet versions should be three minor version. This may be forced through though.",
			vg: &fakeVersionGetter{
				clusterVersion: "v1.14.0",
				kubeletVersion: "v1.10.8",
				kubeadmVersion: "v1.14.0",
			},
			newK8sVersion:         "v1.14.0",
			expectedSkippableErrs: 1,
		},
		{
			name: "experimental upgrades supported if the flag is set",
			vg: &fakeVersionGetter{
				clusterVersion: minimumControlPlaneVersion.WithPatch(3).String(),
				kubeletVersion: minimumKubeletVersion.WithPatch(3).String(),
				kubeadmVersion: currentKubernetesVersion.WithPreRelease("beta.1").String(),
			},
			newK8sVersion:     currentKubernetesVersion.WithPreRelease("beta.1").String(),
			allowExperimental: true,
		},
		{
			name: "release candidate upgrades supported if the flag is set",
			vg: &fakeVersionGetter{
				clusterVersion: minimumControlPlaneVersion.WithPatch(3).String(),
				kubeletVersion: minimumKubeletVersion.WithPatch(3).String(),
				kubeadmVersion: currentKubernetesVersion.WithPreRelease("rc.1").String(),
			},
			newK8sVersion: currentKubernetesVersion.WithPreRelease("rc.1").String(),
			allowRCs:      true,
		},
		{
			name: "release candidate upgrades supported if the flag is set",
			vg: &fakeVersionGetter{
				clusterVersion: minimumControlPlaneVersion.WithPatch(3).String(),
				kubeletVersion: minimumKubeletVersion.WithPatch(3).String(),
				kubeadmVersion: currentKubernetesVersion.WithPreRelease("rc.1").String(),
			},
			newK8sVersion:     currentKubernetesVersion.WithPreRelease("rc.1").String(),
			allowExperimental: true,
		},
		{
			name: "the user should not be able to upgrade to an experimental version if they haven't opted into that",
			vg: &fakeVersionGetter{
				clusterVersion: minimumControlPlaneVersion.WithPatch(3).String(),
				kubeletVersion: minimumKubeletVersion.WithPatch(3).String(),
				kubeadmVersion: currentKubernetesVersion.WithPreRelease("beta.1").String(),
			},
			newK8sVersion:         currentKubernetesVersion.WithPreRelease("beta.1").String(),
			allowRCs:              true,
			expectedSkippableErrs: 1,
		},
		{
			name: "the user should not be able to upgrade to an release candidate version if they haven't opted into that",
			vg: &fakeVersionGetter{
				clusterVersion: minimumControlPlaneVersion.WithPatch(3).String(),
				kubeletVersion: minimumKubeletVersion.WithPatch(3).String(),
				kubeadmVersion: currentKubernetesVersion.WithPreRelease("rc.1").String(),
			},
			newK8sVersion:         currentKubernetesVersion.WithPreRelease("rc.1").String(),
			expectedSkippableErrs: 1,
		},
		{
			name: "the user can't use a newer minor version of kubeadm to upgrade an older version of kubeadm",
			vg: &fakeVersionGetter{
				clusterVersion: minimumControlPlaneVersion.WithPatch(3).String(),
				kubeletVersion: minimumKubeletVersion.WithPatch(3).String(),
				kubeadmVersion: currentKubernetesVersion.String(),
			},
			newK8sVersion:         minimumControlPlaneVersion.WithPatch(6).String(),
			expectedSkippableErrs: 1,
		},
		{
			name: "build release supported at MinimumControlPlaneVersion",
			vg: &fakeVersionGetter{
				clusterVersion: minimumControlPlaneVersion.String(),
				kubeletVersion: minimumControlPlaneVersion.String(),
				kubeadmVersion: minimumControlPlaneVersion.WithBuildMetadata("build").String(),
			},
			newK8sVersion: minimumControlPlaneVersion.WithBuildMetadata("build").String(),
		},
	}

	// Edge / invalid test cases
	edgeTests := []struct {
		name                        string
		vg                          *fakeVersionGetter
		expectedMandatoryErrs       int
		expectedSkippableErrs       int
		allowExperimental, allowRCs bool
		newK8sVersion               string
	}{
		{
			name: "empty version strings",
			vg: &fakeVersionGetter{
				clusterVersion: "",
				kubeletVersion: "",
				kubeadmVersion: "",
			},
			newK8sVersion:         "",
			expectedMandatoryErrs:  1,
			expectedSkippableErrs: 1,
		},
		{
			name: "malformed version strings",
			vg: &fakeVersionGetter{
				clusterVersion: "invalid",
				kubeletVersion: "v1..2",
				kubeadmVersion: "v1.a.b",
			},
			newK8sVersion:         "v1.x.0",
			expectedMandatoryErrs: 1,
			expectedSkippableErrs: 1,
		},
		{
			name: "nil version getter",
			vg:   nil,
			newK8sVersion:         minimumControlPlaneVersion.WithPatch(5).String(),
			expectedMandatoryErrs: 1,
			expectedSkippableErrs: 1,
		},
	}

	// Combine original and edge cases
	allTests := append(tests, edgeTests...)

	fmt.Println(ctestglobals.DebugPrefix(), "Running EnforceVersionPolicies tests, total:", len(allTests))

	for _, rt := range allTests {
		rt := rt // capture range variable
		t.Run(rt.name, func(t *testing.T) {
			newK8sVer, err := version.ParseSemantic(rt.newK8sVersion)
			if err != nil {
				if rt.expectedMandatoryErrs+rt.expectedSkippableErrs == 0 {
					t.Fatalf("couldn't parse version %s: %v", rt.newK8sVersion, err)
				}
				// Expected parse error, count it as a mandatory error
				if rt.expectedMandatoryErrs == 0 {
					t.Errorf("expected mandatory error for parse failure but got none")
				}
				return
			}

			// Guard against nil vg in edge case
			if rt.vg == nil {
				if rt.expectedMandatoryErrs == 0 && rt.expectedSkippableErrs == 0 {
					t.Fatalf("nil version getter not expected")
				}
				// Simulate nil vg handling by treating as error
				if rt.expectedMandatoryErrs == 0 {
					t.Errorf("expected mandatory error for nil vg but got none")
				}
				return
			}

			actualSkewErrs := EnforceVersionPolicies(rt.vg, rt.newK8sVersion, newK8sVer, rt.allowExperimental, rt.allowRCs)
			if actualSkewErrs == nil {
				if rt.expectedMandatoryErrs+rt.expectedSkippableErrs > 0 {
					t.Errorf("expected errors but got none")
				}
				return
			}

			if len(actualSkewErrs.Skippable) != rt.expectedSkippableErrs {
				t.Errorf("expected skippable errors: %d, got: %d\n%#v\n%#v", rt.expectedSkippableErrs, len(actualSkewErrs.Skippable), *rt.vg, actualSkewErrs)
			}
			if len(actualSkewErrs.Mandatory) != rt.expectedMandatoryErrs {
				t.Errorf("expected mandatory errors: %d, got: %d\n%#v\n%#v", rt.expectedMandatoryErrs, len(actualSkewErrs.Mandatory), *rt.vg, actualSkewErrs)
			}
		})
	}
}