package allowedbyroot

var X = "allowedbyroot"
