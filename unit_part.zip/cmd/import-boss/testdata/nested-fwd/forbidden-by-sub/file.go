package forbiddenbysub

var X = "forbiddenbysub"
