package allowedbyboth

var X = "allowedbyboth"
