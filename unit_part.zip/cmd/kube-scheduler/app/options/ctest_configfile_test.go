package options

import (
	"context"
	"errors"
	"fmt"
	"os"
	"path/filepath"
	"syscall"
	"testing"

	"github.com/stretchr/testify/assert"
	"k8s.io/klog/v2"
	"k8s.io/kubernetes/pkg/scheduler/apis/config"
)

func TestCtestLoadConfigFromFile(t *testing.T) {
	tmpDir, err := os.MkdirTemp("", "scheduler-configs")
	if err != nil {
		t.Fatal(err)
	}
	defer os.RemoveAll(tmpDir)

	// Original config files
	correctConfigFile := filepath.Join(tmpDir, "correct_config.yaml")
	if err := os.WriteFile(correctConfigFile,
		[]byte(schedulerConfigMinimalCorrect),
		os.FileMode(0600)); err != nil {
		t.Fatal(err)
	}

	decodeErrConfigFile := filepath.Join(tmpDir, "decode_err_no_version_config.yaml")
	if err := os.WriteFile(decodeErrConfigFile,
		[]byte(schedulerConfigDecodeErr),
		os.FileMode(0600)); err != nil {
		t.Fatal(err)
	}

	versionTooOldConfigFile := filepath.Join(tmpDir, "version_too_old_config.yaml")
	if err := os.WriteFile(versionTooOldConfigFile,
		[]byte(schedulerConfigVersionTooOld),
		os.FileMode(0600)); err != nil {
		t.Fatal(err)
	}

	// Edge case config files
	emptyContentFile := filepath.Join(tmpDir, "empty_content.yaml")
	if err := os.WriteFile(emptyContentFile, []byte{}, os.FileMode(0600)); err != nil {
		t.Fatal(err)
	}

	invalidYAMLFile := filepath.Join(tmpDir, "invalid_yaml.yaml")
	if err := os.WriteFile(invalidYAMLFile, []byte(":::"), os.FileMode(0600)); err != nil {
		t.Fatal(err)
	}

	tests := []struct {
		name           string
		path           string
		expectedErr    error
		expectedConfig *config.KubeSchedulerConfiguration
	}{
		{
			name:           "Empty scheduler config file path",
			path:           "",
			expectedErr:    syscall.Errno(syscall.ENOENT),
			expectedConfig: nil,
		},
		{
			name:           "Correct scheduler config",
			path:           correctConfigFile,
			expectedErr:    nil,
			expectedConfig: &config.KubeSchedulerConfiguration{},
		},
		{
			name:           "Scheduler config with decode error",
			path:           decodeErrConfigFile,
			expectedErr:    errors.New(apiVersionMissing),
			expectedConfig: nil,
		},
		{
			name:           "Scheduler config version too old",
			path:           versionTooOldConfigFile,
			expectedErr:    errors.New(apiVersionTooOld),
			expectedConfig: nil,
		},
		{
			name:           "Empty file content",
			path:           emptyContentFile,
			expectedErr:    errors.New(apiVersionMissing),
			expectedConfig: nil,
		},
		{
			name:           "Invalid YAML format",
			path:           invalidYAMLFile,
			expectedErr:    errors.New(apiVersionMissing),
			expectedConfig: nil,
		},
	}

	logger := klog.FromContext(context.Background())

	for i, test := range tests {
		t.Run(fmt.Sprintf("case_%d: %s", i, test.name), func(t *testing.T) {
			cfg, err := LoadConfigFromFile(logger, test.path)
			if test.expectedConfig == nil {
				assert.Nil(t, cfg)
			} else {
				assert.NotNil(t, cfg)
			}

			if test.expectedErr == nil {
				assert.NoError(t, err)
			} else {
				assert.ErrorContains(t, err, test.expectedErr.Error())
			}
		})
	}
}