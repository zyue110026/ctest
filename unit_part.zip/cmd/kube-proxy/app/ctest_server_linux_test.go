package app

import (
	// "context"
	// "errors"
	"fmt"
	// "os"
	// "path/filepath"
	"reflect"
	// "strings"
	"testing"
	// "time"

	// "github.com/google/go-cmp/cmp"
	// "github.com/spf13/pflag"
	// "k8s.io/apimachinery/pkg/util/ptr"
	v1 "k8s.io/api/core/v1"
	// metav1 "k8s.io/apimachinery/pkg/apis/meta/v1"
	proxyconfigapi "k8s.io/kubernetes/pkg/proxy/apis/config"
	proxyutil "k8s.io/kubernetes/pkg/proxy/util"
	"k8s.io/kubernetes/test/utils/ktesting"
	// "k8s.io/utils/ptr"

	// "github.com/onsi/ginkgo/v2"

	ctest "k8s.io/kubernetes/test/ctest"
	ctestglobals "k8s.io/kubernetes/test/ctest/ctestglobals"
	ctestutils "k8s.io/kubernetes/test/ctest/utils"
)

func TestCtestPlatformApplyDefaults(t *testing.T) {
	fmt.Println(ctestglobals.StartExtendModeSeparator)

	// Retrieve hard‑coded base configuration.
	hc := getHardCodedConfigInfoPlatformApplyDefaults()
	item, found := ctestutils.GetItemByExactTestInfo(hc, "platform apply defaults base")
	if !found {
		t.Fatalf("hard‑coded config not found")
	}
	fmt.Println(ctestglobals.DebugPrefix(), "get default configs:", item)

	// Generate a config object that we can override per test case.
	configObjs, configJson, err := ctest.GenerateEffectiveConfigReturnType[proxyconfigapi.KubeProxyConfiguration](item, ctest.OverrideOnly)
	if err != nil {
		t.Fatalf("failed to generate config: %v", err)
	}
	if configObjs == nil {
		t.Fatalf("no config objects generated")
	}
	fmt.Println(ctestglobals.DebugPrefix(), "New Json Test Configs:", string(configJson))
	fmt.Println(ctestglobals.DebugPrefix(), "Number of test configs:", len(configObjs))

	// Original test cases + a few edge cases.
	testCases := []struct {
		name                string
		mode                proxyconfigapi.ProxyMode
		expectedMode        proxyconfigapi.ProxyMode
		detectLocal         proxyconfigapi.LocalMode
		expectedDetectLocal proxyconfigapi.LocalMode
	}{
		{
			name:                "defaults",
			mode:                "",
			expectedMode:        proxyconfigapi.ProxyModeIPTables,
			detectLocal:         "",
			expectedDetectLocal: proxyconfigapi.LocalModeClusterCIDR,
		},
		{
			name:                "explicit",
			mode:                proxyconfigapi.ProxyModeIPTables,
			expectedMode:        proxyconfigapi.ProxyModeIPTables,
			detectLocal:         proxyconfigapi.LocalModeClusterCIDR,
			expectedDetectLocal: proxyconfigapi.LocalModeClusterCIDR,
		},
		{
			name:                "override mode",
			mode:                "ipvs",
			expectedMode:        proxyconfigapi.ProxyModeIPVS,
			detectLocal:         "",
			expectedDetectLocal: proxyconfigapi.LocalModeClusterCIDR,
		},
		{
			name:                "override detect-local",
			mode:                "",
			expectedMode:        proxyconfigapi.ProxyModeIPTables,
			detectLocal:         "NodeCIDR",
			expectedDetectLocal: proxyconfigapi.LocalModeNodeCIDR,
		},
		{
			name:                "override both",
			mode:                "ipvs",
			expectedMode:        proxyconfigapi.ProxyModeIPVS,
			detectLocal:         "NodeCIDR",
			expectedDetectLocal: proxyconfigapi.LocalModeNodeCIDR,
		},
		// Edge / invalid cases
		{
			name:                "invalid mode string",
			mode:                proxyconfigapi.ProxyMode("invalid"),
			expectedMode:        proxyconfigapi.ProxyModeIPTables,
			detectLocal:         "",
			expectedDetectLocal: proxyconfigapi.LocalModeClusterCIDR,
		},
		{
			name:                "empty detect‑local with valid mode",
			mode:                proxyconfigapi.ProxyModeIPTables,
			expectedMode:        proxyconfigapi.ProxyModeIPTables,
			detectLocal:         proxyconfigapi.LocalMode(""),
			expectedDetectLocal: proxyconfigapi.LocalModeClusterCIDR,
		},
	}

	for i, tc := range testCases {
		t.Run(tc.name, func(t *testing.T) {
			fmt.Printf("Running %d th test case.\n", i)
			// Use a fresh copy of the base config.
			cfg := configObjs[0]
			cfg.Mode = tc.mode
			cfg.DetectLocalMode = tc.detectLocal

			options := NewOptions()
			options.platformApplyDefaults(&cfg)

			if cfg.Mode != tc.expectedMode {
				t.Fatalf("expected mode: %s, got: %s", tc.expectedMode, cfg.Mode)
			}
			if cfg.DetectLocalMode != tc.expectedDetectLocal {
				t.Fatalf("expected detect‑local: %s, got: %s", tc.expectedDetectLocal, cfg.DetectLocalMode)
			}
		})
	}
	fmt.Println(ctestglobals.EndSeparator)
}

func getHardCodedConfigInfoPlatformApplyDefaults() ctestglobals.HardcodedConfig {
	return ctestglobals.HardcodedConfig{
		{
			FixtureFileName: "test_fixture.json",
			TestInfo:        []string{"platform apply defaults base"},
			Field:           "Mode",
			K8sObjects:      []string{"configmaps"},
			HardcodedConfig: proxyconfigapi.KubeProxyConfiguration{
				Mode:            "",
				DetectLocalMode: "",
			},
		},
	}
}

func TestCtestGetLocalDetectors(t *testing.T) {
	fmt.Println(ctestglobals.StartExtendModeSeparator)

	hc := getHardCodedConfigInfoGetLocalDetectors()
	item, found := ctestutils.GetItemByExactTestInfo(hc, "base getLocalDetectors")
	if !found {
		t.Fatalf("hard‑coded config not found")
	}
	fmt.Println(ctestglobals.DebugPrefix(), "get default configs:", item)

	// Generate a prototype config we will modify per test case.
	protoConfigs, configJson, err := ctest.GenerateEffectiveConfigReturnType[proxyconfigapi.KubeProxyConfiguration](item, ctest.OverrideOnly)
	if err != nil {
		t.Fatalf("failed to generate config: %v", err)
	}
	if protoConfigs == nil {
		t.Fatalf("no config objects generated")
	}
	fmt.Println(ctestglobals.DebugPrefix(), "New Json Test Configs:", string(configJson))
	fmt.Println(ctestglobals.DebugPrefix(), "Number of test configs:", len(protoConfigs))

	// Original cases plus a few edge cases.
	cases := []struct {
		name            string
		config          *proxyconfigapi.KubeProxyConfiguration
		primaryIPFamily v1.IPFamily
		nodePodCIDRs    []string
		expected        map[v1.IPFamily]proxyutil.LocalTrafficDetector
	}{
		{
			name: "LocalModeClusterCIDR, single‑stack IPv4 cluster",
			config: &proxyconfigapi.KubeProxyConfiguration{
				DetectLocalMode: proxyconfigapi.LocalModeClusterCIDR,
				DetectLocal: proxyconfigapi.DetectLocalConfiguration{
					ClusterCIDRs: []string{"10.0.0.0/14"},
				},
			},
			primaryIPFamily: v1.IPv4Protocol,
			expected: map[v1.IPFamily]proxyutil.LocalTrafficDetector{
				v1.IPv4Protocol: proxyutil.NewDetectLocalByCIDR("10.0.0.0/14"),
				v1.IPv6Protocol: proxyutil.NewNoOpLocalDetector(),
			},
		},
		// Edge case: unknown detect‑local mode
		{
			name: "unknown detect‑local mode",
			config: &proxyconfigapi.KubeProxyConfiguration{
				DetectLocalMode: proxyconfigapi.LocalMode("unknown"),
			},
			primaryIPFamily: v1.IPv4Protocol,
			expected: map[v1.IPFamily]proxyutil.LocalTrafficDetector{
				v1.IPv4Protocol: proxyutil.NewNoOpLocalDetector(),
				v1.IPv6Protocol: proxyutil.NewNoOpLocalDetector(),
			},
		},
	}

	for _, c := range cases {
		t.Run(c.name, func(t *testing.T) {
			logger, _ := ktesting.NewTestContext(t)

			// Clone base config and apply overrides specific to this case.
			base := protoConfigs[0]
			cfg := base
			if c.config != nil {
				cfg.DetectLocalMode = c.config.DetectLocalMode
				cfg.DetectLocal = c.config.DetectLocal
			}
			r := getLocalDetectors(logger, c.primaryIPFamily, &cfg, c.nodePodCIDRs)
			if !reflect.DeepEqual(r, c.expected) {
				t.Errorf("unexpected detectors, expected: %v, got: %v", c.expected, r)
			}
		})
	}
	fmt.Println(ctestglobals.EndSeparator)
}

func getHardCodedConfigInfoGetLocalDetectors() ctestglobals.HardcodedConfig {
	return ctestglobals.HardcodedConfig{
		{
			FixtureFileName: "test_fixture.json",
			TestInfo:        []string{"base getLocalDetectors"},
			Field:           "DetectLocalMode",
			K8sObjects:      []string{"configmaps"},
			HardcodedConfig: proxyconfigapi.KubeProxyConfiguration{
				DetectLocalMode: proxyconfigapi.LocalModeClusterCIDR,
				DetectLocal: proxyconfigapi.DetectLocalConfiguration{
					ClusterCIDRs: []string{},
				},
			},
		},
	}
}

// -----------------------------------------------------------------------------
// The remainder of the original file (TestConfigChange, TestGetConntrackMax,
// TestSetupConntrack, fakeConntracker, etc.) is unchanged and retains its
// original semantics. -----------------------------------------------------------------------------
