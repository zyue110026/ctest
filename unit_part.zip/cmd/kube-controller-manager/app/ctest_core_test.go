package app

import (
	"context"
	"fmt"
	"testing"
	"time"

	metav1 "k8s.io/apimachinery/pkg/apis/meta/v1"
	"k8s.io/client-go/discovery"
	// fakediscovery "k8s.io/client-go/discovery/fake"
	"k8s.io/client-go/informers"
	// clientset "k8s.io/client-go/kubernetes"
	// fakeclientset "k8s.io/client-go/kubernetes/fake"
	// restclient "k8s.io/client-go/rest"

	ctest "k8s.io/kubernetes/test/ctest"
	ctestglobals "k8s.io/kubernetes/test/ctest/ctestglobals"
	ctestutils "k8s.io/kubernetes/test/ctest/utils"
)

func getHardCodedConfigInfoCoreTest() ctestglobals.HardcodedConfig {
	return ctestglobals.HardcodedConfig{
		{
			FixtureFileName: "test_fixture.json",
			TestInfo:        []string{"default possible resources"},
			Field:           "possibleResources",
			K8sObjects:      []string{},
			HardcodedConfig: []*metav1.APIResourceList{
				{
					GroupVersion: "create/v1",
					APIResources: []metav1.APIResource{
						{
							Name:       "jobs",
							Verbs:      []string{"create", "list", "watch", "delete"},
							ShortNames: []string{"jz"},
							Categories: []string{"all"},
						},
					},
				},
			},
		},
	}
}

// TestCtestController_DiscoveryError rewrites the original TestController_DiscoveryError
// adding edge cases and using dynamically generated configuration.
func TestCtestController_DiscoveryError(t *testing.T) {
	fmt.Println(ctestglobals.StartSeparator)

	// ----------------------------------------------------------------------
	// 1. Load hard‑coded possible resources configuration (extend mode)
	// ----------------------------------------------------------------------
	item, found := ctestutils.GetItemByExactTestInfo(getHardCodedConfigInfoCoreTest(), "default possible resources")
	if !found {
		fmt.Println(ctestglobals.DebugPrefix(), "Failed to find config item by TestInfo")
		t.Fatalf("hard‑coded config not found")
	}
	fmt.Println(ctestglobals.DebugPrefix(), "get default configs:", item)

	fmt.Println(ctestglobals.StartExtendModeSeparator)
	configObjs, configJson, err := ctest.GenerateEffectiveConfigReturnType[[]*metav1.APIResourceList](item, ctest.ExtendOnly)
	if err != nil {
		fmt.Println(ctestglobals.DebugPrefix(), "Failed to get matched fixtures:", err)
		t.Fatalf("config generation failed: %v", err)
	}
	if configObjs == nil {
		fmt.Println(ctestglobals.DebugPrefix(), "Skipping test execution. No new configurations generated.")
		fmt.Println(ctestglobals.EndSeparator)
		return
	}
	fmt.Println(ctestglobals.DebugPrefix(), "New Json Test Configs:", string(configJson))
	fmt.Println(ctestglobals.DebugPrefix(), "Num of Test Cases:", len(configObjs))

	// ----------------------------------------------------------------------
	// 2. Define test cases (original + edge cases)
	// ----------------------------------------------------------------------
	originalTCs := map[string]struct {
		discoveryError    error
		expectedErr       bool
		possibleResources []*metav1.APIResourceList
	}{
		"No Discovery Error": {
			discoveryError:    nil,
			possibleResources: possibleDiscoveryResource(),
			expectedErr:       false,
		},
		"Discovery Calls Partially Failed": {
			discoveryError:    new(discovery.ErrGroupDiscoveryFailed),
			possibleResources: possibleDiscoveryResource(),
			expectedErr:       false,
		},
	}
	edgeTCs := map[string]struct {
		discoveryError    error
		expectedErr       bool
		possibleResources []*metav1.APIResourceList
	}{
		"Nil possibleResources": {
			discoveryError:    nil,
			possibleResources: nil,
			expectedErr:       true,
		},
		"Empty possibleResources": {
			discoveryError:    nil,
			possibleResources: []*metav1.APIResourceList{},
			expectedErr:       true,
		},
		"Discovery error unrelated type": {
			discoveryError:    fmt.Errorf("some other error"),
			possibleResources: possibleDiscoveryResource(),
			expectedErr:       true,
		},
	}
	// Merge maps
	tcs := make(map[string]struct {
		discoveryError    error
		expectedErr       bool
		possibleResources []*metav1.APIResourceList
	})
	for k, v := range originalTCs {
		tcs[k] = v
	}
	for k, v := range edgeTCs {
		tcs[k] = v
	}

	// ----------------------------------------------------------------------
	// 3. Execute test matrix using dynamic possibleResources
	// ----------------------------------------------------------------------
	controllerDescriptorMap := map[string]*ControllerDescriptor{
		"ResourceQuotaController":          newResourceQuotaControllerDescriptor(),
		"GarbageCollectorController":       newGarbageCollectorControllerDescriptor(),
		"EndpointSliceController":          newEndpointSliceControllerDescriptor(),
		"EndpointSliceMirroringController": newEndpointSliceMirroringControllerDescriptor(),
		"PodDisruptionBudgetController":    newDisruptionControllerDescriptor(),
	}
	for i, tc := range tcs {
		fmt.Printf("Running %d th test case.\n", i)
		fmt.Println(ctestglobals.DebugPrefix(), "Test case:", tc)

		// Use the first generated configObj as base possibleResources if the test case
		// does not define its own slice.
		var possible []*metav1.APIResourceList
		if tc.possibleResources != nil {
			possible = tc.possibleResources
		} else if len(configObjs) > 0 {
			possible = configObjs[0]
		}
		testDiscovery := FakeDiscoveryWithError{Err: tc.discoveryError, PossibleResources: possible}
		testClientset := NewFakeClientset(testDiscovery)
		testClientBuilder := TestClientBuilder{clientset: testClientset}
		testInformerFactory := informers.NewSharedInformerFactoryWithOptions(testClientset, time.Duration(1))
		ctx := ControllerContext{
			ClientBuilder:                   testClientBuilder,
			InformerFactory:                 testInformerFactory,
			ObjectOrMetadataInformerFactory: testInformerFactory,
			InformersStarted:                make(chan struct{}),
		}
		for controllerName, controllerDesc := range controllerDescriptorMap {
			_, _, err := controllerDesc.GetInitFunc()(context.TODO(), ctx, controllerName)
			if tc.expectedErr != (err != nil) {
				t.Errorf("%v test failed for use case: %v", controllerName, i)
			}
		}
		_, _, err := startModifiedNamespaceController(
			context.TODO(), ctx, testClientset, testClientBuilder.ConfigOrDie("namespace-controller"))
		if tc.expectedErr != (err != nil) {
			t.Errorf("Namespace Controller test failed for use case: %v", i)
		}
	}
	fmt.Println(ctestglobals.EndSeparator)
}
