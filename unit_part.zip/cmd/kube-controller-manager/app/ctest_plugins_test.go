package app

import (
	"fmt"
	// "reflect"
	// "sort"
	"testing"

	"k8s.io/klog/v2/ktesting"
	"k8s.io/kubernetes/pkg/controller/volume/persistentvolume/config"
	// "k8s.io/kubernetes/pkg/volume"

	ctest "k8s.io/kubernetes/test/ctest"
	ctestglobals "k8s.io/kubernetes/test/ctest/ctestglobals"
	ctestutils "k8s.io/kubernetes/test/ctest/utils"
)

func TestCtestProbeAttachableVolumePlugins(t *testing.T) {
	fmt.Println(ctestglobals.StartSeparator)

	configs, err := getVolumeConfigFromFixtureExtendMode("default volume config")
	if err != nil {
		t.Fatalf("failed to get config from fixture: %v", err)
	}
	if configs == nil {
		fmt.Println(ctestglobals.DebugPrefix(), "Skipping test execution. No new configurations generated.")
		return
	}
	fmt.Println(ctestglobals.DebugPrefix(), "Number of test cases:", len(configs))
	for i, cfg := range configs {
		fmt.Printf("Running %d th test case.\n", i)
		fmt.Println(ctestglobals.DebugPrefix(), "Config object:", cfg)

		// Extend config with an additional field (does not affect plugin selection)
		cfg.FlexVolumePluginDir = "/tmp/flex"

		logger, _ := ktesting.NewTestContext(t)
		plugins, err := ProbeAttachableVolumePlugins(logger, cfg)
		if err != nil {
			t.Fatalf("ProbeAttachableVolumePlugins failed: %s", err)
		}
		checkPlugins(t, plugins, []string{"kubernetes.io/csi", "kubernetes.io/fc", "kubernetes.io/iscsi"})
	}
	fmt.Println(ctestglobals.EndSeparator)
}

func TestCtestProbeExpandableVolumePlugins(t *testing.T) {
	fmt.Println(ctestglobals.StartSeparator)

	configs, err := getVolumeConfigFromFixtureExtendMode("default volume config")
	if err != nil {
		t.Fatalf("failed to get config from fixture: %v", err)
	}
	if configs == nil {
		fmt.Println(ctestglobals.DebugPrefix(), "Skipping test execution. No new configurations generated.")
		return
	}
	fmt.Println(ctestglobals.DebugPrefix(), "Number of test cases:", len(configs))
	for i, cfg := range configs {
		fmt.Printf("Running %d th test case.\n", i)
		fmt.Println(ctestglobals.DebugPrefix(), "Config object:", cfg)

		// Extend config with an additional field (does not affect plugin selection)
		cfg.FlexVolumePluginDir = "/opt/flex"

		logger, _ := ktesting.NewTestContext(t)
		plugins, err := ProbeExpandableVolumePlugins(logger, cfg)
		if err != nil {
			t.Fatalf("ProbeExpandableVolumePlugins failed: %s", err)
		}
		checkPlugins(t, plugins, []string{"kubernetes.io/portworx-volume"})
	}
	fmt.Println(ctestglobals.EndSeparator)
}

func TestCtestProbeControllerVolumePlugins(t *testing.T) {
	fmt.Println(ctestglobals.StartSeparator)

	configs, err := getVolumeConfigFromFixtureExtendMode("default volume config")
	if err != nil {
		t.Fatalf("failed to get config from fixture: %v", err)
	}
	if configs == nil {
		fmt.Println(ctestglobals.DebugPrefix(), "Skipping test execution. No new configurations generated.")
		return
	}
	fmt.Println(ctestglobals.DebugPrefix(), "Number of test cases:", len(configs))
	for i, cfg := range configs {
		fmt.Printf("Running %d th test case.\n", i)
		fmt.Println(ctestglobals.DebugPrefix(), "Config object:", cfg)

		// Extend config with an additional field (does not affect plugin selection)
		cfg.FlexVolumePluginDir = "/var/lib/kubelet/flexvolume"

		logger, _ := ktesting.NewTestContext(t)
		plugins, err := ProbeProvisionableRecyclableVolumePlugins(logger, cfg)
		if err != nil {
			t.Fatalf("ProbeProvisionableRecyclableVolumePlugins failed: %s", err)
		}
		checkPlugins(t, plugins, []string{"kubernetes.io/host-path", "kubernetes.io/nfs", "kubernetes.io/portworx-volume"})
	}
	fmt.Println(ctestglobals.EndSeparator)
}

/* -------------------- Dynamic Config Helpers -------------------- */

func getHardCodedConfigInfoVolumeConfig() ctestglobals.HardcodedConfig {
	return ctestglobals.HardcodedConfig{
		{
			FixtureFileName: "test_fixture.json",
			TestInfo:        []string{"default volume config"},
			Field:           "volumeConfiguration",
			K8sObjects:      []string{"persistentvolumes"},
			HardcodedConfig: config.VolumeConfiguration{
				EnableHostPathProvisioning: true,
				EnableDynamicProvisioning:  true,
				PersistentVolumeRecyclerConfiguration: config.PersistentVolumeRecyclerConfiguration{
					MaximumRetry:                5,
					MinimumTimeoutNFS:           30,
					PodTemplateFilePathNFS:      "",
					IncrementTimeoutNFS:         10,
					PodTemplateFilePathHostPath: "",
					MinimumTimeoutHostPath:      30,
					IncrementTimeoutHostPath:    10,
				},
				FlexVolumePluginDir: "",
			},
		},
	}
}

func getVolumeConfigFromFixtureExtendMode(testinfo string) ([]config.VolumeConfiguration, error) {
	hardcoded := getHardCodedConfigInfoVolumeConfig()
	item, found := ctestutils.GetItemByExactTestInfo(hardcoded, testinfo)
	if !found {
		fmt.Println(ctestglobals.DebugPrefix(), "Failed to find config item by TestInfo")
		return nil, fmt.Errorf("hardcoded config not found")
	}
	fmt.Println(ctestglobals.DebugPrefix(), "get default configs:", item)
	fmt.Println(ctestglobals.StartExtendModeSeparator)
	configObjs, configJson, err := ctest.GenerateEffectiveConfigReturnType[config.VolumeConfiguration](item, ctest.ExtendOnly)
	if err != nil {
		fmt.Println(ctestglobals.DebugPrefix(), "Failed to get matched fixtures: %v", err)
		return nil, err
	}
	if configObjs != nil {
		fmt.Println(ctestglobals.DebugPrefix(), "New Json Test Configs:", string(configJson))
		fmt.Println(ctestglobals.DebugPrefix(), "Num of Test Cases:", len(configObjs))
		return configObjs, nil
	}
	return nil, nil
}
