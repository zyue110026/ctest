package app

import (
	"fmt"
	"testing"
	"time"

	metav1 "k8s.io/apimachinery/pkg/apis/meta/v1"
	csrsigningconfig "k8s.io/kubernetes/pkg/controller/certificates/signer/config"

	ctestglobals "k8s.io/kubernetes/test/ctest/ctestglobals"
)

func TestCtestCertSpecified(t *testing.T) {
	fmt.Println(ctestglobals.StartSeparator)

	allConfig := csrsigningconfig.CSRSigningControllerConfiguration{
		ClusterSigningCertFile: "/cluster-signing-cert",
		ClusterSigningKeyFile:  "/cluster-signing-key",
		ClusterSigningDuration: metav1.Duration{Duration: 10 * time.Hour},
		KubeletServingSignerConfiguration: csrsigningconfig.CSRSigningConfiguration{
			CertFile: "/cluster-signing-kubelet-serving/cert-file",
			KeyFile:  "/cluster-signing-kubelet-serving/key-file",
		},
		KubeletClientSignerConfiguration: csrsigningconfig.CSRSigningConfiguration{
			CertFile: "/cluster-signing-kubelet-client/cert-file",
			KeyFile:  "/cluster-signing-kubelet-client/key-file",
		},
		KubeAPIServerClientSignerConfiguration: csrsigningconfig.CSRSigningConfiguration{
			CertFile: "/cluster-signing-kube-apiserver-client/cert-file",
			KeyFile:  "/cluster-signing-kube-apiserver-client/key-file",
		},
		LegacyUnknownSignerConfiguration: csrsigningconfig.CSRSigningConfiguration{
			CertFile: "/cluster-signing-legacy-unknown/cert-file",
			KeyFile:  "/cluster-signing-legacy-unknown/key-file",
		},
	}
	defaultOnly := csrsigningconfig.CSRSigningControllerConfiguration{
		ClusterSigningCertFile: "/cluster-signing-cert",
		ClusterSigningKeyFile:  "/cluster-signing-key",
		ClusterSigningDuration: metav1.Duration{Duration: 10 * time.Hour},
	}
	specifiedOnly := csrsigningconfig.CSRSigningControllerConfiguration{
		KubeletServingSignerConfiguration: csrsigningconfig.CSRSigningConfiguration{
			CertFile: "/cluster-signing-kubelet-serving/cert-file",
			KeyFile:  "/cluster-signing-kubelet-serving/key-file",
		},
		KubeletClientSignerConfiguration: csrsigningconfig.CSRSigningConfiguration{
			CertFile: "/cluster-signing-kubelet-client/cert-file",
			KeyFile:  "/cluster-signing-kubelet-client/key-file",
		},
		KubeAPIServerClientSignerConfiguration: csrsigningconfig.CSRSigningConfiguration{
			CertFile: "/cluster-signing-kube-apiserver-client/cert-file",
			KeyFile:  "/cluster-signing-kube-apiserver-client/key-file",
		},
		LegacyUnknownSignerConfiguration: csrsigningconfig.CSRSigningConfiguration{
			CertFile: "/cluster-signing-legacy-unknown/cert-file",
			KeyFile:  "/cluster-signing-legacy-unknown/key-file",
		},
	}
	halfASpecified := csrsigningconfig.CSRSigningControllerConfiguration{
		ClusterSigningCertFile: "/cluster-signing-cert",
		ClusterSigningKeyFile:  "/cluster-signing-key",
		ClusterSigningDuration: metav1.Duration{Duration: 10 * time.Hour},
		KubeletServingSignerConfiguration: csrsigningconfig.CSRSigningConfiguration{
			CertFile: "/cluster-signing-kubelet-serving/cert-file",
			KeyFile:  "/cluster-signing-kubelet-serving/key-file",
		},
		KubeletClientSignerConfiguration: csrsigningconfig.CSRSigningConfiguration{
			CertFile: "/cluster-signing-kubelet-client/cert-file",
			KeyFile:  "/cluster-signing-kubelet-client/key-file",
		},
	}
	halfBSpecified := csrsigningconfig.CSRSigningControllerConfiguration{
		ClusterSigningCertFile: "/cluster-signing-cert",
		ClusterSigningKeyFile:  "/cluster-signing-key",
		ClusterSigningDuration: metav1.Duration{Duration: 10 * time.Hour},
		KubeAPIServerClientSignerConfiguration: csrsigningconfig.CSRSigningConfiguration{
			CertFile: "/cluster-signing-kube-apiserver-client/cert-file",
			KeyFile:  "/cluster-signing-kube-apiserver-client/key-file",
		},
		LegacyUnknownSignerConfiguration: csrsigningconfig.CSRSigningConfiguration{
			CertFile: "/cluster-signing-legacy-unknown/cert-file",
			KeyFile:  "/cluster-signing-legacy-unknown/key-file",
		},
	}
	emptyConfig := csrsigningconfig.CSRSigningControllerConfiguration{}

	tests := []struct {
		name              string
		config            csrsigningconfig.CSRSigningControllerConfiguration
		specifiedFn       func(config csrsigningconfig.CSRSigningControllerConfiguration) bool
		expectedSpecified bool
		filesFn           func(config csrsigningconfig.CSRSigningControllerConfiguration) (string, string)
		expectedCert      string
		expectedKey       string
	}{
		// Original test cases
		{
			name:              "allConfig-KubeletServingSignerFilesSpecified",
			config:            allConfig,
			specifiedFn:       areKubeletServingSignerFilesSpecified,
			expectedSpecified: true,
			filesFn:           getKubeletServingSignerFiles,
			expectedCert:      "/cluster-signing-kubelet-serving/cert-file",
			expectedKey:       "/cluster-signing-kubelet-serving/key-file",
		},
		{
			name:              "defaultOnly-KubeletServingSignerFilesSpecified",
			config:            defaultOnly,
			specifiedFn:       areKubeletServingSignerFilesSpecified,
			expectedSpecified: false,
			filesFn:           getKubeletServingSignerFiles,
			expectedCert:      "/cluster-signing-cert",
			expectedKey:       "/cluster-signing-key",
		},
		{
			name:              "specifiedOnly-KubeletServingSignerFilesSpecified",
			config:            specifiedOnly,
			specifiedFn:       areKubeletServingSignerFilesSpecified,
			expectedSpecified: true,
			filesFn:           getKubeletServingSignerFiles,
			expectedCert:      "/cluster-signing-kubelet-serving/cert-file",
			expectedKey:       "/cluster-signing-kubelet-serving/key-file",
		},
		{
			name:              "halfASpecified-KubeletServingSignerFilesSpecified",
			config:            halfASpecified,
			specifiedFn:       areKubeletServingSignerFilesSpecified,
			expectedSpecified: true,
			filesFn:           getKubeletServingSignerFiles,
			expectedCert:      "/cluster-signing-kubelet-serving/cert-file",
			expectedKey:       "/cluster-signing-kubelet-serving/key-file",
		},
		{
			name:              "halfBSpecified-KubeletServingSignerFilesSpecified",
			config:            halfBSpecified,
			specifiedFn:       areKubeletServingSignerFilesSpecified,
			expectedSpecified: false,
			filesFn:           getKubeletServingSignerFiles,
			expectedCert:      "",
			expectedKey:       "",
		},
		{
			name:              "allConfig-KubeletClientSignerFiles",
			config:            allConfig,
			specifiedFn:       areKubeletClientSignerFilesSpecified,
			expectedSpecified: true,
			filesFn:           getKubeletClientSignerFiles,
			expectedCert:      "/cluster-signing-kubelet-client/cert-file",
			expectedKey:       "/cluster-signing-kubelet-client/key-file",
		},
		{
			name:              "defaultOnly-KubeletClientSignerFiles",
			config:            defaultOnly,
			specifiedFn:       areKubeletClientSignerFilesSpecified,
			expectedSpecified: false,
			filesFn:           getKubeletClientSignerFiles,
			expectedCert:      "/cluster-signing-cert",
			expectedKey:       "/cluster-signing-key",
		},
		{
			name:              "specifiedOnly-KubeletClientSignerFiles",
			config:            specifiedOnly,
			specifiedFn:       areKubeletClientSignerFilesSpecified,
			expectedSpecified: true,
			filesFn:           getKubeletClientSignerFiles,
			expectedCert:      "/cluster-signing-kubelet-client/cert-file",
			expectedKey:       "/cluster-signing-kubelet-client/key-file",
		},
		{
			name:              "halfASpecified-KubeletClientSignerFiles",
			config:            halfASpecified,
			specifiedFn:       areKubeletClientSignerFilesSpecified,
			expectedSpecified: true,
			filesFn:           getKubeletClientSignerFiles,
			expectedCert:      "/cluster-signing-kubelet-client/cert-file",
			expectedKey:       "/cluster-signing-kubelet-client/key-file",
		},
		{
			name:              "halfBSpecified-KubeletClientSignerFiles",
			config:            halfBSpecified,
			specifiedFn:       areKubeletClientSignerFilesSpecified,
			expectedSpecified: false,
			filesFn:           getKubeletClientSignerFiles,
			expectedCert:      "",
			expectedKey:       "",
		},
		{
			name:              "allConfig-KubeAPIServerClientSignerFilesSpecified",
			config:            allConfig,
			specifiedFn:       areKubeAPIServerClientSignerFilesSpecified,
			expectedSpecified: true,
			filesFn:           getKubeAPIServerClientSignerFiles,
			expectedCert:      "/cluster-signing-kube-apiserver-client/cert-file",
			expectedKey:       "/cluster-signing-kube-apiserver-client/key-file",
		},
		{
			name:              "defaultOnly-KubeAPIServerClientSignerFilesSpecified",
			config:            defaultOnly,
			specifiedFn:       areKubeAPIServerClientSignerFilesSpecified,
			expectedSpecified: false,
			filesFn:           getKubeAPIServerClientSignerFiles,
			expectedCert:      "/cluster-signing-cert",
			expectedKey:       "/cluster-signing-key",
		},
		{
			name:              "specifiedOnly-KubeAPIServerClientSignerFilesSpecified",
			config:            specifiedOnly,
			specifiedFn:       areKubeAPIServerClientSignerFilesSpecified,
			expectedSpecified: true,
			filesFn:           getKubeAPIServerClientSignerFiles,
			expectedCert:      "/cluster-signing-kube-apiserver-client/cert-file",
			expectedKey:       "/cluster-signing-kube-apiserver-client/key-file",
		},
		{
			name:              "halfASpecified-KubeAPIServerClientSignerFilesSpecified",
			config:            halfASpecified,
			specifiedFn:       areKubeAPIServerClientSignerFilesSpecified,
			expectedSpecified: false,
			filesFn:           getKubeAPIServerClientSignerFiles,
			expectedCert:      "",
			expectedKey:       "",
		},
		{
			name:              "halfBSpecified-KubeAPIServerClientSignerFilesSpecified",
			config:            halfBSpecified,
			specifiedFn:       areKubeAPIServerClientSignerFilesSpecified,
			expectedSpecified: true,
			filesFn:           getKubeAPIServerClientSignerFiles,
			expectedCert:      "/cluster-signing-kube-apiserver-client/cert-file",
			expectedKey:       "/cluster-signing-kube-apiserver-client/key-file",
		},
		{
			name:              "allConfig-LegacyUnknownSignerFilesSpecified",
			config:            allConfig,
			specifiedFn:       areLegacyUnknownSignerFilesSpecified,
			expectedSpecified: true,
			filesFn:           getLegacyUnknownSignerFiles,
			expectedCert:      "/cluster-signing-legacy-unknown/cert-file",
			expectedKey:       "/cluster-signing-legacy-unknown/key-file",
		},
		{
			name:              "defaultOnly-LegacyUnknownSignerFilesSpecified",
			config:            defaultOnly,
			specifiedFn:       areLegacyUnknownSignerFilesSpecified,
			expectedSpecified: false,
			filesFn:           getLegacyUnknownSignerFiles,
			expectedCert:      "/cluster-signing-cert",
			expectedKey:       "/cluster-signing-key",
		},
		{
			name:              "specifiedOnly-LegacyUnknownSignerFilesSpecified",
			config:            specifiedOnly,
			specifiedFn:       areLegacyUnknownSignerFilesSpecified,
			expectedSpecified: true,
			filesFn:           getLegacyUnknownSignerFiles,
			expectedCert:      "/cluster-signing-legacy-unknown/cert-file",
			expectedKey:       "/cluster-signing-legacy-unknown/key-file",
		},
		{
			name:              "halfASpecified-LegacyUnknownSignerFilesSpecified",
			config:            halfASpecified,
			specifiedFn:       areLegacyUnknownSignerFilesSpecified,
			expectedSpecified: false,
			filesFn:           getLegacyUnknownSignerFiles,
			expectedCert:      "",
			expectedKey:       "",
		},
		{
			name:              "halfBSpecified-LegacyUnknownSignerFilesSpecified",
			config:            halfBSpecified,
			specifiedFn:       areLegacyUnknownSignerFilesSpecified,
			expectedSpecified: true,
			filesFn:           getLegacyUnknownSignerFiles,
			expectedCert:      "/cluster-signing-legacy-unknown/cert-file",
			expectedKey:       "/cluster-signing-legacy-unknown/key-file",
		},
		// Edge case: completely empty configuration
		{
			name:              "emptyConfig-KubeletServingSignerFilesSpecified",
			config:            emptyConfig,
			specifiedFn:       areKubeletServingSignerFilesSpecified,
			expectedSpecified: false,
			filesFn:           getKubeletServingSignerFiles,
			expectedCert:      "",
			expectedKey:       "",
		},
		{
			name:              "emptyConfig-KubeletClientSignerFilesSpecified",
			config:            emptyConfig,
			specifiedFn:       areKubeletClientSignerFilesSpecified,
			expectedSpecified: false,
			filesFn:           getKubeletClientSignerFiles,
			expectedCert:      "",
			expectedKey:       "",
		},
		{
			name:              "emptyConfig-KubeAPIServerClientSignerFilesSpecified",
			config:            emptyConfig,
			specifiedFn:       areKubeAPIServerClientSignerFilesSpecified,
			expectedSpecified: false,
			filesFn:           getKubeAPIServerClientSignerFiles,
			expectedCert:      "",
			expectedKey:       "",
		},
		{
			name:              "emptyConfig-LegacyUnknownSignerFilesSpecified",
			config:            emptyConfig,
			specifiedFn:       areLegacyUnknownSignerFilesSpecified,
			expectedSpecified: false,
			filesFn:           getLegacyUnknownSignerFiles,
			expectedCert:      "",
			expectedKey:       "",
		},
	}

	for _, test := range tests {
		t.Run(test.name, func(t *testing.T) {
			actualSpecified := test.specifiedFn(test.config)
			if actualSpecified != test.expectedSpecified {
				t.Errorf("expectedSpecified=%v, got=%v", test.expectedSpecified, actualSpecified)
			}
			actualCert, actualKey := test.filesFn(test.config)
			if actualCert != test.expectedCert {
				t.Errorf("expectedCert=%q, got=%q", test.expectedCert, actualCert)
			}
			if actualKey != test.expectedKey {
				t.Errorf("expectedKey=%q, got=%q", test.expectedKey, actualKey)
			}
		})
	}
	fmt.Println(ctestglobals.EndSeparator)
}