package app

import (
	"context"
	"fmt"
	"testing"

	"k8s.io/apimachinery/pkg/util/version"
	utilfeature "k8s.io/apiserver/pkg/util/feature"
	featuregatetesting "k8s.io/component-base/featuregate/testing"
	controllermanagercontroller "k8s.io/controller-manager/controller"
	"k8s.io/klog/v2/ktesting"
	"k8s.io/kubernetes/cmd/kube-controller-manager/names"
	"k8s.io/kubernetes/pkg/features"

	ctestglobals "k8s.io/kubernetes/test/ctest/ctestglobals"
)

func TestCtestTaintEvictionControllerGating(t *testing.T) {
	fmt.Println(ctestglobals.DebugPrefix(), "Starting TestCtestTaintEvictionControllerGating")

	tests := []struct {
		name               string
		enableFeatureGate  bool
		expectInitFuncCall bool
		controllerList     []string
	}{
		{
			name:               "standalone taint-eviction-controller should run when SeparateTaintEvictionController feature gate is enabled",
			enableFeatureGate:  true,
			expectInitFuncCall: true,
			controllerList:     []string{names.TaintEvictionController},
		},
		{
			name:               "standalone taint-eviction-controller should not run when SeparateTaintEvictionController feature gate is not enabled",
			enableFeatureGate:  false,
			expectInitFuncCall: false,
			controllerList:     []string{names.TaintEvictionController},
		},
		{
			name:               "standalone taint-eviction-controller not listed should not run even when feature gate is enabled",
			enableFeatureGate:  true,
			expectInitFuncCall: false,
			controllerList:     []string{}, // controller not requested
		},
		{
			name:               "standalone taint-eviction-controller listed but feature gate disabled should not run",
			enableFeatureGate:  false,
			expectInitFuncCall: false,
			controllerList:     []string{names.TaintEvictionController},
		},
	}

	fmt.Println(ctestglobals.DebugPrefix(), "Number of test cases:", len(tests))

	for i, test := range tests {
		fmt.Printf("Running %d th test case: %s\n", i, test.name)
		t.Run(test.name, func(t *testing.T) {
			featuregatetesting.SetFeatureGateEmulationVersionDuringTest(t, utilfeature.DefaultFeatureGate, version.MustParse("1.33"))
			featuregatetesting.SetFeatureGateDuringTest(t, utilfeature.DefaultFeatureGate, features.SeparateTaintEvictionController, test.enableFeatureGate)

			_, ctx := ktesting.NewTestContext(t)
			ctx, cancel := context.WithCancel(ctx)
			defer cancel()

			controllerCtx := ControllerContext{}
			if len(test.controllerList) > 0 {
				controllerCtx.ComponentConfig.Generic.Controllers = test.controllerList
			} else {
				// empty list means no controllers are explicitly requested
				controllerCtx.ComponentConfig.Generic.Controllers = []string{}
			}

			initFuncCalled := false

			taintEvictionControllerDescriptor := NewControllerDescriptors()[names.TaintEvictionController]
			taintEvictionControllerDescriptor.initFunc = func(ctx context.Context, controllerContext ControllerContext, controllerName string) (controller controllermanagercontroller.Interface, enabled bool, err error) {
				initFuncCalled = true
				return nil, true, nil
			}

			healthCheck, err := StartController(ctx, controllerCtx, taintEvictionControllerDescriptor, nil)
			if err != nil {
				t.Fatalf("starting a TaintEvictionController controller should not return an error: %v", err)
			}
			if test.expectInitFuncCall != initFuncCalled {
				t.Fatalf("TaintEvictionController init call check failed: expected=%v, got=%v", test.expectInitFuncCall, initFuncCalled)
			}
			hasHealthCheck := healthCheck != nil
			if test.expectInitFuncCall != hasHealthCheck {
				t.Fatalf("TaintEvictionController healthCheck check failed: expected=%v, got=%v", test.expectInitFuncCall, hasHealthCheck)
			}
		})
	}
}