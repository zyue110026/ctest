package options

import (
	"fmt"
	"testing"
)

func TestCtestGetServiceIPAndRanges(t *testing.T) {
	tests := []struct {
		body                    string
		apiServerServiceIP      string
		primaryServiceIPRange   string
		secondaryServiceIPRange string
		expectedError           bool
	}{
		// original test cases
		{"", "10.0.0.1", "10.0.0.0/24", "<nil>", false},
		{"192.0.2.1/24", "192.0.2.1", "192.0.2.0/24", "<nil>", false},
		{"192.0.2.1/24,192.168.128.0/17", "192.0.2.1", "192.0.2.0/24", "192.168.128.0/17", false},
		{"192.0.2.1/24,2001:db2:1:3:4::1/112", "192.0.2.1", "192.0.2.0/24", "2001:db2:1:3:4::/112", false},
		{"2001:db2:1:3:4::1/112,192.0.2.1/24", "2001:db2:1:3:4::1", "2001:db2:1:3:4::/112", "192.0.2.0/24", false},
		{"192.0.2.1/30,192.168.128.0/17", "<nil>", "<nil>", "<nil>", true},
		{"192.0.2.1/33,192.168.128.0/17", "<nil>", "<nil>", "<nil>", true},
		{"192.0.2.1/24,192.168.128.0/33", "<nil>", "<nil>", "<nil>", true},
		{"2001:db2:1:3:4::1/129,192.0.2.1/24", "<nil>", "<nil>", "<nil>", true},
		{"192.0.2.1/24,2001:db2:1:3:4::1/129", "<nil>", "<nil>", "<nil>", true},
		{"192.0.2.1,192.168.128.0/17", "<nil>", "<nil>", "<nil>", true},
		{"192.0.2.1/24,192.168.128.1", "<nil>", "<nil>", "<nil>", true},
		{"2001:db2:1:3:4::1,192.0.2.1/24", "<nil>", "<nil>", "<nil>", true},
		{"192.0.2.1/24,2001:db2:1:3:4::1", "<nil>", "<nil>", "<nil>", true},
		{"bad.ip.range,192.168.0.2/24", "<nil>", "<nil>", "<nil>", true},
		{"192.168.0.2/24,bad.ip.range", "<nil>", "<nil>", "<nil>", true},

		// edge / additional test cases
		{" 192.0.2.1/24", "192.0.2.1", "192.0.2.0/24", "<nil>", false},                           // leading space
		{"192.0.2.1/24 ", "192.0.2.1", "192.0.2.0/24", "<nil>", false},                           // trailing space
		{"\t192.0.2.1/24\n", "192.0.2.1", "192.0.2.0/24", "<nil>", false},                        // whitespace characters
		{",", "<nil>", "<nil>", "<nil>", true},                                                   // empty entries
		{"192.0.2.1/24,,192.168.128.0/17", "<nil>", "<nil>", "<nil>", true},                       // double comma
		{"192.0.2.1/24, ", "<nil>", "<nil>", "<nil>", true},                                       // comma with space only second entry
		{"invalid", "<nil>", "<nil>", "<nil>", true},                                             // completely invalid string
		{"192.0.2.1/24,2001:db2:1:3:4::1/112,10.0.0.0/8", "192.0.2.1", "192.0.2.0/24", "2001:db2:1:3:4::/112", false}, // triple entry (ignore extra)
	}

	fmt.Println("Starting TestCtestGetServiceIPAndRanges with", len(tests), "cases")
	for i, test := range tests {
		fmt.Printf("Running case #%d: %q\n", i, test.body)
		apiServerServiceIP, primaryServiceIPRange, secondaryServiceIPRange, err := getServiceIPAndRanges(test.body)

		if apiServerServiceIP.String() != test.apiServerServiceIP {
			t.Errorf("case %d: expected apiServerServiceIP: %s, got: %s", i, test.apiServerServiceIP, apiServerServiceIP.String())
		}

		if primaryServiceIPRange.String() != test.primaryServiceIPRange {
			t.Errorf("case %d: expected primaryServiceIPRange: %s, got: %s", i, test.primaryServiceIPRange, primaryServiceIPRange.String())
		}

		if secondaryServiceIPRange.String() != test.secondaryServiceIPRange {
			t.Errorf("case %d: expected secondaryServiceIPRange: %s, got: %s", i, test.secondaryServiceIPRange, secondaryServiceIPRange.String())
		}

		if (err == nil) == test.expectedError {
			t.Errorf("case %d: expected err to be: %t, but it was %t", i, test.expectedError, err != nil)
		}
	}
	fmt.Println("Completed TestCtestGetServiceIPAndRanges")
}