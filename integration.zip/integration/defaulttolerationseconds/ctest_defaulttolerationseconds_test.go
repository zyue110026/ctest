package defaulttolerationseconds

import (
	"context"
	"fmt"
	"testing"

	v1 "k8s.io/api/core/v1"
	metav1 "k8s.io/apimachinery/pkg/apis/meta/v1"
	// "k8s.io/apiserver/pkg/admission"
	// "k8s.io/apiserver/pkg/admission/initializer"
	"k8s.io/apimachinery/pkg/util/uuid"
	"k8s.io/kubernetes/pkg/apis/core/helper"
	"k8s.io/kubernetes/pkg/controlplane"
	// "k8s.io/kubernetes/plugin/pkg/admission/defaulttolerationseconds"
	"k8s.io/kubernetes/test/integration/framework"
	"k8s.io/kubernetes/test/utils/ktesting"

	ctest "k8s.io/kubernetes/test/ctest"
	ctestglobals "k8s.io/kubernetes/test/ctest/ctestglobals"
	ctestutils "k8s.io/kubernetes/test/ctest/utils"
)

func TestCtestAdmission(t *testing.T) {
	// -------------------------------------------------------------------------
	// Setup test server with admission plugin
	// -------------------------------------------------------------------------
	tCtx := ktesting.Init(t)
	handler, err := newHandlerForTest()
	if err != nil {
		t.Fatalf("unexpected error initializing handler: %v", err)
	}
	client, _, tearDownFn := framework.StartTestServer(tCtx, t, framework.TestServerSetup{
		ModifyServerConfig: func(cfg *controlplane.Config) {
			cfg.ControlPlane.Generic.EnableProfiling = true
			cfg.ControlPlane.Generic.AdmissionControl = handler
		},
	})
	defer tearDownFn()

	// -------------------------------------------------------------------------
	// Namespace creation
	// -------------------------------------------------------------------------
	ns := framework.CreateNamespaceOrDie(client, "default-toleration-seconds", t)
	defer framework.DeleteNamespaceOrDie(client, ns, t)

	// -------------------------------------------------------------------------
	// Load hard‑coded pod spec configuration
	// -------------------------------------------------------------------------
	fmt.Println(ctestglobals.DebugPrefix(), "Start of TestCtestAdmission")
	hc := getHardCodedConfigInfoDefaultTolerationSeconds()
	item, found := ctestutils.GetItemByExactTestInfo(hc, "default pod spec")
	if !found {
		fmt.Println(ctestglobals.DebugPrefix(), "Failed to find hard‑coded config")
		t.Skip("hard‑coded config not found")
	}
	fmt.Println(ctestglobals.DebugPrefix(), "Matched config item:", item)
	fmt.Println(ctestglobals.StartOverrideModeSeparator)
	configObjs, configJSON, err := ctest.GenerateEffectiveConfigReturnType[v1.PodSpec](item, ctest.OverrideOnly)
	if err != nil {
		t.Fatalf("failed to generate effective config: %v", err)
	}
	if configObjs == nil {
		fmt.Println(ctestglobals.DebugPrefix(), "Skipping test execution. No new configurations generated.")
		return
	}
	fmt.Println(ctestglobals.DebugPrefix(), "New Json Test Configs:", string(configJSON))
	fmt.Println(ctestglobals.DebugPrefix(), "Number of test configs:", len(configObjs))

	// -------------------------------------------------------------------------
	// Define test cases (original + edge cases)
	// -------------------------------------------------------------------------
	var defaultSeconds int64 = 300
	nodeNotReady := v1.Toleration{
		Key:               v1.TaintNodeNotReady,
		Operator:          v1.TolerationOpExists,
		Effect:            v1.TaintEffectNoExecute,
		TolerationSeconds: &defaultSeconds,
	}
	nodeUnreachable := v1.Toleration{
		Key:               v1.TaintNodeUnreachable,
		Operator:          v1.TolerationOpExists,
		Effect:            v1.TaintEffectNoExecute,
		TolerationSeconds: &defaultSeconds,
	}

	testCases := []struct {
		name               string
		existingToleration []v1.Toleration
		expectedToleration []v1.Toleration
	}{
		{
			name:               "original behavior – no tolerations",
			existingToleration: nil,
			expectedToleration: []v1.Toleration{nodeNotReady, nodeUnreachable},
		},
		{
			name: "existing nodeNotReady toleration with custom seconds – should not be overridden",
			existingToleration: []v1.Toleration{
				{
					Key:               v1.TaintNodeNotReady,
					Operator:          v1.TolerationOpExists,
					Effect:            v1.TaintEffectNoExecute,
					TolerationSeconds: func() *int64 { v := int64(100); return &v }(),
				},
			},
			expectedToleration: []v1.Toleration{
				{
					Key:               v1.TaintNodeNotReady,
					Operator:          v1.TolerationOpExists,
					Effect:            v1.TaintEffectNoExecute,
					TolerationSeconds: func() *int64 { v := int64(100); return &v }(),
				},
				nodeUnreachable,
			},
		},
		{
			name: "existing nodeUnreachable toleration without seconds – plugin should add default seconds",
			existingToleration: []v1.Toleration{
				{
					Key:      v1.TaintNodeUnreachable,
					Operator: v1.TolerationOpExists,
					Effect:   v1.TaintEffectNoExecute,
				},
			},
			expectedToleration: []v1.Toleration{nodeNotReady, nodeUnreachable},
		},
	}

	// -------------------------------------------------------------------------
	// Execute each configuration with each test case
	// -------------------------------------------------------------------------
	for cfgIdx, cfg := range configObjs {
		fmt.Printf("Running config #%d\n", cfgIdx)
		fmt.Println(cfg)
		for tcIdx, tc := range testCases {
			fmt.Printf("Running test case #%d: %s\n", tcIdx, tc.name)
			podName := "pod-" + string(uuid.NewUUID())
			pod := &v1.Pod{
				ObjectMeta: metav1.ObjectMeta{
					Name:      podName,
					Namespace: ns.Name,
				},
				Spec: cfg,
			}
			// inject any existing tolerations defined by the test case
			if len(tc.existingToleration) > 0 {
				pod.Spec.Tolerations = append(pod.Spec.Tolerations, tc.existingToleration...)
			}
			createdPod, err := client.CoreV1().Pods(pod.Namespace).Create(context.Background(), pod, metav1.CreateOptions{})
			if err != nil {
				t.Fatalf("error creating pod %s: %v", podName, err)
			}
			// -----------------------------------------------------------------
			// Validation of tolerations
			// -----------------------------------------------------------------
			found := 0
			for _, tnt := range createdPod.Spec.Tolerations {
				if tnt.MatchToleration(&nodeNotReady) && helper.Semantic.DeepEqual(tnt, nodeNotReady) {
					found++
					continue
				}
				if tnt.MatchToleration(&nodeUnreachable) && helper.Semantic.DeepEqual(tnt, nodeUnreachable) {
					found++
					continue
				}
			}
			expectedCount := 0
			for _, exp := range tc.expectedToleration {
				if exp.MatchToleration(&nodeNotReady) && helper.Semantic.DeepEqual(exp, nodeNotReady) {
					expectedCount++
				}
				if exp.MatchToleration(&nodeUnreachable) && helper.Semantic.DeepEqual(exp, nodeUnreachable) {
					expectedCount++
				}
			}
			if found != expectedCount {
				t.Fatalf("test case %q failed: expected %d default tolerations, got %d. Tolerations: %v",
					tc.name, expectedCount, found, createdPod.Spec.Tolerations)
			}
		}
	}
	fmt.Println(ctestglobals.EndSeparator)
}

// getHardCodedConfigInfoDefaultTolerationSeconds returns the minimal pod spec
// required for the admission test.
func getHardCodedConfigInfoDefaultTolerationSeconds() ctestglobals.HardcodedConfig {
	return ctestglobals.HardcodedConfig{
		{
			FixtureFileName: "test_fixture.json",
			TestInfo:        []string{"default pod spec"},
			Field:           "spec",
			K8sObjects:      []string{"pods"},
			HardcodedConfig: v1.PodSpec{
				Containers: []v1.Container{
					{
						Name:  "test",
						Image: "an-image",
					},
				},
				RestartPolicy: v1.RestartPolicyNever,
			},
		},
	}
}
