package openshift

import (
	"fmt"
	"testing"

	genericapiserver "k8s.io/apiserver/pkg/server"
	"k8s.io/kubernetes/pkg/controlplane"
	controlplaneapiserver "k8s.io/kubernetes/pkg/controlplane/apiserver"

	ctest "k8s.io/kubernetes/test/ctest"
	ctestglobals "k8s.io/kubernetes/test/ctest/ctestglobals"
	ctestutils "k8s.io/kubernetes/test/ctest/utils"
)

func TestCtestApiserverExportsSymbols(t *testing.T) {
	fmt.Println(ctestglobals.StartSeparator)

	hc := getHardCodedConfigInfoApiserverExportsSymbols()
	item, found := ctestutils.GetItemByExactTestInfo(hc, "apiserver exports symbols")
	if !found {
		fmt.Println(ctestglobals.DebugPrefix(), "Failed to find config item by TestInfo")
		t.Fatalf("Get default hardcoded config failed.")
	}
	fmt.Println(ctestglobals.DebugPrefix(), "get default configs:", item)

	fmt.Println(ctestglobals.StartOverrideModeSeparator)
	cfgObjs, cfgJson, err := ctest.GenerateEffectiveConfigReturnType[controlplane.Config](item, ctest.OverrideOnly)
	if err != nil {
		fmt.Println(ctestglobals.DebugPrefix(), "Failed to get matched fixtures:", err)
		t.Fatalf("Failed to get matched fixtures: %v", err)
	}
	if cfgObjs == nil {
		fmt.Println(ctestglobals.DebugPrefix(), "Skipping test execution. No new configurations generated.")
		fmt.Println(ctestglobals.EndSeparator)
		return
	}
	fmt.Println(ctestglobals.DebugPrefix(), "New Json Test Configs:", string(cfgJson))
	fmt.Println(ctestglobals.DebugPrefix(), "Number of Test Cases:", len(cfgObjs))

	for i, cfg := range cfgObjs {
		fmt.Printf("Running %d th test case.\n", i)
		fmt.Println(cfg)

		_ = &cfg

		_ = &controlplane.Instance{
			ControlPlane: &controlplaneapiserver.Server{
				GenericAPIServer: &genericapiserver.GenericAPIServer{},
			},
		}
	}
	fmt.Println(ctestglobals.EndSeparator)
}

func getHardCodedConfigInfoApiserverExportsSymbols() ctestglobals.HardcodedConfig {
	return ctestglobals.HardcodedConfig{
		{
			FixtureFileName: "test_fixture.json",
			TestInfo:        []string{"apiserver exports symbols"},
			Field:           "EnableMetrics",
			K8sObjects:      []string{"pods"},
			HardcodedConfig: controlplane.Config{
				ControlPlane: controlplaneapiserver.Config{
					Generic: &genericapiserver.Config{
						EnableMetrics: true,
					},
					Extra: controlplaneapiserver.Extra{
						EnableLogsSupport: false,
					},
				},
			},
		},
	}
}