package dualstack

import (
	"fmt"
	"testing"
	"time"

	// "github.com/onsi/gomega"
	"k8s.io/api/core/v1"
	discovery "k8s.io/api/discovery/v1"
	"k8s.io/apimachinery/pkg/api/errors"
	metav1 "k8s.io/apimachinery/pkg/apis/meta/v1"
	"k8s.io/apimachinery/pkg/util/intstr"
	"k8s.io/apimachinery/pkg/util/uuid"
	"k8s.io/apimachinery/pkg/util/wait"
	"k8s.io/client-go/informers"
	"k8s.io/kubernetes/cmd/kube-apiserver/app/options"
	"k8s.io/kubernetes/pkg/controller/endpoint"
	"k8s.io/kubernetes/pkg/controller/endpointslice"
	"k8s.io/kubernetes/test/integration/framework"
	"k8s.io/kubernetes/test/utils/ktesting"

	ctest "k8s.io/kubernetes/test/ctest"
	ctestglobals "k8s.io/kubernetes/test/ctest/ctestglobals"
	ctestutils "k8s.io/kubernetes/test/ctest/utils"
)

func TestCtestDualStackEndpoints(t *testing.T) {
	fmt.Println(ctestglobals.StartSeparator)

	// Dynamic server config (service CIDRs)
	serviceCIDR := "10.0.0.0/16"
	secondaryServiceCIDR := "2001:db8:1::/112"
	labelMap := func() map[string]string {
		return map[string]string{"foo": "bar"}
	}

	// Setup test server with dynamic service CIDR ranges
	tCtx := ktesting.Init(t)
	client, _, tearDownFn := framework.StartTestServer(tCtx, t, framework.TestServerSetup{
		ModifyServerRunOptions: func(opts *options.ServerRunOptions) {
			opts.ServiceClusterIPRanges = fmt.Sprintf("%s,%s", serviceCIDR, secondaryServiceCIDR)
			opts.Admission.GenericAdmission.DisablePlugins = []string{"ServiceAccount"}
		},
	})
	defer tearDownFn()

	// Wait for default "kubernetes" service
	if err := wait.Poll(250*time.Millisecond, time.Minute, func() (bool, error) {
		_, err := client.CoreV1().Services(metav1.NamespaceDefault).Get(tCtx, "kubernetes", metav1.GetOptions{})
		if err != nil && !errors.IsNotFound(err) {
			return false, err
		}
		return !errors.IsNotFound(err), nil
	}); err != nil {
		t.Fatalf("Creating kubernetes service timed out")
	}

	// Informer factory
	resyncPeriod := 0 * time.Hour
	informerFactory := informers.NewSharedInformerFactory(client, resyncPeriod)

	// Create fake node
	testNode := &v1.Node{
		ObjectMeta: metav1.ObjectMeta{
			Name: "fakenode",
		},
		Spec: v1.NodeSpec{Unschedulable: false},
		Status: v1.NodeStatus{
			Conditions: []v1.NodeCondition{
				{
					Type:              v1.NodeReady,
					Status:            v1.ConditionTrue,
					Reason:            "schedulable condition",
					LastHeartbeatTime: metav1.Time{Time: time.Now()},
				},
			},
		},
	}
	if _, err := client.CoreV1().Nodes().Create(tCtx, testNode, metav1.CreateOptions{}); err != nil {
		t.Fatalf("Failed to create Node %q: %v", testNode.Name, err)
	}

	// Controllers
	epController := endpoint.NewEndpointController(
		tCtx,
		informerFactory.Core().V1().Pods(),
		informerFactory.Core().V1().Services(),
		informerFactory.Core().V1().Endpoints(),
		client,
		1*time.Second)

	epsController := endpointslice.NewController(
		tCtx,
		informerFactory.Core().V1().Pods(),
		informerFactory.Core().V1().Services(),
		informerFactory.Core().V1().Nodes(),
		informerFactory.Discovery().V1().EndpointSlices(),
		int32(100),
		client,
		1*time.Second)

	informerFactory.Start(tCtx.Done())
	go epController.Run(tCtx, 1)
	go epsController.Run(tCtx, 1)

	// Original testcases
	originalTestCases := []struct {
		name           string
		serviceType    v1.ServiceType
		ipFamilies     []v1.IPFamily
		ipFamilyPolicy v1.IPFamilyPolicy
	}{
		{
			name:           "Service IPv4 Only",
			serviceType:    v1.ServiceTypeClusterIP,
			ipFamilies:     []v1.IPFamily{v1.IPv4Protocol},
			ipFamilyPolicy: v1.IPFamilyPolicySingleStack,
		},
		{
			name:           "Service IPv6 Only",
			serviceType:    v1.ServiceTypeClusterIP,
			ipFamilies:     []v1.IPFamily{v1.IPv6Protocol},
			ipFamilyPolicy: v1.IPFamilyPolicySingleStack,
		},
		{
			name:           "Service IPv6 IPv4 Dual Stack",
			serviceType:    v1.ServiceTypeClusterIP,
			ipFamilies:     []v1.IPFamily{v1.IPv6Protocol, v1.IPv4Protocol},
			ipFamilyPolicy: v1.IPFamilyPolicyRequireDualStack,
		},
		{
			name:           "Service IPv4 IPv6 Dual Stack",
			serviceType:    v1.ServiceTypeClusterIP,
			ipFamilies:     []v1.IPFamily{v1.IPv4Protocol, v1.IPv6Protocol},
			ipFamilyPolicy: v1.IPFamilyPolicyRequireDualStack,
		},
	}

	// Edge testcases (extend original pod spec with an extra env var)
	edgeTestCases := []struct {
		name string
	}{
		{name: "Edge: extra env var on pod"},
	}

	// Merge original and edge cases
	var testCases []struct {
		name           string
		serviceType    v1.ServiceType
		ipFamilies     []v1.IPFamily
		ipFamilyPolicy v1.IPFamilyPolicy
		extendPod      bool
	}
	for _, oc := range originalTestCases {
		testCases = append(testCases, struct {
			name           string
			serviceType    v1.ServiceType
			ipFamilies     []v1.IPFamily
			ipFamilyPolicy v1.IPFamilyPolicy
			extendPod      bool
		}{
			name:           oc.name,
			serviceType:    oc.serviceType,
			ipFamilies:     oc.ipFamilies,
			ipFamilyPolicy: oc.ipFamilyPolicy,
			extendPod:      false,
		})
	}
	for _, ec := range edgeTestCases {
		// reuse first original case parameters but set extendPod true
		base := originalTestCases[0]
		testCases = append(testCases, struct {
			name           string
			serviceType    v1.ServiceType
			ipFamilies     []v1.IPFamily
			ipFamilyPolicy v1.IPFamilyPolicy
			extendPod      bool
		}{
			name:           ec.name,
			serviceType:    base.serviceType,
			ipFamilies:     base.ipFamilies,
			ipFamilyPolicy: base.ipFamilyPolicy,
			extendPod:      true,
		})
	}

	// Load hard‑coded pod spec config
	podCfgInfo := getHardCodedConfigInfoDualstackPod()
	podItem, found := ctestutils.GetItemByExactTestInfo(podCfgInfo, "default pod spec")
	if !found {
		fmt.Println(ctestglobals.DebugPrefix(), "Failed to find pod config")
	}
	fmt.Println(ctestglobals.DebugPrefix(), "Pod config item:", podItem)
	fmt.Println(ctestglobals.StartExtendModeSeparator)
	podConfigObjs, podConfigJSON, err := ctest.GenerateEffectiveConfigReturnType[v1.PodSpec](podItem, ctest.ExtendOnly)
	if err != nil {
		fmt.Println(ctestglobals.DebugPrefix(), "Failed to generate pod config:", err)
	}
	if podConfigObjs != nil {
		fmt.Println(ctestglobals.DebugPrefix(), "Pod config JSON:", string(podConfigJSON))
		fmt.Println(ctestglobals.DebugPrefix(), "Number of pod config objects:", len(podConfigObjs))
	}
	// Load hard‑coded service spec config
	svcCfgInfo := getHardCodedConfigInfoDualstackService()
	svcItem, found := ctestutils.GetItemByExactTestInfo(svcCfgInfo, "default service spec")
	if !found {
		fmt.Println(ctestglobals.DebugPrefix(), "Failed to find service config")
	}
	fmt.Println(ctestglobals.DebugPrefix(), "Service config item:", svcItem)
	fmt.Println(ctestglobals.StartExtendModeSeparator)
	svcConfigObjs, svcConfigJSON, err := ctest.GenerateEffectiveConfigReturnType[v1.ServiceSpec](svcItem, ctest.ExtendOnly)
	if err != nil {
		fmt.Println(ctestglobals.DebugPrefix(), "Failed to generate service config:", err)
	}
	if svcConfigObjs != nil {
		fmt.Println(ctestglobals.DebugPrefix(), "Service config JSON:", string(svcConfigJSON))
		fmt.Println(ctestglobals.DebugPrefix(), "Number of service config objects:", len(svcConfigObjs))
	}

	// Execute tests
	for i, tc := range testCases {
		t.Run(tc.name, func(t *testing.T) {
			ns := framework.CreateNamespaceOrDie(client, fmt.Sprintf("test-endpointslice-dualstack-%d", i), t)
			defer framework.DeleteNamespaceOrDie(client, ns, t)

			// Pick first pod config (or fallback to empty)
			var podSpec v1.PodSpec
			if len(podConfigObjs) > 0 {
				podSpec = podConfigObjs[0]
			}
			// Extend pod spec with extra env when requested
			if tc.extendPod {
				if len(podSpec.Containers) == 0 {
					t.Fatalf("Pod spec has no containers to extend")
				}
				podSpec.Containers[0].Env = []v1.EnvVar{
					{Name: "EXTRA_ENV", Value: "extra"},
				}
			}
			// Ensure mandatory fields
			podSpec.NodeName = "fakenode"
			if len(podSpec.Containers) == 0 {
				podSpec.Containers = []v1.Container{{Name: "fake-name", Image: "fakeimage"}}
			} else {
				if podSpec.Containers[0].Name == "" {
					podSpec.Containers[0].Name = "fake-name"
				}
				if podSpec.Containers[0].Image == "" {
					podSpec.Containers[0].Image = "fakeimage"
				}
			}
			pod := &v1.Pod{
				ObjectMeta: metav1.ObjectMeta{
					Name:      "test-pod-" + string(uuid.NewUUID()),
					Namespace: ns.Name,
					Labels:    labelMap(),
				},
				Spec: podSpec,
			}
			createdPod, err := client.CoreV1().Pods(ns.Name).Create(tCtx, pod, metav1.CreateOptions{})
			if err != nil {
				t.Fatalf("Failed to create pod %s: %v", pod.Name, err)
			}
			// Set pod IPs
			podIPbyFamily := map[v1.IPFamily]string{
				v1.IPv4Protocol: "1.1.1.1",
				v1.IPv6Protocol: "2001:db2::65",
			}
			createdPod.Status = v1.PodStatus{
				Phase:  v1.PodRunning,
				PodIPs: []v1.PodIP{{IP: podIPbyFamily[v1.IPv4Protocol]}, {IP: podIPbyFamily[v1.IPv6Protocol]}},
			}
			_, err = client.CoreV1().Pods(ns.Name).UpdateStatus(tCtx, createdPod, metav1.UpdateOptions{})
			if err != nil {
				t.Fatalf("Failed to update pod status %s: %v", pod.Name, err)
			}

			// Service spec
			var svcSpec v1.ServiceSpec
			if len(svcConfigObjs) > 0 {
				svcSpec = svcConfigObjs[0]
			}
			svcSpec.Type = tc.serviceType
			svcSpec.IPFamilies = tc.ipFamilies
			svcSpec.IPFamilyPolicy = &tc.ipFamilyPolicy
			svcSpec.Selector = labelMap()
			svcSpec.Ports = []v1.ServicePort{
				{
					Name:       fmt.Sprintf("port-test-%d", i),
					Port:       443,
					TargetPort: intstr.IntOrString{IntVal: 443},
					Protocol:   v1.ProtocolTCP,
				},
			}
			svc := &v1.Service{
				ObjectMeta: metav1.ObjectMeta{
					Name:      fmt.Sprintf("svc-test-%d-%s", i, string(uuid.NewUUID())),
					Namespace: ns.Name,
					Labels:    labelMap(),
				},
				Spec: svcSpec,
			}
			_, err = client.CoreV1().Services(ns.Name).Create(tCtx, svc, metav1.CreateOptions{})
			if err != nil {
				t.Fatalf("Error creating service: %v", err)
			}

			// Verify legacy Endpoints
			if err := wait.PollImmediate(1*time.Second, wait.ForeverTestTimeout, func() (bool, error) {
				e, err := client.CoreV1().Endpoints(ns.Name).Get(tCtx, svc.Name, metav1.GetOptions{})
				if err != nil {
					t.Logf("Error fetching endpoints: %v", err)
					return false, nil
				}
				if len(e.Subsets) > 0 && len(e.Subsets[0].NotReadyAddresses) > 0 {
					if e.Subsets[0].NotReadyAddresses[0].IP == podIPbyFamily[tc.ipFamilies[0]] {
						return true, nil
					}
					t.Logf("Endpoint address %s does not match expected %s", e.Subsets[0].Addresses[0].IP, podIPbyFamily[tc.ipFamilies[0]])
				}
				return false, nil
			}); err != nil {
				t.Fatalf("Endpoints not found: %v", err)
			}

			// Verify EndpointSlices
			if err := wait.PollImmediate(1*time.Second, wait.ForeverTestTimeout, func() (bool, error) {
				ls := discovery.LabelServiceName + "=" + svc.Name
				esList, err := client.DiscoveryV1().EndpointSlices(ns.Name).List(tCtx, metav1.ListOptions{LabelSelector: ls})
				if err != nil {
					t.Logf("Error listing EndpointSlices: %v", err)
					return false, nil
				}
				if len(esList.Items) != len(tc.ipFamilies) {
					t.Logf("Waiting for EndpointSlices count %d, got %d", len(tc.ipFamilies), len(esList.Items))
					return false, nil
				}
				for _, ipFamily := range tc.ipFamilies {
					found := false
					for _, slice := range esList.Items {
						if len(slice.Endpoints) > 0 && len(slice.Endpoints[0].Addresses) > 0 {
							if string(ipFamily) == string(slice.AddressType) && slice.Endpoints[0].Addresses[0] == podIPbyFamily[ipFamily] {
								found = true
								break
							}
						}
					}
					if !found {
						t.Logf("EndpointSlice missing address for %s", ipFamily)
						return false, nil
					}
				}
				return true, nil
			}); err != nil {
				t.Fatalf("Error waiting for endpoint slices: %v", err)
			}
		})
	}
	fmt.Println(ctestglobals.EndSeparator)
}

// Hard‑coded PodSpec used for dynamic configuration
func getHardCodedConfigInfoDualstackPod() ctestglobals.HardcodedConfig {
	return ctestglobals.HardcodedConfig{
		{
			FixtureFileName: "test_fixture.json",
			TestInfo:        []string{"default pod spec"},
			Field:           "spec",
			K8sObjects:      []string{"pods"},
			HardcodedConfig: v1.PodSpec{
				NodeName: "fakenode",
				Containers: []v1.Container{
					{
						Name:  "fake-name",
						Image: "fakeimage",
					},
				},
			},
		},
	}
}

// Hard‑coded ServiceSpec used for dynamic configuration
func getHardCodedConfigInfoDualstackService() ctestglobals.HardcodedConfig {
	return ctestglobals.HardcodedConfig{
		{
			FixtureFileName: "test_fixture.json",
			TestInfo:        []string{"default service spec"},
			Field:           "spec",
			K8sObjects: []string{
				"services",
				"pods",
				"endpoints",
				"endpointslices",
			},
			HardcodedConfig: v1.ServiceSpec{
				Type: v1.ServiceTypeClusterIP,
				Ports: []v1.ServicePort{
					{
						Name:       "port-default",
						Port:       443,
						TargetPort: intstr.IntOrString{IntVal: 443},
						Protocol:   v1.ProtocolTCP,
					},
				},
			},
		},
	}
}
