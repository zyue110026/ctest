package certificates

import (
	"context"
	"crypto/x509"
	"crypto/x509/pkix"
	"fmt"
	"testing"
	"time"

	certv1 "k8s.io/api/certificates/v1"
	// rbacv1 "k8s.io/api/rbac/v1"
	metav1 "k8s.io/apimachinery/pkg/apis/meta/v1"
	// "k8s.io/apimachinery/pkg/runtime/schema"
	// "k8s.io/apimachinery/pkg/util/wait"
	"k8s.io/client-go/informers"
	clientset "k8s.io/client-go/kubernetes"
	restclient "k8s.io/client-go/rest"
	"k8s.io/klog/v2/ktesting"
	kubeapiservertesting "k8s.io/kubernetes/cmd/kube-apiserver/app/testing"
	// "k8s.io/kubernetes/pkg/controller/certificates"
	"k8s.io/kubernetes/pkg/controller/certificates/approver"
	// "k8s.io/kubernetes/test/integration/authutil"
	"k8s.io/kubernetes/test/integration/framework"

	ctest "k8s.io/kubernetes/test/ctest"
	ctestglobals "k8s.io/kubernetes/test/ctest/ctestglobals"
	ctestutils "k8s.io/kubernetes/test/ctest/utils"
)

func TestCtestController_AutoApproval(t *testing.T) {
	// Load hard‑coded CSR spec template
	fmt.Println(ctestglobals.DebugPrefix(), "Loading default CSR spec config")
	item, found := ctestutils.GetItemByExactTestInfo(getHardCodedConfigInfoControllerApproval(), "default csr spec")
	if !found {
		t.Fatalf("default csr spec config not found")
	}
	fmt.Println(ctestglobals.DebugPrefix(), "Default config item:", item)
	fmt.Println(ctestglobals.StartOverrideModeSeparator)
	configObjs, configJSON, err := ctest.GenerateEffectiveConfigReturnType[certv1.CertificateSigningRequestSpec](item, ctest.OverrideOnly)
	if err != nil {
		t.Fatalf("failed to generate config: %v", err)
	}
	if configObjs == nil {
		fmt.Println(ctestglobals.DebugPrefix(), "Skipping test execution. No new configurations generated.")
		return
	}
	fmt.Println(ctestglobals.DebugPrefix(), "New Json Test Configs:", string(configJSON))
	fmt.Println(ctestglobals.DebugPrefix(), "Number of CSR spec configs:", len(configObjs))

	// original valid test cases
	originalTests := map[string]struct {
		signerName          string
		request             []byte
		usages              []certv1.KeyUsage
		username            string
		autoApproved        bool
		grantNodeClient     bool
		grantSelfNodeClient bool
	}{
		"should auto‑approve CSR that has kube‑apiserver‑client‑kubelet signerName and matches requirements": {
			signerName:          certv1.KubeAPIServerClientKubeletSignerName,
			request:             pemWithTemplate(&x509.CertificateRequest{Subject: pkix.Name{CommonName: "system:node:abc", Organization: []string{"system:nodes"}}}),
			usages:              []certv1.KeyUsage{certv1.UsageDigitalSignature, certv1.UsageKeyEncipherment, certv1.UsageClientAuth},
			username:            "system:node:abc",
			grantSelfNodeClient: true,
			autoApproved:        true,
		},
		"should auto‑approve CSR that has kube‑apiserver‑client‑kubelet signerName and matches requirements despite missing username if nodeclient permissions are granted": {
			signerName:      certv1.KubeAPIServerClientKubeletSignerName,
			request:         pemWithTemplate(&x509.CertificateRequest{Subject: pkix.Name{CommonName: "system:node:abc", Organization: []string{"system:nodes"}}}),
			usages:          []certv1.KeyUsage{certv1.UsageDigitalSignature, certv1.UsageKeyEncipherment, certv1.UsageClientAuth},
			username:        "does-not-match-cn",
			grantNodeClient: true,
			autoApproved:    true,
		},
		"should not auto‑approve CSR that has kube‑apiserver‑client signerName that DOES match kubelet CSR requirements": {
			signerName:   certv1.KubeAPIServerClientSignerName,
			request:      pemWithTemplate(&x509.CertificateRequest{Subject: pkix.Name{CommonName: "system:node:abc", Organization: []string{"system:nodes"}}}),
			usages:       []certv1.KeyUsage{certv1.UsageDigitalSignature, certv1.UsageKeyEncipherment, certv1.UsageClientAuth},
			username:     "system:node:abc",
			autoApproved: false,
		},
	}
	// edge / invalid test cases
	edgeTests := map[string]struct {
		signerName          string
		request             []byte
		usages              []certv1.KeyUsage
		username            string
		autoApproved        bool
		grantNodeClient     bool
		grantSelfNodeClient bool
	}{
		"invalid empty signerName": {
			signerName:   "",
			request:      pemWithTemplate(&x509.CertificateRequest{Subject: pkix.Name{CommonName: "system:node:xyz", Organization: []string{"system:nodes"}}}),
			usages:       []certv1.KeyUsage{certv1.UsageClientAuth},
			username:     "system:node:xyz",
			autoApproved: false,
		},
		"invalid nil request": {
			signerName:   certv1.KubeAPIServerClientKubeletSignerName,
			request:      nil,
			usages:       []certv1.KeyUsage{certv1.UsageClientAuth},
			username:     "system:node:xyz",
			autoApproved: false,
		},
		"invalid empty usages": {
			signerName:   certv1.KubeAPIServerClientKubeletSignerName,
			request:      pemWithTemplate(&x509.CertificateRequest{Subject: pkix.Name{CommonName: "system:node:xyz", Organization: []string{"system:nodes"}}}),
			usages:       []certv1.KeyUsage{},
			username:     "system:node:xyz",
			autoApproved: false,
		},
		"invalid missing username with grantSelfNodeClient": {
			signerName:          certv1.KubeAPIServerClientKubeletSignerName,
			request:             pemWithTemplate(&x509.CertificateRequest{Subject: pkix.Name{CommonName: "system:node:xyz", Organization: []string{"system:nodes"}}}),
			usages:              []certv1.KeyUsage{certv1.UsageClientAuth},
			username:            "",
			grantSelfNodeClient: true,
			autoApproved:        false,
		},
	}
	// merge original and edge cases
	tests := make(map[string]struct {
		signerName          string
		request             []byte
		usages              []certv1.KeyUsage
		username            string
		autoApproved        bool
		grantNodeClient     bool
		grantSelfNodeClient bool
	})
	for k, v := range originalTests {
		tests[k] = v
	}
	for k, v := range edgeTests {
		tests[k] = v
	}

	for cfgIdx, cfg := range configObjs {
		fmt.Printf("Running CSR spec config #%d\n", cfgIdx)
		fmt.Println(cfg)
		for name, tc := range tests {
			t.Run(name, func(t *testing.T) {
				_, ctx := ktesting.NewTestContext(t)
				ctx, cancel := context.WithCancel(ctx)
				defer cancel()

				// Start apiserver with default options (can be extended later)
				s := kubeapiservertesting.StartTestServerOrDie(t, kubeapiservertesting.NewDefaultTestServerOptions(), []string{""}, framework.SharedEtcd())
				defer s.TearDownFn()
				client := clientset.NewForConfigOrDie(s.ClientConfig)
				informerFactory := informers.NewSharedInformerFactory(clientset.NewForConfigOrDie(restclient.AddUserAgent(s.ClientConfig, "certificatesigningrequest-informers")), time.Second)

				// Register controller
				c := approver.NewCSRApprovingController(ctx, client, informerFactory.Certificates().V1().CertificateSigningRequests())
				informerFactory.Start(ctx.Done())
				go c.Run(ctx, 1)

				// Grant permissions if required
				if tc.grantNodeClient {
					grantUserNodeClientPermissions(t, client, tc.username, false)
				}
				if tc.grantSelfNodeClient {
					grantUserNodeClientPermissions(t, client, tc.username, true)
				}

				// Impersonate user
				impersonationConfig := restclient.CopyConfig(s.ClientConfig)
				impersonationConfig.Impersonate.UserName = tc.username
				impersonationClient, err := clientset.NewForConfig(impersonationConfig)
				if err != nil {
					t.Fatalf("error creating impersonation client: %v", err)
				}

				// Build CSR using dynamic spec template and test overrides
				spec := cfg
				if tc.signerName != "" {
					spec.SignerName = tc.signerName
				}
				if tc.request != nil {
					spec.Request = tc.request
				}
				if tc.usages != nil {
					spec.Usages = tc.usages
				}
				csr := &certv1.CertificateSigningRequest{
					ObjectMeta: metav1.ObjectMeta{
						Name: "csr",
					},
					Spec: spec,
				}
				_, err = impersonationClient.CertificatesV1().CertificateSigningRequests().Create(context.TODO(), csr, metav1.CreateOptions{})
				if err != nil {
					t.Fatalf("failed to create CSR: %v", err)
				}

				if tc.autoApproved {
					if err := waitForCertificateRequestApproved(client, csr.Name); err != nil {
						t.Errorf("expected auto‑approval, got error: %v", err)
					}
				} else {
					if err := ensureCertificateRequestNotApproved(client, csr.Name); err != nil {
						t.Errorf("expected no auto‑approval, got error: %v", err)
					}
				}
			})
		}
	}
	fmt.Println(ctestglobals.EndSeparator)
}

func getHardCodedConfigInfoControllerApproval() ctestglobals.HardcodedConfig {
	return ctestglobals.HardcodedConfig{
		{
			FixtureFileName: "test_fixture.json",
			TestInfo:        []string{"default csr spec"},
			Field:           "spec",
			K8sObjects:      []string{"certificatesigningrequests"},
			HardcodedConfig: certv1.CertificateSigningRequestSpec{
				SignerName: certv1.KubeAPIServerClientKubeletSignerName,
				Request:    []byte("placeholder"),
				Usages:     []certv1.KeyUsage{certv1.UsageClientAuth},
			},
		},
	}
}
