package certificates

import (
	"context"
	// "fmt"
	"testing"

	certv1 "k8s.io/api/certificates/v1"
	rbacv1 "k8s.io/api/rbac/v1"
	metav1 "k8s.io/apimachinery/pkg/apis/meta/v1"
	// "k8s.io/apimachinery/pkg/runtime/schema"
	clientset "k8s.io/client-go/kubernetes"
	restclient "k8s.io/client-go/rest"
	kubeapiservertesting "k8s.io/kubernetes/cmd/kube-apiserver/app/testing"
	// "k8s.io/kubernetes/test/integration/authutil"
	"k8s.io/kubernetes/test/integration/framework"

	// ctest "k8s.io/kubernetes/test/ctest"
	ctestglobals "k8s.io/kubernetes/test/ctest/ctestglobals"
	// ctestutils "k8s.io/kubernetes/test/ctest/utils"
)

func TestCtestCSRSignerNameSigningPlugin(t *testing.T) {
	tests := map[string]struct {
		allowedSignerName string
		signerName        string
		error             string
	}{
		"should admit when a user has permission for the exact signerName": {
			allowedSignerName: "example.com/something",
			signerName:        "example.com/something",
		},
		"should admit when a user has permission for the wildcard-suffixed signerName": {
			allowedSignerName: "example.com/*",
			signerName:        "example.com/something",
		},
		"should deny if a user does not have permission for the given signerName": {
			allowedSignerName: "example.com/not-something",
			signerName:        "example.com/something",
			error:             `certificatesigningrequests.certificates.k8s.io "csr" is forbidden: user not permitted to sign requests with signerName "example.com/something"`,
		},
		// edge / invalid cases
		"empty allowedSignerName should deny any signerName": {
			allowedSignerName: "",
			signerName:        "example.com/something",
			error:             `certificatesigningrequests.certificates.k8s.io "csr" is forbidden: user not permitted to sign requests with signerName "example.com/something"`,
		},
		"wildcard only allowedSignerName should admit any signerName": {
			allowedSignerName: "*",
			signerName:        "example.com/anything",
		},
		"invalid allowedSignerName format should deny": {
			allowedSignerName: "invalid//format",
			signerName:        "example.com/something",
			error:             `certificatesigningrequests.certificates.k8s.io "csr" is forbidden: user not permitted to sign requests with signerName "example.com/something"`,
		},
		"empty signerName should be denied even if allowed": {
			allowedSignerName: "example.com/*",
			signerName:        "",
			error:             `certificatesigningrequests.certificates.k8s.io "csr" is forbidden: user not permitted to sign requests with signerName ""`,
		},
	}
	for name, test := range tests {
		t.Run(name, func(t *testing.T) {
			s := kubeapiservertesting.StartTestServerOrDie(t, kubeapiservertesting.NewDefaultTestServerOptions(), []string{"--authorization-mode=RBAC"}, framework.SharedEtcd())
			defer s.TearDownFn()
			client := clientset.NewForConfigOrDie(s.ClientConfig)

			if err := client.RbacV1().ClusterRoleBindings().Delete(context.TODO(), "cluster-admin", metav1.DeleteOptions{}); err != nil {
				t.Fatal(err)
			}

			const username = "test-user"
			grantUserPermissionToSignFor(t, client, username, test.allowedSignerName)
			csr := createTestingCSR(t, client.CertificatesV1().CertificateSigningRequests(), "csr", test.signerName, "")

			testuserConfig := restclient.CopyConfig(s.ClientConfig)
			testuserConfig.Impersonate = restclient.ImpersonationConfig{UserName: username}
			testuserClient := clientset.NewForConfigOrDie(testuserConfig)

			if _, err := client.CertificatesV1().CertificateSigningRequests().UpdateStatus(context.TODO(), csr, metav1.UpdateOptions{DryRun: []string{metav1.DryRunAll}}); err != nil {
				t.Errorf("expected no superuser error but got: %v", err)
			}

			_, err := testuserClient.CertificatesV1().CertificateSigningRequests().UpdateStatus(context.TODO(), csr, metav1.UpdateOptions{})
			if err != nil && test.error != err.Error() {
				t.Errorf("expected error %q but got: %v", test.error, err)
			}
			if err == nil && test.error != "" {
				t.Errorf("expected to get an error %q but got none", test.error)
			}
		})
	}
}

// Hardcoded config for the signing ClusterRole used in the test.
func getHardCodedConfigInfoClusterRole() ctestglobals.HardcodedConfig {
	return ctestglobals.HardcodedConfig{
		{
			FixtureFileName: "test_fixture.json",
			TestInfo:        []string{"signer clusterrole"},
			Field:           "rules",
			K8sObjects:      []string{"clusterroles"},
			HardcodedConfig: rbacv1.ClusterRole{
				Rules: []rbacv1.PolicyRule{
					{
						Verbs:     []string{"sign"},
						APIGroups: []string{certv1.SchemeGroupVersion.Group},
						Resources: []string{"signers"},
						// ResourceNames will be set dynamically in the test
					},
					{
						Verbs:     []string{"update"},
						APIGroups: []string{certv1.SchemeGroupVersion.Group},
						Resources: []string{"certificatesigningrequests/status"},
					},
				},
			},
		},
	}
}
