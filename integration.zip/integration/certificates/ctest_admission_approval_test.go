package certificates

import (
	"context"
	"fmt"
	"testing"

	certv1 "k8s.io/api/certificates/v1"
	v1 "k8s.io/api/core/v1"
	// rbacv1 "k8s.io/api/rbac/v1"
	metav1 "k8s.io/apimachinery/pkg/apis/meta/v1"
	// "k8s.io/apimachinery/pkg/runtime/schema"
	clientset "k8s.io/client-go/kubernetes"
	restclient "k8s.io/client-go/rest"
	kubeapiservertesting "k8s.io/kubernetes/cmd/kube-apiserver/app/testing"
	// "k8s.io/kubernetes/test/integration/authutil"
	"k8s.io/kubernetes/test/integration/framework"

	ctest "k8s.io/kubernetes/test/ctest"
	ctestglobals "k8s.io/kubernetes/test/ctest/ctestglobals"
	ctestutils "k8s.io/kubernetes/test/ctest/utils"
	// "github.com/google/uuid"
)

type signerTestSpec struct {
	AllowedSignerName string `json:"allowedSignerName"`
	SignerName        string `json:"signerName"`
	ExpectedError     string `json:"error,omitempty"`
}

// Rewritten test with dynamic configuration and edge cases
func TestCtestCSRSignerNameApprovalPlugin(t *testing.T) {
	fmt.Println(ctestglobals.StartUnionModeSeparator)

	// Retrieve hard‑coded baseline configuration
	item, found := ctestutils.GetItemByExactTestInfo(getHardCodedConfigInfoCSRSigner(), "CSR signer approval plugin")
	if !found {
		fmt.Println(ctestglobals.DebugPrefix(), "Failed to find config item by TestInfo")
		t.Fatalf("hard‑coded config not found")
	}
	fmt.Println(ctestglobals.DebugPrefix(), "get default configs:", item)

	// Generate effective configs (allow both extend and override)
	configObjs, configJson, err := ctest.GenerateEffectiveConfigReturnType[signerTestSpec](item, ctest.Union)
	if err != nil {
		fmt.Println(ctestglobals.DebugPrefix(), "Failed to get matched fixtures:", err)
		t.Fatalf("GenerateEffectiveConfigReturnType failed: %v", err)
	}
	if configObjs != nil {
		fmt.Println(ctestglobals.DebugPrefix(), "New Json Test Configs:", string(configJson))
		fmt.Println(ctestglobals.DebugPrefix(), "Number of test cases (baseline):", len(configObjs))
	} else {
		fmt.Println(ctestglobals.DebugPrefix(), "Skipping test execution. No baseline configs found.")
		return
	}

	// Edge / invalid cases
	edgeCases := []signerTestSpec{
		{
			AllowedSignerName: "",
			SignerName:        "example.com/something",
			ExpectedError:     `certificatesigningrequests.certificates.k8s.io "csr" is forbidden`,
		},
		{
			AllowedSignerName: "example.com/*",
			SignerName:        "example.com/other",
			ExpectedError:     "",
		},
		{
			AllowedSignerName: "example.com/something",
			SignerName:        "",
			ExpectedError:     `certificatesigningrequests.certificates.k8s.io "csr" is forbidden`,
		},
	}
	// Append edge cases to the slice of configs
	configObjs = append(configObjs, edgeCases...)
	fmt.Println(ctestglobals.DebugPrefix(), "Total number of test cases after adding edges:", len(configObjs))

	for i, spec := range configObjs {
		testName := fmt.Sprintf("case-%d", i)
		if spec.ExpectedError != "" {
			testName = fmt.Sprintf("%s-expected-error", testName)
		}
		t.Run(testName, func(t *testing.T) {
			// Run an apiserver with the default configuration options.
			s := kubeapiservertesting.StartTestServerOrDie(t, kubeapiservertesting.NewDefaultTestServerOptions(), []string{"--authorization-mode=RBAC"}, framework.SharedEtcd())
			defer s.TearDownFn()
			client := clientset.NewForConfigOrDie(s.ClientConfig)

			// Grant 'test-user' permission to approve CertificateSigningRequests with the specified signerName.
			const username = "test-user"
			grantUserPermissionToApproveFor(t, client, username, spec.AllowedSignerName)

			// Create a CSR to attempt to approve.
			csr := createTestingCSR(t, client.CertificatesV1().CertificateSigningRequests(), "csr", spec.SignerName, "")

			// Create a second client, impersonating the 'test-user' for us to test with.
			testuserConfig := restclient.CopyConfig(s.ClientConfig)
			testuserConfig.Impersonate = restclient.ImpersonationConfig{UserName: username}
			testuserClient := clientset.NewForConfigOrDie(testuserConfig)

			// Attempt to update the Approved condition.
			csr.Status.Conditions = append(csr.Status.Conditions, certv1.CertificateSigningRequestCondition{
				Type:    certv1.CertificateApproved,
				Status:  v1.ConditionTrue,
				Reason:  "AutoApproved",
				Message: "Approved during integration test",
			})
			_, err := testuserClient.CertificatesV1().CertificateSigningRequests().UpdateApproval(context.TODO(), csr.Name, csr, metav1.UpdateOptions{})
			if err != nil && spec.ExpectedError != "" && err.Error() != spec.ExpectedError {
				t.Errorf("expected error %q but got: %v", spec.ExpectedError, err)
			}
			if err != nil && spec.ExpectedError == "" {
				t.Errorf("unexpected error: %v", err)
			}
			if err == nil && spec.ExpectedError != "" {
				t.Errorf("expected error %q but got none", spec.ExpectedError)
			}
		})
	}
}

// Hard‑coded baseline configuration for the CSR signer approval plugin test
func getHardCodedConfigInfoCSRSigner() ctestglobals.HardcodedConfig {
	return ctestglobals.HardcodedConfig{
		{
			FixtureFileName: "test_fixture.json",
			TestInfo:        []string{"CSR signer approval plugin"},
			Field:           "allowedSignerName",
			K8sObjects: []string{
				"clusterroles",
				"clusterrolebindings",
				"certificatesigningrequests",
			},
			HardcodedConfig: signerTestSpec{
				AllowedSignerName: "example.com/something",
				SignerName:        "example.com/something",
				ExpectedError:     "",
			},
		},
	}
}
