package certificates

import (
	"context"
	// "crypto/ed25519"
	// "crypto/rand"
	// "crypto/x509"
	// "crypto/x509/pkix"
	// "encoding/pem"
	"fmt"
	"testing"

	certv1 "k8s.io/api/certificates/v1"
	metav1 "k8s.io/apimachinery/pkg/apis/meta/v1"
	"k8s.io/apimachinery/pkg/util/uuid"
	clientset "k8s.io/client-go/kubernetes"
	// certclientset "k8s.io/client-go/kubernetes/typed/certificates/v1"
	kubeapiservertesting "k8s.io/kubernetes/cmd/kube-apiserver/app/testing"

	"k8s.io/kubernetes/test/integration/framework"

	ctest "k8s.io/kubernetes/test/ctest"
	ctestglobals "k8s.io/kubernetes/test/ctest/ctestglobals"
	ctestutils "k8s.io/kubernetes/test/ctest/utils"
)

func TestCtestCSRSignerNameFieldSelector(t *testing.T) {
	fmt.Println(ctestglobals.StartSeparator)

	// Load hard‑coded config for CSR specs
	hardcoded := getHardCodedConfigInfoCSRSignerNameFieldSelector()
	item, found := ctestutils.GetItemByExactTestInfo(hardcoded, "default CSR signerName")
	if !found {
		fmt.Println(ctestglobals.DebugPrefix(), "hard‑coded config not found, skipping test")
		fmt.Println(ctestglobals.EndSeparator)
		return
	}
	fmt.Println(ctestglobals.DebugPrefix(), "matched config:", item)

	fmt.Println(ctestglobals.StartExtendModeSeparator)
	configObjs, configJson, err := ctest.GenerateEffectiveConfigReturnType[certv1.CertificateSigningRequestSpec](item, ctest.ExtendOnly)
	if err != nil {
		t.Fatalf("failed to generate effective config: %v", err)
	}
	if configObjs == nil {
		fmt.Println(ctestglobals.DebugPrefix(), "no config objects generated, skipping test")
		fmt.Println(ctestglobals.EndSeparator)
		return
	}
	fmt.Println(ctestglobals.DebugPrefix(), "New Json Test Configs:", string(configJson))
	fmt.Println(ctestglobals.DebugPrefix(), "Number of test cases:", len(configObjs))

	server := kubeapiservertesting.StartTestServerOrDie(t, nil, framework.DefaultTestServerFlags(), framework.SharedEtcd())
	defer server.TearDownFn()
	client := clientset.NewForConfigOrDie(server.ClientConfig)
	csrClient := client.CertificatesV1().CertificateSigningRequests()

	createdCSRNames := make([]string, 0, len(configObjs))
	signerNames := make([]string, 0, len(configObjs))

	for i, spec := range configObjs {
		fmt.Printf("Running %d th test case.\n", i)
		fmt.Println(spec)

		// Ensure Request field is populated; use empty group if not set
		if len(spec.Request) == 0 {
			spec.Request = pemWithGroup("")
		}
		name := fmt.Sprintf("csr-%d-%s", i, string(uuid.NewUUID()))
		csr := &certv1.CertificateSigningRequest{
			ObjectMeta: metav1.ObjectMeta{
				Name: name,
			},
			Spec: spec,
		}
		_, err := csrClient.Create(context.TODO(), csr, metav1.CreateOptions{})
		if err != nil {
			t.Fatalf("failed to create CSR %q: %v", name, err)
		}
		createdCSRNames = append(createdCSRNames, name)
		signerNames = append(signerNames, spec.SignerName)
	}

	// Validate field selector for each distinct signerName
	seen := map[string]bool{}
	for _, signer := range signerNames {
		if seen[signer] {
			continue
		}
		seen[signer] = true

		selector := fmt.Sprintf("spec.signerName=%s", signer)
		list, err := csrClient.List(context.TODO(), metav1.ListOptions{FieldSelector: selector})
		if err != nil {
			t.Fatalf("unable to list CSRs with %s: %v", selector, err)
		}
		expectedCount := 0
		for _, name := range createdCSRNames {
			// Retrieve CSR to check its signerName
			csr, err := csrClient.Get(context.TODO(), name, metav1.GetOptions{})
			if err != nil {
				t.Fatalf("failed to get CSR %q: %v", name, err)
			}
			if csr.Spec.SignerName == signer {
				expectedCount++
			}
		}
		if len(list.Items) != expectedCount {
			t.Fatalf("field selector %s expected %d items, got %d", selector, expectedCount, len(list.Items))
		}
	}
	fmt.Println(ctestglobals.EndSeparator)
}

// Hard‑coded configuration for CSR signerName field selector tests.
func getHardCodedConfigInfoCSRSignerNameFieldSelector() ctestglobals.HardcodedConfig {
	return ctestglobals.HardcodedConfig{
		{
			FixtureFileName: "test_fixture.json",
			TestInfo:        []string{"default CSR signerName"},
			Field:           "signerName",
			K8sObjects:      []string{"certificatesigningrequests"},
			HardcodedConfig: []certv1.CertificateSigningRequestSpec{
				{
					SignerName: "example.com/signer-name-1",
				},
				{
					SignerName: "example.com/signer-name-2",
				},
				{
					SignerName: "", // edge case: empty signerName
				},
				{
					SignerName: "example.com/" + string([]byte{0xff, 0xfe, 0xfd}), // edge case: non‑ASCII chars
				},
			},
		},
	}
}
