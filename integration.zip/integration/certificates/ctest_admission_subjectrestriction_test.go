package certificates

import (
	"context"
	"fmt"
	"testing"

	certv1 "k8s.io/api/certificates/v1"
	metav1 "k8s.io/apimachinery/pkg/apis/meta/v1"
	clientset "k8s.io/client-go/kubernetes"

	kubeapiservertesting "k8s.io/kubernetes/cmd/kube-apiserver/app/testing"
	"k8s.io/kubernetes/test/integration/framework"

	ctest "k8s.io/kubernetes/test/ctest"
	ctestglobals "k8s.io/kubernetes/test/ctest/ctestglobals"
	ctestutils "k8s.io/kubernetes/test/ctest/utils"
)

func TestCtestCertificateSubjectRestrictionPlugin(t *testing.T) {
	fmt.Println(ctestglobals.StartSeparator)

	// Load hardcoded config for CSR spec
	cfgInfo := getHardCodedConfigInfoCertificateSubjectRestriction()
	item, found := ctestutils.GetItemByExactTestInfo(cfgInfo, "default csr spec")
	if !found {
		fmt.Println(ctestglobals.DebugPrefix(), "Failed to find config item by TestInfo")
		t.Fatalf("hardcoded config not found")
	}
	fmt.Println(ctestglobals.DebugPrefix(), "get default configs:", item)

	// Generate effective configurations (override mode)
	configObjs, configJson, err := ctest.GenerateEffectiveConfigReturnType[certv1.CertificateSigningRequestSpec](item, ctest.OverrideOnly)
	if err != nil {
		fmt.Println(ctestglobals.DebugPrefix(), "Failed to get matched fixtures:", err)
		t.Fatalf("config generation error: %v", err)
	}
	if configObjs == nil {
		fmt.Println(ctestglobals.DebugPrefix(), "Skipping test execution. No new configurations generated.")
		fmt.Println(ctestglobals.EndSeparator)
		return
	}
	fmt.Println(ctestglobals.DebugPrefix(), "New Json Test Configs:", string(configJson))
	fmt.Println(ctestglobals.DebugPrefix(), "Number of test cases:", len(configObjs))

	// Base test scenarios (original)
	baseTests := map[string]struct {
		signerName string
		group      string
		error      string
	}{
		"should reject a request if signerName is kube-apiserver-client and group is system:masters": {
			signerName: certv1.KubeAPIServerClientSignerName,
			group:      "system:masters",
			error:      `certificatesigningrequests.certificates.k8s.io "csr" is forbidden: use of kubernetes.io/kube-apiserver-client signer with system:masters group is not allowed`,
		},
		"should admit a request if signerName is kube-apiserver-client and group is NOT system:masters": {
			signerName: certv1.KubeAPIServerClientSignerName,
			group:      "system:notmasters",
		},
	}

	// Edge/invalid test scenarios
	edgeTests := map[string]struct {
		signerName string
		group      string
		error      string
	}{
		"empty signerName": {
			signerName: "",
			group:      "system:masters",
			error:      `certificatesigningrequests.certificates.k8s.io "csr" is forbidden: signerName must be specified`,
		},
		"empty group": {
			signerName: certv1.KubeAPIServerClientSignerName,
			group:     "",
		},
		"invalid signerName": {
			signerName: "invalid/signer",
			group:      "system:masters",
			error:      `certificatesigningrequests.certificates.k8s.io "csr" is forbidden: unknown signer`,
		},
	}

	// Merge base and edge tests
	for name, tc := range baseTests {
		edgeTests[name] = tc
	}

	// Iterate over generated config objects and test cases
	for cfgIdx, spec := range configObjs {
		for name, tc := range edgeTests {
			t.Run(fmt.Sprintf("%s_cfg%d", name, cfgIdx), func(t *testing.T) {
				// Start apiserver with default options
				s := kubeapiservertesting.StartTestServerOrDie(t, kubeapiservertesting.NewDefaultTestServerOptions(), []string{""}, framework.SharedEtcd())
				defer s.TearDownFn()
				client := clientset.NewForConfigOrDie(s.ClientConfig)

				// Build CSR and apply generated spec
				csr := buildTestingCSR("csr", tc.signerName, tc.group)
				// Overwrite CSR spec with generated config (override mode)
				csr.Spec = spec
				// Ensure test‑specific overrides are applied after the spec merge
				csr.Spec.SignerName = tc.signerName
				csr.Spec.Groups = []string{tc.group}

				_, err := client.CertificatesV1().CertificateSigningRequests().Create(context.TODO(), csr, metav1.CreateOptions{})
				if err != nil && tc.error != err.Error() {
					t.Errorf("expected error %q but got: %v", tc.error, err)
				}
				if err == nil && tc.error != "" {
					t.Errorf("expected error %q but got none", tc.error)
				}
			})
		}
	}

	fmt.Println(ctestglobals.EndSeparator)
}

// getHardCodedConfigInfoCertificateSubjectRestriction returns the minimal hard‑coded CSR spec used in the test.
func getHardCodedConfigInfoCertificateSubjectRestriction() ctestglobals.HardcodedConfig {
	return ctestglobals.HardcodedConfig{
		{
			FixtureFileName: "test_fixture.json",
			TestInfo:        []string{"default csr spec"},
			Field:           "spec",
			K8sObjects:      []string{"certificatesigningrequests"},
			HardcodedConfig: certv1.CertificateSigningRequestSpec{
				SignerName: certv1.KubeAPIServerClientSignerName,
				Groups:     []string{"system:masters"},
			},
		},
	}
}