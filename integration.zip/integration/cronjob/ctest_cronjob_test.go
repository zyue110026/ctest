package cronjob

import (
	// "context"
	"fmt"
	"testing"
	// "time"

	// "github.com/onsi/ginkgo/v2"
	"k8s.io/api/batch/v1"
	corev1 "k8s.io/api/core/v1"
	metav1 "k8s.io/apimachinery/pkg/apis/meta/v1"
	"k8s.io/apimachinery/pkg/util/uuid"
	// "k8s.io/apimachinery/pkg/util/wait"
	// "k8s.io/client-go/informers"
	// clientset "k8s.io/client-go/kubernetes"
	// clientbatchv1 "k8s.io/client-go/kubernetes/typed/batch/v1"
	// restclient "k8s.io/client-go/rest"
	// "k8s.io/kubernetes/cmd/kube-apiserver/app/testing"
	// "k8s.io/kubernetes/pkg/controller/cronjob"
	// "k8s.io/kubernetes/pkg/controller/job"
	"k8s.io/kubernetes/test/integration/framework"
	"k8s.io/kubernetes/test/utils/ktesting"

	ctest "k8s.io/kubernetes/test/ctest"
	ctestglobals "k8s.io/kubernetes/test/ctest/ctestglobals"
	ctestutils "k8s.io/kubernetes/test/ctest/utils"
)

func TestCtestCronJobLaunchesPodAndCleansUp(t *testing.T) {
	fmt.Println(ctestglobals.StartSeparator)

	// Load hard‑coded CronJobSpec configuration.
	item, found := ctestutils.GetItemByExactTestInfo(getHardCodedConfigInfoCronJob(), "default cronjob spec")
	if !found {
		fmt.Println(ctestglobals.DebugPrefix(), "Failed to find config item by TestInfo")
		t.Fatalf("Get default hardcoded config failed.")
	}
	fmt.Println(ctestglobals.DebugPrefix(), "get default configs:", item)
	fmt.Println(ctestglobals.StartExtendModeSeparator)

	specs, specJSON, err := ctest.GenerateEffectiveConfigReturnType[v1.CronJobSpec](item, ctest.ExtendOnly)
	if err != nil {
		fmt.Println(ctestglobals.DebugPrefix(), "Failed to get matched fixtures: %v", err)
		t.Fatalf("Failed to get matched fixtures: %v", err)
	}
	if specs == nil {
		fmt.Println(ctestglobals.DebugPrefix(), "Skipping test execution. No new configurations generated.")
		return
	}
	fmt.Println(ctestglobals.DebugPrefix(), "New Json Test Configs:", string(specJSON))
	fmt.Println(ctestglobals.DebugPrefix(), "Number of test cases:", len(specs))

	for i, spec := range specs {
		fmt.Printf("Running %d th test case.\n", i)
		fmt.Println(spec)

		// Extend config with a harmless label to verify extend‑mode handling.
		if spec.JobTemplate.Spec.Template.Labels == nil {
			spec.JobTemplate.Spec.Template.Labels = map[string]string{}
		}
		spec.JobTemplate.Spec.Template.Labels["ctest‑extend"] = "true"

		// Dynamically generated names.
		cronJobName := "foo-" + string(uuid.NewUUID())
		namespaceName := "simple-cronjob-test-" + string(uuid.NewUUID())

		// Standard test setup.
		tCtx := ktesting.Init(t)
		closeFn, cjc, jc, informerSet, clientSet := setup(tCtx, t)
		defer closeFn()
		defer tCtx.Cancel("test has completed")

		ns := framework.CreateNamespaceOrDie(clientSet, namespaceName, t)
		defer framework.DeleteNamespaceOrDie(clientSet, ns, t)

		cjClient := clientSet.BatchV1().CronJobs(ns.Name)

		informerSet.Start(tCtx.Done())
		go cjc.Run(tCtx, 1)
		go jc.Run(tCtx, 1)

		// Build CronJob object using the dynamic spec.
		cronJob := &v1.CronJob{
			TypeMeta: metav1.TypeMeta{
				Kind:       "CronJob",
				APIVersion: "batch/v1",
			},
			ObjectMeta: metav1.ObjectMeta{
				Namespace: ns.Name,
				Name:      cronJobName,
			},
			Spec: spec,
		}

		_, err := cjClient.Create(tCtx, cronJob, metav1.CreateOptions{})
		if err != nil {
			t.Fatalf("Failed to create CronJob: %v", err)
		}
		defer cleanupCronJobs(t, cjClient, cronJobName)

		validateJobAndPod(t, clientSet, namespaceName)
	}
	fmt.Println(ctestglobals.EndSeparator)
}

// -----------------------------------------------------------------------------
// Helper to retrieve dynamic CronJobSpec configurations.
func getHardCodedConfigInfoCronJob() ctestglobals.HardcodedConfig {
	return ctestglobals.HardcodedConfig{
		{
			FixtureFileName: "test_fixture.json",
			TestInfo:        []string{"default cronjob spec"},
			Field:           "spec",
			K8sObjects: []string{
				"cronjobs",
				"jobs",
				"pods",
			},
			HardcodedConfig: v1.CronJobSpec{
				Schedule:                   "* * * * ?",
				SuccessfulJobsHistoryLimit: func() *int32 { var i int32 = 0; return &i }(),
				JobTemplate: v1.JobTemplateSpec{
					Spec: v1.JobSpec{
						Template: corev1.PodTemplateSpec{
							Spec: corev1.PodSpec{
								Containers: []corev1.Container{
									{
										Name:  "foo",
										Image: "bar",
									},
								},
								TerminationGracePeriodSeconds: func() *int64 { var i int64 = 0; return &i }(),
								RestartPolicy:                 corev1.RestartPolicyNever,
							},
						},
					},
				},
			},
		},
	}
}
