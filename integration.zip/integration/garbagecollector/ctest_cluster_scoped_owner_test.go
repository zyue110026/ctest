package garbagecollector

import (
	"context"
	"fmt"
	// "io"
	"net/http"
	"strings"
	"testing"
	"time"

	v1 "k8s.io/api/core/v1"
	apierrors "k8s.io/apimachinery/pkg/api/errors"
	"k8s.io/apimachinery/pkg/api/resource"
	metav1 "k8s.io/apimachinery/pkg/apis/meta/v1"
	"k8s.io/apimachinery/pkg/types"
	"k8s.io/apimachinery/pkg/util/wait"
	kubeapiservertesting "k8s.io/kubernetes/cmd/kube-apiserver/app/testing"
	"k8s.io/kubernetes/test/integration/framework"

	"k8s.io/apimachinery/pkg/util/uuid"
	ctest "k8s.io/kubernetes/test/ctest"
	ctestglobals "k8s.io/kubernetes/test/ctest/ctestglobals"
	ctestutils "k8s.io/kubernetes/test/ctest/utils"
)

// TestCtestClusterScopedOwners rewrites the original TestClusterScopedOwners to use dynamic
// configuration generation and adds edge‑case scenarios.
func TestCtestClusterScopedOwners(t *testing.T) {
	// ---------- Setup test server with delayed PV watch ----------
	server := kubeapiservertesting.StartTestServerOrDie(t, nil, framework.DefaultTestServerFlags(), framework.SharedEtcd())
	server.ClientConfig.WrapTransport = func(rt http.RoundTripper) http.RoundTripper {
		return roundTripFunc(func(req *http.Request) (*http.Response, error) {
			if req.URL.Query().Get("watch") != "true" || !strings.Contains(req.URL.String(), "persistentvolumes") {
				return rt.RoundTrip(req)
			}
			resp, err := rt.RoundTrip(req)
			if err != nil {
				return resp, err
			}
			resp.Body = &readDelayer{30 * time.Second, resp.Body}
			return resp, err
		})
	}
	ctx := setupWithServer(t, server, 5)
	defer ctx.tearDown()

	_, clientSet := ctx.gc, ctx.clientSet

	// ---------- Create test namespace ----------
	ns := createNamespaceOrDie("gc-cluster-scope-deletion", clientSet, t)
	defer deleteNamespaceOrDie(ns.Name, clientSet, t)

	// ---------- Generate PersistentVolume spec from hard‑coded config ----------
	fmt.Println(ctestglobals.StartSeparator)
	hardcodedPV := getHardCodedConfigInfoPV()
	itemPV, foundPV := ctestutils.GetItemByExactTestInfo(hardcodedPV, "valid persistent volume")
	if !foundPV {
		fmt.Println(ctestglobals.DebugPrefix(), "Failed to find PV config")
		t.FailNow()
	}
	fmt.Println(ctestglobals.DebugPrefix(), "PV config item:", itemPV)
	fmt.Println(ctestglobals.StartExtendModeSeparator)
	pvConfigs, pvJSON, err := ctest.GenerateEffectiveConfigReturnType[v1.PersistentVolumeSpec](itemPV, ctest.ExtendOnly)
	if err != nil {
		fmt.Println(ctestglobals.DebugPrefix(), "Error generating PV configs:", err)
		t.FailNow()
	}
	fmt.Println(ctestglobals.DebugPrefix(), "PV JSON:", string(pvJSON))
	fmt.Println(ctestglobals.DebugPrefix(), "Number of PV configs:", len(pvConfigs))
	if len(pvConfigs) == 0 {
		fmt.Println(ctestglobals.DebugPrefix(), "Skipping test execution. No PV configs generated.")
		t.FailNow()
	}
	// Use the first generated PV spec (test expects a single PV)
	pvSpec := pvConfigs[0]

	// ---------- Create PersistentVolume ----------
	pvName := "pv-" + string(uuid.NewUUID())
	pv, err := clientSet.CoreV1().PersistentVolumes().Create(context.TODO(), &v1.PersistentVolume{
		ObjectMeta: metav1.ObjectMeta{Name: pvName},
		Spec:       pvSpec,
	}, metav1.CreateOptions{})
	if err != nil {
		t.Fatalf("Failed to create PersistentVolume: %v", err)
	}
	fmt.Println(ctestglobals.DebugPrefix(), "Created PersistentVolume:", pv.Name)

	// ---------- Generate ConfigMap base spec (valid ownerReference) ----------
	configMapBase := getHardCodedConfigInfoConfigMap()
	itemCM, foundCM := ctestutils.GetItemByExactTestInfo(configMapBase, "valid configmap with owner")
	if !foundCM {
		fmt.Println(ctestglobals.DebugPrefix(), "Failed to find ConfigMap config")
		t.FailNow()
	}
	fmt.Println(ctestglobals.DebugPrefix(), "ConfigMap config item:", itemCM)
	fmt.Println(ctestglobals.StartExtendModeSeparator)
	cmConfigs, cmJSON, err := ctest.GenerateEffectiveConfigReturnType[v1.ConfigMap](itemCM, ctest.ExtendOnly)
	if err != nil {
		fmt.Println(ctestglobals.DebugPrefix(), "Error generating ConfigMap configs:", err)
		t.FailNow()
	}
	fmt.Println(ctestglobals.DebugPrefix(), "ConfigMap JSON:", string(cmJSON))
	fmt.Println(ctestglobals.DebugPrefix(), "Number of ConfigMap configs:", len(cmConfigs))
	if len(cmConfigs) == 0 {
		fmt.Println(ctestglobals.DebugPrefix(), "Skipping ConfigMap creation. No configs generated.")
		t.FailNow()
	}
	// Use first generated ConfigMap as the valid case
	validCM := cmConfigs[0]
	validCM.Namespace = ns.Name
	validCM.Name = "cm-valid"
	// Update the OwnerReference to point to the PV we just created
	validCM.OwnerReferences = []metav1.OwnerReference{{Kind: "PersistentVolume", APIVersion: "v1", Name: pv.Name, UID: pv.UID}}

	// ---------- Create valid ConfigMap ----------
	if _, err := clientSet.CoreV1().ConfigMaps(ns.Name).Create(context.TODO(), &validCM, metav1.CreateOptions{}); err != nil {
		t.Fatalf("Failed to create valid ConfigMap: %v", err)
	}
	fmt.Println(ctestglobals.DebugPrefix(), "Created valid ConfigMap")

	// ---------- Edge case ConfigMaps ----------
	edgeCases := []struct {
		name          string
		configMapFunc func() v1.ConfigMap
		shouldExist   bool // true if the ConfigMap must remain after GC
	}{
		{
			name: "cm-missing",
			configMapFunc: func() v1.ConfigMap {
				return v1.ConfigMap{
					ObjectMeta: metav1.ObjectMeta{
						Name:            "cm-missing",
						Namespace:       ns.Name,
						Labels:          map[string]string{"missing": "true"},
						OwnerReferences: []metav1.OwnerReference{{Kind: "PersistentVolume", APIVersion: "v1", Name: "missing-name", UID: types.UID("missing-uid")}},
					},
				}
			},
			shouldExist: false,
		},
		{
			name: "cm-invalid",
			configMapFunc: func() v1.ConfigMap {
				return v1.ConfigMap{
					ObjectMeta: metav1.ObjectMeta{
						Name:            "cm-invalid",
						Namespace:       ns.Name,
						OwnerReferences: []metav1.OwnerReference{{Kind: "UnknownType", APIVersion: "unknown.group/v1", Name: "invalid-name", UID: types.UID("invalid-uid")}},
					},
				}
			},
			shouldExist: true,
		},
		{
			name: "cm-empty-ownerref",
			configMapFunc: func() v1.ConfigMap {
				return v1.ConfigMap{
					ObjectMeta: metav1.ObjectMeta{
						Name:            "cm-empty-ownerref",
						Namespace:       ns.Name,
						OwnerReferences: []metav1.OwnerReference{},
					},
				}
			},
			shouldExist: true,
		},
		{
			name: "cm-invalid-uid",
			configMapFunc: func() v1.ConfigMap {
				return v1.ConfigMap{
					ObjectMeta: metav1.ObjectMeta{
						Name:            "cm-invalid-uid",
						Namespace:       ns.Name,
						OwnerReferences: []metav1.OwnerReference{{Kind: "PersistentVolume", APIVersion: "v1", Name: pv.Name, UID: ""}},
					},
				}
			},
			shouldExist: true,
		},
		{
			name: "cm-multiple-owners",
			configMapFunc: func() v1.ConfigMap {
				return v1.ConfigMap{
					ObjectMeta: metav1.ObjectMeta{
						Name:      "cm-multiple-owners",
						Namespace: ns.Name,
						OwnerReferences: []metav1.OwnerReference{
							{Kind: "PersistentVolume", APIVersion: "v1", Name: pv.Name, UID: pv.UID, Controller: ptrToTrue()},
							{Kind: "PersistentVolume", APIVersion: "v1", Name: "missing-name", UID: types.UID("missing-uid")},
						},
					},
				}
			},
			shouldExist: true, // because a valid controller already exists, GC should not delete
		},
	}

	for _, ec := range edgeCases {
		cm := ec.configMapFunc()
		if _, err := clientSet.CoreV1().ConfigMaps(ns.Name).Create(context.TODO(), &cm, metav1.CreateOptions{}); err != nil {
			t.Fatalf("Failed to create edge case ConfigMap %s: %v", ec.name, err)
		}
		fmt.Println(ctestglobals.DebugPrefix(), "Created edge case ConfigMap:", ec.name)
	}

	// ---------- Wait for deletable children (missing parent) to be removed ----------
	if err := wait.Poll(5*time.Second, 300*time.Second, func() (bool, error) {
		_, err := clientSet.CoreV1().ConfigMaps(ns.Name).Get(context.TODO(), "cm-missing", metav1.GetOptions{})
		switch {
		case apierrors.IsNotFound(err):
			return true, nil
		case err != nil:
			return false, err
		default:
			t.Logf("cm-missing still exists, retrying")
			return false, nil
		}
	}); err != nil {
		t.Fatalf("Timed out waiting for cm-missing to be GC'd: %v", err)
	}
	fmt.Println(ctestglobals.DebugPrefix(), "Deletable child cm-missing removed")

	// Give extra time for any blocked deletions (should be none)
	time.Sleep(5 * time.Second)

	// ---------- Verify expectations for each edge case ----------
	verification := []struct {
		name        string
		shouldExist bool
	}{
		{"cm-invalid", true},
		{"cm-empty-ownerref", true},
		{"cm-invalid-uid", true},
		{"cm-multiple-owners", true},
	}
	for _, v := range verification {
		_, err := clientSet.CoreV1().ConfigMaps(ns.Name).Get(context.TODO(), v.name, metav1.GetOptions{})
		if v.shouldExist {
			if err != nil {
				t.Fatalf("ConfigMap %s should exist but got error: %v", v.name, err)
			}
		} else {
			if err == nil || !apierrors.IsNotFound(err) {
				t.Fatalf("ConfigMap %s should have been deleted, but still present", v.name)
			}
		}
	}

	// ---------- Verify valid ConfigMap still exists ----------
	if _, err := clientSet.CoreV1().ConfigMaps(ns.Name).Get(context.TODO(), "cm-valid", metav1.GetOptions{}); err != nil {
		t.Fatalf("Valid ConfigMap unexpectedly missing: %v", err)
	}
	fmt.Println(ctestglobals.DebugPrefix(), "Valid ConfigMap still present")
	fmt.Println(ctestglobals.EndSeparator)
}

// ptrToTrue returns a *bool set to true; used for OwnerReference.Controller fields.
func ptrToTrue() *bool { b := true; return &b }

func getHardCodedConfigInfoPV() ctestglobals.HardcodedConfig {
	return ctestglobals.HardcodedConfig{
		{
			FixtureFileName: "test_fixture.json",
			TestInfo:        []string{"valid persistent volume"},
			Field:           "spec",
			K8sObjects: []string{
				"persistentvolumes",
			},
			HardcodedConfig: v1.PersistentVolumeSpec{
				PersistentVolumeSource: v1.PersistentVolumeSource{
					HostPath: &v1.HostPathVolumeSource{Path: "/foo"},
				},
				Capacity:    v1.ResourceList{v1.ResourceStorage: resource.MustParse("1Gi")},
				AccessModes: []v1.PersistentVolumeAccessMode{v1.ReadWriteMany},
			},
		},
	}
}

func getHardCodedConfigInfoConfigMap() ctestglobals.HardcodedConfig {
	return ctestglobals.HardcodedConfig{
		{
			FixtureFileName: "test_fixture.json",
			TestInfo:        []string{"valid configmap with owner"},
			Field:           "metadata.ownerReferences",
			K8sObjects: []string{
				"configmaps",
			},
			HardcodedConfig: v1.ConfigMap{
				ObjectMeta: metav1.ObjectMeta{
					OwnerReferences: []metav1.OwnerReference{
						{
							Kind:       "PersistentVolume",
							APIVersion: "v1",
							// Name and UID will be patched dynamically in the test
						},
					},
				},
				Data: map[string]string{},
			},
		},
	}
}
