package controlplane

import (
	"fmt"
	"io"
	"net/http"
	"sync"
	"testing"
	"time"

	"k8s.io/apimachinery/pkg/util/wait"
	"k8s.io/client-go/rest"
	kubeapiservertesting "k8s.io/kubernetes/cmd/kube-apiserver/app/testing"
	"k8s.io/kubernetes/test/integration/framework"

	ctest "k8s.io/kubernetes/test/ctest"
	ctestglobals "k8s.io/kubernetes/test/ctest/ctestglobals"
	ctestutils "k8s.io/kubernetes/test/ctest/utils"
)

// Rewritten test with dynamic configuration generation
func TestCtestGracefulShutdown(t *testing.T) {
	fmt.Println(ctestglobals.StartSeparator)
	configs := getHardCodedConfigInfoGracefulShutdown()

	item, found := ctestutils.GetItemByExactTestInfo(configs, "graceful shutdown server flags")
	if !found {
		t.Fatalf("hardcoded config not found for graceful shutdown")
	}
	fmt.Println(ctestglobals.DebugPrefix(), "matched config item:", item)

	fmt.Println(ctestglobals.StartExtendModeSeparator)
	configObjs, configJSON, err := ctest.GenerateEffectiveConfigReturnType[[]string](item, ctest.ExtendOnly)
	if err != nil {
		t.Fatalf("failed to generate effective config: %v", err)
	}
	fmt.Println(ctestglobals.DebugPrefix(), "generated config JSON:", string(configJSON))
	if configObjs == nil || len(configObjs) == 0 {
		fmt.Println(ctestglobals.DebugPrefix(), "Skipping test execution. No new configurations generated.")
		fmt.Println(ctestglobals.EndSeparator)
		return
	}
	fmt.Println(ctestglobals.DebugPrefix(), "number of config objects:", len(configObjs))

	for i, flags := range configObjs {
		fmt.Printf("Running config #%d with flags: %v\n", i, flags)

		server := kubeapiservertesting.StartTestServerOrDie(t, nil, flags, framework.SharedEtcd())

		tearDownOnce := sync.Once{}
		defer tearDownOnce.Do(server.TearDownFn)

		transport, err := rest.TransportFor(server.ClientConfig)
		if err != nil {
			t.Fatalf("unexpected error: %v", err)
		}
		client := http.Client{Transport: transport}

		req, body, err := newBlockingRequest("POST", server.ClientConfig.Host+"/api/v1/namespaces")
		if err != nil {
			t.Fatal(err)
		}
		respErrCh := backgroundRoundtrip(transport, req)

		t.Logf("server should be blocking request for data in body")
		time.Sleep(time.Millisecond * 500)
		select {
		case respErr := <-respErrCh:
			if respErr.err != nil {
				t.Fatalf("unexpected error: %v", err)
			}
			bs, err := io.ReadAll(respErr.resp.Body)
			if err != nil {
				t.Fatal(err)
			}
			t.Fatalf("unexpected server answer: %d, body: %s", respErr.resp.StatusCode, string(bs))
		default:
		}

		t.Logf("server should answer")
		resp, err := client.Get(server.ClientConfig.Host + "/")
		if err != nil {
			t.Fatal(err)
		}
		resp.Body.Close()

		t.Logf("shutting down server")
		wg := sync.WaitGroup{}
		wg.Add(1)
		go func() {
			defer wg.Done()
			tearDownOnce.Do(server.TearDownFn)
		}()

		t.Logf("server should fail new requests")
		if err := wait.Poll(time.Millisecond*100, wait.ForeverTestTimeout, func() (bool, error) {
			resp, err := client.Get(server.ClientConfig.Host + "/")
			if err != nil {
				return true, nil
			}
			resp.Body.Close()
			return false, nil
		}); err != nil {
			t.Fatalf("server did not shutdown")
		}

		t.Logf("server should answer pending request")
		time.Sleep(time.Millisecond * 500)
		if _, err := body.Write([]byte("garbage")); err != nil {
			t.Fatal(err)
		}
		body.Close()
		respErr := <-respErrCh
		if respErr.err != nil {
			t.Fatal(respErr.err)
		}
		defer respErr.resp.Body.Close()
		bs, err := io.ReadAll(respErr.resp.Body)
		if err != nil {
			t.Fatal(err)
		}
		t.Logf("response: code %d, body: %s", respErr.resp.StatusCode, string(bs))

		wg.Wait()
	}
	fmt.Println(ctestglobals.EndSeparator)
}

func getHardCodedConfigInfoGracefulShutdown() ctestglobals.HardcodedConfig {
	return ctestglobals.HardcodedConfig{{
		FixtureFileName: "test_fixture.json",
		TestInfo:        []string{"graceful shutdown server flags"},
		Field:           "flags",
		K8sObjects:      []string{"apiservers"},
		HardcodedConfig: []string{},
	}}
}
