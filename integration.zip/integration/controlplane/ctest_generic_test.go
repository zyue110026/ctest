package controlplane

import (
	"context"
	"fmt"
	"strings"
	"testing"

	"github.com/google/go-cmp/cmp"
	"github.com/stretchr/testify/require"
	// "github.com/onsi/gomega"

	ctest "k8s.io/kubernetes/test/ctest"
	ctestglobals "k8s.io/kubernetes/test/ctest/ctestglobals"
	ctestutils "k8s.io/kubernetes/test/ctest/utils"

	"github.com/google/uuid"

	corev1 "k8s.io/api/core/v1"
	apiextensionsclientset "k8s.io/apiextensions-apiserver/pkg/client/clientset/clientset"
	metav1 "k8s.io/apimachinery/pkg/apis/meta/v1"
	"k8s.io/apimachinery/pkg/apis/meta/v1/unstructured"
	"k8s.io/apimachinery/pkg/runtime/schema"
	"k8s.io/apimachinery/pkg/util/sets"
	"k8s.io/client-go/dynamic"
	"k8s.io/client-go/kubernetes"

	genericcontrolplanetesting "k8s.io/kubernetes/pkg/controlplane/apiserver/samples/generic/server/testing"
	"k8s.io/kubernetes/test/integration/etcd"
	"k8s.io/kubernetes/test/integration/framework"
)

func TestCtestGenericControlplaneStartUp(t *testing.T) {
	fmt.Println(ctestglobals.StartSeparator)
	hardcoded := getHardCodedConfigInfoGenericControlplane()

	// --- start server (unchanged) ---
	server, err := genericcontrolplanetesting.StartTestServer(t, genericcontrolplanetesting.NewDefaultTestServerOptions(), nil, framework.SharedEtcd())
	if err != nil {
		t.Fatal(err)
	}
	defer server.TearDownFn()

	ctx, cancel := context.WithCancel(context.Background())
	t.Cleanup(cancel)

	client, err := kubernetes.NewForConfig(server.ClientConfig)
	if err != nil {
		t.Fatal(err)
	}
	dynamicClient, err := dynamic.NewForConfig(server.ClientConfig)
	if err != nil {
		t.Fatal(err)
	}
	// --- verify readyz and API groups (unchanged) ---
	_, err = client.RESTClient().Get().AbsPath("/readyz").Do(ctx).Raw()
	require.NoError(t, err)

	groups, err := client.Discovery().ServerPreferredResources()
	require.NoError(t, err)

	t.Logf("Found %d API groups", len(groups))
	grs := sets.New[string]()
	for _, g := range groups {
		var group string
		comps := strings.SplitN(g.GroupVersion, "/", 2)
		if len(comps) == 2 {
			group = comps[0]
		}
		for _, r := range g.APIResources {
			grs.Insert(schema.GroupResource{Group: group, Resource: r.Name}.String())
		}
	}
	expected := sets.New[string](
		"apiservices.apiregistration.k8s.io",
		"certificatesigningrequests.certificates.k8s.io",
		"clusterrolebindings.rbac.authorization.k8s.io",
		"clusterroles.rbac.authorization.k8s.io",
		"configmaps",
		"customresourcedefinitions.apiextensions.k8s.io",
		"events",
		"events.events.k8s.io",
		"flowschemas.flowcontrol.apiserver.k8s.io",
		"leasecandidates.coordination.k8s.io",
		"leases.coordination.k8s.io",
		"localsubjectaccessreviews.authorization.k8s.io",
		"mutatingwebhookconfigurations.admissionregistration.k8s.io",
		"namespaces",
		"prioritylevelconfigurations.flowcontrol.apiserver.k8s.io",
		"resourcequotas",
		"rolebindings.rbac.authorization.k8s.io",
		"roles.rbac.authorization.k8s.io",
		"secrets",
		"selfsubjectaccessreviews.authorization.k8s.io",
		"selfsubjectreviews.authentication.k8s.io",
		"selfsubjectrulesreviews.authorization.k8s.io",
		"serviceaccounts",
		"storageversions.internal.apiserver.k8s.io",
		"subjectaccessreviews.authorization.k8s.io",
		"tokenreviews.authentication.k8s.io",
		"validatingadmissionpolicies.admissionregistration.k8s.io",
		"validatingadmissionpolicybindings.admissionregistration.k8s.io",
		"validatingwebhookconfigurations.admissionregistration.k8s.io",
		"mutatingadmissionpolicies.admissionregistration.k8s.io",
		"mutatingadmissionpolicybindings.admissionregistration.k8s.io",
	)
	if diff := cmp.Diff(sets.List(expected), sets.List(grs)); diff != "" {
		t.Fatalf("unexpected API groups: +want, -got\n%s", diff)
	}
	// ---------------------------------------------------------
	// Dynamic configuration generation and resource creation
	// ---------------------------------------------------------

	// 1. Namespace configurations (extend mode, allowing extra fields)
	fmt.Println(ctestglobals.DebugPrefix(), "Processing Namespace configs")
	nsItem, nsFound := ctestutils.GetItemByExactTestInfo(hardcoded, "namespace")
	if nsFound {
		nsObjs, nsJson, err := ctest.GenerateEffectiveConfigReturnType[corev1.Namespace](nsItem, ctest.ExtendOnly)
		if err != nil {
			t.Fatalf("failed to generate namespace configs: %v", err)
		}
		fmt.Println(ctestglobals.DebugPrefix(), "New Json Namespace Configs:", string(nsJson))
		fmt.Println(ctestglobals.DebugPrefix(), "Number of Namespace configs:", len(nsObjs))
		if len(nsObjs) == 0 {
			fmt.Println(ctestglobals.DebugPrefix(), "Skipping Namespace creation: no configs")
		} else {
			for i, ns := range nsObjs {
				fmt.Printf("Running Namespace config #%d\n", i)
				fmt.Println(ns)
				if ns.Name == "" {
					ns.Name = "ns-" + uuid.New().String()
				}
				_, err = client.CoreV1().Namespaces().Create(ctx, &ns, metav1.CreateOptions{})
				if err != nil {
					t.Fatalf("failed to create namespace %q: %v", ns.Name, err)
				}
			}
		}
	} else {
		fmt.Println(ctestglobals.DebugPrefix(), "Namespace config not found, skipping")
	}

	// 2. ConfigMap configurations (extend mode)
	fmt.Println(ctestglobals.DebugPrefix(), "Processing ConfigMap configs")
	cmItem, cmFound := ctestutils.GetItemByExactTestInfo(hardcoded, "configmap")
	if cmFound {
		cmObjs, cmJson, err := ctest.GenerateEffectiveConfigReturnType[corev1.ConfigMap](cmItem, ctest.ExtendOnly)
		if err != nil {
			t.Fatalf("failed to generate configmap configs: %v", err)
		}
		fmt.Println(ctestglobals.DebugPrefix(), "New Json ConfigMap Configs:", string(cmJson))
		fmt.Println(ctestglobals.DebugPrefix(), "Number of ConfigMap configs:", len(cmObjs))
		if len(cmObjs) == 0 {
			fmt.Println(ctestglobals.DebugPrefix(), "Skipping ConfigMap creation: no configs")
		} else {
			for i, cm := range cmObjs {
				fmt.Printf("Running ConfigMap config #%d\n", i)
				fmt.Println(cm)
				ns := cm.Namespace
				if ns == "" {
					ns = "default"
				}
				_, err = client.CoreV1().ConfigMaps(ns).Create(ctx, &cm, metav1.CreateOptions{})
				if err != nil {
					t.Fatalf("failed to create configmap %q in ns %q: %v", cm.Name, ns, err)
				}
			}
		}
	} else {
		fmt.Println(ctestglobals.DebugPrefix(), "ConfigMap config not found, skipping")
	}

	// 3. Custom Resource (Panda) configurations (override mode)
	fmt.Println(ctestglobals.DebugPrefix(), "Processing Panda custom resource configs")
	pandaItem, pandaFound := ctestutils.GetItemByExactTestInfo(hardcoded, "panda")
	if pandaFound {
		pandaObjs, pandaJson, err := ctest.GenerateEffectiveConfigReturnType[map[string]interface{}](pandaItem, ctest.OverrideOnly)
		if err != nil {
			t.Fatalf("failed to generate panda configs: %v", err)
		}
		fmt.Println(ctestglobals.DebugPrefix(), "New Json Panda Configs:", string(pandaJson))
		fmt.Println(ctestglobals.DebugPrefix(), "Number of Panda configs:", len(pandaObjs))
		if len(pandaObjs) == 0 {
			fmt.Println(ctestglobals.DebugPrefix(), "Skipping Panda creation: no configs")
		} else {
			for i, obj := range pandaObjs {
				fmt.Printf("Running Panda config #%d\n", i)
				fmt.Println(obj)
				unstructuredObj := &unstructured.Unstructured{Object: obj}
				_, err = dynamicClient.Resource(schema.GroupVersionResource{Group: "awesome.bears.com", Version: "v1", Resource: "pandas"}).Create(ctx, unstructuredObj, metav1.CreateOptions{})
				if err != nil {
					t.Fatalf("failed to create panda custom resource: %v", err)
				}
			}
		}
	} else {
		fmt.Println(ctestglobals.DebugPrefix(), "Panda config not found, skipping")
	}

	// ---------------------------------------------------------
	// The rest of the original test (CRD creation) remains unchanged
	// ---------------------------------------------------------

	// Create CRDs (using original helper)
	etcd.CreateTestCRDs(t, apiextensionsclientset.NewForConfigOrDie(server.ClientConfig), false, etcd.GetCustomResourceDefinitionData()...)
	// Verify that creating a custom resource works (already done above)

	fmt.Println(ctestglobals.EndSeparator)
}

// getHardCodedConfigInfoGenericControlplane returns the minimal hard‑coded configurations
// required by TestCtestGenericControlplaneStartUp. Each entry includes the fixture name,
// a unique TestInfo identifier, the field that is being injected, the list of
// K8s objects that could contain the field, and the minimal configuration value.
func getHardCodedConfigInfoGenericControlplane() ctestglobals.HardcodedConfig {
	return ctestglobals.HardcodedConfig{
		{
			FixtureFileName: "test_fixture.json",
			TestInfo:        []string{"namespace"},
			Field:           "metadata.name",
			K8sObjects:      []string{"namespaces"},
			HardcodedConfig: corev1.Namespace{
				ObjectMeta: metav1.ObjectMeta{
					Name: "test",
				},
			},
		},
		{
			FixtureFileName: "test_fixture.json",
			TestInfo:        []string{"configmap"},
			Field:           "data",
			K8sObjects:      []string{"configmaps"},
			HardcodedConfig: corev1.ConfigMap{
				ObjectMeta: metav1.ObjectMeta{
					Namespace: "test",
					Name:      "config",
				},
				Data: map[string]string{
					"foo": "bar",
				},
			},
		},
		{
			FixtureFileName: "test_fixture.json",
			TestInfo:        []string{"panda"},
			Field:           "metadata.name",
			K8sObjects:      []string{"customresourcedefinitions", "pandas"},
			HardcodedConfig: map[string]interface{}{
				"apiVersion": "awesome.bears.com/v1",
				"kind":       "Panda",
				"metadata": map[string]interface{}{
					"name": "baobao",
				},
			},
		},
	}
}
