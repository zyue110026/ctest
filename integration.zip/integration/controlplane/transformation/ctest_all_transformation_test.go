package transformation

import (
	// "context"
	"fmt"
	"testing"
	// "time"

	apiextensionsclientset "k8s.io/apiextensions-apiserver/pkg/client/clientset/clientset"
	// "k8s.io/apimachinery/pkg/api/meta"
	// metav1 "k8s.io/apimachinery/pkg/apis/meta/v1"
	// "k8s.io/apimachinery/pkg/runtime/schema"
	// "k8s.io/client-go/dynamic"
	"k8s.io/kubernetes/test/integration/etcd"

	ctest "k8s.io/kubernetes/test/ctest"
	ctestglobals "k8s.io/kubernetes/test/ctest/ctestglobals"
	ctestutils "k8s.io/kubernetes/test/ctest/utils"
)

func TestCtestEncryptSupportedForAllResourceTypes(t *testing.T) {
	fmt.Println(ctestglobals.StartSeparator)

	// ---- Load dynamic encryption configuration ----
	hardcodedCfg := getHardCodedConfigInfoEncryptionConfig()
	item, found := ctestutils.GetItemByExactTestInfo(hardcodedCfg, "encryption config yaml")
	if !found {
		fmt.Println(ctestglobals.DebugPrefix(), "Failed to find encryption config in hardcoded data")
		t.Skip("no encryption config found")
		return
	}
	fmt.Println(ctestglobals.DebugPrefix(), "matched encryption config item:", item)

	fmt.Println(ctestglobals.StartExtendModeSeparator)
	configObjs, configJSON, err := ctest.GenerateEffectiveConfigReturnType[string](item, ctest.ExtendOnly)
	if err != nil {
		fmt.Println(ctestglobals.DebugPrefix(), "error generating effective config:", err)
		t.Fatalf("failed to generate config: %v", err)
	}
	if configObjs == nil || len(configObjs) == 0 {
		fmt.Println(ctestglobals.DebugPrefix(), "Skipping test execution. No new configurations generated.")
		t.Skip("no config generated")
		return
	}
	fmt.Println(ctestglobals.DebugPrefix(), "New Json Test Configs:", string(configJSON))
	fmt.Println(ctestglobals.DebugPrefix(), "Number of config objects:", len(configObjs))

	// Use the first generated config as the encryption config YAML
	encryptionConfig := configObjs[0]

	// ---- Create test environment ----
	test, err := newTransformTest(t, transformTestConfig{transformerConfigYAML: encryptionConfig})
	if err != nil {
		t.Fatalf("failed to start Kube API Server with encryptionConfig\n %s, error: %v", encryptionConfig, err)
	}
	t.Cleanup(test.cleanUp)

	// the storage registry for CRs is dynamic so create one to exercise the wiring
	etcd.CreateTestCRDs(t, apiextensionsclientset.NewForConfigOrDie(test.kubeAPIServer.ClientConfig), false, etcd.GetCustomResourceDefinitionData()...)

	// ---- Base test cases (original) ----
	baseCases := []struct {
		group     string
		version   string
		kind      string
		resource  string
		name      string
		namespace string
	}{
		{"", "v1", "ConfigMap", "configmaps", "cm1", testNamespace},
		{"apiextensions.k8s.io", "v1", "CustomResourceDefinition", "customresourcedefinitions", "pandas.awesome.bears.com", ""},
		{"awesome.bears.com", "v1", "Panda", "pandas", "cr3panda", ""},
		{"apiregistration.k8s.io", "v1", "APIService", "apiservices", "as2.foo.com", ""},
		{"", "v1", "Pod", "pods", "pod1", testNamespace},
	}

	// ---- Edge / invalid test cases ----
	edgeCases := []struct {
		group     string
		version   string
		kind      string
		resource  string
		name      string
		namespace string
	}{
		// empty group and version (should default to core/v1 for pods)
		{"", "", "Pod", "pods", "edge-pod-no-version", testNamespace},
		// unknown resource type
		{"", "v1", "Unknown", "unknowns", "unknown1", testNamespace},
		// missing name
		{"", "v1", "ConfigMap", "configmaps", "", testNamespace},
		// missing namespace for a namespaced resource (should fail)
		{"", "v1", "Pod", "pods", "edge-pod-no-ns", ""},
		// invalid group (nonsense)
		{"invalid.group", "v1", "Foo", "foos", "foo1", ""},
	}

	// Combine all test cases
	allCases := append(baseCases, edgeCases...)

	for _, tt := range allCases {
		tt := tt // capture range variable
		t.Run(tt.resource, func(t *testing.T) {
			t.Parallel()
			fmt.Printf(ctestglobals.DebugPrefix()+"Running test case: %+v\n", tt)

			createResources(t, test, tt.group, tt.version, tt.kind, tt.resource, tt.name, tt.namespace)
			// we always attempt to run the transformer; failures are expected for invalid cases
			test.runResource(t, unSealWithCBCTransformer, aesCBCPrefix, tt.group, tt.version, tt.resource, tt.name, tt.namespace)
		})
	}

	fmt.Println(ctestglobals.EndSeparator)
}

// getHardCodedConfigInfoEncryptionConfig returns the static encryption configuration YAML
func getHardCodedConfigInfoEncryptionConfig() ctestglobals.HardcodedConfig {
	const yaml = `
kind: EncryptionConfiguration
apiVersion: apiserver.config.k8s.io/v1
resources:
- resources:
  - pods
  - configmaps
  - customresourcedefinitions.apiextensions.k8s.io
  - pandas.awesome.bears.com
  - apiservices.apiregistration.k8s.io
  providers:
  - aescbc:
      keys:
      - name: key1
        secret: c2VjcmV0IGlzIHNlY3VyZQ==
`
	return ctestglobals.HardcodedConfig{
		{
			FixtureFileName: "test_fixture.json",
			TestInfo:        []string{"encryption config yaml"},
			Field:           "encryptionConfig",
			K8sObjects: []string{
				"pods", "configmaps", "customresourcedefinitions", "apiservices",
			},
			HardcodedConfig: yaml,
		},
	}
}
