package controlplane

import (
	// "bytes"
	"context"
	// "encoding/json"
	"fmt"
	// "io"
	// "net/http"
	// "os"
	// "path"
	"strconv"
	"strings"
	// "sync"
	"testing"
	// "time"

	// "sigs.k8s.io/yaml"

	appsv1 "k8s.io/api/apps/v1"
	corev1 "k8s.io/api/core/v1"
	// apierrors "k8s.io/apimachinery/pkg/api/errors"
	metav1 "k8s.io/apimachinery/pkg/apis/meta/v1"
	"k8s.io/apimachinery/pkg/runtime"
	// "k8s.io/apimachinery/pkg/util/wait"
	"k8s.io/apimachinery/pkg/util/uuid"
	clientset "k8s.io/client-go/kubernetes"
	// clienttypedv1 "k8s.io/client-go/kubernetes/typed/core/v1"
	// restclient "k8s.io/client-go/rest"
	// "k8s.io/kubernetes/cmd/kube-apiserver/app/options"
	kubeapiservertesting "k8s.io/kubernetes/cmd/kube-apiserver/app/testing"
	// "k8s.io/kubernetes/test/integration"
	"k8s.io/kubernetes/test/integration/framework"
	// "k8s.io/kubernetes/test/utils/ktesting"

	ctest "k8s.io/kubernetes/test/ctest"
	ctestglobals "k8s.io/kubernetes/test/ctest/ctestglobals"
	ctestutils "k8s.io/kubernetes/test/ctest/utils"
)

func getHardCodedConfigInfoObjectSize() ctestglobals.HardcodedConfig {
	return ctestglobals.HardcodedConfig{
		{
			FixtureFileName: "test_fixture.json",
			TestInfo:        []string{"default deployment for size test"},
			Field:           "spec",
			K8sObjects: []string{
				"deployments", "pods", "replicasets", "statefulsets", "daemonsets",
			},
			HardcodedConfig: &appsv1.Deployment{
				TypeMeta: metav1.TypeMeta{
					Kind:       "Deployment",
					APIVersion: "apps/v1",
				},
				ObjectMeta: metav1.ObjectMeta{
					Namespace: "default",
					Name:      "test",
				},
				Spec: appsv1.DeploymentSpec{
					Replicas: func() *int32 { i := int32(1); return &i }(),
					Selector: &metav1.LabelSelector{
						MatchLabels: map[string]string{
							"foo": "bar",
						},
					},
					Strategy: appsv1.DeploymentStrategy{
						Type: appsv1.RollingUpdateDeploymentStrategyType,
					},
					Template: corev1.PodTemplateSpec{
						ObjectMeta: metav1.ObjectMeta{
							Labels: map[string]string{"foo": "bar"},
						},
						Spec: corev1.PodSpec{
							Containers: []corev1.Container{
								{
									Name:  "foo",
									Image: "foo",
								},
							},
						},
					},
				},
			},
		},
	}
}

func TestCtestObjectSizeResponses(t *testing.T) {
	fmt.Println(ctestglobals.StartSeparator)
	hardCfg := getHardCodedConfigInfoObjectSize()
	item, found := ctestutils.GetItemByExactTestInfo(hardCfg, "default deployment for size test")
	if !found {
		fmt.Println(ctestglobals.DebugPrefix(), "Failed to find config item by TestInfo")
		t.Skip("no hardcoded config found")
	}
	fmt.Println(ctestglobals.DebugPrefix(), "get default configs:", item)

	fmt.Println(ctestglobals.StartExtendModeSeparator)
	configObjs, configJson, err := ctest.GenerateEffectiveConfigReturnType[*appsv1.Deployment](item, ctest.ExtendOnly)
	if err != nil {
		fmt.Println(ctestglobals.DebugPrefix(), "Failed to get matched fixtures:", err)
		t.Fatalf("fixture generation error: %v", err)
	}
	if configObjs == nil {
		fmt.Println(ctestglobals.DebugPrefix(), "Skipping test execution. No new configurations generated.")
		fmt.Println(ctestglobals.EndSeparator)
		return
	}
	fmt.Println(ctestglobals.DebugPrefix(), "New Json Test Configs:", string(configJson))
	fmt.Println(ctestglobals.DebugPrefix(), "Number of test cases:", len(configObjs))

	const (
		DeploymentMegabyteSize      = 25000
		DeploymentTwoMegabyteSize   = 30000
		DeploymentThreeMegabyteSize = 45000
	)

	expectedMsgFor1MB := `etcdserver: request is too large`
	expectedMsgFor2MB := `rpc error: code = ResourceExhausted desc = trying to send message larger than max`
	expectedMsgFor3MB := `Request entity too large: limit is 3145728`
	expectedMsgForLargeAnnotation := `metadata.annotations: Too long: may not be more than 262144 bytes`

	for i, baseDeployment := range configObjs {
		fmt.Printf("Running %d th test case (base deployment).\n", i)
		fmt.Println(baseDeployment)

		// Helper to clone deployment and set a unique name
		clone := func() *appsv1.Deployment {
			newDep := baseDeployment.DeepCopy()
			newDep.ObjectMeta.Name = "test-deploy-" + string(uuid.NewUUID())
			return newDep
		}

		// Labels size tests
		labelTests := []struct {
			size            int
			expectedMessage string
		}{
			{DeploymentMegabyteSize, expectedMsgFor1MB},
			{DeploymentTwoMegabyteSize, expectedMsgFor2MB},
			{DeploymentThreeMegabyteSize, expectedMsgFor3MB},
		}
		for _, lt := range labelTests {
			dep := clone()
			labelsMap := map[string]string{}
			for i := 0; i < lt.size; i++ {
				key := "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + strconv.Itoa(i)
				labelsMap[key] = "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"
			}
			dep.ObjectMeta.Labels = labelsMap

			runDeploymentSizeTest(t, dep, lt.expectedMessage)
		}

		// Annotations size test (single size)
		dep := clone()
		annotationsMap := map[string]string{}
		for i := 0; i < DeploymentMegabyteSize; i++ {
			key := "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + strconv.Itoa(i)
			annotationsMap[key] = "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"
		}
		dep.ObjectMeta.Annotations = annotationsMap
		runDeploymentSizeTest(t, dep, expectedMsgForLargeAnnotation)

		// Finalizers size tests
		finalizerTests := []struct {
			size            int
			expectedMessage string
		}{
			{DeploymentMegabyteSize, expectedMsgFor1MB},
			{DeploymentTwoMegabyteSize, expectedMsgFor2MB},
			{DeploymentThreeMegabyteSize, expectedMsgFor3MB},
		}
		for _, ft := range finalizerTests {
			dep := clone()
			finalizerSlice := []string{}
			for i := 0; i < ft.size; i++ {
				finalizerSlice = append(finalizerSlice, "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaa")
			}
			dep.ObjectMeta.Finalizers = finalizerSlice
			runDeploymentSizeTest(t, dep, ft.expectedMessage)
		}
	}
	fmt.Println(ctestglobals.EndSeparator)
}

func runDeploymentSizeTest(t *testing.T, deployment *appsv1.Deployment, expectedMessage string) {
	server := kubeapiservertesting.StartTestServerOrDie(t, nil, []string{"--storage-media-type=application/json"}, framework.SharedEtcd())
	defer server.TearDownFn()
	server.ClientConfig.ContentType = runtime.ContentTypeJSON
	client := clientset.NewForConfigOrDie(server.ClientConfig)

	_, err := client.AppsV1().Deployments(metav1.NamespaceDefault).Create(context.TODO(), deployment, metav1.CreateOptions{})
	if err == nil {
		t.Errorf("expected error for deployment %s but got nil", deployment.ObjectMeta.Name)
		return
	}
	if !strings.Contains(err.Error(), expectedMessage) {
		t.Errorf("deployment %s error mismatch: got %q, want substring %q", deployment.ObjectMeta.Name, err.Error(), expectedMessage)
	}
}
