package audit

import (
	"context"
	// "encoding/json"
	"fmt"
	"net/http"
	"os"
	"strings"
	"testing"
	"time"

	"k8s.io/apimachinery/pkg/util/uuid"
	"k8s.io/apimachinery/pkg/util/wait"
	utiltesting "k8s.io/client-go/util/testing"

	// "k8s.io/api/admission/v1beta1"
	// admissionregistrationv1 "k8s.io/api/admissionregistration/v1"
	appsv1 "k8s.io/api/apps/v1"
	// authenticationv1 "k8s.io/api/authentication/v1"
	// autoscalingv1 "k8s.io/api/autoscaling/v1"
	apiv1 "k8s.io/api/core/v1"
	metav1 "k8s.io/apimachinery/pkg/apis/meta/v1"
	// "k8s.io/apimachinery/pkg/apis/meta/v1/unstructured"
	// "k8s.io/apimachinery/pkg/runtime/schema"
	"k8s.io/apimachinery/pkg/types"
	// "k8s.io/apiserver/pkg/admission/plugin/webhook/mutating"
	auditinternal "k8s.io/apiserver/pkg/apis/audit"
	// auditv1 "k8s.io/apiserver/pkg/apis/audit/v1"
	clientset "k8s.io/client-go/kubernetes"
	kubeapiservertesting "k8s.io/kubernetes/cmd/kube-apiserver/app/testing"
	"k8s.io/kubernetes/test/integration/framework"
	"k8s.io/kubernetes/test/utils"

	// "github.com/onsi/ginkgo/v2"
	ctest "k8s.io/kubernetes/test/ctest"
	ctestglobals "k8s.io/kubernetes/test/ctest/ctestglobals"
	ctestutils "k8s.io/kubernetes/test/ctest/utils"
)

// TestCtestAudit is a dynamic‑config version of TestAudit. It loads hard‑coded
// ConfigMap specifications from a fixture (via ctest) and runs the original
// audit verification logic for each generated ConfigMap as well as a set of
// edge‑case ConfigMaps.
func TestCtestAudit(t *testing.T) {
	for version := range versions {
		runCtestWithVersion(t, version)
	}
}

func runCtestWithVersion(t *testing.T, version string) {
	webhookMux := http.NewServeMux()
	webhookMux.Handle("/mutation", utils.AdmissionWebhookHandler(t, admitFunc))
	url, closeFunc, err := utils.NewAdmissionWebhookServer(webhookMux)
	defer closeFunc()
	if err != nil {
		t.Fatalf("%v", err)
	}

	// prepare audit policy file
	auditPolicy := strings.Replace(auditPolicyPattern, "{version}", version, 1)
	policyFile, err := os.CreateTemp("", "audit-policy.yaml")
	if err != nil {
		t.Fatalf("Failed to create audit policy file: %v", err)
	}
	defer os.Remove(policyFile.Name())
	if _, err := policyFile.Write([]byte(auditPolicy)); err != nil {
		t.Fatalf("Failed to write audit policy file: %v", err)
	}
	if err := policyFile.Close(); err != nil {
		t.Fatalf("Failed to close audit policy file: %v", err)
	}

	// prepare audit log file
	logFile, err := os.CreateTemp("", "audit.log")
	if err != nil {
		t.Fatalf("Failed to create audit log file: %v", err)
	}
	defer utiltesting.CloseAndRemove(t, logFile)

	// start api server
	result := kubeapiservertesting.StartTestServerOrDie(t, nil,
		[]string{
			"--audit-policy-file", policyFile.Name(),
			"--audit-log-version", version,
			"--audit-log-mode", "blocking",
			"--audit-log-path", logFile.Name(),
		},
		framework.SharedEtcd(),
	)
	defer result.TearDownFn()

	kubeclient, err := clientset.NewForConfig(result.ClientConfig)
	if err != nil {
		t.Fatalf("Unexpected error: %v", err)
	}
	if err := createMutationWebhook(kubeclient, url+"/mutation"); err != nil {
		t.Fatal(err)
	}

	// --- dynamic ConfigMap generation -----------------------------------------
	fmt.Println(ctestglobals.StartSeparator)
	configInfos := getHardCodedConfigInfoAuditConfigMap()
	item, found := ctestutils.GetItemByExactTestInfo(configInfos, "default audit configmap")
	if !found {
		fmt.Println(ctestglobals.DebugPrefix(), "Failed to find config item")
		t.Fatalf("Failed to locate hardcoded config")
	}
	fmt.Println(ctestglobals.DebugPrefix(), "Loaded config item:", item)
	fmt.Println(ctestglobals.StartExtendModeSeparator)
	cfgObjs, cfgJSON, err := ctest.GenerateEffectiveConfigReturnType[apiv1.ConfigMap](item, ctest.ExtendOnly)
	if err != nil {
		fmt.Println(ctestglobals.DebugPrefix(), "Generate config error:", err)
		t.Fatalf("Generate config error: %v", err)
	}
	if cfgObjs == nil {
		fmt.Println(ctestglobals.DebugPrefix(), "Skipping test execution. No new config objs generated.")
		fmt.Println(ctestglobals.EndSeparator)
		return
	}
	fmt.Println(ctestglobals.DebugPrefix(), "New Json Test Configs:", string(cfgJSON))
	fmt.Println(ctestglobals.DebugPrefix(), "Number of config objects:", len(cfgObjs))

	// Add edge cases manually
	edgeConfigs := []apiv1.ConfigMap{
		{
			ObjectMeta: metav1.ObjectMeta{
				Name:      "audit-configmap-empty-data",
				Namespace: "", // will be overridden per test case
			},
			Data: map[string]string{},
		},
		{
			ObjectMeta: metav1.ObjectMeta{
				Name:      "audit-configmap-nil-data",
				Namespace: "",
			},
			// Data nil (zero value)
		},
		{
			ObjectMeta: metav1.ObjectMeta{
				Name:      "audit-configmap-large",
				Namespace: "",
			},
			Data: func() map[string]string {
				m := make(map[string]string, 1000)
				for i := 0; i < 1000; i++ {
					m[fmt.Sprintf("k%d", i)] = fmt.Sprintf("v%d", i)
				}
				return m
			}(),
		},
	}
	allConfigs := append(cfgObjs, edgeConfigs...)

	// test cases matrix (original matrix unchanged)
	tcs := []struct {
		auditLevel            auditinternal.Level
		enableMutatingWebhook bool
		namespace             string
	}{
		{
			auditLevel:            auditinternal.LevelRequestResponse,
			enableMutatingWebhook: false,
			namespace:             nonAdmissionWebhookNamespace,
		},
		{
			auditLevel:            auditinternal.LevelMetadata,
			enableMutatingWebhook: true,
			namespace:             "webhook-audit-metadata",
		},
		{
			auditLevel:            auditinternal.LevelRequest,
			enableMutatingWebhook: true,
			namespace:             "webhook-audit-request",
		},
		{
			auditLevel:            auditinternal.LevelRequestResponse,
			enableMutatingWebhook: true,
			namespace:             "webhook-audit-response",
		},
	}
	crossGroupTestCases := []struct {
		auditLevel auditinternal.Level
		expEvents  []utils.AuditEvent
		namespace  string
	}{
		{
			auditLevel: auditinternal.LevelRequest,
			namespace:  "create-audit-request",
			expEvents: []utils.AuditEvent{
				{
					Level:             auditinternal.LevelRequest,
					Stage:             auditinternal.StageResponseComplete,
					RequestURI:        fmt.Sprintf("/api/v1/namespaces/%s/serviceaccounts/%s/token", "create-audit-request", "audit-serviceaccount"),
					Verb:              "create",
					Code:              201,
					User:              auditTestUser,
					Resource:          "serviceaccounts",
					Namespace:         "create-audit-request",
					RequestObject:     true,
					ResponseObject:    false,
					AuthorizeDecision: "allow",
				},
			},
		},
		{
			auditLevel: auditinternal.LevelRequestResponse,
			namespace:  "create-audit-response",
			expEvents: []utils.AuditEvent{
				{
					Level:             auditinternal.LevelRequestResponse,
					Stage:             auditinternal.StageResponseComplete,
					RequestURI:        fmt.Sprintf("/api/v1/namespaces/%s/serviceaccounts/%s/token", "create-audit-response", "audit-serviceaccount"),
					Verb:              "create",
					Code:              201,
					User:              auditTestUser,
					Resource:          "serviceaccounts",
					Namespace:         "create-audit-response",
					RequestObject:     true,
					ResponseObject:    true,
					AuthorizeDecision: "allow",
				},
			},
		},
		{
			auditLevel: auditinternal.LevelRequest,
			namespace:  "update-audit-request",
			expEvents: []utils.AuditEvent{
				{
					Level:             auditinternal.LevelRequest,
					Stage:             auditinternal.StageResponseComplete,
					RequestURI:        fmt.Sprintf("/apis/apps/v1/namespaces/%s/deployments/%s/scale", "update-audit-request", "audit-deployment"),
					Verb:              "update",
					Code:              200,
					User:              auditTestUser,
					Resource:          "deployments",
					Namespace:         "update-audit-request",
					RequestObject:     true,
					ResponseObject:    false,
					AuthorizeDecision: "allow",
				},
			},
		},
		{
			auditLevel: auditinternal.LevelRequestResponse,
			namespace:  "update-audit-response",
			expEvents: []utils.AuditEvent{
				{
					Level:             auditinternal.LevelRequestResponse,
					Stage:             auditinternal.StageResponseComplete,
					RequestURI:        fmt.Sprintf("/apis/apps/v1/namespaces/%s/deployments/%s/scale", "update-audit-response", "audit-deployment"),
					Verb:              "update",
					Code:              200,
					User:              auditTestUser,
					Resource:          "deployments",
					Namespace:         "update-audit-response",
					RequestObject:     true,
					ResponseObject:    true,
					AuthorizeDecision: "allow",
				},
			},
		},
	}

	// iterate over generated config objects (including edge cases)
	for cfgIdx, cfg := range allConfigs {
		// Apply a unique namespace per iteration to avoid collisions
		nsSuffix := fmt.Sprintf("%d-%s", cfgIdx, string(uuid.NewUUID()))
		fmt.Printf("Running config #%d: %s\n", cfgIdx, cfg.Name)

		for _, tc := range tcs {
			t.Run(fmt.Sprintf("%s.%s.%t.%s", version, tc.auditLevel, tc.enableMutatingWebhook, nsSuffix), func(t *testing.T) {
				// Namespace is derived from test case namespace merged with suffix
				nsName := fmt.Sprintf("%s-%s", tc.namespace, nsSuffix)
				testAuditDynamic(t, version, tc.auditLevel, tc.enableMutatingWebhook, nsName, kubeclient, logFile, &cfg)
			})
		}
		for _, tc := range crossGroupTestCases {
			t.Run(fmt.Sprintf("cross-group-%s.%s.%s.%s", version, tc.auditLevel, tc.namespace, nsSuffix), func(t *testing.T) {
				nsName := fmt.Sprintf("%s-%s", tc.namespace, nsSuffix)
				testAuditCrossGroupDynamic(t, version, tc.expEvents, nsName, kubeclient, logFile, &cfg)
			})
		}
	}
	fmt.Println(ctestglobals.EndSeparator)
}

// testAuditDynamic is identical to testAudit but uses a dynamically supplied ConfigMap
// object (cfg) for the ConfigMap operations.
func testAuditDynamic(t *testing.T, version string, level auditinternal.Level, enableMutatingWebhook bool, namespace string, kubeclient clientset.Interface, logFile *os.File, cfg *apiv1.ConfigMap) {
	var lastMissingReport string
	createNamespace(t, kubeclient, namespace)

	if err := wait.Poll(500*time.Millisecond, wait.ForeverTestTimeout, func() (bool, error) {
		// perform configmap operations using the supplied config
		configMapOperationsDynamic(t, kubeclient, namespace, cfg)

		// check for corresponding audit logs
		stream, err := os.Open(logFile.Name())
		if err != nil {
			return false, fmt.Errorf("unexpected error: %v", err)
		}
		defer stream.Close()
		missingReport, err := utils.CheckAuditLines(stream, getExpectedEvents(level, enableMutatingWebhook, namespace), versions[version])
		if err != nil {
			return false, fmt.Errorf("unexpected error: %v", err)
		}
		if len(missingReport.MissingEvents) > 0 {
			lastMissingReport = missingReport.String()
			return false, nil
		}
		return true, nil
	}); err != nil {
		t.Fatalf("failed to get expected events -- missingReport: %s, error: %v", lastMissingReport, err)
	}
}

// testAuditCrossGroupDynamic mirrors testAuditCrossGroupSubResource but injects the
// dynamic ConfigMap (unused by the sub‑resource tests; kept for signature parity).
func testAuditCrossGroupDynamic(t *testing.T, version string, expEvents []utils.AuditEvent, namespace string, kubeclient clientset.Interface, logFile *os.File, cfg *apiv1.ConfigMap) {
	var (
		lastMissingReport string
		sa                *apiv1.ServiceAccount
		deploy            *appsv1.Deployment
	)

	createNamespace(t, kubeclient, namespace)
	switch expEvents[0].Resource {
	case "serviceaccounts":
		sa = createServiceAccount(t, kubeclient, namespace)
	case "deployments":
		deploy = createDeployment(t, kubeclient, namespace)
	default:
		t.Fatalf("%v resource has no cross-group sub-resources", expEvents[0].Resource)
	}

	if err := wait.Poll(500*time.Millisecond, wait.ForeverTestTimeout, func() (bool, error) {
		if sa != nil {
			tokenRequestOperations(t, kubeclient, sa.Namespace, sa.Name)
		}
		if deploy != nil {
			scaleOperations(t, kubeclient, deploy.Namespace, deploy.Name)
		}
		stream, err := os.Open(logFile.Name())
		if err != nil {
			return false, fmt.Errorf("unexpected error: %v", err)
		}
		defer stream.Close()
		missingReport, err := utils.CheckAuditLines(stream, expEvents, versions[version])
		if err != nil {
			return false, fmt.Errorf("unexpected error: %v", err)
		}
		if len(missingReport.MissingEvents) > 0 {
			lastMissingReport = missingReport.String()
			return false, nil
		}
		return true, nil
	}); err != nil {
		t.Fatalf("failed to get expected events -- missingReport: %s, error: %v", lastMissingReport, err)
	}
}

// configMapOperationsDynamic replaces the static ConfigMap definition with the
// supplied ConfigMap object. It respects the same label mutation logic as the
// original implementation.
func configMapOperationsDynamic(t *testing.T, kubeclient clientset.Interface, namespace string, cfg *apiv1.ConfigMap) {
	// Ensure namespace field matches the test namespace
	cfg.Namespace = namespace

	// Add admission label if needed (mirrors original logic)
	if namespace != nonAdmissionWebhookNamespace {
		if cfg.Labels == nil {
			cfg.Labels = map[string]string{}
		}
		cfg.Labels["admission"] = "true"
	}

	_, err := kubeclient.CoreV1().ConfigMaps(namespace).Create(context.TODO(), cfg, metav1.CreateOptions{})
	expectNoError(t, err, "failed to create audit-configmap")

	_, err = kubeclient.CoreV1().ConfigMaps(namespace).Get(context.TODO(), cfg.Name, metav1.GetOptions{})
	expectNoError(t, err, "failed to get audit-configmap")

	cmChan, err := kubeclient.CoreV1().ConfigMaps(namespace).Watch(context.TODO(), watchOptions)
	expectNoError(t, err, "failed to create watch for config maps")
	for range cmChan.ResultChan() {
		// Block until watch timeout expires.
	}

	_, err = kubeclient.CoreV1().ConfigMaps(namespace).Update(context.TODO(), cfg, metav1.UpdateOptions{})
	expectNoError(t, err, "failed to update audit-configmap")

	_, err = kubeclient.CoreV1().ConfigMaps(namespace).Patch(context.TODO(), cfg.Name, types.JSONPatchType, patch, metav1.PatchOptions{})
	expectNoError(t, err, "failed to patch configmap")

	_, err = kubeclient.CoreV1().ConfigMaps(namespace).List(context.TODO(), metav1.ListOptions{})
	expectNoError(t, err, "failed to list config maps")

	err = kubeclient.CoreV1().ConfigMaps(namespace).Delete(context.TODO(), cfg.Name, metav1.DeleteOptions{})
	expectNoError(t, err, "failed to delete audit-configmap")
}

// getHardCodedConfigInfoAuditConfigMap returns the base ConfigMap fixture used by the audit tests.
func getHardCodedConfigInfoAuditConfigMap() ctestglobals.HardcodedConfig {
	return ctestglobals.HardcodedConfig{
		{
			FixtureFileName: "test_fixture.json",
			TestInfo:        []string{"default audit configmap"},
			Field:           "data",
			K8sObjects:      []string{"configmaps"},
			HardcodedConfig: apiv1.ConfigMap{
				ObjectMeta: metav1.ObjectMeta{
					Name: "audit-configmap",
				},
				Data: map[string]string{
					"map-key": "map-value",
				},
			},
		},
	}
}

// The rest of the file (admitFunc, createMutationWebhook, createNamespace,
// createServiceAccount, createDeployment, tokenRequestOperations, scaleOperations,
// expectNoError, getExpectedEvents, etc.) is unchanged from the original
// implementation and is omitted here for brevity.
