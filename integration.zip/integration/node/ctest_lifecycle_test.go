package node

import (
	"fmt"
	"testing"
	"time"

	v1 "k8s.io/api/core/v1"
	"k8s.io/apimachinery/pkg/api/resource"
	metav1 "k8s.io/apimachinery/pkg/apis/meta/v1"
	"k8s.io/apimachinery/pkg/util/uuid"
	"k8s.io/apimachinery/pkg/util/version"
	"k8s.io/apimachinery/pkg/util/wait"
	// "k8s.io/apiserver/pkg/admission"
	// "k8s.io/apiserver/pkg/admission/initializer"
	"k8s.io/apiserver/pkg/util/feature"
	"k8s.io/client-go/informers"
	clientset "k8s.io/client-go/kubernetes"
	restclient "k8s.io/client-go/rest"
	featuregatetesting "k8s.io/component-base/featuregate/testing"
	"k8s.io/klog/v2"
	"k8s.io/kubernetes/cmd/kube-controller-manager/names"
	podutil "k8s.io/kubernetes/pkg/api/v1/pod"
	"k8s.io/kubernetes/pkg/controller/nodelifecycle"
	"k8s.io/kubernetes/pkg/controller/tainteviction"
	"k8s.io/kubernetes/pkg/features"
	// "k8s.io/kubernetes/plugin/pkg/admission/defaulttolerationseconds"
	"k8s.io/kubernetes/plugin/pkg/admission/podtolerationrestriction"
	pluginapi "k8s.io/kubernetes/plugin/pkg/admission/podtolerationrestriction/apis/podtolerationrestriction"
	testutils "k8s.io/kubernetes/test/integration/util"
	imageutils "k8s.io/kubernetes/test/utils/image"

	ctest "k8s.io/kubernetes/test/ctest"
	ctestglobals "k8s.io/kubernetes/test/ctest/ctestglobals"
	// ctestutils "k8s.io/kubernetes/test/ctest/utils"
)

func TestCtestEvictionForNoExecuteTaintAddedByUser(t *testing.T) {
	nodeCount := 3
	nodeIndex := 1

	// Original table‑driven cases
	tests := map[string]struct {
		enableSeparateTaintEvictionController  bool
		startStandaloneTaintEvictionController bool
		wantPodEvicted                         bool
	}{
		"taint added by user; pod condition added; controller disabled": {
			enableSeparateTaintEvictionController:  false,
			startStandaloneTaintEvictionController: false,
			wantPodEvicted:                         true,
		},
		"controller enabled but not started": {
			enableSeparateTaintEvictionController:  true,
			startStandaloneTaintEvictionController: false,
			wantPodEvicted:                         false,
		},
		"controller enabled and started": {
			enableSeparateTaintEvictionController:  true,
			startStandaloneTaintEvictionController: true,
			wantPodEvicted:                         true,
		},
		// edge case: controller not enabled but started (should act like disabled)
		"controller not enabled but started": {
			enableSeparateTaintEvictionController:  false,
			startStandaloneTaintEvictionController: true,
			wantPodEvicted:                         false,
		},
	}

	// --------------------- dynamic config generation ---------------------
	fmt.Println(ctestglobals.StartExtendModeSeparator)
	nodeConfigs, nodeJson, err := ctest.GenerateEffectiveConfigReturnType[v1.Node](getHardCodedConfigInfoNodeEviction()[0], ctest.ExtendOnly)
	if err != nil {
		t.Fatalf("failed to generate node config: %v", err)
	}
	fmt.Println(ctestglobals.DebugPrefix(), "node config json:", string(nodeJson))
	podConfigs, podJson, err := ctest.GenerateEffectiveConfigReturnType[v1.PodSpec](getHardCodedConfigInfoPodEviction()[0], ctest.ExtendOnly)
	if err != nil {
		t.Fatalf("failed to generate pod config: %v", err)
	}
	fmt.Println(ctestglobals.DebugPrefix(), "pod config json:", string(podJson))
	fmt.Println(ctestglobals.EndSeparator)

	for name, tc := range tests {
		t.Run(name, func(t *testing.T) {
			// Clone node template
			nodes := make([]*v1.Node, 0, nodeCount)
			for i := 0; i < nodeCount; i++ {
				// use first generated config as base
				baseNode := nodeConfigs[0]
				newNode := baseNode.DeepCopy()
				newNode.Name = fmt.Sprintf("testnode-%d-%s", i, string(uuid.NewUUID()))
				newNode.Labels = map[string]string{"node.kubernetes.io/exclude-disruption": "true"}
				newNode.Status.Conditions = []v1.NodeCondition{
					{
						Type:   v1.NodeReady,
						Status: v1.ConditionTrue,
					},
				}
				nodes = append(nodes, newNode)
			}

			// Build pod from dynamic config
			basePodSpec := podConfigs[0]
			testPod := &v1.Pod{
				ObjectMeta: metav1.ObjectMeta{
					Name: "testpod-" + string(uuid.NewUUID()),
				},
				Spec: basePodSpec,
			}
			testPod.Spec.NodeName = nodes[nodeIndex].Name
			testPod.Spec.Containers = []v1.Container{
				{
					Name:  "container",
					Image: imageutils.GetPauseImageName(),
				},
			}

			// Feature gate emulation & setup
			featuregatetesting.SetFeatureGateEmulationVersionDuringTest(t, feature.DefaultFeatureGate, version.MustParse("1.33"))
			featuregatetesting.SetFeatureGateDuringTest(t, feature.DefaultFeatureGate, features.SeparateTaintEvictionController, tc.enableSeparateTaintEvictionController)
			testCtx := testutils.InitTestAPIServer(t, "taint-no-execute", nil)
			cs := testCtx.ClientSet

			// Build clientset and informers for controllers.
			externalClientConfig := restclient.CopyConfig(testCtx.KubeConfig)
			externalClientConfig.QPS = -1
			externalClientset := clientset.NewForConfigOrDie(externalClientConfig)
			externalInformers := informers.NewSharedInformerFactory(externalClientset, time.Second)

			// Start NodeLifecycleController
			nc, err := nodelifecycle.NewNodeLifecycleController(
				testCtx.Ctx,
				externalInformers.Coordination().V1().Leases(),
				externalInformers.Core().V1().Pods(),
				externalInformers.Core().V1().Nodes(),
				externalInformers.Apps().V1().DaemonSets(),
				cs,
				1*time.Second,
				time.Minute,
				time.Millisecond,
				100,
				100,
				50,
				0.55,
			)
			if err != nil {
				t.Fatalf("Failed to create node controller: %v", err)
			}
			externalInformers.Start(testCtx.Ctx.Done())
			externalInformers.WaitForCacheSync(testCtx.Ctx.Done())
			go nc.Run(testCtx.Ctx)

			// Optional standalone TaintEvictionController
			if tc.startStandaloneTaintEvictionController {
				tm, _ := tainteviction.New(
					testCtx.Ctx,
					testCtx.ClientSet,
					externalInformers.Core().V1().Pods(),
					externalInformers.Core().V1().Nodes(),
					names.TaintEvictionController,
				)
				go tm.Run(testCtx.Ctx)
			}

			// Create nodes
			for i := range nodes {
				nodes[i], err = cs.CoreV1().Nodes().Create(testCtx.Ctx, nodes[i], metav1.CreateOptions{})
				if err != nil {
					t.Fatalf("Failed to create node: %v", err)
				}
			}

			// Create pod
			testPod, err = cs.CoreV1().Pods(testCtx.NS.Name).Create(testCtx.Ctx, testPod, metav1.CreateOptions{})
			if err != nil {
				t.Fatalf("Failed to create pod: %v", err)
			}

			// Add user taint
			if err := testutils.AddTaintToNode(cs, nodes[nodeIndex].Name, v1.Taint{Key: "CustomTaintByUser", Effect: v1.TaintEffectNoExecute}); err != nil {
				t.Fatalf("Failed to add taint: %v", err)
			}

			// Wait for eviction/termination
			err = wait.PollUntilContextTimeout(testCtx.Ctx, time.Second, 20*time.Second, true, testutils.PodIsGettingEvicted(cs, testPod.Namespace, testPod.Name))
			if err != nil && tc.wantPodEvicted {
				t.Fatalf("Expected eviction but got error: %v", err)
			} else if !wait.Interrupted(err) && !tc.wantPodEvicted {
				t.Fatalf("Unexpected eviction of pod %v", klog.KObj(testPod))
			}

			// Verify DisruptionTarget condition
			pod, err := cs.CoreV1().Pods(testCtx.NS.Name).Get(testCtx.Ctx, testPod.Name, metav1.GetOptions{})
			if err != nil {
				t.Fatalf("Failed to get pod: %v", err)
			}
			_, cond := podutil.GetPodCondition(&pod.Status, v1.DisruptionTarget)
			if tc.wantPodEvicted && cond == nil {
				t.Errorf("Expected DisruptionTarget condition, got none")
			}
			if !tc.wantPodEvicted && cond != nil {
				t.Errorf("Unexpected DisruptionTarget condition: %v", cond)
			}
		})
	}
}

func TestCtestTaintBasedEvictions(t *testing.T) {
	nodeCount := 3
	nodeIndex := 1
	zero := int64(0)
	gracePeriod := int64(1)

	// Base pod template (used in many table entries)
	basePod := &v1.Pod{
		ObjectMeta: metav1.ObjectMeta{
			Name:                       "testpod1",
			DeletionGracePeriodSeconds: &zero,
		},
		Spec: v1.PodSpec{
			Containers: []v1.Container{
				{Name: "container", Image: imageutils.GetPauseImageName()},
			},
			Tolerations: []v1.Toleration{
				{
					Key:      v1.TaintNodeNotReady,
					Operator: v1.TolerationOpExists,
					Effect:   v1.TaintEffectNoExecute,
				},
			},
			TerminationGracePeriodSeconds: &gracePeriod,
		},
	}

	tests := []struct {
		name                                  string
		nodeTaints                            []v1.Taint
		nodeConditions                        []v1.NodeCondition
		pod                                   *v1.Pod
		tolerationSeconds                     int64
		expectedWaitForPodCondition           string
		enableSeparateTaintEvictionController bool
	}{
		{
			name:                                  "NodeNotReady, 200s, controller disabled",
			nodeTaints:                            []v1.Taint{{Key: v1.TaintNodeNotReady, Effect: v1.TaintEffectNoExecute}},
			nodeConditions:                        []v1.NodeCondition{{Type: v1.NodeReady, Status: v1.ConditionFalse}},
			pod:                                   basePod.DeepCopy(),
			tolerationSeconds:                     200,
			expectedWaitForPodCondition:           "updated with tolerationSeconds of 200",
			enableSeparateTaintEvictionController: false,
		},
		{
			name:                                  "NodeNotReady, 200s, controller enabled",
			nodeTaints:                            []v1.Taint{{Key: v1.TaintNodeNotReady, Effect: v1.TaintEffectNoExecute}},
			nodeConditions:                        []v1.NodeCondition{{Type: v1.NodeReady, Status: v1.ConditionFalse}},
			pod:                                   basePod.DeepCopy(),
			tolerationSeconds:                     200,
			expectedWaitForPodCondition:           "updated with tolerationSeconds of 200",
			enableSeparateTaintEvictionController: true,
		},
		{
			name:           "No pod tolerations, controller disabled",
			nodeTaints:     []v1.Taint{{Key: v1.TaintNodeNotReady, Effect: v1.TaintEffectNoExecute}},
			nodeConditions: []v1.NodeCondition{{Type: v1.NodeReady, Status: v1.ConditionFalse}},
			pod: &v1.Pod{
				ObjectMeta: metav1.ObjectMeta{Name: "testpod1"},
				Spec: v1.PodSpec{
					Containers: []v1.Container{
						{Name: "container", Image: imageutils.GetPauseImageName()},
					},
				},
			},
			tolerationSeconds:                     300,
			expectedWaitForPodCondition:           "updated with tolerationSeconds=300",
			enableSeparateTaintEvictionController: false,
		},
		{
			name:           "No pod tolerations, controller enabled",
			nodeTaints:     []v1.Taint{{Key: v1.TaintNodeNotReady, Effect: v1.TaintEffectNoExecute}},
			nodeConditions: []v1.NodeCondition{{Type: v1.NodeReady, Status: v1.ConditionFalse}},
			pod: &v1.Pod{
				ObjectMeta: metav1.ObjectMeta{Name: "testpod1"},
				Spec: v1.PodSpec{
					Containers: []v1.Container{
						{Name: "container", Image: imageutils.GetPauseImageName()},
					},
				},
			},
			tolerationSeconds:                     300,
			expectedWaitForPodCondition:           "updated with tolerationSeconds=300",
			enableSeparateTaintEvictionController: true,
		},
		{
			name:                                  "NodeNotReady, 0s, controller disabled",
			nodeTaints:                            []v1.Taint{{Key: v1.TaintNodeNotReady, Effect: v1.TaintEffectNoExecute}},
			nodeConditions:                        []v1.NodeCondition{{Type: v1.NodeReady, Status: v1.ConditionFalse}},
			pod:                                   basePod.DeepCopy(),
			tolerationSeconds:                     0,
			expectedWaitForPodCondition:           "terminating",
			enableSeparateTaintEvictionController: false,
		},
		{
			name:                                  "NodeNotReady, 0s, controller enabled",
			nodeTaints:                            []v1.Taint{{Key: v1.TaintNodeNotReady, Effect: v1.TaintEffectNoExecute}},
			nodeConditions:                        []v1.NodeCondition{{Type: v1.NodeReady, Status: v1.ConditionFalse}},
			pod:                                   basePod.DeepCopy(),
			tolerationSeconds:                     0,
			expectedWaitForPodCondition:           "terminating",
			enableSeparateTaintEvictionController: true,
		},
		{
			name:                                  "NodeUnreachable, controller disabled",
			nodeTaints:                            []v1.Taint{{Key: v1.TaintNodeUnreachable, Effect: v1.TaintEffectNoExecute}},
			nodeConditions:                        []v1.NodeCondition{{Type: v1.NodeReady, Status: v1.ConditionUnknown}},
			enableSeparateTaintEvictionController: false,
		},
		{
			name:                                  "NodeUnreachable, controller enabled",
			nodeTaints:                            []v1.Taint{{Key: v1.TaintNodeUnreachable, Effect: v1.TaintEffectNoExecute}},
			nodeConditions:                        []v1.NodeCondition{{Type: v1.NodeReady, Status: v1.ConditionUnknown}},
			enableSeparateTaintEvictionController: true,
		},
		// edge case: pod with nil tolerations and zero tolerationSeconds
		{
			name:           "Pod nil tolerations, zero seconds, controller disabled",
			nodeTaints:     []v1.Taint{{Key: v1.TaintNodeNotReady, Effect: v1.TaintEffectNoExecute}},
			nodeConditions: []v1.NodeCondition{{Type: v1.NodeReady, Status: v1.ConditionFalse}},
			pod: &v1.Pod{
				ObjectMeta: metav1.ObjectMeta{Name: "testpod2"},
				Spec: v1.PodSpec{
					Containers: []v1.Container{
						{Name: "container", Image: imageutils.GetPauseImageName()},
					},
				},
			},
			tolerationSeconds:                     0,
			expectedWaitForPodCondition:           "terminating",
			enableSeparateTaintEvictionController: false,
		},
	}

	// ---------- dynamic config for pod template ----------
	fmt.Println(ctestglobals.StartExtendModeSeparator)
	podTemplateConfig, podJson, err := ctest.GenerateEffectiveConfigReturnType[v1.PodSpec](getHardCodedConfigInfoPodTaintBased()[0], ctest.ExtendOnly)
	if err != nil {
		t.Fatalf("failed to generate pod template config: %v", err)
	}
	fmt.Println(ctestglobals.DebugPrefix(), "pod template json:", string(podJson))
	fmt.Println(ctestglobals.EndSeparator)

	for _, test := range tests {
		t.Run(test.name, func(t *testing.T) {
			featuregatetesting.SetFeatureGateEmulationVersionDuringTest(t, feature.DefaultFeatureGate, version.MustParse("1.33"))
			featuregatetesting.SetFeatureGateDuringTest(t, feature.DefaultFeatureGate, features.SeparateTaintEvictionController, test.enableSeparateTaintEvictionController)

			testCtx := testutils.InitTestAPIServer(t, "taint-based-evictions", nil)

			// Clientset & informers
			externalClientConfig := restclient.CopyConfig(testCtx.KubeConfig)
			externalClientConfig.QPS = -1
			externalClientset := clientset.NewForConfigOrDie(externalClientConfig)
			externalInformers := informers.NewSharedInformerFactory(externalClientset, time.Second)
			podTolerations := podtolerationrestriction.NewPodTolerationsPlugin(&pluginapi.Configuration{})
			podTolerations.SetExternalKubeClientSet(externalClientset)
			podTolerations.SetExternalKubeInformerFactory(externalInformers)

			cs := testCtx.ClientSet

			// NodeLifecycleController
			nc, err := nodelifecycle.NewNodeLifecycleController(
				testCtx.Ctx,
				externalInformers.Coordination().V1().Leases(),
				externalInformers.Core().V1().Pods(),
				externalInformers.Core().V1().Nodes(),
				externalInformers.Apps().V1().DaemonSets(),
				cs,
				1*time.Second,
				time.Minute,
				time.Millisecond,
				100,
				100,
				50,
				0.55,
			)
			if err != nil {
				t.Fatalf("Failed to create node controller: %v", err)
			}
			externalInformers.Start(testCtx.Ctx.Done())
			externalInformers.WaitForCacheSync(testCtx.Ctx.Done())
			go nc.Run(testCtx.Ctx)

			// Optional TaintEvictionController
			if test.enableSeparateTaintEvictionController {
				tm, _ := tainteviction.New(
					testCtx.Ctx,
					testCtx.ClientSet,
					externalInformers.Core().V1().Pods(),
					externalInformers.Core().V1().Nodes(),
					names.TaintEvictionController,
				)
				go tm.Run(testCtx.Ctx)
			}

			// Create nodes
			nodeRes := v1.ResourceList{
				v1.ResourceCPU:    resource.MustParse("4000m"),
				v1.ResourceMemory: resource.MustParse("16Gi"),
				v1.ResourcePods:   resource.MustParse("110"),
			}
			var nodes []*v1.Node
			for i := 0; i < nodeCount; i++ {
				node := &v1.Node{
					ObjectMeta: metav1.ObjectMeta{
						Name: fmt.Sprintf("node-%d-%s", i, string(uuid.NewUUID())),
						Labels: map[string]string{
							v1.LabelTopologyRegion:                  "region1",
							v1.LabelTopologyZone:                    "zone1",
							"node.kubernetes.io/exclude-disruption": "true",
						},
					},
					Spec: v1.NodeSpec{},
					Status: v1.NodeStatus{
						Capacity:    nodeRes,
						Allocatable: nodeRes,
					},
				}
				if i == nodeIndex {
					node.Status.Conditions = append(node.Status.Conditions, test.nodeConditions...)
				} else {
					node.Status.Conditions = append(node.Status.Conditions, v1.NodeCondition{
						Type:   v1.NodeReady,
						Status: v1.ConditionTrue,
					})
				}
				nodes = append(nodes, node)
				if _, err := cs.CoreV1().Nodes().Create(testCtx.Ctx, node, metav1.CreateOptions{}); err != nil {
					t.Fatalf("Failed to create node: %v", err)
				}
			}

			// Create pod if defined
			if test.pod != nil {
				test.pod.Spec.NodeName = nodes[nodeIndex].Name
				test.pod.Name = "testpod-" + string(uuid.NewUUID())
				// Apply dynamic pod template base for missing fields
				if len(test.pod.Spec.Containers) == 0 {
					baseSpec := podTemplateConfig[0]
					test.pod.Spec.Containers = baseSpec.Containers
				}
				if len(test.pod.Spec.Tolerations) > 0 && test.pod.Spec.Tolerations[0].TolerationSeconds != nil {
					test.pod.Spec.Tolerations[0].TolerationSeconds = &test.tolerationSeconds
				}
				test.pod, err = cs.CoreV1().Pods(testCtx.NS.Name).Create(testCtx.Ctx, test.pod, metav1.CreateOptions{})
				if err != nil {
					t.Fatalf("Failed to create pod: %v", err)
				}
			}

			// Apply taints to target node
			if err := testutils.WaitForNodeTaints(testCtx.Ctx, cs, nodes[nodeIndex], test.nodeTaints); err != nil {
				t.Fatalf("Failed to apply node taints: %v", err)
			}

			if test.pod != nil {
				err = wait.PollImmediate(time.Second, 15*time.Second, func() (bool, error) {
					podObj, err := cs.CoreV1().Pods(test.pod.Namespace).Get(testCtx.Ctx, test.pod.Name, metav1.GetOptions{})
					if err != nil {
						return false, err
					}
					if test.tolerationSeconds == 0 {
						return podObj.DeletionTimestamp != nil, nil
					}
					if seconds, err := testutils.GetTolerationSeconds(podObj.Spec.Tolerations); err == nil {
						return seconds == test.tolerationSeconds, nil
					}
					return false, nil
				})
				if err != nil {
					t.Fatalf("Pod did not reach expected state: %v", err)
				}
				testutils.CleanupPods(testCtx.Ctx, cs, t, []*v1.Pod{test.pod})
			}
			testutils.CleanupNodes(cs, t)
		})
	}
}

// ----------- Hardcoded config generators ------------

func getHardCodedConfigInfoNodeEviction() ctestglobals.HardcodedConfig {
	return ctestglobals.HardcodedConfig{
		{
			FixtureFileName: "test_fixture.json",
			TestInfo:        []string{"node eviction base config"},
			Field:           "node",
			K8sObjects:      []string{"nodes"},
			HardcodedConfig: v1.Node{
				Status: v1.NodeStatus{
					Conditions: []v1.NodeCondition{
						{
							Type:   v1.NodeReady,
							Status: v1.ConditionTrue,
						},
					},
				},
			},
		},
	}
}

func getHardCodedConfigInfoPodEviction() ctestglobals.HardcodedConfig {
	return ctestglobals.HardcodedConfig{
		{
			FixtureFileName: "test_fixture.json",
			TestInfo:        []string{"pod eviction base config"},
			Field:           "podSpec",
			K8sObjects:      []string{"pods"},
			HardcodedConfig: v1.PodSpec{
				Containers: []v1.Container{
					{
						Name:  "container",
						Image: imageutils.GetPauseImageName(),
					},
				},
			},
		},
	}
}

func getHardCodedConfigInfoPodTaintBased() ctestglobals.HardcodedConfig {
	return ctestglobals.HardcodedConfig{
		{
			FixtureFileName: "test_fixture.json",
			TestInfo:        []string{"pod taint‑based evictions base config"},
			Field:           "podSpec",
			K8sObjects:      []string{"pods"},
			HardcodedConfig: v1.PodSpec{
				Containers: []v1.Container{
					{
						Name:  "container",
						Image: imageutils.GetPauseImageName(),
					},
				},
			},
		},
	}
}
