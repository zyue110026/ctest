package network

import (
	// "encoding/json"
	"fmt"
	"testing"
	"time"

	"k8s.io/api/core/v1"
	// "k8s.io/apimachinery/pkg/api/meta"
	metav1 "k8s.io/apimachinery/pkg/apis/meta/v1"
	"k8s.io/apimachinery/pkg/types"
	"k8s.io/apimachinery/pkg/util/intstr"
	// "k8s.io/apimachinery/pkg/util/strategicpatch"
	"k8s.io/apimachinery/pkg/util/uuid"
	"k8s.io/apimachinery/pkg/util/wait"
	"k8s.io/kubernetes/cmd/kube-apiserver/app/options"
	"k8s.io/kubernetes/pkg/controlplane"

	"k8s.io/kubernetes/test/integration/framework"
	"k8s.io/kubernetes/test/utils/ktesting"

	ctest "k8s.io/kubernetes/test/ctest"
	ctestglobals "k8s.io/kubernetes/test/ctest/ctestglobals"
	ctestutils "k8s.io/kubernetes/test/ctest/utils"
)

func TestCtestServicesFinalizersRepairLoop(t *testing.T) {
	serviceCIDR := "10.0.0.0/16"
	clusterIP := "10.0.0.20"
	interval := 5 * time.Second

	fmt.Println(ctestglobals.StartExtendModeSeparator)
	hardcoded := getHardCodedConfigInfoServiceFinalizers()
	item, found := ctestutils.GetItemByExactTestInfo(hardcoded, "service with finalizer")
	if !found {
		fmt.Println(ctestglobals.DebugPrefix(), "Failed to find config item by TestInfo")
		t.Fatalf("hardcoded config not found")
	}
	fmt.Println(ctestglobals.DebugPrefix(), "matched config:", item)

	cfgObjs, cfgJSON, err := ctest.GenerateEffectiveConfigReturnType[v1.ServiceSpec](item, ctest.ExtendOnly)
	if err != nil {
		fmt.Println(ctestglobals.DebugPrefix(), "GenerateEffectiveConfig error:", err)
		t.Fatalf("failed to generate config")
	}
	if cfgObjs == nil {
		fmt.Println(ctestglobals.DebugPrefix(), "Skipping test execution. No new configurations generated.")
		return
	}
	fmt.Println(ctestglobals.DebugPrefix(), "New Json Test Configs:", string(cfgJSON))
	fmt.Println(ctestglobals.DebugPrefix(), "Number of test cases:", len(cfgObjs))

	tCtx := ktesting.Init(t)
	client, _, tearDownFn := framework.StartTestServer(tCtx, t, framework.TestServerSetup{
		ModifyServerRunOptions: func(opts *options.ServerRunOptions) {
			opts.ServiceClusterIPRanges = serviceCIDR
		},
		ModifyServerConfig: func(cfg *controlplane.Config) {
			cfg.Extra.RepairServicesInterval = interval
		},
	})
	defer tearDownFn()

	// verify client is working
	if err := wait.PollImmediate(5*time.Second, 2*time.Minute, func() (bool, error) {
		_, err := client.CoreV1().Endpoints(metav1.NamespaceDefault).Get(tCtx, "kubernetes", metav1.GetOptions{})
		if err != nil {
			t.Logf("error fetching endpoints: %v", err)
			return false, nil
		}
		return true, nil
	}); err != nil {
		t.Fatalf("server without enabled endpoints failed to register: %v", err)
	}

	for i, spec := range cfgObjs {
		fmt.Printf("Running %d th test case.\n", i)
		fmt.Println(spec)

		svcName := "svc-" + string(uuid.NewUUID())
		svcNodePort := v1.Service{
			ObjectMeta: metav1.ObjectMeta{
				Name:       svcName,
				Finalizers: []string{"foo.bar/some-finalizer"},
			},
			Spec: spec,
		}
		// Ensure the spec has required fields that were not part of the hardcoded minimal config
		if svcNodePort.Spec.ClusterIP == "" {
			svcNodePort.Spec.ClusterIP = clusterIP
		}
		if len(svcNodePort.Spec.Ports) == 0 {
			svcNodePort.Spec.Ports = []v1.ServicePort{{
				Port:       8443,
				NodePort:   30443,
				TargetPort: intstr.FromInt32(8443),
				Protocol:   v1.ProtocolTCP,
			}}
		}
		if svcNodePort.Spec.Type == "" {
			svcNodePort.Spec.Type = v1.ServiceTypeNodePort
		}

		// Create service
		if _, err := client.CoreV1().Services(metav1.NamespaceDefault).Create(tCtx, &svcNodePort, metav1.CreateOptions{}); err != nil {
			t.Fatalf("unexpected error creating service: %v", err)
		}
		t.Logf("Created service: %s", svcNodePort.Name)

		// Check the service has been created correctly
		svc, err := client.CoreV1().Services(metav1.NamespaceDefault).Get(tCtx, svcNodePort.Name, metav1.GetOptions{})
		if err != nil || svc.Spec.ClusterIP != svcNodePort.Spec.ClusterIP {
			t.Fatalf("created service is not correct: %v", err)
		}
		t.Logf("Service created successfully: %v", svc)

		// Delete service
		if err := client.CoreV1().Services(metav1.NamespaceDefault).Delete(tCtx, svcNodePort.Name, metav1.DeleteOptions{}); err != nil {
			t.Fatalf("unexpected error deleting service: %v", err)
		}
		t.Logf("Deleted service: %s", svcNodePort.Name)

		// wait for the repair loop to recover the deleted resources
		time.Sleep(interval + 1)

		// Check that the service was not deleted and the IP is already allocated
		svc, err = client.CoreV1().Services(metav1.NamespaceDefault).Get(tCtx, svcNodePort.Name, metav1.GetOptions{})
		if err != nil || svc.Spec.ClusterIP != svcNodePort.Spec.ClusterIP {
			t.Fatalf("service not recovered correctly: %v", err)
		}
		t.Logf("Service after Delete: %v", svc)

		// Remove the finalizer
		if _, err = client.CoreV1().Services(metav1.NamespaceDefault).Patch(tCtx, svcNodePort.Name, types.JSONPatchType, []byte(`[{"op":"remove","path":"/metadata/finalizers"}]`), metav1.PatchOptions{}); err != nil {
			t.Fatalf("unexpected error removing finalizer: %v", err)
		}
		t.Logf("Removed service finalizer: %s", svcNodePort.Name)

		// Check that the service was deleted
		_, err = client.CoreV1().Services(metav1.NamespaceDefault).Get(tCtx, svcNodePort.Name, metav1.GetOptions{})
		if err == nil {
			t.Fatalf("service was not delete: %v", err)
		}

		// Try to create service again
		if _, err := client.CoreV1().Services(metav1.NamespaceDefault).Create(tCtx, &svcNodePort, metav1.CreateOptions{}); err != nil {
			t.Fatalf("unexpected error creating service: %v", err)
		}
		t.Logf("Created service again: %s", svcNodePort.Name)
	}
	fmt.Println(ctestglobals.EndSeparator)
}

func getHardCodedConfigInfoServiceFinalizers() ctestglobals.HardcodedConfig {
	return ctestglobals.HardcodedConfig{
		{
			FixtureFileName: "test_fixture.json",
			TestInfo:        []string{"service with finalizer"},
			Field:           "spec",
			K8sObjects: []string{
				"services", "pods", "endpoints",
			},
			HardcodedConfig: v1.ServiceSpec{
				ClusterIP: "10.0.0.20",
				Ports: []v1.ServicePort{{
					Port:       8443,
					NodePort:   30443,
					TargetPort: intstr.FromInt32(8443),
					Protocol:   v1.ProtocolTCP,
				}},
				Type: v1.ServiceTypeNodePort,
			},
		},
		{
			FixtureFileName: "test_fixture.json",
			TestInfo:        []string{"service with empty finalizer edge"},
			Field:           "spec",
			K8sObjects: []string{
				"services",
			},
			HardcodedConfig: v1.ServiceSpec{
				ClusterIP: "",
				Ports: []v1.ServicePort{{
					Port:       0,
					NodePort:   0,
					TargetPort: intstr.FromInt32(0),
					Protocol:   v1.ProtocolTCP,
				}},
				Type: v1.ServiceTypeNodePort,
			},
		},
	}
}
