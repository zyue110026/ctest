package apimachinery

import (
	"context"
	"fmt"
	"reflect"
	"testing"
	"time"

	// "github.com/onsi/ginkgo/v2"
	// "github.com/onsi/gomega"
	corev1 "k8s.io/api/core/v1"
	metav1 "k8s.io/apimachinery/pkg/apis/meta/v1"
	"k8s.io/apimachinery/pkg/fields"
	"k8s.io/apimachinery/pkg/runtime"
	"k8s.io/apimachinery/pkg/types"
	"k8s.io/apimachinery/pkg/util/wait"
	"k8s.io/apimachinery/pkg/watch"
	"k8s.io/client-go/kubernetes"
	"k8s.io/client-go/tools/cache"
	watchtools "k8s.io/client-go/tools/watch"

	ctest "k8s.io/kubernetes/test/ctest"
	ctestglobals "k8s.io/kubernetes/test/ctest/ctestglobals"
	ctestutils "k8s.io/kubernetes/test/ctest/utils"

	"k8s.io/apimachinery/pkg/util/uuid"
	kubeapiservertesting "k8s.io/kubernetes/cmd/kube-apiserver/app/testing"
	"k8s.io/kubernetes/test/integration/framework"
)

func TestCtestWatchRestartsIfTimeoutNotReached(t *testing.T) {
	timeout := 30 * time.Second

	server := kubeapiservertesting.StartTestServerOrDie(t, nil, []string{"--min-request-timeout=7"}, framework.SharedEtcd())
	defer server.TearDownFn()

	clientset, err := kubernetes.NewForConfig(server.ClientConfig)
	if err != nil {
		t.Fatalf("Failed to create clientset: %v", err)
	}

	namespaceObject := framework.CreateNamespaceOrDie(clientset, "retry-watch", t)
	defer framework.DeleteNamespaceOrDie(clientset, namespaceObject, t)

	getListFunc := func(c *kubernetes.Clientset, secret *corev1.Secret) func(options metav1.ListOptions) *corev1.SecretList {
		return func(options metav1.ListOptions) *corev1.SecretList {
			options.FieldSelector = fields.OneTermEqualSelector("metadata.name", secret.Name).String()
			res, err := c.CoreV1().Secrets(secret.Namespace).List(context.TODO(), options)
			if err != nil {
				t.Fatalf("Failed to list Secrets: %v", err)
			}
			return res
		}
	}

	getWatchFunc := func(c *kubernetes.Clientset, secret *corev1.Secret) func(options metav1.ListOptions) (watch.Interface, error) {
		return func(options metav1.ListOptions) (watch.Interface, error) {
			options.FieldSelector = fields.OneTermEqualSelector("metadata.name", secret.Name).String()
			res, err := c.CoreV1().Secrets(secret.Namespace).Watch(context.TODO(), options)
			if err != nil {
				t.Fatalf("Failed to create a watcher on Secrets: %v", err)
			}
			return res, err
		}
	}

	generateEvents := func(t *testing.T, c *kubernetes.Clientset, secret *corev1.Secret, referenceOutput *[]string, stopChan chan struct{}, stoppedChan chan struct{}) {
		defer close(stoppedChan)
		counter := 0
		softTimeout := timeout - 5*time.Second
		if softTimeout < 0 {
			panic("Timeout has to be greater than 5 seconds!")
		}
		endChannel := time.After(softTimeout)
		for {
			select {
			case <-time.After(1000 * time.Millisecond):
				counter = counter + 1
				patch := fmt.Sprintf(`{"metadata": {"annotations": {"count": "%d"}}}`, counter)
				_, err := c.CoreV1().Secrets(secret.Namespace).Patch(context.TODO(), secret.Name, types.StrategicMergePatchType, []byte(patch), metav1.PatchOptions{})
				if err != nil {
					t.Errorf("Failed to patch secret: %v", err)
					return
				}
				*referenceOutput = append(*referenceOutput, fmt.Sprintf("%d", counter))
			case <-endChannel:
				return
			case <-stopChan:
				return
			}
		}
	}

	// Load hard‑coded secret configuration via ctest
	fmt.Println(ctestglobals.StartSeparator)
	hardConfig := getHardCodedConfigInfoWatchRestart()
	item, found := ctestutils.GetItemByExactTestInfo(hardConfig, "default secret")
	if !found {
		t.Fatalf("Failed to locate hard‑coded config")
	}
	configObjs, configJSON, err := ctest.GenerateEffectiveConfigReturnType[corev1.Secret](item, ctest.OverrideOnly)
	if err != nil {
		t.Fatalf("Generate config failed: %v", err)
	}
	if configObjs == nil {
		fmt.Println(ctestglobals.DebugPrefix(), "Skipping test execution. No new configurations generated.")
		return
	}
	fmt.Println(ctestglobals.DebugPrefix(), "get default configs:", item)
	fmt.Println(ctestglobals.StartOverrideModeSeparator)
	fmt.Println(ctestglobals.DebugPrefix(), "New Json Test Configs:", string(configJSON))
	fmt.Println(ctestglobals.DebugPrefix(), "Number of test cases:", len(configObjs))

	for cfgIdx, cfgSecret := range configObjs {
		// Prepare base secret for this iteration
		baseSecret := cfgSecret.DeepCopy()
		baseSecret.Name = fmt.Sprintf("secret-%d-%s", cfgIdx, string(uuid.NewUUID()))
		baseSecret.Namespace = namespaceObject.Name

		// Edge case: secret without annotations
		edgeSecret := baseSecret.DeepCopy()
		edgeSecret.Annotations = map[string]string{}

		// Determine initial count for normalizer
		initialCount := baseSecret.Annotations["count"]
		if initialCount == "" {
			initialCount = "0"
		}

		tt := []struct {
			name                string
			succeed             bool
			secret              *corev1.Secret
			getWatcher          func(c *kubernetes.Clientset, secret *corev1.Secret) (watch.Interface, error, func())
			normalizeOutputFunc func(referenceOutput []string) []string
		}{
			{
				name:    "regular watcher should fail",
				succeed: false,
				secret:  baseSecret,
				getWatcher: func(c *kubernetes.Clientset, secret *corev1.Secret) (watch.Interface, error, func()) {
					options := metav1.ListOptions{
						ResourceVersion: secret.ResourceVersion,
					}
					w, err := getWatchFunc(c, secret)(options)
					return w, err, noop
				},
				normalizeOutputFunc: noopNormalization,
			},
			{
				name:    "RetryWatcher survives closed watches",
				succeed: true,
				secret:  baseSecret,
				getWatcher: func(c *kubernetes.Clientset, secret *corev1.Secret) (watch.Interface, error, func()) {
					lw := &cache.ListWatch{
						WatchFunc: func(options metav1.ListOptions) (watch.Interface, error) {
							return getWatchFunc(c, secret)(options)
						},
					}
					w, err := watchtools.NewRetryWatcher(secret.ResourceVersion, lw)
					return w, err, func() { <-w.Done() }
				},
				normalizeOutputFunc: noopNormalization,
			},
			{
				name:    "InformerWatcher survives closed watches",
				succeed: true,
				secret:  baseSecret,
				getWatcher: func(c *kubernetes.Clientset, secret *corev1.Secret) (watch.Interface, error, func()) {
					lw := &cache.ListWatch{
						ListFunc: func(options metav1.ListOptions) (runtime.Object, error) {
							return getListFunc(c, secret)(options), nil
						},
						WatchFunc: func(options metav1.ListOptions) (watch.Interface, error) {
							return getWatchFunc(c, secret)(options)
						},
					}
					_, informer, w, done := watchtools.NewIndexerInformerWatcher(lw, &corev1.Secret{})
					cache.WaitForCacheSync(context.TODO().Done(), informer.HasSynced)
					return w, nil, func() { <-done }
				},
				normalizeOutputFunc: normalizeInformerOutputFunc(initialCount),
			},
			{
				name:    "edge: secret without annotations",
				succeed: false,
				secret:  edgeSecret,
				getWatcher: func(c *kubernetes.Clientset, secret *corev1.Secret) (watch.Interface, error, func()) {
					options := metav1.ListOptions{
						ResourceVersion: secret.ResourceVersion,
					}
					w, err := getWatchFunc(c, secret)(options)
					return w, err, noop
				},
				normalizeOutputFunc: noopNormalization,
			},
		}

		for _, tmptc := range tt {
			tc := tmptc // copy for parallel
			t.Run(fmt.Sprintf("%s-%d", tc.name, cfgIdx), func(t *testing.T) {
				t.Parallel()
				c, err := kubernetes.NewForConfig(server.ClientConfig)
				if err != nil {
					t.Fatalf("Failed to create clientset: %v", err)
				}

				secret, err := c.CoreV1().Secrets(tc.secret.Namespace).Create(context.TODO(), tc.secret, metav1.CreateOptions{})
				if err != nil {
					t.Fatalf("Failed to create secret %s/%s: %v", tc.secret.Namespace, tc.secret.Name, err)
				}

				watcher, err, doneFn := tc.getWatcher(c, secret)
				if err != nil {
					t.Fatalf("Failed to create watcher: %v", err)
				}
				defer doneFn()

				var referenceOutput []string
				var output []string
				stopChan := make(chan struct{})
				stoppedChan := make(chan struct{})
				go generateEvents(t, c, secret, &referenceOutput, stopChan, stoppedChan)

				startTime := time.Now()
				ctx, cancel := watchtools.ContextWithOptionalTimeout(context.Background(), timeout)
				defer cancel()
				_, err = watchtools.UntilWithoutRetry(ctx, watcher, func(event watch.Event) (bool, error) {
					s, ok := event.Object.(*corev1.Secret)
					if !ok {
						t.Fatalf("Received non‑Secret object: %#v", event.Object)
					}
					output = append(output, s.Annotations["count"])
					return false, nil
				})
				watchDuration := time.Since(startTime)
				close(stopChan)
				<-stoppedChan

				output = tc.normalizeOutputFunc(output)

				t.Logf("Watch duration: %v; timeout: %v", watchDuration, timeout)

				if err == nil && !tc.succeed {
					t.Fatalf("Watch should have timed out but exited without error")
				}
				if !wait.Interrupted(err) && tc.succeed {
					t.Fatalf("Watch exited with error: %v", err)
				}
				if watchDuration < timeout && tc.succeed {
					t.Fatalf("Watch timed out prematurely after %v, expected %v", watchDuration, timeout)
				}
				if watchDuration >= timeout && !tc.succeed {
					t.Fatalf("Watch succeeded unexpectedly")
				}
				if tc.succeed && !reflect.DeepEqual(referenceOutput, output) {
					t.Fatalf("Reference and real output differ!\nRef:  %#v\nReal: %#v", referenceOutput, output)
				}
			})
		}
	}
	fmt.Println(ctestglobals.EndSeparator)
}

// getHardCodedConfigInfoWatchRestart returns the minimal secret configuration used by the test.
func getHardCodedConfigInfoWatchRestart() ctestglobals.HardcodedConfig {
	return ctestglobals.HardcodedConfig{
		{
			FixtureFileName: "test_fixture.json",
			TestInfo:        []string{"default secret"},
			Field:           "metadata.annotations",
			K8sObjects:      []string{"secrets"},
			HardcodedConfig: corev1.Secret{
				ObjectMeta: metav1.ObjectMeta{
					Annotations: map[string]string{
						"count": "0",
					},
				},
				Data: map[string][]byte{
					"data": []byte("value1\n"),
				},
			},
		},
	}
}
