package apimachinery

import (
	"context"
	"fmt"
	"testing"

	// "k8s.io/apimachinery/pkg/api/meta"
	metav1 "k8s.io/apimachinery/pkg/apis/meta/v1"
	"k8s.io/apimachinery/pkg/apis/meta/v1/unstructured"
	"k8s.io/apimachinery/pkg/runtime/schema"
	"k8s.io/apimachinery/pkg/util/sets"
	"k8s.io/client-go/dynamic"
	"k8s.io/client-go/kubernetes"

	kubeapiservertesting "k8s.io/kubernetes/cmd/kube-apiserver/app/testing"
	"k8s.io/kubernetes/test/integration/framework"

	ctest "k8s.io/kubernetes/test/ctest"
	ctestglobals "k8s.io/kubernetes/test/ctest/ctestglobals"
	ctestutils "k8s.io/kubernetes/test/ctest/utils"
)

type listTestConfig struct {
	Namespaced    bool
	Namespace     string
	LabelSelector string
}

func TestCtestCheckFieldItemsInEmptyList(t *testing.T) {
	// Start API server
	server := kubeapiservertesting.StartTestServerOrDie(t, nil, []string{
		"--runtime-config=api/all=true",
	}, framework.SharedEtcd())
	defer server.TearDownFn()

	clientSet, err := kubernetes.NewForConfig(server.ClientConfig)
	if err != nil {
		t.Fatal(err)
	}
	dynamicClient, err := dynamic.NewForConfig(server.ClientConfig)
	if err != nil {
		t.Fatal(err)
	}

	// --- Dynamic configuration generation ------------------------------------------------
	fmt.Println(ctestglobals.StartSeparator)
	hardcodedConfig := getHardCodedConfigInfoCheckFieldItemsInEmptyList()
	item, found := ctestutils.GetItemByExactTestInfo(hardcodedConfig, "default list test config")
	if !found {
		fmt.Println(ctestglobals.DebugPrefix(), "Failed to find config item by TestInfo")
		t.Fatalf("hardcoded config not found")
	}
	fmt.Println(ctestglobals.DebugPrefix(), "Matched config:", item)
	fmt.Println(ctestglobals.StartExtendModeSeparator)
	cfgObjs, cfgJSON, err := ctest.GenerateEffectiveConfigReturnType[listTestConfig](item, ctest.ExtendOnly)
	if err != nil {
		fmt.Println(ctestglobals.DebugPrefix(), "GenerateEffectiveConfigReturnType error:", err)
		t.Fatalf("config generation failed: %v", err)
	}
	if cfgObjs == nil {
		fmt.Println(ctestglobals.DebugPrefix(), "Skipping test execution. No new configurations generated.")
		return
	}
	fmt.Println(ctestglobals.DebugPrefix(), "New Json Test Configs:", string(cfgJSON))
	fmt.Println(ctestglobals.DebugPrefix(), "Number of test configs:", len(cfgObjs))

	// Append edge‑case configurations
	edgeCases := []listTestConfig{
		{Namespaced: true, Namespace: "", LabelSelector: "non-exist=non-exist"},
		{Namespaced: true, Namespace: "non-exist", LabelSelector: "non-exist!=non-exist"},
	}
	cfgObjs = append(cfgObjs, edgeCases...)
	// -------------------------------------------------------------------------------------

	discoveryGroups, lists, err := clientSet.Discovery().ServerGroupsAndResources()
	if err != nil {
		t.Fatal(err)
	}
	_ = discoveryGroups // unused but retained for parity with original test

	for i, cfg := range cfgObjs {
		fmt.Printf("Running config #%d:\n", i)
		fmt.Println(cfg)

		for _, resources := range lists {
			for _, resource := range resources.APIResources {
				gv, err := schema.ParseGroupVersion(resources.GroupVersion)
				if err != nil {
					t.Fatalf("parse group version error: %v", err)
				}
				gvr := schema.GroupVersionResource{
					Group:    gv.Group,
					Version:  gv.Version,
					Resource: resource.Name,
				}

				if !sets.NewString(resource.Verbs...).Has("list") {
					t.Logf("skip gvr: %s", gvr)
					continue
				}

				var list *unstructured.UnstructuredList
				listOpts := metav1.ListOptions{LabelSelector: cfg.LabelSelector}
				if cfg.Namespaced && resource.Namespaced {
					list, err = dynamicClient.Resource(gvr).Namespace(cfg.Namespace).List(context.Background(), listOpts)
				} else {
					list, err = dynamicClient.Resource(gvr).List(context.Background(), listOpts)
				}
				if err != nil {
					t.Fatalf("list error for %s: %v", gvr, err)
				}
				if list == nil {
					t.Fatalf("gvr: %s, list is nil", gvr)
				}
				// Field `items` in List object should be a zero‑length array when no obj in etcd.
				if list.Items == nil {
					t.Fatalf("gvr: %s, fields items of list is nil", gvr)
				}
				if len(list.Items) > 0 {
					// Use meta.Accessor to get kind for clearer debug, but keep original failure semantics.
					t.Fatalf("gvr: %s, fields items should be a zero‑length array", gvr)
				}
			}
		}
	}
	fmt.Println(ctestglobals.EndSeparator)
}

// getHardCodedConfigInfoCheckFieldItemsInEmptyList returns the baseline configuration
// used by TestCtestCheckFieldItemsInEmptyList. It provides a default ListOptions
// configuration that matches the original test (namespaced resource, non‑existent
// namespace and label selector).
func getHardCodedConfigInfoCheckFieldItemsInEmptyList() ctestglobals.HardcodedConfig {
	return ctestglobals.HardcodedConfig{
		{
			FixtureFileName: "test_fixture.json",
			TestInfo:        []string{"default list test config"},
			Field:           "listOptions",
			K8sObjects: []string{
				"pods", "services", "configmaps", "secrets", "namespaces",
				"persistentvolumes", "persistentvolumeclaims", "jobs", "cronjobs",
				"daemonsets", "deployments", "replicasets", "statefulsets",
			},
			HardcodedConfig: listTestConfig{
				Namespaced:    true,
				Namespace:     "non-exist",
				LabelSelector: "non-exist=non-exist",
			},
		},
	}
}
