package apimachinery

import (
	"context"
	"fmt"
	"testing"
	"time"

	corev1 "k8s.io/api/core/v1"
	// apiequality "k8s.io/apimachinery/pkg/api/equality"
	metav1 "k8s.io/apimachinery/pkg/apis/meta/v1"
	"k8s.io/apimachinery/pkg/fields"
	// "k8s.io/apimachinery/pkg/runtime"
	"k8s.io/apimachinery/pkg/watch"
	"k8s.io/client-go/kubernetes"
	kubeapiservertesting "k8s.io/kubernetes/cmd/kube-apiserver/app/testing"
	"k8s.io/kubernetes/test/integration/framework"

	"k8s.io/apimachinery/pkg/util/uuid"
	ctest "k8s.io/kubernetes/test/ctest"
	ctestglobals "k8s.io/kubernetes/test/ctest/ctestglobals"
	ctestutils "k8s.io/kubernetes/test/ctest/utils"
)

func TestCtestWatchNamespaceEvent(t *testing.T) {
	fmt.Println(ctestglobals.StartExtendModeSeparator)
	fmt.Println(ctestglobals.DebugPrefix(), "Generating dynamic namespace configs")
	hardcoded := getHardCodedConfigInfoNamespace()
	item, found := ctestutils.GetItemByExactTestInfo(hardcoded, "default namespace")
	if !found {
		fmt.Println(ctestglobals.DebugPrefix(), "Failed to find config item by TestInfo")
		t.Skip("no dynamic config found")
		return
	}
	fmt.Println(ctestglobals.DebugPrefix(), "Matched config item:", item)

	configObjs, configJson, err := ctest.GenerateEffectiveConfigReturnType[corev1.Namespace](item, ctest.ExtendOnly)
	if err != nil {
		fmt.Println(ctestglobals.DebugPrefix(), "Failed to generate effective config:", err)
		t.Fatalf("config generation error: %v", err)
	}
	if configObjs == nil {
		fmt.Println(ctestglobals.DebugPrefix(), "Skipping test execution. No new configurations generated.")
		return
	}
	fmt.Println(ctestglobals.DebugPrefix(), "New Json Test Configs:", string(configJson))
	fmt.Println(ctestglobals.DebugPrefix(), "Number of dynamic namespace configs:", len(configObjs))

	timeout := 30 * time.Second
	server := kubeapiservertesting.StartTestServerOrDie(t, nil, nil, framework.SharedEtcd())
	defer server.TearDownFn()
	clientSet, err := kubernetes.NewForConfig(server.ClientConfig)
	if err != nil {
		t.Fatal(err)
	}

	newWatcher := func(ctx context.Context, ns *corev1.Namespace, resourceVersion string) (watch.Interface, error) {
		return clientSet.CoreV1().Namespaces().Watch(ctx, metav1.ListOptions{
			FieldSelector:   fields.OneTermEqualSelector("metadata.name", ns.Name).String(),
			ResourceVersion: resourceVersion,
		})
	}
	newLegacyNSWatcher := func(ctx context.Context, ns *corev1.Namespace, resourceVersion string) (watch.Interface, error) {
		if resourceVersion == "" {
			return clientSet.CoreV1().RESTClient().Get().
				RequestURI(fmt.Sprintf("/api/v1/watch/namespaces/%s", ns.Name)).Watch(ctx)
		}
		return clientSet.CoreV1().RESTClient().Get().
			RequestURI(fmt.Sprintf("/api/v1/watch/namespaces/%s?resourceVersion=%s", ns.Name, resourceVersion)).Watch(ctx)
	}

	type testCase struct {
		name            string
		namespace       *corev1.Namespace
		resourceVersion string
		getWatcher      func(ctx context.Context, ns *corev1.Namespace, rv string) (watch.Interface, error)
	}
	var tt []testCase

	// original static cases
	tt = append(tt, []testCase{
		{
			name:       "watch namespace",
			namespace:  &corev1.Namespace{ObjectMeta: metav1.ObjectMeta{Name: "watch-namespace"}},
			getWatcher: newWatcher,
		},
		{
			name:            "watch namespace with resource version",
			namespace:       &corev1.Namespace{ObjectMeta: metav1.ObjectMeta{Name: "watch-ns-with-rv"}},
			getWatcher:      newWatcher,
			resourceVersion: "0",
		},
		{
			name:       "legacy watch namespace api",
			namespace:  &corev1.Namespace{ObjectMeta: metav1.ObjectMeta{Name: "legacy-watch-ns"}},
			getWatcher: newLegacyNSWatcher,
		},
		{
			name:            "legacy watch namespace api with resource version",
			namespace:       &corev1.Namespace{ObjectMeta: metav1.ObjectMeta{Name: "legacy-watch-ns-with-rv"}},
			getWatcher:      newLegacyNSWatcher,
			resourceVersion: "0",
		},
	}...)

	// dynamic cases derived from fixtures
	for i, cfg := range configObjs {
		// case 1: simple watcher, no resourceVersion
		nsCopy := cfg.DeepCopy()
		nsCopy.Name = "dyn-ns-" + string(uuid.NewUUID())
		tt = append(tt, testCase{
			name:       fmt.Sprintf("dynamic watch namespace %d", i),
			namespace:  nsCopy,
			getWatcher: newWatcher,
		})

		// case 2: with explicit resourceVersion "0"
		nsCopy2 := cfg.DeepCopy()
		nsCopy2.Name = "dyn-ns-rv-" + string(uuid.NewUUID())
		tt = append(tt, testCase{
			name:            fmt.Sprintf("dynamic watch namespace with rv %d", i),
			namespace:       nsCopy2,
			getWatcher:      newWatcher,
			resourceVersion: "0",
		})

		// case 3: legacy watcher, no resourceVersion
		nsCopy3 := cfg.DeepCopy()
		nsCopy3.Name = "dyn-legacy-ns-" + string(uuid.NewUUID())
		tt = append(tt, testCase{
			name:       fmt.Sprintf("dynamic legacy watch namespace %d", i),
			namespace:  nsCopy3,
			getWatcher: newLegacyNSWatcher,
		})

		// edge case: namespace with pre‑existing annotations
		nsAnnot := cfg.DeepCopy()
		nsAnnot.Name = "dyn-annot-ns-" + string(uuid.NewUUID())
		nsAnnot.Annotations = map[string]string{"existing": "val"}
		tt = append(tt, testCase{
			name:       fmt.Sprintf("dynamic watch namespace with existing annotations %d", i),
			namespace:  nsAnnot,
			getWatcher: newWatcher,
		})
	}

	fmt.Println(ctestglobals.DebugPrefix(), "Total test cases to run:", len(tt))
	t.Run("group", func(t *testing.T) {
		for _, tc := range tt {
			tc := tc // capture range variable
			t.Run(tc.name, func(t *testing.T) {
				t.Parallel()
				startTest := time.Now()
				ctx, cancel := context.WithTimeout(context.Background(), timeout)
				defer cancel()

				if tc.namespace.Name == "" {
					t.Fatalf("namespace name is empty, cannot create")
				}
				ns, err := clientSet.CoreV1().Namespaces().Create(ctx, tc.namespace, metav1.CreateOptions{})
				if err != nil {
					t.Fatalf("Failed to create testing namespace %s: %v", tc.namespace.Name, err)
				}
				defer framework.DeleteNamespaceOrDie(clientSet, ns, t)

				watcher, err := tc.getWatcher(ctx, ns, tc.resourceVersion)
				if err != nil {
					t.Fatalf("Failed to create watcher: %v", err)
				}
				defer watcher.Stop()

				t.Logf("start watching namespace %s event", tc.namespace.Name)
				generateAndWatchNamespaceEvent(ctx, t, clientSet, ns, watcher)
				t.Logf("Watch duration: %v", time.Since(startTest))
			})
		}
	})
	fmt.Println(ctestglobals.EndSeparator)
}

func getHardCodedConfigInfoNamespace() ctestglobals.HardcodedConfig {
	return ctestglobals.HardcodedConfig{
		{
			FixtureFileName: "test_fixture.json",
			TestInfo:        []string{"default namespace"},
			Field:           "metadata.name",
			K8sObjects:      []string{"namespaces"},
			HardcodedConfig: corev1.Namespace{
				ObjectMeta: metav1.ObjectMeta{
					Name: "placeholder",
				},
			},
		},
	}
}
