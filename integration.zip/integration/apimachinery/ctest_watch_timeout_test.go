package apimachinery

import (
	"bytes"
	"context"
	"fmt"
	"io"
	// "net/http"
	"net/http/httptest"
	"net/http/httputil"
	"net/url"
	"strings"
	"testing"
	"time"

	"golang.org/x/net/websocket"

	corev1 "k8s.io/api/core/v1"
	metav1 "k8s.io/apimachinery/pkg/apis/meta/v1"
	"k8s.io/apimachinery/pkg/util/uuid"
	"k8s.io/client-go/kubernetes"
	restclient "k8s.io/client-go/rest"
	// "k8s.io/kubectl/pkg/proxy"
	kubectlproxy "k8s.io/kubectl/pkg/proxy"
	kubeapiservertesting "k8s.io/kubernetes/cmd/kube-apiserver/app/testing"
	"k8s.io/kubernetes/test/integration/framework"

	ctest "k8s.io/kubernetes/test/ctest"
	ctestglobals "k8s.io/kubernetes/test/ctest/ctestglobals"
	ctestutils "k8s.io/kubernetes/test/ctest/utils"
)

func TestCtestWebsocketWatchClientTimeout(t *testing.T) {
	fmt.Println(ctestglobals.StartExtendModeSeparator)

	// server setup
	server := kubeapiservertesting.StartTestServerOrDie(t, nil, framework.DefaultTestServerFlags(), framework.SharedEtcd())
	defer server.TearDownFn()

	// -------- Service hard‑coded config ----------
	svcItem, found := ctestutils.GetItemByExactTestInfo(getHardCodedConfigInfoService(), "default service")
	if !found {
		t.Fatalf("default service config not found")
	}
	fmt.Println(ctestglobals.DebugPrefix(), "get default service configs:", svcItem)

	svcObjs, svcJson, err := ctest.GenerateEffectiveConfigReturnType[corev1.ServiceSpec](svcItem, ctest.ExtendOnly)
	if err != nil {
		t.Fatalf("failed to generate service configs: %v", err)
	}
	fmt.Println(ctestglobals.DebugPrefix(), "New Json Service Configs:", string(svcJson))
	if svcObjs == nil {
		fmt.Println(ctestglobals.DebugPrefix(), "Skipping test execution. No new service configurations generated.")
		return
	}
	// -------- ConfigMap hard‑coded config ----------
	cmItem, found := ctestutils.GetItemByExactTestInfo(getHardCodedConfigInfoConfigMap(), "default configmap")
	if !found {
		t.Fatalf("default configmap config not found")
	}
	fmt.Println(ctestglobals.DebugPrefix(), "get default configmap configs:", cmItem)

	cmObjs, cmJson, err := ctest.GenerateEffectiveConfigReturnType[corev1.ConfigMap](cmItem, ctest.ExtendOnly)
	if err != nil {
		t.Fatalf("failed to generate configmap configs: %v", err)
	}
	fmt.Println(ctestglobals.DebugPrefix(), "New Json ConfigMap Configs:", string(cmJson))
	if cmObjs == nil {
		fmt.Println(ctestglobals.DebugPrefix(), "Skipping test execution. No new configmap configurations generated.")
		return
	}

	// clientset
	clientset, err := kubernetes.NewForConfig(server.ClientConfig)
	if err != nil {
		t.Fatal(err)
	}

	// iterate over generated service specs (could be multiple)
	for i, svcSpec := range svcObjs {
		// generate unique names
		svcName := fmt.Sprintf("svc-%s-%d", string(uuid.NewUUID()), i)
		cmName := fmt.Sprintf("cm-%s-%d", string(uuid.NewUUID()), i)

		// create Service
		svc := &corev1.Service{
			ObjectMeta: metav1.ObjectMeta{
				Name:      svcName,
				Namespace: "default",
			},
			Spec: svcSpec,
		}
		if _, err := clientset.CoreV1().Services("default").Create(context.TODO(), svc, metav1.CreateOptions{}); err != nil {
			t.Fatalf("failed to create service: %v", err)
		}

		// create ConfigMap (use first generated configmap as template)
		cmTemplate := cmObjs[0]
		cm := &corev1.ConfigMap{
			ObjectMeta: metav1.ObjectMeta{
				Name:      cmName,
				Namespace: "default",
			},
			Data: cmTemplate.Data,
		}
		if _, err := clientset.CoreV1().ConfigMaps("default").Create(context.TODO(), cm, metav1.CreateOptions{}); err != nil {
			t.Fatalf("failed to create configmap: %v", err)
		}

		// testcases (original + edge)
		testcases := []struct {
			name         string
			path         string
			timeout      time.Duration
			expectResult string
		}{
			{
				name:         "configmaps",
				path:         "/api/v1/configmaps?watch=true&timeoutSeconds=5",
				timeout:      10 * time.Second,
				expectResult: fmt.Sprintf(`"name":"%s"`, cmName),
			},
			{
				name:         "services",
				path:         "/api/v1/services?watch=true&timeoutSeconds=5",
				timeout:      10 * time.Second,
				expectResult: fmt.Sprintf(`"name":"%s"`, svcName),
			},
			{
				name:         "configmaps-long",
				path:         "/api/v1/configmaps?watch=true&timeoutSeconds=10",
				timeout:      20 * time.Second,
				expectResult: fmt.Sprintf(`"name":"%s"`, cmName),
			},
		}

		for _, tc := range testcases {
			t.Run(tc.name, func(t *testing.T) {
				u, err := url.Parse(server.ClientConfig.Host + tc.path)
				if err != nil {
					t.Fatal(err)
				}
				wsc, err := websocketConfig(u, server.ClientConfig, nil)
				if err != nil {
					t.Fatal(err)
				}
				wsConn, err := websocket.DialConfig(wsc)
				if err != nil {
					t.Fatal(err)
				}
				defer wsConn.Close()

				resultCh := make(chan string)
				go func() {
					defer close(resultCh)
					buf := &bytes.Buffer{}
					for {
						var msg []byte
						if err := websocket.Message.Receive(wsConn, &msg); err != nil {
							if err == io.EOF {
								resultCh <- buf.String()
								return
							}
							if !t.Failed() {
								t.Errorf("Failed to read from websocket %v", err)
							}
							return
						}
						if len(msg) == 0 {
							t.Logf("zero-length message")
							continue
						}
						t.Logf("Read %v %v", len(msg), string(msg))
						buf.Write(msg)
					}
				}()

				select {
				case resultString := <-resultCh:
					if !strings.Contains(resultString, tc.expectResult) {
						t.Fatalf("Unexpected result:\n%s", resultString)
					}
				case <-time.After(tc.timeout):
					t.Fatalf("hit timeout before connection closed")
				}
			})
		}
	}

	// reverse‑proxy sub‑test (unchanged logic, but uses the same config generation)
	t.Run("reverse proxy", func(t *testing.T) {
		u, _ := url.Parse(server.ClientConfig.Host)
		proxy := httputil.NewSingleHostReverseProxy(u)
		proxy.FlushInterval = -1

		transport, err := restclient.TransportFor(server.ClientConfig)
		if err != nil {
			t.Fatal(err)
		}
		proxy.Transport = transport

		proxyServer := httptest.NewServer(proxy)
		defer proxyServer.Close()

		t.Logf("client to %s, backend at %s", proxyServer.URL, server.ClientConfig.Host)
		testWatchClientTimeouts(t, &restclient.Config{Host: proxyServer.URL})
	})

	// kubectl‑proxy sub‑test (unchanged logic, but uses the same config generation)
	t.Run("kubectl proxy", func(t *testing.T) {
		kubectlProxyServer, err := kubectlproxy.NewServer("", "/", "/static/", nil, server.ClientConfig, 0, false)
		if err != nil {
			t.Fatal(err)
		}
		kubectlProxyListener, err := kubectlProxyServer.Listen("", 0)
		if err != nil {
			t.Fatal(err)
		}
		defer kubectlProxyListener.Close()
		go kubectlProxyServer.ServeOnListener(kubectlProxyListener)

		t.Logf("client to %s, backend at %s", kubectlProxyListener.Addr().String(), server.ClientConfig.Host)
		testWatchClientTimeouts(t, &restclient.Config{Host: "http://" + kubectlProxyListener.Addr().String()})
	})

	fmt.Println(ctestglobals.EndSeparator)
}

// ---------- Hard‑coded config helpers ----------
func getHardCodedConfigInfoService() ctestglobals.HardcodedConfig {
	return ctestglobals.HardcodedConfig{
		{
			FixtureFileName: "test_fixture.json",
			TestInfo:        []string{"default service"},
			Field:           "spec",
			K8sObjects:      []string{"services"},
			HardcodedConfig: corev1.ServiceSpec{
				Ports: []corev1.ServicePort{{Name: "http", Port: 80}},
			},
		},
	}
}

func getHardCodedConfigInfoConfigMap() ctestglobals.HardcodedConfig {
	return ctestglobals.HardcodedConfig{
		{
			FixtureFileName: "test_fixture.json",
			TestInfo:        []string{"default configmap"},
			Field:           "metadata",
			K8sObjects:      []string{"configmaps"},
			HardcodedConfig: corev1.ConfigMap{
				Data: map[string]string{
					"data-1": "value-1",
					"data-2": "value-2",
					"data-3": "value-3",
				},
			},
		},
	}
}
