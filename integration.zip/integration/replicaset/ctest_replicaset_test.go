package replicaset

import (
	// "context"
	"fmt"
	"reflect"
	// "strings"
	"testing"
	// "time"

	apps "k8s.io/api/apps/v1"
	v1 "k8s.io/api/core/v1"
	// "k8s.io/apimachinery/pkg/api/errors"
	metav1 "k8s.io/apimachinery/pkg/apis/meta/v1"
	// "k8s.io/apimachinery/pkg/labels"
	// "k8s.io/apimachinery/pkg/util/uuid"
	"k8s.io/apimachinery/pkg/util/wait"
	// "k8s.io/client-go/informers"
	// clientset "k8s.io/client-go/kubernetes"
	// appsclient "k8s.io/client-go/kubernetes/typed/apps/v1"
	// typedv1 "k8s.io/client-go/kubernetes/typed/core/v1"
	// restclient "k8s.io/client-go/rest"
	// "k8s.io/client-go/tools/cache"
	// "k8s.io/client-go/util/retry"
	// featuregatetesting "k8s.io/component-base/featuregate/testing"
	// kubeapiservertesting "k8s.io/kubernetes/cmd/kube-apiserver/app/testing"
	// "k8s.io/kubernetes/pkg/api/v1/pod"
	// "k8s.io/kubernetes/pkg/apis/core"
	// "k8s.io/kubernetes/pkg/controller/replicaset"
	// "k8s.io/kubernetes/pkg/features"
	"k8s.io/kubernetes/test/integration/framework"
	// testutil "k8s.io/kubernetes/test/utils"
	// "k8s.io/kubernetes/test/utils/ktesting"
	"k8s.io/utils/ptr"

	ctest "k8s.io/kubernetes/test/ctest"
	ctestglobals "k8s.io/kubernetes/test/ctest/ctestglobals"
	ctestutils "k8s.io/kubernetes/test/ctest/utils"
)

/* -------------------------------------------------------------------------- */
/* Modified test: TestAdoption -> TestCtestAdoption with edge cases and dynamic   */
/* configuration handling.                                                      */
/* -------------------------------------------------------------------------- */

func TestCtestAdoption(t *testing.T) {
	// ----------------------------------------------------------------------
	// 1. Load hard‑coded base ReplicaSet configuration (used for dynamic
	//    extension/override in the loop below).
	// ----------------------------------------------------------------------
	fmt.Println(ctestglobals.StartSeparator)
	hardConfig := getHardCodedConfigInfoAdoption()
	item, found := ctestutils.GetItemByExactTestInfo(hardConfig, "default replicaSet")
	if !found {
		fmt.Println(ctestglobals.DebugPrefix(), "Failed to find hard‑coded config for adoption test")
		t.Fatalf("Hard‑coded config not found")
	}
	fmt.Println(ctestglobals.DebugPrefix(), "Matched config item:", item)

	// ----------------------------------------------------------------------
	// 2. Generate effective config objects.  We use Union mode so that any
	//    overrides from fixtures are merged with the hard‑coded defaults.
	// ----------------------------------------------------------------------
	configObjs, configJson, err := ctest.GenerateEffectiveConfigReturnType[apps.ReplicaSetSpec](item, ctest.Union)
	if err != nil {
		fmt.Println(ctestglobals.DebugPrefix(), "Failed to generate config:", err)
		t.Fatalf("GenerateEffectiveConfigReturnType failed: %v", err)
	}
	if configObjs == nil {
		fmt.Println(ctestglobals.DebugPrefix(), "Skipping test execution. No new configurations generated.")
		fmt.Println(ctestglobals.EndSeparator)
		return
	}
	fmt.Println(ctestglobals.DebugPrefix(), "New Json Test Configs:", string(configJson))
	fmt.Println(ctestglobals.DebugPrefix(), "Number of config objects:", len(configObjs))

	// ----------------------------------------------------------------------
	// 3. Base test cases from original test plus additional edge cases.
	// ----------------------------------------------------------------------
	baseCases := []struct {
		name                    string
		existingOwnerReferences func(rs *apps.ReplicaSet) []metav1.OwnerReference
		expectedOwnerReferences func(rs *apps.ReplicaSet) []metav1.OwnerReference
	}{
		{
			"pod refers rs as an owner, not a controller",
			func(rs *apps.ReplicaSet) []metav1.OwnerReference {
				return []metav1.OwnerReference{{UID: rs.UID, Name: rs.Name, APIVersion: "apps/v1", Kind: "ReplicaSet"}}
			},
			func(rs *apps.ReplicaSet) []metav1.OwnerReference {
				return []metav1.OwnerReference{{UID: rs.UID, Name: rs.Name, APIVersion: "apps/v1", Kind: "ReplicaSet", Controller: ptr.To(true), BlockOwnerDeletion: ptr.To(true)}}
			},
		},
		{
			"pod doesn't have owner references",
			func(rs *apps.ReplicaSet) []metav1.OwnerReference {
				return []metav1.OwnerReference{}
			},
			func(rs *apps.ReplicaSet) []metav1.OwnerReference {
				return []metav1.OwnerReference{{UID: rs.UID, Name: rs.Name, APIVersion: "apps/v1", Kind: "ReplicaSet", Controller: ptr.To(true), BlockOwnerDeletion: ptr.To(true)}}
			},
		},
		{
			"pod refers rs as a controller",
			func(rs *apps.ReplicaSet) []metav1.OwnerReference {
				return []metav1.OwnerReference{{UID: rs.UID, Name: rs.Name, APIVersion: "apps/v1", Kind: "ReplicaSet", Controller: ptr.To(true)}}
			},
			func(rs *apps.ReplicaSet) []metav1.OwnerReference {
				return []metav1.OwnerReference{{UID: rs.UID, Name: rs.Name, APIVersion: "apps/v1", Kind: "ReplicaSet", Controller: ptr.To(true)}}
			},
		},
		{
			"pod refers other rs as the controller, refers the rs as an owner",
			func(rs *apps.ReplicaSet) []metav1.OwnerReference {
				return []metav1.OwnerReference{
					{UID: "1", Name: "anotherRS", APIVersion: "apps/v1", Kind: "ReplicaSet", Controller: ptr.To(true)},
					{UID: rs.UID, Name: rs.Name, APIVersion: "apps/v1", Kind: "ReplicaSet"},
				}
			},
			func(rs *apps.ReplicaSet) []metav1.OwnerReference {
				return []metav1.OwnerReference{
					{UID: "1", Name: "anotherRS", APIVersion: "apps/v1", Kind: "ReplicaSet", Controller: ptr.To(true)},
					{UID: rs.UID, Name: rs.Name, APIVersion: "apps/v1", Kind: "ReplicaSet"},
				}
			},
		},
		// ------------------------------------------------------------------
		// Edge cases added below
		// ------------------------------------------------------------------
		{
			"pod has multiple controller owners",
			func(rs *apps.ReplicaSet) []metav1.OwnerReference {
				return []metav1.OwnerReference{
					{UID: "c1", Name: "cRS1", APIVersion: "apps/v1", Kind: "ReplicaSet", Controller: ptr.To(true)},
					{UID: "c2", Name: "cRS2", APIVersion: "apps/v1", Kind: "ReplicaSet", Controller: ptr.To(true)},
				}
			},
			func(rs *apps.ReplicaSet) []metav1.OwnerReference {
				// No adoption should happen because a controller already exists
				return []metav1.OwnerReference{
					{UID: "c1", Name: "cRS1", APIVersion: "apps/v1", Kind: "ReplicaSet", Controller: ptr.To(true)},
					{UID: "c2", Name: "cRS2", APIVersion: "apps/v1", Kind: "ReplicaSet", Controller: ptr.To(true)},
				}
			},
		},
		{
			"pod has owner reference with empty UID",
			func(rs *apps.ReplicaSet) []metav1.OwnerReference {
				return []metav1.OwnerReference{{UID: "", Name: rs.Name, APIVersion: "apps/v1", Kind: "ReplicaSet"}}
			},
			func(rs *apps.ReplicaSet) []metav1.OwnerReference {
				// Adoption should not occur due to invalid UID
				return []metav1.OwnerReference{{UID: "", Name: rs.Name, APIVersion: "apps/v1", Kind: "ReplicaSet"}}
			},
		},
		{
			"pod has owner reference with unknown kind",
			func(rs *apps.ReplicaSet) []metav1.OwnerReference {
				return []metav1.OwnerReference{{UID: rs.UID, Name: rs.Name, APIVersion: "apps/v1", Kind: "UnknownKind"}}
			},
			func(rs *apps.ReplicaSet) []metav1.OwnerReference {
				// No adoption because kind is not ReplicaSet
				return []metav1.OwnerReference{{UID: rs.UID, Name: rs.Name, APIVersion: "apps/v1", Kind: "UnknownKind"}}
			},
		},
		{
			"pod refers other object as controller and has nil pointer fields",
			func(rs *apps.ReplicaSet) []metav1.OwnerReference {
				return []metav1.OwnerReference{
					{UID: "other", Name: "otherObj", APIVersion: "apps/v1", Kind: "Deployment", Controller: ptr.To(true)},
					{UID: rs.UID, Name: rs.Name, APIVersion: "apps/v1", Kind: "ReplicaSet", Controller: nil, BlockOwnerDeletion: nil},
				}
			},
			func(rs *apps.ReplicaSet) []metav1.OwnerReference {
				// Should remain unchanged
				return []metav1.OwnerReference{
					{UID: "other", Name: "otherObj", APIVersion: "apps/v1", Kind: "Deployment", Controller: ptr.To(true)},
					{UID: rs.UID, Name: rs.Name, APIVersion: "apps/v1", Kind: "ReplicaSet", Controller: nil, BlockOwnerDeletion: nil},
				}
			},
		},
	}

	// ----------------------------------------------------------------------
	// 4. Execute each test case against each generated ReplicaSetSpec variant.
	// ----------------------------------------------------------------------
	for cfgIdx, cfg := range configObjs {
		fmt.Printf("Running config object #%d\n", cfgIdx)
		fmt.Println(cfg)

		for i, tc := range baseCases {
			t.Run(fmt.Sprintf("%s cfg#%d", tc.name, cfgIdx), func(t *testing.T) {
				// Setup test environment
				tCtx, closeFn, rm, informers, clientSet := rmSetup(t)
				defer closeFn()

				ns := framework.CreateNamespaceOrDie(clientSet, fmt.Sprintf("rs-adoption-%d-%d", cfgIdx, i), t)
				defer framework.DeleteNamespaceOrDie(clientSet, ns, t)

				rsClient := clientSet.AppsV1().ReplicaSets(ns.Name)
				podClient := clientSet.CoreV1().Pods(ns.Name)

				// Create ReplicaSet using the dynamic spec (override default name/replicas)
				rs := &apps.ReplicaSet{
					ObjectMeta: metav1.ObjectMeta{
						Name:      fmt.Sprintf("rs-%d-%d", cfgIdx, i),
						Namespace: ns.Name,
					},
					Spec: cfg,
				}
				// Ensure at least one replica for the adoption test
				if rs.Spec.Replicas == nil || *rs.Spec.Replicas == 0 {
					one := int32(1)
					rs.Spec.Replicas = &one
				}
				_, err := rsClient.Create(tCtx, rs, metav1.CreateOptions{})
				if err != nil {
					t.Fatalf("Failed to create ReplicaSet: %v", err)
				}

				// Create pod with the ownerReferences defined by the testcase
				podName := fmt.Sprintf("pod-%d-%d", cfgIdx, i)
				pod := newMatchingPod(podName, ns.Name)
				pod.OwnerReferences = tc.existingOwnerReferences(rs)

				_, err = podClient.Create(tCtx, pod, metav1.CreateOptions{})
				if err != nil {
					t.Fatalf("Failed to create Pod: %v", err)
				}

				// Run controller
				stopControllers := runControllerAndInformers(t, rm, informers, 1)
				defer stopControllers()

				// Verify ownerReferences after controller reconciliation
				if err := wait.PollImmediate(interval, timeout, func() (bool, error) {
					updatedPod, err := podClient.Get(tCtx, pod.Name, metav1.GetOptions{})
					if err != nil {
						return false, err
					}
					exp := tc.expectedOwnerReferences(rs)
					if reflect.DeepEqual(exp, updatedPod.OwnerReferences) {
						return true, nil
					}
					t.Logf("ownerReferences mismatch, expected %v, got %v", exp, updatedPod.OwnerReferences)
					return false, nil
				}); err != nil {
					t.Fatalf("test %q failed: %v", tc.name, err)
				}
			})
		}
	}
	fmt.Println(ctestglobals.EndSeparator)
}

/* -------------------------------------------------------------------------- */
/* Helper: hard‑coded config for ReplicaSet spec (used by dynamic generation).  */
/* -------------------------------------------------------------------------- */

func getHardCodedConfigInfoAdoption() ctestglobals.HardcodedConfig {
	return ctestglobals.HardcodedConfig{
		{
			FixtureFileName: "test_fixture.json",
			TestInfo:        []string{"default replicaSet"},
			Field:           "spec",
			K8sObjects:      []string{"replicasets"},
			HardcodedConfig: apps.ReplicaSetSpec{
				Selector: &metav1.LabelSelector{
					MatchLabels: labelMap(),
				},
				Replicas: func() *int32 { i := int32(1); return &i }(),
				Template: v1.PodTemplateSpec{
					ObjectMeta: metav1.ObjectMeta{
						Labels: labelMap(),
					},
					Spec: v1.PodSpec{
						Containers: []v1.Container{
							{
								Name:  "dynamic-container",
								Image: "k8s.gcr.io/pause:3.9",
							},
						},
						RestartPolicy: v1.RestartPolicyNever,
					},
				},
			},
		},
	}
}

/* -------------------------------------------------------------------------- */
/* The remainder of the original file (helpers, other tests, etc.) is unchanged.*/
/* -------------------------------------------------------------------------- */

// rmSetup, rmSimpleSetup, runControllerAndInformers, waitToObservePods,
// createRSsPods, waitRSStable, waitForTerminatingPods,
// waitForTerminatingPods, scaleRS, updatePod, updatePodStatus,
// getPods, updateRS, testPodControllerRefPatch, setPodsReadyCondition,
// testScalingUsingScaleSubresource, and all other tests remain unchanged.
// --------------------------------------------------------------------------
