package auth

import (
	// "context"
	"fmt"
	"os"
	"testing"
	"time"

	utiltesting "k8s.io/client-go/util/testing"

	metav1 "k8s.io/apimachinery/pkg/apis/meta/v1"
	"k8s.io/apiserver/pkg/authentication/authenticator"
	// clientset "k8s.io/client-go/kubernetes"
	restclient "k8s.io/client-go/rest"
	"k8s.io/controller-manager/pkg/clientbuilder"
	"k8s.io/kubernetes/cmd/kube-apiserver/app/options"
	kubeoptions "k8s.io/kubernetes/pkg/kubeapiserver/options"
	"k8s.io/kubernetes/test/integration/framework"
	"k8s.io/kubernetes/test/utils/ktesting"

	ctest "k8s.io/kubernetes/test/ctest"
	ctestglobals "k8s.io/kubernetes/test/ctest/ctestglobals"
	ctestutils "k8s.io/kubernetes/test/ctest/utils"
)

type clientBuilderConfig struct {
	Issuer             string
	Audiences          []string
	MaxExpiration      time.Duration
	Expiration         int64
	Leeway             int
	Namespace          string
	ServiceAccountName string
}

func TestCtestDynamicClientBuilder(t *testing.T) {
	fmt.Println(ctestglobals.StartSeparator)

	// Load hard‑coded config and allow extensions / overrides.
	hardcoded := getHardCodedConfigInfoDynamicClientBuilder()
	item, found := ctestutils.GetItemByExactTestInfo(hardcoded, "default dynamic client builder")
	if !found {
		t.Fatalf("hardcoded config not found")
	}
	fmt.Println(ctestglobals.DebugPrefix(), "matched config item:", item)

	configObjs, configJSON, err := ctest.GenerateEffectiveConfigReturnType[clientBuilderConfig](item, ctest.ExtendOnly)
	if err != nil {
		t.Fatalf("failed to generate config: %v", err)
	}
	if configObjs == nil {
		fmt.Println(ctestglobals.DebugPrefix(), "Skipping test execution. No new configurations generated.")
		fmt.Println(ctestglobals.EndSeparator)
		return
	}
	fmt.Println(ctestglobals.DebugPrefix(), "New Json Test Configs:", string(configJSON))
	fmt.Println(ctestglobals.DebugPrefix(), "Number of test cases:", len(configObjs))

	// Add edge / invalid cases manually.
	edgeCases := []clientBuilderConfig{
		{
			Issuer:             "",
			Audiences:          []string{"api"},
			MaxExpiration:      time.Hour,
			Expiration:         0,
			Leeway:             0,
			Namespace:          "default",
			ServiceAccountName: "dt",
		},
		{
			Issuer:             "https://invalid.example.com",
			Audiences:          []string{},
			MaxExpiration:      time.Hour * 24,
			Expiration:         1<<31 - 1,
			Leeway:             -1,
			Namespace:          "default",
			ServiceAccountName: "dt",
		},
	}
	configObjs = append(configObjs, edgeCases...)

	for i, cfg := range configObjs {
		fmt.Printf("Running %d th test case.\n", i)
		fmt.Println(cfg)

		tmpfile, err := os.CreateTemp("/tmp", "key")
		if err != nil {
			t.Fatalf("create temp file failed: %v", err)
		}
		defer utiltesting.CloseAndRemove(t, tmpfile)

		if err = os.WriteFile(tmpfile.Name(), []byte(ecdsaPrivateKey), 0666); err != nil {
			t.Fatalf("write file %s failed: %v", tmpfile.Name(), err)
		}

		iss := cfg.Issuer
		if iss == "" {
			iss = "https://foo.bar.example.com"
		}
		aud := authenticator.Audiences(cfg.Audiences)
		if len(aud) == 0 {
			aud = authenticator.Audiences{"api"}
		}
		maxExpiration := cfg.MaxExpiration
		if maxExpiration == 0 {
			maxExpiration = time.Hour
		}

		tCtx := ktesting.Init(t)
		baseClient, baseConfig, tearDownFn := framework.StartTestServer(tCtx, t, framework.TestServerSetup{
			ModifyServerRunOptions: func(opts *options.ServerRunOptions) {
				opts.ServiceAccountSigningKeyFile = tmpfile.Name()
				opts.ServiceAccountTokenMaxExpiration = maxExpiration
				if opts.Authentication == nil {
					opts.Authentication = &kubeoptions.BuiltInAuthenticationOptions{}
				}
				opts.Authentication.APIAudiences = aud
				if opts.Authentication.ServiceAccounts == nil {
					opts.Authentication.ServiceAccounts = &kubeoptions.ServiceAccountAuthenticationOptions{}
				}
				opts.Authentication.ServiceAccounts.Issuers = []string{iss}
				opts.Authentication.ServiceAccounts.KeyFiles = []string{tmpfile.Name()}
				opts.Authorization.Modes = []string{"AlwaysAllow"}
			},
		})
		defer tearDownFn()

		exp := cfg.Expiration
		if exp == 0 {
			exp = 600
		}
		leeway := cfg.Leeway
		if leeway == 0 {
			leeway = 99
		}
		ns := cfg.Namespace
		if ns == "" {
			ns = "default"
		}
		saName := cfg.ServiceAccountName
		if saName == "" {
			saName = "dt"
		}
		clientBuilder := clientbuilder.NewTestDynamicClientBuilder(
			restclient.AnonymousClientConfig(baseConfig),
			baseClient.CoreV1(),
			ns, exp, leeway)

		dymClient, err := clientBuilder.Client(saName)
		if err != nil {
			t.Fatalf("build client via dynamic client builder failed: %v", err)
		}

		if err = testClientBuilder(dymClient, ns, saName); err != nil {
			t.Fatalf("dynamic client get resources failed before deleting sa: %v", err)
		}

		// Trigger token rotation by deleting the service account used by the dynamic client.
		if err = dymClient.CoreV1().ServiceAccounts(ns).Delete(tCtx, saName, metav1.DeleteOptions{}); err != nil {
			t.Fatalf("delete service account %s failed: %v", saName, err)
		}
		time.Sleep(10 * time.Second)

		if err = testClientBuilder(dymClient, ns, saName); err != nil {
			t.Fatalf("dynamic client get resources failed after deleting sa: %v", err)
		}
	}
	fmt.Println(ctestglobals.EndSeparator)
}

func getHardCodedConfigInfoDynamicClientBuilder() ctestglobals.HardcodedConfig {
	return ctestglobals.HardcodedConfig{{
		FixtureFileName: "test_fixture.json",
		TestInfo:        []string{"default dynamic client builder"},
		Field:           "clientBuilderConfig",
		K8sObjects:      []string{},
		HardcodedConfig: clientBuilderConfig{
			Issuer:             "https://foo.bar.example.com",
			Audiences:          []string{"api"},
			MaxExpiration:      time.Hour,
			Expiration:         600,
			Leeway:             99,
			Namespace:          "default",
			ServiceAccountName: "dt",
		},
	}}
}
