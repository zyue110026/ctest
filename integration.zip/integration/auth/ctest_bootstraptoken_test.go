package auth

import (
	// "bytes"
	"fmt"
	"io"
	"net/http"
	"testing"
	"time"

	"k8s.io/api/core/v1"
	metav1 "k8s.io/apimachinery/pkg/apis/meta/v1"
	// "k8s.io/apimachinery/pkg/labels"
	"k8s.io/apiserver/pkg/authentication/group"
	"k8s.io/apiserver/pkg/authentication/request/bearertoken"
	"k8s.io/client-go/rest"
	bootstrapapi "k8s.io/cluster-bootstrap/token/api"
	"k8s.io/kubernetes/cmd/kube-apiserver/app/options"
	"k8s.io/kubernetes/pkg/controlplane"
	"k8s.io/kubernetes/plugin/pkg/auth/authenticator/token/bootstrap"
	"k8s.io/kubernetes/test/integration"
	"k8s.io/kubernetes/test/integration/framework"
	"k8s.io/kubernetes/test/utils/ktesting"

	ctest "k8s.io/kubernetes/test/ctest"
	ctestglobals "k8s.io/kubernetes/test/ctest/ctestglobals"
	ctestutils "k8s.io/kubernetes/test/ctest/utils"
)

// TestCtestBootstrapTokenAuth validates bootstrap token authentication using
// dynamically generated secret configurations and includes edge‑case scenarios.
func TestCtestBootstrapTokenAuth(t *testing.T) {
	fmt.Println(ctestglobals.StartSeparator)

	// Retrieve hard‑coded secret definitions.
	hc := getHardCodedConfigInfoBootstrapToken()
	item, found := ctestutils.GetItemByExactTestInfo(hc, "bootstrap token test scenarios")
	if !found {
		fmt.Println(ctestglobals.DebugPrefix(), "Failed to find config item by TestInfo")
		t.Fatalf("hardcoded config not found")
	}
	fmt.Println(ctestglobals.DebugPrefix(), "get default configs:", item)
	fmt.Println(ctestglobals.StartOverrideModeSeparator)

	// Generate effective secret objects (override mode to allow test‑specific values).
	secretObjs, secretJSON, err := ctest.GenerateEffectiveConfigReturnType[v1.Secret](item, ctest.OverrideOnly)
	if err != nil {
		fmt.Println(ctestglobals.DebugPrefix(), "Failed to get matched fixtures: %v", err)
		t.Fatalf("GenerateEffectiveConfigReturnType error: %v", err)
	}
	if secretObjs == nil {
		fmt.Println(ctestglobals.DebugPrefix(), "Skipping test execution. No new configurations generated.")
		return
	}
	fmt.Println(ctestglobals.DebugPrefix(), "New Json Test Configs:", string(secretJSON))
	fmt.Println(ctestglobals.DebugPrefix(), "Number of test cases:", len(secretObjs))

	// Static request definition used for all cases.
	request := struct {
		verb string
		url  string
	}{"GET", path("pods", "", "")}

	for i, sec := range secretObjs {
		fmt.Printf("Running %d th test case.\n", i)
		fmt.Println(sec)

		// Determine expected status based on secret contents.
		validID := string(sec.Data[bootstrapapi.BootstrapTokenIDKey]) != ""
		validSecret := string(sec.Data[bootstrapapi.BootstrapTokenSecretKey]) != ""
		usageAuth := string(sec.Data[bootstrapapi.BootstrapTokenUsageAuthentication]) == "true"
		expirationRaw, hasExp := sec.Data[bootstrapapi.BootstrapTokenExpirationKey]
		expValid := true
		if hasExp {
			if t, err := time.Parse(time.RFC3339, string(expirationRaw)); err != nil || t.Before(time.Now().UTC()) {
				expValid = false
			}
		}
		expect200 := validID && validSecret && usageAuth && expValid

		expectedCodes := integration.Code401
		if expect200 {
			expectedCodes = integration.Code200
		}

		// Begin sub‑test.
		t.Run(fmt.Sprintf("dynamic-secret-%d", i), func(t *testing.T) {
			tCtx := ktesting.Init(t)
			authenticator := group.NewAuthenticatedGroupAdder(bearertoken.New(bootstrap.NewTokenAuthenticator(bootstrapSecrets{&sec})))

			kubeClient, kubeConfig, tearDownFn := framework.StartTestServer(tCtx, t, framework.TestServerSetup{
				ModifyServerRunOptions: func(opts *options.ServerRunOptions) {
					opts.Authorization.Modes = []string{"AlwaysAllow"}
				},
				ModifyServerConfig: func(config *controlplane.Config) {
					config.ControlPlane.Generic.Authentication.Authenticator = authenticator
				},
			})
			defer tearDownFn()

			ns := framework.CreateNamespaceOrDie(kubeClient, "auth-bootstrap-token", t)
			defer framework.DeleteNamespaceOrDie(kubeClient, ns, t)

			transport, err := rest.TransportFor(kubeConfig)
			if err != nil {
				t.Fatal(err)
			}

			token := fmt.Sprintf("%s.%s", sec.Data[bootstrapapi.BootstrapTokenIDKey], sec.Data[bootstrapapi.BootstrapTokenSecretKey])
			req, err := http.NewRequest(request.verb, kubeConfig.Host+request.url, nil)
			if err != nil {
				t.Fatalf("unexpected error: %v", err)
			}
			req.Header.Set("Authorization", fmt.Sprintf("Bearer %s", token))

			resp, err := transport.RoundTrip(req)
			if err != nil {
				t.Fatalf("unexpected error: %v", err)
			}
			defer resp.Body.Close()
			b, _ := io.ReadAll(resp.Body)

			if _, ok := expectedCodes[resp.StatusCode]; !ok {
				t.Errorf("Expected status one of %v, but got %v", expectedCodes, resp.StatusCode)
				t.Errorf("Body: %v", string(b))
			}
		})
	}
	fmt.Println(ctestglobals.EndSeparator)
}

// getHardCodedConfigInfoBootstrapToken provides hard‑coded secret configurations
// used for dynamic test generation.
func getHardCodedConfigInfoBootstrapToken() ctestglobals.HardcodedConfig {
	validID := "token1"
	validSecret := "validtokensecret"
	expiredTime := time.Now().UTC().Add(-time.Hour).Format(time.RFC3339)
	futureTime := time.Now().UTC().Add(time.Hour).Format(time.RFC3339)

	return ctestglobals.HardcodedConfig{
		{
			FixtureFileName: "test_fixture.json",
			TestInfo:        []string{"bootstrap token test scenarios"},
			Field:           "data",
			K8sObjects:      []string{"secrets"},
			HardcodedConfig: v1.Secret{
				ObjectMeta: metav1.ObjectMeta{
					Namespace: metav1.NamespaceSystem,
					Name:      bootstrapapi.BootstrapTokenSecretPrefix,
				},
				Type: v1.SecretTypeBootstrapToken,
				Data: map[string][]byte{
					bootstrapapi.BootstrapTokenIDKey:               []byte(validID),
					bootstrapapi.BootstrapTokenSecretKey:           []byte(validSecret),
					bootstrapapi.BootstrapTokenUsageAuthentication: []byte("true"),
				},
			},
		},
		{
			FixtureFileName: "test_fixture.json",
			TestInfo:        []string{"bootstrap token test scenarios"},
			Field:           "data",
			K8sObjects:      []string{"secrets"},
			HardcodedConfig: v1.Secret{
				ObjectMeta: metav1.ObjectMeta{
					Namespace: metav1.NamespaceSystem,
					Name:      bootstrapapi.BootstrapTokenSecretPrefix,
				},
				Type: v1.SecretTypeBootstrapToken,
				Data: map[string][]byte{
					bootstrapapi.BootstrapTokenIDKey:               []byte(validID),
					bootstrapapi.BootstrapTokenSecretKey:           []byte("invalid"),
					bootstrapapi.BootstrapTokenUsageAuthentication: []byte("true"),
				},
			},
		},
		{
			FixtureFileName: "test_fixture.json",
			TestInfo:        []string{"bootstrap token test scenarios"},
			Field:           "data",
			K8sObjects:      []string{"secrets"},
			HardcodedConfig: v1.Secret{
				ObjectMeta: metav1.ObjectMeta{
					Namespace: metav1.NamespaceSystem,
					Name:      bootstrapapi.BootstrapTokenSecretPrefix,
				},
				Type: v1.SecretTypeBootstrapToken,
				Data: map[string][]byte{
					bootstrapapi.BootstrapTokenIDKey:               []byte(validID),
					bootstrapapi.BootstrapTokenSecretKey:           []byte("invalid"),
					bootstrapapi.BootstrapTokenUsageAuthentication: []byte("true"),
					bootstrapapi.BootstrapTokenExpirationKey:       []byte(expiredTime),
				},
			},
		},
		// Edge case: empty token ID
		{
			FixtureFileName: "test_fixture.json",
			TestInfo:        []string{"bootstrap token test scenarios"},
			Field:           "data",
			K8sObjects:      []string{"secrets"},
			HardcodedConfig: v1.Secret{
				ObjectMeta: metav1.ObjectMeta{
					Namespace: metav1.NamespaceSystem,
					Name:      bootstrapapi.BootstrapTokenSecretPrefix,
				},
				Type: v1.SecretTypeBootstrapToken,
				Data: map[string][]byte{
					bootstrapapi.BootstrapTokenIDKey:               []byte(""),
					bootstrapapi.BootstrapTokenSecretKey:           []byte(validSecret),
					bootstrapapi.BootstrapTokenUsageAuthentication: []byte("true"),
				},
			},
		},
		// Edge case: empty token secret
		{
			FixtureFileName: "test_fixture.json",
			TestInfo:        []string{"bootstrap token test scenarios"},
			Field:           "data",
			K8sObjects:      []string{"secrets"},
			HardcodedConfig: v1.Secret{
				ObjectMeta: metav1.ObjectMeta{
					Namespace: metav1.NamespaceSystem,
					Name:      bootstrapapi.BootstrapTokenSecretPrefix,
				},
				Type: v1.SecretTypeBootstrapToken,
				Data: map[string][]byte{
					bootstrapapi.BootstrapTokenIDKey:               []byte(validID),
					bootstrapapi.BootstrapTokenSecretKey:           []byte(""),
					bootstrapapi.BootstrapTokenUsageAuthentication: []byte("true"),
				},
			},
		},
		// Edge case: missing usage authentication key
		{
			FixtureFileName: "test_fixture.json",
			TestInfo:        []string{"bootstrap token test scenarios"},
			Field:           "data",
			K8sObjects:      []string{"secrets"},
			HardcodedConfig: v1.Secret{
				ObjectMeta: metav1.ObjectMeta{
					Namespace: metav1.NamespaceSystem,
					Name:      bootstrapapi.BootstrapTokenSecretPrefix,
				},
				Type: v1.SecretTypeBootstrapToken,
				Data: map[string][]byte{
					bootstrapapi.BootstrapTokenIDKey:     []byte(validID),
					bootstrapapi.BootstrapTokenSecretKey: []byte(validSecret),
				},
			},
		},
		// Edge case: malformed expiration timestamp
		{
			FixtureFileName: "test_fixture.json",
			TestInfo:        []string{"bootstrap token test scenarios"},
			Field:           "data",
			K8sObjects:      []string{"secrets"},
			HardcodedConfig: v1.Secret{
				ObjectMeta: metav1.ObjectMeta{
					Namespace: metav1.NamespaceSystem,
					Name:      bootstrapapi.BootstrapTokenSecretPrefix,
				},
				Type: v1.SecretTypeBootstrapToken,
				Data: map[string][]byte{
					bootstrapapi.BootstrapTokenIDKey:               []byte(validID),
					bootstrapapi.BootstrapTokenSecretKey:           []byte(validSecret),
					bootstrapapi.BootstrapTokenUsageAuthentication: []byte("true"),
					bootstrapapi.BootstrapTokenExpirationKey:       []byte("not-a-timestamp"),
				},
			},
		},
		// Edge case: future expiration (still valid)
		{
			FixtureFileName: "test_fixture.json",
			TestInfo:        []string{"bootstrap token test scenarios"},
			Field:           "data",
			K8sObjects:      []string{"secrets"},
			HardcodedConfig: v1.Secret{
				ObjectMeta: metav1.ObjectMeta{
					Namespace: metav1.NamespaceSystem,
					Name:      bootstrapapi.BootstrapTokenSecretPrefix,
				},
				Type: v1.SecretTypeBootstrapToken,
				Data: map[string][]byte{
					bootstrapapi.BootstrapTokenIDKey:               []byte(validID),
					bootstrapapi.BootstrapTokenSecretKey:           []byte(validSecret),
					bootstrapapi.BootstrapTokenUsageAuthentication: []byte("true"),
					bootstrapapi.BootstrapTokenExpirationKey:       []byte(futureTime),
				},
			},
		},
	}
}
