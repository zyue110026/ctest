package benchmark

import (
	// "context"
	"encoding/json"
	"fmt"
	"os"
	"path/filepath"
	"testing"

	// "github.com/google/go-cmp/cmp"
	// "github.com/google/go-cmp/cmp/cmpopts"
	"k8s.io/apimachinery/pkg/api/resource"
	metav1 "k8s.io/apimachinery/pkg/apis/meta/v1"
	"k8s.io/apimachinery/pkg/util/sets"
	// "k8s.io/apimachinery/pkg/util/uuid"
	v1 "k8s.io/api/core/v1"
	"k8s.io/client-go/kubernetes/fake"

	ctest "k8s.io/kubernetes/test/ctest"
	ctestglobals "k8s.io/kubernetes/test/ctest/ctestglobals"
	ctestutils "k8s.io/kubernetes/test/ctest/utils"

	// "github.com/google/go-cmp/cmp/cmpopts"
	// "github.com/google/go-cmp/cmp"
	// "github.com/google/go-cmp/cmp/cmpopts"
	// "github.com/google/go-cmp/cmp"
	// "github.com/google/go-cmp/cmp/cmpopts"
	// "github.com/google/go-cmp/cmp"
	// "github.com/google/go-cmp/cmp/cmpopts"

	// "github.com/google/go-cmp/cmp"
	// "github.com/google/go-cmp/cmp/cmpopts"
	// "github.com/google/go-cmp/cmp"
	// "github.com/google/go-cmp/cmp/cmpopts"
	// "github.com/google/go-cmp/cmp"

	// "github.com/google/go-cmp/cmp"
	// "github.com/google/go-cmp/cmp/cmpopts"
	// "github.com/google/go-cmp/cmp"

	// "github.com/google/go-cmp/cmp"
	// "github.com/google/go-cmp/cmp/cmpopts"

	// "github.com/google/go-cmp/cmp"
	// "github.com/google/go-cmp/cmp/cmpopts"

	// "github.com/google/go-cmp/cmp"
	// "github.com/google/go-cmp/cmp/cmpopts"

	// "golang.org/x/exp/slices"

	// "k8s.io/apimachinery/pkg/util/sets"
	// "k8s.io/apimachinery/pkg/util/uuid"
	"k8s.io/kubernetes/test/e2e/framework"

	testutils "k8s.io/kubernetes/test/utils"
	ktesting "k8s.io/kubernetes/test/utils/ktesting"
	"k8s.io/utils/ptr"
)

func TestCtestRunOp(t *testing.T) {
	fmt.Println(ctestglobals.DebugPrefix(), "Start TestCtestRunOp")
	tests := []struct {
		name            string
		op              realOp
		expectedFailure bool
		verifyFuncs     []verifyFunc
	}{
		{
			name: "Create Single Node",
			op: &createNodesOp{
				Opcode: createNodesOpcode,
				Count:  1,
			},
			verifyFuncs: []verifyFunc{
				verifyCount(1),
				verifyObj(
					&v1.Node{
						ObjectMeta: metav1.ObjectMeta{
							GenerateName: "node-0-",
						},
						Status: v1.NodeStatus{
							Capacity: v1.ResourceList{
								v1.ResourceCPU:    resource.MustParse("4"),
								v1.ResourceMemory: resource.MustParse("32Gi"),
								v1.ResourcePods:   resource.MustParse("110"),
							},
							Allocatable: v1.ResourceList{
								v1.ResourceCPU:    resource.MustParse("4"),
								v1.ResourceMemory: resource.MustParse("32Gi"),
								v1.ResourcePods:   resource.MustParse("110"),
							},
						},
					}),
			},
		},
		{
			name: "Create Multiple Nodes",
			op: &createNodesOp{
				Opcode: createNodesOpcode,
				Count:  5,
			},
			verifyFuncs: []verifyFunc{
				verifyCount(5),
				verifyObj(
					&v1.Node{
						ObjectMeta: metav1.ObjectMeta{
							GenerateName: "node-0-",
						},
						Status: v1.NodeStatus{
							Capacity: v1.ResourceList{
								v1.ResourceCPU:    resource.MustParse("4"),
								v1.ResourceMemory: resource.MustParse("32Gi"),
								v1.ResourcePods:   resource.MustParse("110"),
							},
							Allocatable: v1.ResourceList{
								v1.ResourceCPU:    resource.MustParse("4"),
								v1.ResourceMemory: resource.MustParse("32Gi"),
								v1.ResourcePods:   resource.MustParse("110"),
							},
						},
					}),
			},
		},
		{
			name: "Create Nodes with Label Strategy",
			op: &createNodesOp{
				Opcode:                   createNodesOpcode,
				Count:                    3,
				LabelNodePrepareStrategy: testutils.NewLabelNodePrepareStrategy("test-label", "value1", "value2", "value3"),
			},
			verifyFuncs: []verifyFunc{
				verifyCount(3),
				verifyLabelValuesAllowed("test-label", sets.New("value1", "value2", "value3")),
			},
		},
		{
			name: "Create Nodes with Unique Label Strategy",
			op: &createNodesOp{
				Opcode:                  createNodesOpcode,
				Count:                   2,
				UniqueNodeLabelStrategy: testutils.NewUniqueNodeLabelStrategy("unique-test-label"),
			},
			verifyFuncs: []verifyFunc{
				verifyCount(2),
				verifyUniqueLabelValues("unique-test-label"),
			},
		},
		{
			name: "Create Nodes with Node Allocatable Strategy",
			op: &createNodesOp{
				Opcode: createNodesOpcode,
				Count:  2,
				NodeAllocatableStrategy: testutils.NewNodeAllocatableStrategy(
					map[v1.ResourceName]string{
						v1.ResourceCPU:    "2",
						v1.ResourceMemory: "4Gi",
					},
					nil, // no CSI node allocatable
					nil, // no migrated plugins
				),
			},
			verifyFuncs: []verifyFunc{
				verifyCount(2),
				verifyObj(
					&v1.Node{
						ObjectMeta: metav1.ObjectMeta{
							GenerateName: "node-0-",
						},
						Status: v1.NodeStatus{
							Capacity: v1.ResourceList{
								v1.ResourceCPU:    resource.MustParse("4"),
								v1.ResourceMemory: resource.MustParse("32Gi"),
								v1.ResourcePods:   resource.MustParse("110"),
							},
							Allocatable: v1.ResourceList{
								v1.ResourceCPU:    resource.MustParse("2"),
								v1.ResourceMemory: resource.MustParse("4Gi"),
								v1.ResourcePods:   resource.MustParse("110"),
							},
						},
					}),
			},
		},
		{
			name: "Create Nodes with Custom Template",
			op: &createNodesOp{
				Opcode: createNodesOpcode,
				Count:  2,
				// NodeTemplatePath will be set dynamically below using hardcoded config.
			},
			verifyFuncs: []verifyFunc{
				verifyCount(2),
				verifyObj(
					&v1.Node{
						ObjectMeta: metav1.ObjectMeta{
							GenerateName: "custom-node-",
						},
						Status: v1.NodeStatus{
							Capacity: v1.ResourceList{
								v1.ResourcePods:   resource.MustParse("100"),
								v1.ResourceCPU:    resource.MustParse("4"),
								v1.ResourceMemory: resource.MustParse("8Gi"),
							},
						},
					},
				),
			},
		},
		{
			name: "Invalid Node Template Path",
			op: &createNodesOp{
				Opcode:           createNodesOpcode,
				Count:            1,
				NodeTemplatePath: ptr.To("non-existent-file.json"),
			},
			expectedFailure: true,
		},
		{
			name: "Invalid Node Template JSON",
			op: &createNodesOp{
				Opcode:           createNodesOpcode,
				Count:            1,
				NodeTemplatePath: nil, // will be set to malformed file below
			},
			expectedFailure: true,
		},
	}

	// Prepare dynamic configurations for custom node template
	fmt.Println(ctestglobals.DebugPrefix(), "Generating dynamic node template configs")
	hardcodedConfigs := getHardCodedConfigInfoSchedulerPerfTest()
	item, found := ctestutils.GetItemByExactTestInfo(hardcodedConfigs, "custom node template")
	if !found {
		fmt.Println(ctestglobals.DebugPrefix(), "Custom node template config not found")
		framework.Failf("Failed to locate custom node template config")
	}
	fmt.Println(ctestglobals.DebugPrefix(), "Matched config item:", item)
	configObjs, _, err := ctest.GenerateEffectiveConfigReturnType[v1.Node](item, ctest.ExtendOnly)
	if err != nil {
		fmt.Println(ctestglobals.DebugPrefix(), "Error generating config:", err)
		framework.Failf("Failed to generate config: %v", err)
	}
	if len(configObjs) == 0 {
		fmt.Println(ctestglobals.DebugPrefix(), "No config objects generated")
		framework.Failf("No config objects generated")
	}
	customNodeTemplate := configObjs[0]

	// create temporary file for valid custom node template
	customTemplateFile := createTempNodeFile(t, &customNodeTemplate)
	// create temporary file with malformed JSON for edge case
	malformedTemplateFile := createMalformedNodeFile(t)

	for _, tt := range tests {
		// inject dynamic template paths where needed
		if tt.name == "Create Nodes with Custom Template" {
			if op, ok := tt.op.(*createNodesOp); ok {
				op.NodeTemplatePath = customTemplateFile
			}
		}
		if tt.name == "Invalid Node Template JSON" {
			if op, ok := tt.op.(*createNodesOp); ok {
				op.NodeTemplatePath = malformedTemplateFile
			}
		}
		t.Run(tt.name, func(t *testing.T) {
			_, tCtx := ktesting.NewTestContext(t)
			client := fake.NewSimpleClientset()
			tCtx = ktesting.WithClients(tCtx, nil, nil, client, nil, nil)

			exec := &WorkloadExecutor{
				tCtx:                         tCtx,
				numPodsScheduledPerNamespace: make(map[string]int),
				nextNodeIndex:                0,
			}

			err := exec.runOp(tt.op, 0)

			if tt.expectedFailure {
				if err == nil {
					t.Fatalf("Expected error but got none")
				}
				return
			}

			if err != nil {
				t.Fatalf("Failed to run operation: %v", err)
			}

			if tt.verifyFuncs != nil {
				for i, vf := range tt.verifyFuncs {
					if err := vf(t, tCtx, tt.op); err != nil {
						t.Fatalf("Verification function %d failed for test %q: %v", i, tt.name, err)
					}
				}
			}
		})
	}
	fmt.Println(ctestglobals.EndSeparator)
}

// createTempNodeFile creates a temporary JSON file for the given node.
func createTempNodeFile(t *testing.T, node *v1.Node) *string {
	t.Helper()
	dir, err := os.MkdirTemp("", "scheduler-perf-test")
	if err != nil {
		t.Fatalf("Failed to create temp dir: %v", err)
	}
	t.Cleanup(func() {
		_ = os.RemoveAll(dir)
	})
	path := filepath.Join(dir, "node_template.json")
	f, err := os.Create(path)
	if err != nil {
		t.Fatalf("Failed to create file %s: %v", path, err)
	}
	enc := json.NewEncoder(f)
	if err := enc.Encode(node); err != nil {
		t.Fatalf("Failed to encode node to %s: %v", path, err)
	}
	if err := f.Close(); err != nil {
		t.Fatalf("Failed to close file %s: %v", path, err)
	}
	return &path
}

// createMalformedNodeFile creates a temporary file with invalid JSON content.
func createMalformedNodeFile(t *testing.T) *string {
	t.Helper()
	dir, err := os.MkdirTemp("", "scheduler-perf-test")
	if err != nil {
		t.Fatalf("Failed to create temp dir: %v", err)
	}
	t.Cleanup(func() {
		_ = os.RemoveAll(dir)
	})
	path := filepath.Join(dir, "malformed.json")
	if err := os.WriteFile(path, []byte("{invalid-json"), 0644); err != nil {
		t.Fatalf("Failed to write malformed JSON to %s: %v", path, err)
	}
	return &path
}

// getHardCodedConfigInfoSchedulerPerfTest returns hardcoded configs for dynamic generation.
func getHardCodedConfigInfoSchedulerPerfTest() ctestglobals.HardcodedConfig {
	return ctestglobals.HardcodedConfig{
		{
			FixtureFileName: "test_fixture.json",
			TestInfo:        []string{"custom node template"},
			Field:           "node",
			K8sObjects:      []string{"nodes"},
			HardcodedConfig: v1.Node{
				ObjectMeta: metav1.ObjectMeta{
					GenerateName: "custom-node-",
				},
				Status: v1.NodeStatus{
					Capacity: v1.ResourceList{
						v1.ResourcePods:   resource.MustParse("100"),
						v1.ResourceCPU:    resource.MustParse("4"),
						v1.ResourceMemory: resource.MustParse("8Gi"),
					},
				},
			},
		},
	}
}
