package benchmark

import (
	"fmt"
	"strings"
	"testing"

	ctest "k8s.io/kubernetes/test/ctest"
	ctestglobals "k8s.io/kubernetes/test/ctest/ctestglobals"
	ctestutils "k8s.io/kubernetes/test/ctest/utils"
)

func TestCtestLabelFilter(t *testing.T) {
	fmt.Println(ctestglobals.StartSeparator)

	hardcodedConfig := getHardCodedConfigInfoLabelFilter()
	// Retrieve the config entry for the label filter test
	item, found := ctestutils.GetItemByExactTestInfo(hardcodedConfig, "label filter test")
	if !found {
		t.Fatalf("hardcoded config for label filter test not found")
	}
	fmt.Println(ctestglobals.DebugPrefix(), "get default configs:", item)

	fmt.Println(ctestglobals.StartUnionModeSeparator)
	configObjs, configJSON, err := ctest.GenerateEffectiveConfigReturnType[map[string]map[string]bool](item, ctest.Union)
	if err != nil {
		t.Fatalf("failed to generate effective config: %v", err)
	}
	if configObjs == nil {
		fmt.Println(ctestglobals.DebugPrefix(), "Skipping test execution. No new configurations generated.")
		return
	}
	fmt.Println(ctestglobals.DebugPrefix(), "New Json Test Configs:", string(configJSON))
	fmt.Println(ctestglobals.DebugPrefix(), "Number of test case groups:", len(configObjs))

	for i, testcases := range configObjs {
		fmt.Printf("Running %d th test case group.\n", i)
		fmt.Println(testcases)

		for labelFilter, labelResults := range testcases {
			t.Run(labelFilter, func(t *testing.T) {
				for labels, expected := range labelResults {
					t.Run(labels, func(t *testing.T) {
						actual := enabled(strings.Split(labelFilter, ","), strings.Split(labels, ",")...)
						if actual != expected {
							t.Errorf("expected enabled to be %v, got %v", expected, actual)
						}
					})
				}
			})
		}
	}
	fmt.Println(ctestglobals.EndSeparator)
}

// getHardCodedConfigInfoLabelFilter returns the hard‑coded test matrix for the label filter test.
// The matrix includes the original cases plus a few additional edge cases.
func getHardCodedConfigInfoLabelFilter() ctestglobals.HardcodedConfig {
	return ctestglobals.HardcodedConfig{
		{
			FixtureFileName: "test_fixture.json",
			TestInfo:        []string{"label filter test"},
			Field:           "testcases",
			K8sObjects:      []string{},
			HardcodedConfig: map[string]map[string]bool{
				"": {
					"":               true,
					"performance":    true,
					"fastPerformance": true,
					"unknown":        true, // edge: empty filter with unknown label
				},
				"performance": {
					"":               false,
					"performance":    true,
					"fastPerformance": true,
				},
				"fastPerformance": {
					"":               false,
					"performance":    false,
					"fastPerformance": true,
				},
				"-fast": {
					"":               true,
					"performance":    true,
					"fastPerformance": false,
				},
				"+performance,-fast": {
					"":               false,
					"performance":    true,
					"fastPerformance": false,
				},
				" , ": { // edge: malformed filter consisting of only commas/spaces
					"any": true,
				},
			},
		},
	}
}