package namespace

import (
	"context"
	"encoding/json"
	"fmt"
	"testing"
	"time"

	appsv1 "k8s.io/api/apps/v1"
	corev1 "k8s.io/api/core/v1"
	metav1 "k8s.io/apimachinery/pkg/apis/meta/v1"
	"k8s.io/apimachinery/pkg/apis/meta/v1/unstructured"
	"k8s.io/apimachinery/pkg/util/dump"
	"k8s.io/apimachinery/pkg/util/uuid"
	"k8s.io/apimachinery/pkg/util/wait"
	// "k8s.io/client-go/dynamic"
	// "k8s.io/client-go/informers"
	// clientset "k8s.io/client-go/kubernetes"
	// "k8s.io/client-go/metadata"
	// restclient "k8s.io/client-go/rest"
	// "k8s.io/klog/v2/ktesting"
	// kubeapiservertesting "k8s.io/kubernetes/cmd/kube-apiserver/app/testing"
	// "k8s.io/kubernetes/pkg/controller/namespace"
	// // "k8s.io/kubernetes/test/integration/etcd"
	// "k8s.io/kubernetes/test/integration/framework"

	ctest "k8s.io/kubernetes/test/ctest"
	ctestglobals "k8s.io/kubernetes/test/ctest/ctestglobals"
	ctestutils "k8s.io/kubernetes/test/ctest/utils"
)

func TestCtestNamespaceCondition(t *testing.T) {
	fmt.Println(ctestglobals.StartSeparator)
	hardcodedCfg := getHardCodedConfigInfoNamespaceCondition()

	// 1. fetch pod config
	podItem, podFound := ctestutils.GetItemByExactTestInfo(hardcodedCfg, "default pod")
	if !podFound {
		fmt.Println(ctestglobals.DebugPrefix(), "Pod config not found, skipping test")
		fmt.Println(ctestglobals.EndSeparator)
		return
	}
	fmt.Println(ctestglobals.DebugPrefix(), "get default pod configs:", podItem)
	fmt.Println(ctestglobals.StartExtendModeSeparator)
	podObjs, podJson, podErr := ctest.GenerateEffectiveConfigReturnType[*corev1.Pod](podItem, ctest.ExtendOnly)
	if podErr != nil || podObjs == nil {
		fmt.Println(ctestglobals.DebugPrefix(), "Failed to generate pod configs:", podErr)
		fmt.Println(ctestglobals.EndSeparator)
		return
	}
	fmt.Println(ctestglobals.DebugPrefix(), "New Json Test Configs (Pod):", string(podJson))
	fmt.Println(ctestglobals.DebugPrefix(), "Num of Pod test cases:", len(podObjs))

	// 2. fetch deployment config
	deployItem, deployFound := ctestutils.GetItemByExactTestInfo(hardcodedCfg, "default deployment")
	if !deployFound {
		fmt.Println(ctestglobals.DebugPrefix(), "Deployment config not found, skipping test")
		fmt.Println(ctestglobals.EndSeparator)
		return
	}
	fmt.Println(ctestglobals.DebugPrefix(), "get default deployment configs:", deployItem)
	fmt.Println(ctestglobals.StartExtendModeSeparator)
	deployObjs, deployJson, deployErr := ctest.GenerateEffectiveConfigReturnType[*appsv1.Deployment](deployItem, ctest.ExtendOnly)
	if deployErr != nil || deployObjs == nil {
		fmt.Println(ctestglobals.DebugPrefix(), "Failed to generate deployment configs:", deployErr)
		fmt.Println(ctestglobals.EndSeparator)
		return
	}
	fmt.Println(ctestglobals.DebugPrefix(), "New Json Test Configs (Deployment):", string(deployJson))
	fmt.Println(ctestglobals.DebugPrefix(), "Num of Deployment test cases:", len(deployObjs))

	// Run test for each combination (pod config + deployment config)
	for pi, podObj := range podObjs {
		for di, deployObj := range deployObjs {
			fmt.Printf("Running pod config #%d and deployment config #%d test case.\n", pi, di)
			fmt.Println(podObj)
			fmt.Println(deployObj)

			ctx, closeFn, nsController, informers, kubeClient, dynamicClient := namespaceLifecycleSetup(t)
			defer closeFn()

			nsName := "test-namespace-conditions-" + string(uuid.NewUUID())
			_, err := kubeClient.CoreV1().Namespaces().Create(ctx, &corev1.Namespace{
				ObjectMeta: metav1.ObjectMeta{
					Name: nsName,
				},
			}, metav1.CreateOptions{})
			if err != nil {
				t.Fatalf("failed to create namespace: %v", err)
			}

			// start informers/controllers
			ctx, cancel := context.WithCancel(ctx)
			defer cancel()
			informers.Start(ctx.Done())
			informers.WaitForCacheSync(ctx.Done())
			go nsController.Run(ctx, 5)

			// create pod
			podJSON, err := objToUnstructured(podObj, "v1", "Pod")
			if err != nil {
				t.Fatalf("failed to convert pod to unstructured: %v", err)
			}
			_, err = dynamicClient.Resource(corev1.SchemeGroupVersion.WithResource("pods")).Namespace(nsName).Create(ctx, podJSON, metav1.CreateOptions{})
			if err != nil {
				t.Fatalf("failed to create pod: %v", err)
			}

			// create deployment (add finalizer if not present)
			if len(deployObj.Spec.Template.Spec.Containers) == 0 {
				deployObj.Spec.Template.Spec.Containers = []corev1.Container{{Name: "default", Image: "busybox"}}
			}
			if deployObj.ObjectMeta.Finalizers == nil {
				deployObj.ObjectMeta.Finalizers = []string{"custom.io/finalizer"}
			}
			deployJSON, err := objToUnstructured(deployObj, "apps/v1", "Deployment")
			if err != nil {
				t.Fatalf("failed to convert deployment to unstructured: %v", err)
			}
			_, err = dynamicClient.Resource(appsv1.SchemeGroupVersion.WithResource("deployments")).Namespace(nsName).Create(ctx, deployJSON, metav1.CreateOptions{})
			if err != nil {
				t.Fatalf("failed to create deployment: %v", err)
			}

			// delete namespace
			if err = kubeClient.CoreV1().Namespaces().Delete(ctx, nsName, metav1.DeleteOptions{}); err != nil {
				t.Fatalf("failed to delete namespace: %v", err)
			}

			// poll for expected conditions
			err = wait.PollUntilContextTimeout(ctx, 1*time.Second, 60*time.Second, true, func(ctx context.Context) (bool, error) {
				curr, err := kubeClient.CoreV1().Namespaces().Get(ctx, nsName, metav1.GetOptions{})
				if err != nil {
					return false, err
				}
				conditionsFound := 0
				for _, condition := range curr.Status.Conditions {
					switch condition.Type {
					case corev1.NamespaceDeletionGVParsingFailure:
						if condition.Message == `All legacy kube types successfully parsed` {
							conditionsFound++
						}
					case corev1.NamespaceDeletionDiscoveryFailure:
						if condition.Message == `All resources successfully discovered` {
							conditionsFound++
						}
					case corev1.NamespaceDeletionContentFailure:
						if condition.Message == `All content successfully deleted, may be waiting on finalization` {
							conditionsFound++
						}
					case corev1.NamespaceContentRemaining:
						if condition.Message == `Some resources are remaining: deployments.apps has 1 resource instances` {
							conditionsFound++
						}
					case corev1.NamespaceFinalizersRemaining:
						if condition.Message == `Some content in the namespace has finalizers remaining: custom.io/finalizer in 1 resource instances` {
							conditionsFound++
						}
					}
				}
				t.Log(dump.Pretty(curr))
				return conditionsFound == 5, nil
			})
			if err != nil {
				t.Fatalf("condition verification failed: %v", err)
			}
		}
	}
	fmt.Println(ctestglobals.EndSeparator)
}

func TestCtestNamespaceLabels(t *testing.T) {
	fmt.Println(ctestglobals.StartSeparator)
	hardcodedCfg := getHardCodedConfigInfoNamespaceLabels()
	item, found := ctestutils.GetItemByExactTestInfo(hardcodedCfg, "default namespace")
	if !found {
		fmt.Println(ctestglobals.DebugPrefix(), "Namespace config not found, skipping test")
		fmt.Println(ctestglobals.EndSeparator)
		return
	}
	fmt.Println(ctestglobals.DebugPrefix(), "get default namespace configs:", item)
	fmt.Println(ctestglobals.StartExtendModeSeparator)
	nsObjs, nsJson, err := ctest.GenerateEffectiveConfigReturnType[*corev1.Namespace](item, ctest.ExtendOnly)
	if err != nil || nsObjs == nil {
		fmt.Println(ctestglobals.DebugPrefix(), "Failed to generate namespace configs:", err)
		fmt.Println(ctestglobals.EndSeparator)
		return
	}
	fmt.Println(ctestglobals.DebugPrefix(), "New Json Test Configs (Namespace):", string(nsJson))
	fmt.Println(ctestglobals.DebugPrefix(), "Num of Namespace test cases:", len(nsObjs))

	for i, nsObj := range nsObjs {
		fmt.Printf("Running namespace test case #%d\n", i)
		fmt.Println(nsObj)
		ctx, closeFn, nsController, _, kubeClient, _ := namespaceLifecycleSetup(t)
		defer closeFn()

		ctx, cancel := context.WithCancel(ctx)
		defer cancel()
		// even though nscontroller not used, we must run it
		go nsController.Run(ctx, 5)

		nsNamePrefix := "test-namespace-labels-generated-"
		nsObj.ObjectMeta.GenerateName = nsNamePrefix + string(uuid.NewUUID())
		createdNs, err := kubeClient.CoreV1().Namespaces().Create(ctx, nsObj, metav1.CreateOptions{})
		if err != nil {
			t.Fatalf("failed to create namespace: %v", err)
		}

		if createdNs.Name != createdNs.Labels[corev1.LabelMetadataName] {
			t.Fatalf("expected %q, got %q", createdNs.Name, createdNs.Labels[corev1.LabelMetadataName])
		}

		nsList, err := kubeClient.CoreV1().Namespaces().List(ctx, metav1.ListOptions{})
		if err != nil {
			t.Fatalf("failed to list namespaces: %v", err)
		}
		for _, ns := range nsList.Items {
			if ns.Name != ns.Labels[corev1.LabelMetadataName] {
				t.Fatalf("expected %q, got %q", ns.Name, ns.Labels[corev1.LabelMetadataName])
			}
		}
	}
	fmt.Println(ctestglobals.EndSeparator)
}

// helper to convert typed object to *unstructured.Unstructured
func objToUnstructured(obj interface{}, version, kind string) (*unstructured.Unstructured, error) {
	b, err := json.Marshal(obj)
	if err != nil {
		return nil, err
	}
	return jsonToUnstructured(string(b), version, kind)
}

func getHardCodedConfigInfoNamespaceCondition() ctestglobals.HardcodedConfig {
	return ctestglobals.HardcodedConfig{
		{
			FixtureFileName: "test_fixture.json",
			TestInfo:        []string{"default pod"},
			Field:           "spec",
			K8sObjects:      []string{"pods"},
			HardcodedConfig: &corev1.Pod{
				ObjectMeta: metav1.ObjectMeta{
					GenerateName: "pod-",
				},
				Spec: corev1.PodSpec{
					Containers: []corev1.Container{
						{
							Name:    "busybox",
							Image:   "busybox",
							Command: []string{"sleep", "3600"},
						},
					},
					RestartPolicy: corev1.RestartPolicyNever,
				},
			},
		},
		{
			FixtureFileName: "test_fixture.json",
			TestInfo:        []string{"default deployment"},
			Field:           "metadata.finalizers",
			K8sObjects:      []string{"deployments"},
			HardcodedConfig: &appsv1.Deployment{
				ObjectMeta: metav1.ObjectMeta{
					GenerateName: "deploy-",
					Finalizers:   []string{"custom.io/finalizer"},
				},
				Spec: appsv1.DeploymentSpec{
					Replicas: int32Ptr(1),
					Selector: &metav1.LabelSelector{
						MatchLabels: map[string]string{"app": "test"},
					},
					Template: corev1.PodTemplateSpec{
						ObjectMeta: metav1.ObjectMeta{
							Labels: map[string]string{"app": "test"},
						},
						Spec: corev1.PodSpec{
							Containers: []corev1.Container{
								{
									Name:  "busybox",
									Image: "busybox",
									Command: []string{
										"sleep",
										"3600",
									},
								},
							},
						},
					},
				},
			},
		},
	}
}

func getHardCodedConfigInfoNamespaceLabels() ctestglobals.HardcodedConfig {
	return ctestglobals.HardcodedConfig{
		{
			FixtureFileName: "test_fixture.json",
			TestInfo:        []string{"default namespace"},
			Field:           "metadata",
			K8sObjects:      []string{"namespaces"},
			HardcodedConfig: &corev1.Namespace{
				ObjectMeta: metav1.ObjectMeta{
					GenerateName: "ns-",
				},
			},
		},
	}
}

func int32Ptr(i int32) *int32 { return &i }
