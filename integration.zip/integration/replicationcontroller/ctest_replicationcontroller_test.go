package replicationcontroller

import (
	"fmt"
	"reflect"
	"testing"

	metav1 "k8s.io/apimachinery/pkg/apis/meta/v1"
	// "k8s.io/apimachinery/pkg/util/uuid"
	v1 "k8s.io/api/core/v1"
	"k8s.io/apimachinery/pkg/util/wait"

	ctest "k8s.io/kubernetes/test/ctest"
	ctestglobals "k8s.io/kubernetes/test/ctest/ctestglobals"
	ctestutils "k8s.io/kubernetes/test/ctest/utils"
	"k8s.io/kubernetes/test/integration/framework"
	"k8s.io/utils/ptr"
)

func TestCtestAdoptionEdgeCases(t *testing.T) {
	// Retrieve hard‑coded default OwnerReferences configuration
	fmt.Println(ctestglobals.StartExtendModeSeparator)
	hc := getHardCodedConfigInfoAdoption()
	item, found := ctestutils.GetItemByExactTestInfo(hc, "default ownerReferences")
	if !found {
		fmt.Println(ctestglobals.DebugPrefix(), "Failed to find hard‑coded config for adoption test")
		t.Skip("hard‑coded config not found")
	}
	configObjs, configJson, err := ctest.GenerateEffectiveConfigReturnType[[]metav1.OwnerReference](item, ctest.ExtendOnly)
	if err != nil {
		fmt.Println(ctestglobals.DebugPrefix(), "Failed to generate effective config:", err)
		t.Fatalf("config generation error: %v", err)
	}
	if configObjs == nil {
		fmt.Println(ctestglobals.DebugPrefix(), "Skipping test execution. No new configurations generated.")
		t.Skip("no configs")
	}
	fmt.Println(ctestglobals.DebugPrefix(), "New Json Test Configs:", string(configJson))
	fmt.Println(ctestglobals.DebugPrefix(), "Number of config objects:", len(configObjs))

	// Edge test cases that exercise ownerReference handling
	edgeTestCases := []struct {
		name                    string
		existingOwnerReferences func(rc *v1.ReplicationController) []metav1.OwnerReference
		expectedOwnerReferences func(rc *v1.ReplicationController) []metav1.OwnerReference
	}{
		{
			name: "pod has multiple controller owners",
			existingOwnerReferences: func(rc *v1.ReplicationController) []metav1.OwnerReference {
				return []metav1.OwnerReference{
					{UID: "1", Name: "rc1", APIVersion: "v1", Kind: "ReplicationController", Controller: ptr.To(true)},
					{UID: "2", Name: "rc2", APIVersion: "v1", Kind: "ReplicationController", Controller: ptr.To(true)},
				}
			},
			expectedOwnerReferences: func(rc *v1.ReplicationController) []metav1.OwnerReference {
				// No adoption should happen because a controller already exists
				return []metav1.OwnerReference{
					{UID: "1", Name: "rc1", APIVersion: "v1", Kind: "ReplicationController", Controller: ptr.To(true)},
					{UID: "2", Name: "rc2", APIVersion: "v1", Kind: "ReplicationController", Controller: ptr.To(true)},
				}
			},
		},
		{
			name: "pod has owner reference with empty UID",
			existingOwnerReferences: func(rc *v1.ReplicationController) []metav1.OwnerReference {
				return []metav1.OwnerReference{
					{UID: "", Name: rc.Name, APIVersion: "v1", Kind: "ReplicationController"},
				}
			},
			expectedOwnerReferences: func(rc *v1.ReplicationController) []metav1.OwnerReference {
				// Adoption should not occur due to invalid UID
				return []metav1.OwnerReference{
					{UID: "", Name: rc.Name, APIVersion: "v1", Kind: "ReplicationController"},
				}
			},
		},
		{
			name: "pod has owner reference with unknown kind",
			existingOwnerReferences: func(rc *v1.ReplicationController) []metav1.OwnerReference {
				return []metav1.OwnerReference{
					{UID: rc.UID, Name: rc.Name, APIVersion: "v1", Kind: "UnknownKind"},
				}
			},
			expectedOwnerReferences: func(rc *v1.ReplicationController) []metav1.OwnerReference {
				// No adoption because kind is not ReplicationController
				return []metav1.OwnerReference{
					{UID: rc.UID, Name: rc.Name, APIVersion: "v1", Kind: "UnknownKind"},
				}
			},
		},
		{
			name: "pod has owner reference with invalid API version",
			existingOwnerReferences: func(rc *v1.ReplicationController) []metav1.OwnerReference {
				return []metav1.OwnerReference{
					{UID: rc.UID, Name: rc.Name, APIVersion: "invalid/v1", Kind: "ReplicationController"},
				}
			},
			expectedOwnerReferences: func(rc *v1.ReplicationController) []metav1.OwnerReference {
				// Adoption should fail because APIVersion does not match
				return []metav1.OwnerReference{
					{UID: rc.UID, Name: rc.Name, APIVersion: "invalid/v1", Kind: "ReplicationController"},
				}
			},
		},
		{
			name: "pod has mixed valid and invalid owner references",
			existingOwnerReferences: func(rc *v1.ReplicationController) []metav1.OwnerReference {
				return []metav1.OwnerReference{
					{UID: "random", Name: "otherRC", APIVersion: "v1", Kind: "ReplicationController", Controller: ptr.To(true)},
					{UID: "", Name: rc.Name, APIVersion: "v1", Kind: "ReplicationController"},
				}
			},
			expectedOwnerReferences: func(rc *v1.ReplicationController) []metav1.OwnerReference {
				// No adoption because a controller already exists
				return []metav1.OwnerReference{
					{UID: "random", Name: "otherRC", APIVersion: "v1", Kind: "ReplicationController", Controller: ptr.To(true)},
					{UID: "", Name: rc.Name, APIVersion: "v1", Kind: "ReplicationController"},
				}
			},
		},
	}

	// Combine each generated config (currently just the default empty slice) with each edge case
	for cfgIdx, cfg := range configObjs {
		fmt.Printf("Running config object #%d: %v\n", cfgIdx, cfg)
		for i, tc := range edgeTestCases {
			fmt.Printf("Running edge case #%d: %s\n", i, tc.name)
			t.Run(tc.name, func(t *testing.T) {
				tCtx, closeFn, rm, informers, clientSet := rmSetup(t)
				defer closeFn()
				ns := framework.CreateNamespaceOrDie(clientSet, fmt.Sprintf("rc-adoption-edge-%d-%d", cfgIdx, i), t)
				defer framework.DeleteNamespaceOrDie(clientSet, ns, t)

				rcClient := clientSet.CoreV1().ReplicationControllers(ns.Name)
				podClient := clientSet.CoreV1().Pods(ns.Name)

				// Create a ReplicationController
				const rcName = "rc"
				rc, err := rcClient.Create(tCtx, newRC(rcName, ns.Name, 1), metav1.CreateOptions{})
				if err != nil {
					t.Fatalf("Failed to create ReplicationController: %v", err)
				}

				// Prepare the pod with the ownerReferences defined by the test case
				podName := fmt.Sprintf("pod-%d-%d", cfgIdx, i)
				pod := newMatchingPod(podName, ns.Name)
				pod.OwnerReferences = tc.existingOwnerReferences(rc)

				// Apply the (possibly empty) default config to the pod (extend mode)
				if len(cfg) > 0 {
					// In extend mode we simply append the default OwnerReferences if any
					pod.OwnerReferences = append(pod.OwnerReferences, cfg...)
				}

				_, err = podClient.Create(tCtx, pod, metav1.CreateOptions{})
				if err != nil {
					t.Fatalf("Failed to create Pod: %v", err)
				}

				stopControllers := runControllerAndInformers(t, rm, informers, 1)
				defer stopControllers()

				if err := wait.PollImmediate(interval, timeout, func() (bool, error) {
					updatedPod, err := podClient.Get(tCtx, pod.Name, metav1.GetOptions{})
					if err != nil {
						return false, err
					}
					exp := tc.expectedOwnerReferences(rc)
					if reflect.DeepEqual(exp, updatedPod.OwnerReferences) {
						return true, nil
					}
					t.Logf("ownerReferences mismatch, expected %v, got %v", exp, updatedPod.OwnerReferences)
					return false, nil
				}); err != nil {
					t.Fatalf("edge test %q failed: %v", tc.name, err)
				}
			})
		}
	}
}

// getHardCodedConfigInfoAdoption returns the minimal default OwnerReferences configuration
// used as a baseline for the adoption tests.
func getHardCodedConfigInfoAdoption() ctestglobals.HardcodedConfig {
	return ctestglobals.HardcodedConfig{
		{
			FixtureFileName: "test_fixture.json",
			TestInfo:        []string{"default ownerReferences"},
			Field:           "ownerReferences",
			K8sObjects:      []string{"pods"},
			HardcodedConfig: []metav1.OwnerReference{},
		},
	}
}
