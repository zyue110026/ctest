package events

import (
	"context"
	"fmt"
	"testing"
	"time"

	// "github.com/onsi/gomega"
	v1 "k8s.io/api/core/v1"
	metav1 "k8s.io/apimachinery/pkg/apis/meta/v1"
	"k8s.io/apimachinery/pkg/types"
	"k8s.io/apimachinery/pkg/util/uuid"
	"k8s.io/apimachinery/pkg/util/wait"
	clientset "k8s.io/client-go/kubernetes"
	"k8s.io/client-go/kubernetes/scheme"
	typedv1 "k8s.io/client-go/kubernetes/typed/core/v1"
	"k8s.io/client-go/tools/events"
	"k8s.io/client-go/tools/record"
	ref "k8s.io/client-go/tools/reference"
	kubeapiservertesting "k8s.io/kubernetes/cmd/kube-apiserver/app/testing"
	"k8s.io/kubernetes/test/integration/framework"

	ctest "k8s.io/kubernetes/test/ctest"
	ctestglobals "k8s.io/kubernetes/test/ctest/ctestglobals"
	ctestutils "k8s.io/kubernetes/test/ctest/utils"
)

func TestCtestEventCompatibility(t *testing.T) {
	fmt.Println(ctestglobals.StartSeparator)
	hardcoded := getHardCodedConfigInfoEventPod()
	item, found := ctestutils.GetItemByExactTestInfo(hardcoded, "event compatibility pod")
	if !found {
		fmt.Println(ctestglobals.DebugPrefix(), "Failed to find config item by TestInfo")
		t.Fatalf("Hardcoded config not found")
	}
	fmt.Println(ctestglobals.DebugPrefix(), "Matched config item:", item)

	fmt.Println(ctestglobals.StartOverrideModeSeparator)
	configObjs, configJson, err := ctest.GenerateEffectiveConfigReturnType[v1.Pod](item, ctest.OverrideOnly)
	if err != nil {
		fmt.Println(ctestglobals.DebugPrefix(), "GenerateEffectiveConfigReturnType error:", err)
		t.Fatalf("Generate config failed: %v", err)
	}
	if configObjs == nil {
		fmt.Println(ctestglobals.DebugPrefix(), "Skipping test execution. No new configurations generated.")
		fmt.Println(ctestglobals.EndSeparator)
		return
	}
	fmt.Println(ctestglobals.DebugPrefix(), "New Json Test Configs:", string(configJson))
	fmt.Println(ctestglobals.DebugPrefix(), "Number of test cases:", len(configObjs))

	// add edge cases
	edgePods := []v1.Pod{}
	for _, base := range configObjs {
		// base case
		edgePods = append(edgePods, base)

		// empty name
		emptyName := base.DeepCopy()
		emptyName.ObjectMeta.Name = ""
		edgePods = append(edgePods, *emptyName)

		// empty namespace
		emptyNS := base.DeepCopy()
		emptyNS.ObjectMeta.Namespace = ""
		edgePods = append(edgePods, *emptyNS)

		// empty UID
		emptyUID := base.DeepCopy()
		emptyUID.ObjectMeta.UID = ""
		edgePods = append(edgePods, *emptyUID)

		// very long name
		longName := base.DeepCopy()
		longName.ObjectMeta.Name = string(uuid.NewUUID()) + string(uuid.NewUUID()) + string(uuid.NewUUID())
		edgePods = append(edgePods, *longName)
	}

	for i, podCfg := range edgePods {
		fmt.Printf("Running %d th test case.\n", i)
		fmt.Println(podCfg)

		// start apiserver
		result := kubeapiservertesting.StartTestServerOrDie(t, nil, framework.DefaultTestServerFlags(), framework.SharedEtcd())
		defer result.TearDownFn()
		client := clientset.NewForConfigOrDie(result.ClientConfig)

		// ensure UID is set (if empty, generate one)
		if podCfg.ObjectMeta.UID == "" {
			podCfg.ObjectMeta.UID = types.UID(uuid.NewUUID())
		}
		// ensure name and namespace are set (if empty, generate)
		if podCfg.ObjectMeta.Name == "" {
			podCfg.ObjectMeta.Name = "pod-" + string(uuid.NewUUID())
		}
		if podCfg.ObjectMeta.Namespace == "" {
			podCfg.ObjectMeta.Namespace = "default"
		}

		regarding, err := ref.GetReference(scheme.Scheme, &podCfg)
		if err != nil {
			t.Fatal(err)
		}
		related, err := ref.GetPartialReference(scheme.Scheme, &podCfg, ".spec.containers[0]")
		if err != nil {
			t.Fatal(err)
		}

		stopCh := make(chan struct{})
		defer close(stopCh)
		oldBroadcaster := record.NewBroadcaster()
		defer oldBroadcaster.Shutdown()
		oldRecorder := oldBroadcaster.NewRecorder(scheme.Scheme, v1.EventSource{Component: "integration"})
		oldBroadcaster.StartRecordingToSink(&typedv1.EventSinkImpl{Interface: client.CoreV1().Events("")})
		oldRecorder.Eventf(regarding, v1.EventTypeNormal, "started", "note")

		newBroadcaster := events.NewBroadcaster(&events.EventSinkImpl{Interface: client.EventsV1()})
		defer newBroadcaster.Shutdown()
		newRecorder := newBroadcaster.NewRecorder(scheme.Scheme, "k8s.io/kube-scheduler")
		newBroadcaster.StartRecordingToSink(stopCh)
		newRecorder.Eventf(regarding, related, v1.EventTypeNormal, "memoryPressure", "killed", "memory pressure")

		err = wait.PollImmediate(100*time.Millisecond, 20*time.Second, func() (bool, error) {
			v1Events, err := client.EventsV1().Events("").List(context.TODO(), metav1.ListOptions{})
			if err != nil {
				return false, err
			}
			if len(v1Events.Items) != 2 {
				return false, nil
			}
			events, err := client.CoreV1().Events("").List(context.TODO(), metav1.ListOptions{})
			if err != nil {
				return false, err
			}
			if len(events.Items) != 2 {
				return false, nil
			}
			return true, nil
		})
		if err != nil {
			t.Fatalf("unexpected err: %v", err)
		}
	}
	fmt.Println(ctestglobals.EndSeparator)
}

func TestCtestEventSeries(t *testing.T) {
	fmt.Println(ctestglobals.StartSeparator)
	hardcoded := getHardCodedConfigInfoEventPod()
	item, found := ctestutils.GetItemByExactTestInfo(hardcoded, "event series pod")
	if !found {
		fmt.Println(ctestglobals.DebugPrefix(), "Failed to find config item by TestInfo")
		t.Fatalf("Hardcoded config not found")
	}
	fmt.Println(ctestglobals.DebugPrefix(), "Matched config item:", item)

	fmt.Println(ctestglobals.StartOverrideModeSeparator)
	configObjs, configJson, err := ctest.GenerateEffectiveConfigReturnType[v1.Pod](item, ctest.OverrideOnly)
	if err != nil {
		fmt.Println(ctestglobals.DebugPrefix(), "GenerateEffectiveConfigReturnType error:", err)
		t.Fatalf("Generate config failed: %v", err)
	}
	if configObjs == nil {
		fmt.Println(ctestglobals.DebugPrefix(), "Skipping test execution. No new configurations generated.")
		fmt.Println(ctestglobals.EndSeparator)
		return
	}
	fmt.Println(ctestglobals.DebugPrefix(), "New Json Test Configs:", string(configJson))
	fmt.Println(ctestglobals.DebugPrefix(), "Number of test cases:", len(configObjs))

	edgePods := []v1.Pod{}
	for _, base := range configObjs {
		edgePods = append(edgePods, base)
		emptyUID := base.DeepCopy()
		emptyUID.ObjectMeta.UID = ""
		edgePods = append(edgePods, *emptyUID)
	}

	for i, podCfg := range edgePods {
		fmt.Printf("Running %d th test case.\n", i)
		fmt.Println(podCfg)

		result := kubeapiservertesting.StartTestServerOrDie(t, nil, framework.DefaultTestServerFlags(), framework.SharedEtcd())
		defer result.TearDownFn()
		client := clientset.NewForConfigOrDie(result.ClientConfig)

		if podCfg.ObjectMeta.UID == "" {
			podCfg.ObjectMeta.UID = types.UID(uuid.NewUUID())
		}
		if podCfg.ObjectMeta.Name == "" {
			podCfg.ObjectMeta.Name = "pod-" + string(uuid.NewUUID())
		}
		if podCfg.ObjectMeta.Namespace == "" {
			podCfg.ObjectMeta.Namespace = "default"
		}

		regarding, err := ref.GetReference(scheme.Scheme, &podCfg)
		if err != nil {
			t.Fatal(err)
		}
		related, err := ref.GetPartialReference(scheme.Scheme, &podCfg, ".spec.containers[0]")
		if err != nil {
			t.Fatal(err)
		}

		stopCh := make(chan struct{})
		defer close(stopCh)

		broadcaster := events.NewBroadcaster(&events.EventSinkImpl{Interface: client.EventsV1()})
		defer broadcaster.Shutdown()
		recorder := broadcaster.NewRecorder(scheme.Scheme, "k8s.io/kube-scheduler")
		broadcaster.StartRecordingToSink(stopCh)
		recorder.Eventf(regarding, related, v1.EventTypeNormal, "memoryPressure", "killed", "memory pressure")
		recorder.Eventf(regarding, related, v1.EventTypeNormal, "memoryPressure", "killed", "memory pressure")

		err = wait.PollImmediate(100*time.Millisecond, 20*time.Second, func() (bool, error) {
			events, err := client.EventsV1().Events("").List(context.TODO(), metav1.ListOptions{})
			if err != nil {
				return false, err
			}
			if len(events.Items) != 1 {
				return false, nil
			}
			if events.Items[0].Series == nil {
				return false, nil
			}
			if events.Items[0].Series.Count != 2 {
				return false, fmt.Errorf("expected EventSeries to have a starting count of 2, got: %d", events.Items[0].Series.Count)
			}
			return true, nil
		})
		if err != nil {
			t.Fatalf("error waiting for an Event with a non nil Series to be created: %v", err)
		}
	}
	fmt.Println(ctestglobals.EndSeparator)
}

func getHardCodedConfigInfoEventPod() ctestglobals.HardcodedConfig {
	return ctestglobals.HardcodedConfig{
		{
			FixtureFileName: "test_fixture.json",
			TestInfo:        []string{"event compatibility pod", "event series pod"},
			Field:           "metadata",
			K8sObjects:      []string{"pods"},
			HardcodedConfig: v1.Pod{
				ObjectMeta: metav1.ObjectMeta{
					Name:      "foo",
					Namespace: "default",
					UID:       "bar",
				},
			},
		},
	}
}
