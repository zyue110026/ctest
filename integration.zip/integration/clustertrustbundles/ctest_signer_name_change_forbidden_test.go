package clustertrustbundles

import (
	"context"
	"crypto/x509"
	"crypto/x509/pkix"
	"fmt"
	"math/big"
	"strings"
	"testing"

	certsv1beta1 "k8s.io/api/certificates/v1beta1"
	metav1 "k8s.io/apimachinery/pkg/apis/meta/v1"
	"k8s.io/client-go/kubernetes"
	kubeapiservertesting "k8s.io/kubernetes/cmd/kube-apiserver/app/testing"
	"k8s.io/kubernetes/test/integration/framework"

	ctest "k8s.io/kubernetes/test/ctest"
	ctestglobals "k8s.io/kubernetes/test/ctest/ctestglobals"
	ctestutils "k8s.io/kubernetes/test/ctest/utils"
)

func TestCtestCTBSignerNameChangeForbidden(t *testing.T) {
	fmt.Println(ctestglobals.StartSeparator)

	hardcodedConfig := getHardCodedConfigInfoCTBSignerNameChangeForbidden()
	item, found := ctestutils.GetItemByExactTestInfo(hardcodedConfig, "default clustertrustbundle spec")
	if !found {
		t.Fatalf("hardcoded config not found")
	}
	fmt.Println(ctestglobals.DebugPrefix(), "matched config item:", item)

	fmt.Println(ctestglobals.StartOverrideModeSeparator)
	configObjs, configJson, err := ctest.GenerateEffectiveConfigReturnType[certsv1beta1.ClusterTrustBundleSpec](item, ctest.OverrideOnly)
	if err != nil {
		t.Fatalf("failed to generate config: %v", err)
	}
	if configObjs == nil || len(configObjs) == 0 {
		fmt.Println(ctestglobals.DebugPrefix(), "Skipping test execution. No new configurations generated.")
		fmt.Println(ctestglobals.EndSeparator)
		return
	}
	fmt.Println(ctestglobals.DebugPrefix(), "New Json Test Configs:", string(configJson))
	fmt.Println(ctestglobals.DebugPrefix(), "Number of config objects:", len(configObjs))

	// original test cases
	originalCases := []struct {
		objectName string
		signer1    string
		signer2    string
	}{
		{
			objectName: "foo",
			signer1:    "",
			signer2:    "foo.com/bar",
		},
		{
			objectName: "foo.com:bar:abc",
			signer1:    "foo.com/bar",
			signer2:    "",
		},
		{
			objectName: "foo.com:bar:abc",
			signer1:    "foo.com/bar",
			signer2:    "foo.com/bar2",
		},
	}
	// edge / additional cases
	edgeCases := []struct {
		objectName string
		signer1    string
		signer2    string
	}{
		{
			objectName: "valid-name",
			signer1:    "valid-signer",
			signer2:    "valid-signer2",
		},
		{
			objectName: "valid-nochange",
			signer1:    "same-signer",
			signer2:    "same-signer",
		},
		{
			objectName: "long-name-" + strings.Repeat("a", 250),
			signer1:    "long-signer-" + strings.Repeat("b", 250),
			signer2:    "long-signer-" + strings.Repeat("c", 250),
		},
	}
	// combine
	testCases := append(originalCases, edgeCases...)

	for i, specTemplate := range configObjs {
		fmt.Printf("Running config object #%d\n", i)
		fmt.Println(specTemplate)

		for _, tc := range testCases {
			tc := tc // capture range variable
			t.Run(fmt.Sprintf("%s -> %s (obj:%s)", tc.signer1, tc.signer2, tc.objectName), func(t *testing.T) {
				ctx := context.Background()

				server := kubeapiservertesting.StartTestServerOrDie(t, nil,
					[]string{
						"--feature-gates=ClusterTrustBundle=true",
						fmt.Sprintf("--runtime-config=%s=true", certsv1beta1.SchemeGroupVersion),
					},
					framework.SharedEtcd())
				defer server.TearDownFn()

				client := kubernetes.NewForConfigOrDie(server.ClientConfig)

				// Clone the spec template to avoid mutation across iterations
				spec := specTemplate
				// Populate TrustBundle with a valid PEM block
				spec.TrustBundle = mustMakePEMBlock("CERTIFICATE", nil,
					mustMakeCertificate(t, &x509.Certificate{
						SerialNumber: big.NewInt(0),
						Subject: pkix.Name{
							CommonName: "root1",
						},
						IsCA:                  true,
						BasicConstraintsValid: true,
					}))
				// Set initial signerName from test case
				spec.SignerName = tc.signer1

				bundle := &certsv1beta1.ClusterTrustBundle{
					ObjectMeta: metav1.ObjectMeta{
						Name: tc.objectName,
					},
					Spec: spec,
				}

				_, err := client.CertificatesV1beta1().ClusterTrustBundles().Create(ctx, bundle, metav1.CreateOptions{})
				if err != nil {
					t.Fatalf("Error while creating bundle %s: %v", tc.objectName, err)
				}

				// Attempt to change signer name to signer2
				bundle.Spec.SignerName = tc.signer2
				_, err = client.CertificatesV1beta1().ClusterTrustBundles().Update(ctx, bundle, metav1.UpdateOptions{})
				if tc.signer1 != tc.signer2 {
					if err == nil {
						t.Fatalf("Expected error when updating signer from %q to %q, got nil", tc.signer1, tc.signer2)
					}
				} else {
					if err != nil {
						t.Fatalf("Did not expect error when signer unchanged (%q), got: %v", tc.signer1, err)
					}
				}
			})
		}
		_ = i // silence unused warning if any
	}
	fmt.Println(ctestglobals.EndSeparator)
}

// getHardCodedConfigInfoCTBSignerNameChangeForbidden returns a minimal hardcoded spec for ClusterTrustBundle.
func getHardCodedConfigInfoCTBSignerNameChangeForbidden() ctestglobals.HardcodedConfig {
	return ctestglobals.HardcodedConfig{
		{
			FixtureFileName: "test_fixture.json",
			TestInfo:        []string{"default clustertrustbundle spec"},
			Field:           "spec",
			K8sObjects:      []string{"clustertrustbundles"},
			HardcodedConfig: certsv1beta1.ClusterTrustBundleSpec{
				SignerName:  "placeholder-signer",
				TrustBundle: "PLACEHOLDER_PEM",
			},
		},
	}
}