package clustertrustbundles

import (
	"context"
	"crypto/x509"
	"crypto/x509/pkix"
	"fmt"
	"math/big"
	"testing"

	certsv1beta1 "k8s.io/api/certificates/v1beta1"
	// rbacv1 "k8s.io/api/rbac/v1"
	metav1 "k8s.io/apimachinery/pkg/apis/meta/v1"
	// "k8s.io/apimachinery/pkg/runtime/schema"
	"k8s.io/client-go/kubernetes"
	"k8s.io/client-go/rest"
	kubeapiservertesting "k8s.io/kubernetes/cmd/kube-apiserver/app/testing"
	// "k8s.io/kubernetes/test/integration/authutil"
	"k8s.io/kubernetes/test/integration/framework"

	ctest "k8s.io/kubernetes/test/ctest"
	ctestglobals "k8s.io/kubernetes/test/ctest/ctestglobals"
	ctestutils "k8s.io/kubernetes/test/ctest/utils"
)

func TestCtestCTBAttestPlugin(t *testing.T) {
	fmt.Println(ctestglobals.StartSeparator)
	// Retrieve hardcoded config for ClusterTrustBundleSpec
	hardcodedConfig := getHardCodedConfigInfoAdmissionEstablishTrust()
	// Find the config item by test info
	item, found := ctestutils.GetItemByExactTestInfo(hardcodedConfig, "default clustertrustbundle spec")
	if !found {
		fmt.Println(ctestglobals.DebugPrefix(), "Failed to find config item by TestInfo")
		t.Skip("no hardcoded config found")
	}
	fmt.Println(ctestglobals.DebugPrefix(), "Matched config item:", item)

	// Generate effective configs (extend mode)
	configObjs, configJson, err := ctest.GenerateEffectiveConfigReturnType[certsv1beta1.ClusterTrustBundleSpec](item, ctest.ExtendOnly)
	if err != nil {
		fmt.Println(ctestglobals.DebugPrefix(), "Failed to generate config:", err)
		t.Fatalf("config generation failed: %v", err)
	}
	if configObjs == nil {
		fmt.Println(ctestglobals.DebugPrefix(), "Skipping test execution. No new configurations generated.")
		return
	}
	fmt.Println(ctestglobals.DebugPrefix(), "New Json Test Configs:", string(configJson))
	fmt.Println(ctestglobals.DebugPrefix(), "Number of config objects:", len(configObjs))

	// Original + edge test cases
	testCases := []struct {
		description       string
		trustBundleName   string
		allowedSignerName string
		targetSignerName  string
		wantError         string
	}{
		{
			description:       "should admit if the clustertrustbundle doesn't target a signer",
			trustBundleName:   "foo",
			allowedSignerName: "foo.com/bar",
		},
		{
			description:       "should admit if the user has attest for the exact signer name",
			trustBundleName:   "foo.com:bar:abc",
			allowedSignerName: "foo.com/bar",
			targetSignerName:  "foo.com/bar",
		},
		{
			description:       "should admit if the user has attest for the wildcard-suffixed signer name",
			trustBundleName:   "foo.com:bar:abc",
			allowedSignerName: "foo.com/*",
			targetSignerName:  "foo.com/bar",
		},
		{
			description:       "should deny if the user does not have permission for the signer name",
			trustBundleName:   "foo.com:bar:abc",
			allowedSignerName: "abc.com/def",
			targetSignerName:  "foo.com/bar",
			wantError:         "clustertrustbundles.certificates.k8s.io \"foo.com:bar:abc\" is forbidden: user not permitted to attest for signerName \"foo.com/bar\"",
		},
		// Edge / invalid cases
		{
			description:       "should deny when no allowed signer provided but signer is targeted",
			trustBundleName:   "edge-no-allowed",
			allowedSignerName: "",
			targetSignerName:  "foo.com/bar",
			wantError:         "clustertrustbundles.certificates.k8s.io \"edge-no-allowed\" is forbidden: user not permitted to attest for signerName \"foo.com/bar\"",
		},
		{
			description:       "should deny when allowed signer wildcard does not match target signer",
			trustBundleName:   "edge-wildcard-mismatch",
			allowedSignerName: "foo.com/*",
			targetSignerName:  "other.com/bar",
			wantError:         "clustertrustbundles.certificates.k8s.io \"edge-wildcard-mismatch\" is forbidden: user not permitted to attest for signerName \"other.com/bar\"",
		},
	}

	for cfgIdx, cfg := range configObjs {
		fmt.Printf("Running config object %d/%d\n", cfgIdx+1, len(configObjs))
		fmt.Println(cfg)
		for i, tc := range testCases {
			fmt.Printf("Running test case %d: %s\n", i, tc.description)
			t.Run(tc.description, func(t *testing.T) {
				ctx := context.Background()

				server := kubeapiservertesting.StartTestServerOrDie(t, nil,
					[]string{
						"--authorization-mode=RBAC",
						"--feature-gates=ClusterTrustBundle=true",
						fmt.Sprintf("--runtime-config=%s=true", certsv1beta1.SchemeGroupVersion),
					},
					framework.SharedEtcd())
				defer server.TearDownFn()

				client := kubernetes.NewForConfigOrDie(server.ClientConfig)

				if tc.allowedSignerName != "" {
					grantUserPermissionToAttestFor(ctx, t, client, "test-user", tc.allowedSignerName)
				}

				// Impersonate test-user
				testUserConfig := rest.CopyConfig(server.ClientConfig)
				testUserConfig.Impersonate = rest.ImpersonationConfig{UserName: "test-user"}
				testUserClient := kubernetes.NewForConfigOrDie(testUserConfig)

				// Build spec from dynamic config and test case values
				spec := cfg
				if tc.targetSignerName != "" {
					spec.SignerName = tc.targetSignerName
				}
				// Always set a valid TrustBundle
				spec.TrustBundle = mustMakePEMBlock("CERTIFICATE", nil, mustMakeCertificate(t, &x509.Certificate{
					SerialNumber: big.NewInt(0),
					Subject: pkix.Name{
						CommonName: "root1",
					},
					IsCA:                  true,
					BasicConstraintsValid: true,
				}))

				bundle := &certsv1beta1.ClusterTrustBundle{
					ObjectMeta: metav1.ObjectMeta{
						Name: tc.trustBundleName,
					},
					Spec: spec,
				}

				_, err := testUserClient.CertificatesV1beta1().ClusterTrustBundles().Create(ctx, bundle, metav1.CreateOptions{})
				if err != nil && err.Error() != tc.wantError {
					t.Fatalf("Bad error while creating ClusterTrustBundle; got %q want %q", err.Error(), tc.wantError)
				} else if err == nil && tc.wantError != "" {
					t.Fatalf("Bad error while creating ClusterTrustBundle; got nil want %q", tc.wantError)
				}
			})
		}
	}
	fmt.Println(ctestglobals.EndSeparator)
}

// Hardcoded config for ClusterTrustBundleSpec
func getHardCodedConfigInfoAdmissionEstablishTrust() ctestglobals.HardcodedConfig {
	return ctestglobals.HardcodedConfig{
		{
			FixtureFileName: "test_fixture.json",
			TestInfo:        []string{"default clustertrustbundle spec"},
			Field:           "spec",
			K8sObjects:      []string{"clustertrustbundles"},
			HardcodedConfig: certsv1beta1.ClusterTrustBundleSpec{
				SignerName:  "",
				TrustBundle: "",
			},
		},
	}
}
