package endpointslice

import (
	"context"
	"fmt"
	"sort"
	"testing"
	"time"

	corev1 "k8s.io/api/core/v1"
	discovery "k8s.io/api/discovery/v1"
	apiequality "k8s.io/apimachinery/pkg/api/equality"
	metav1 "k8s.io/apimachinery/pkg/apis/meta/v1"
	"k8s.io/apimachinery/pkg/util/wait"
	"k8s.io/client-go/informers"
	clientset "k8s.io/client-go/kubernetes"
	kubeapiservertesting "k8s.io/kubernetes/cmd/kube-apiserver/app/testing"
	"k8s.io/kubernetes/pkg/controller/endpoint"
	"k8s.io/kubernetes/pkg/controller/endpointslice"
	"k8s.io/kubernetes/pkg/controller/endpointslicemirroring"
	"k8s.io/kubernetes/test/integration/framework"
	"k8s.io/kubernetes/test/utils/ktesting"

	// "github.com/onsi/ginkgo/v2"
	"k8s.io/kubernetes/test/ctest"
	ctestglobals "k8s.io/kubernetes/test/ctest/ctestglobals"
	ctestutils "k8s.io/kubernetes/test/ctest/utils"
)

func TestCtestEndpointSliceMirroring(t *testing.T) {
	// Disable ServiceAccount admission plugin as we don't have serviceaccount controller running.
	server := kubeapiservertesting.StartTestServerOrDie(t, nil, framework.DefaultTestServerFlags(), framework.SharedEtcd())
	defer server.TearDownFn()

	client, err := clientset.NewForConfig(server.ClientConfig)
	if err != nil {
		t.Fatalf("Error creating clientset: %v", err)
	}

	tCtx := ktesting.Init(t)
	resyncPeriod := 12 * time.Hour
	informerFactory := informers.NewSharedInformerFactory(client, resyncPeriod)

	epController := endpoint.NewEndpointController(
		tCtx,
		informerFactory.Core().V1().Pods(),
		informerFactory.Core().V1().Services(),
		informerFactory.Core().V1().Endpoints(),
		client,
		1*time.Second)

	epsController := endpointslice.NewController(
		tCtx,
		informerFactory.Core().V1().Pods(),
		informerFactory.Core().V1().Services(),
		informerFactory.Core().V1().Nodes(),
		informerFactory.Discovery().V1().EndpointSlices(),
		int32(100),
		client,
		1*time.Second)

	epsmController := endpointslicemirroring.NewController(
		tCtx,
		informerFactory.Core().V1().Endpoints(),
		informerFactory.Discovery().V1().EndpointSlices(),
		informerFactory.Core().V1().Services(),
		int32(100),
		client,
		1*time.Second)

	// start informers & controllers
	informerFactory.Start(tCtx.Done())
	go epController.Run(tCtx, 5)
	go epsController.Run(tCtx, 5)
	go epsmController.Run(tCtx, 5)

	// ------- dynamic config generation -------
	fmt.Println(ctestglobals.StartSeparator)
	serviceItem, found := ctestutils.GetItemByExactTestInfo(getHardCodedConfigInfoService(), "default service")
	if !found {
		t.Fatalf("default service config not found")
	}
	serviceObjs, serviceJson, err := ctest.GenerateEffectiveConfigReturnType[corev1.Service](serviceItem, ctest.OverrideOnly)
	if err != nil {
		t.Fatalf("service config generation failed: %v", err)
	}
	fmt.Println(ctestglobals.DebugPrefix(), "service config json:", string(serviceJson))

	endpointItem, found := ctestutils.GetItemByExactTestInfo(getHardCodedConfigInfoEndpoints(), "default endpoints")
	if !found {
		t.Fatalf("default endpoints config not found")
	}
	endpointObjs, endpointJson, err := ctest.GenerateEffectiveConfigReturnType[corev1.Endpoints](endpointItem, ctest.OverrideOnly)
	if err != nil {
		t.Fatalf("endpoints config generation failed: %v", err)
	}
	fmt.Println(ctestglobals.DebugPrefix(), "endpoints config json:", string(endpointJson))
	// ------------------------------------------------

	baseService := corev1.Service{}
	if len(serviceObjs) > 0 {
		baseService = serviceObjs[0]
	}
	baseEndpoints := corev1.Endpoints{}
	if len(endpointObjs) > 0 {
		baseEndpoints = endpointObjs[0]
	}

	originalTestCases := []struct {
		testName                     string
		service                      *corev1.Service
		customEndpoints              *corev1.Endpoints
		expectEndpointSlice          int
		expectEndpointSliceManagedBy string
	}{
		{
			testName: "Service with selector",
			service: &corev1.Service{
				ObjectMeta: metav1.ObjectMeta{
					Name: "test-123",
				},
				Spec: corev1.ServiceSpec{
					Ports: []corev1.ServicePort{{Port: int32(80)}},
					Selector: map[string]string{
						"foo": "bar",
					},
				},
			},
			expectEndpointSlice:          1,
			expectEndpointSliceManagedBy: "endpointslice-controller.k8s.io",
		},
		{
			testName: "Service without selector",
			service: &corev1.Service{
				ObjectMeta: metav1.ObjectMeta{
					Name: "test-123",
				},
				Spec: corev1.ServiceSpec{
					Ports: []corev1.ServicePort{{Port: int32(80)}},
				},
			},
			customEndpoints: &corev1.Endpoints{
				ObjectMeta: metav1.ObjectMeta{
					Name: "test-123",
				},
				Subsets: []corev1.EndpointSubset{{
					Ports: []corev1.EndpointPort{{Port: 80}},
					Addresses: []corev1.EndpointAddress{{
						IP: "10.0.0.1",
					}},
				}},
			},
			expectEndpointSlice:          1,
			expectEndpointSliceManagedBy: "endpointslicemirroring-controller.k8s.io",
		},
		{
			testName: "Service without selector Endpoint multiple subsets and same address",
			service: &corev1.Service{
				ObjectMeta: metav1.ObjectMeta{
					Name: "test-123",
				},
				Spec: corev1.ServiceSpec{
					Ports: []corev1.ServicePort{{Port: int32(80)}},
				},
			},
			customEndpoints: &corev1.Endpoints{
				ObjectMeta: metav1.ObjectMeta{
					Name: "test-123",
				},
				Subsets: []corev1.EndpointSubset{
					{
						Ports:     []corev1.EndpointPort{{Name: "port1", Port: 80}},
						Addresses: []corev1.EndpointAddress{{IP: "10.0.0.1"}},
					},
					{
						Ports:     []corev1.EndpointPort{{Name: "port2", Port: 90}},
						Addresses: []corev1.EndpointAddress{{IP: "10.0.0.1"}},
					},
				},
			},
			expectEndpointSlice:          1,
			expectEndpointSliceManagedBy: "endpointslicemirroring-controller.k8s.io",
		},
		{
			testName: "Service without selector Endpoint multiple subsets",
			service: &corev1.Service{
				ObjectMeta: metav1.ObjectMeta{
					Name: "test-123",
				},
				Spec: corev1.ServiceSpec{
					Ports: []corev1.ServicePort{{Port: int32(80)}},
				},
			},
			customEndpoints: &corev1.Endpoints{
				ObjectMeta: metav1.ObjectMeta{
					Name: "test-123",
				},
				Subsets: []corev1.EndpointSubset{
					{
						Ports:     []corev1.EndpointPort{{Name: "port1", Port: 80}},
						Addresses: []corev1.EndpointAddress{{IP: "10.0.0.1"}},
					},
					{
						Ports:     []corev1.EndpointPort{{Name: "port2", Port: 90}},
						Addresses: []corev1.EndpointAddress{{IP: "10.0.0.2"}},
					},
				},
			},
			expectEndpointSlice:          2,
			expectEndpointSliceManagedBy: "endpointslicemirroring-controller.k8s.io",
		},
		{
			testName: "Service without Endpoints",
			service: &corev1.Service{
				ObjectMeta: metav1.ObjectMeta{
					Name: "test-123",
				},
				Spec: corev1.ServiceSpec{
					Ports: []corev1.ServicePort{{Port: int32(80)}},
					Selector: map[string]string{
						"foo": "bar",
					},
				},
			},
			customEndpoints:              nil,
			expectEndpointSlice:          1,
			expectEndpointSliceManagedBy: "endpointslice-controller.k8s.io",
		},
		{
			testName: "Endpoints without Service",
			service:  nil,
			customEndpoints: &corev1.Endpoints{
				ObjectMeta: metav1.ObjectMeta{
					Name: "test-123",
				},
				Subsets: []corev1.EndpointSubset{{
					Ports:     []corev1.EndpointPort{{Port: 80}},
					Addresses: []corev1.EndpointAddress{{IP: "10.0.0.1"}},
				}},
			},
			expectEndpointSlice: 0,
		},
		// Edge case: empty selector map
		{
			testName: "Service with empty selector map",
			service: &corev1.Service{
				ObjectMeta: metav1.ObjectMeta{
					Name: "test-123",
				},
				Spec: corev1.ServiceSpec{
					Ports:    []corev1.ServicePort{{Port: int32(80)}},
					Selector: map[string]string{},
				},
			},
			expectEndpointSlice:          1,
			expectEndpointSliceManagedBy: "endpointslice-controller.k8s.io",
		},
		// Edge case: service with nil ports (should produce no EndpointSlice)
		{
			testName: "Service with nil ports",
			service: &corev1.Service{
				ObjectMeta: metav1.ObjectMeta{
					Name: "test-123",
				},
				Spec: corev1.ServiceSpec{
					Ports:    nil,
					Selector: map[string]string{"foo": "bar"},
				},
			},
			expectEndpointSlice: 0,
		},
	}

	fmt.Println(ctestglobals.DebugPrefix(), "Number of test cases:", len(originalTestCases))

	for i, tc := range originalTestCases {
		t.Run(tc.testName, func(t *testing.T) {
			ns := framework.CreateNamespaceOrDie(client, fmt.Sprintf("test-endpointslice-mirroring-%d", i), t)
			defer framework.DeleteNamespaceOrDie(client, ns, t)

			resourceName := ""

			// ----- Service creation using dynamic base -----
			if tc.service != nil {
				svc := baseService.DeepCopy()
				svc.Name = tc.service.ObjectMeta.Name
				svc.Namespace = ns.Name
				svc.Spec.Ports = tc.service.Spec.Ports
				svc.Spec.Selector = tc.service.Spec.Selector
				resourceName = svc.Name
				_, err = client.CoreV1().Services(ns.Name).Create(tCtx, svc, metav1.CreateOptions{})
				if err != nil {
					t.Fatalf("Error creating service: %v", err)
				}
			}
			// ----- Endpoints creation using dynamic base -----
			if tc.customEndpoints != nil {
				ep := baseEndpoints.DeepCopy()
				ep.Name = tc.customEndpoints.ObjectMeta.Name
				ep.Namespace = ns.Name
				ep.Subsets = tc.customEndpoints.Subsets
				resourceName = ep.Name
				_, err = client.CoreV1().Endpoints(ns.Name).Create(tCtx, ep, metav1.CreateOptions{})
				if err != nil {
					t.Fatalf("Error creating endpoints: %v", err)
				}
			}

			err = wait.PollImmediate(1*time.Second, wait.ForeverTestTimeout, func() (bool, error) {
				lSelector := discovery.LabelServiceName + "=" + resourceName
				esList, err := client.DiscoveryV1().EndpointSlices(ns.Name).List(tCtx, metav1.ListOptions{LabelSelector: lSelector})
				if err != nil {
					t.Logf("Error listing EndpointSlices: %v", err)
					return false, err
				}

				if tc.expectEndpointSlice > 0 {
					if len(esList.Items) < tc.expectEndpointSlice {
						t.Logf("Waiting for EndpointSlice to be created")
						return false, nil
					}
					if len(esList.Items) != tc.expectEndpointSlice {
						return false, fmt.Errorf("Only expected %d EndpointSlice, got %d", tc.expectEndpointSlice, len(esList.Items))
					}
					endpointSlice := esList.Items[0]
					if tc.expectEndpointSliceManagedBy != "" && endpointSlice.Labels[discovery.LabelManagedBy] != tc.expectEndpointSliceManagedBy {
						return false, fmt.Errorf("Expected EndpointSlice to be managed by %s, got %s", tc.expectEndpointSliceManagedBy, endpointSlice.Labels[discovery.LabelManagedBy])
					}
				} else if len(esList.Items) > 0 {
					t.Logf("Waiting for EndpointSlices to be removed, still %d", len(esList.Items))
					return false, nil
				}
				return true, nil
			})
			if err != nil {
				t.Fatalf("Timed out waiting for conditions: %v", err)
			}
		})
	}
	fmt.Println(ctestglobals.EndSeparator)
}

func TestCtestEndpointSliceMirroringUpdates(t *testing.T) {
	// Disable ServiceAccount admission plugin as we don't have serviceaccount controller running.
	server := kubeapiservertesting.StartTestServerOrDie(t, nil, framework.DefaultTestServerFlags(), framework.SharedEtcd())
	defer server.TearDownFn()

	client, err := clientset.NewForConfig(server.ClientConfig)
	if err != nil {
		t.Fatalf("Error creating clientset: %v", err)
	}

	resyncPeriod := 12 * time.Hour
	informerFactory := informers.NewSharedInformerFactory(client, resyncPeriod)

	tCtx := ktesting.Init(t)
	epsmController := endpointslicemirroring.NewController(
		tCtx,
		informerFactory.Core().V1().Endpoints(),
		informerFactory.Discovery().V1().EndpointSlices(),
		informerFactory.Core().V1().Services(),
		int32(100),
		client,
		1*time.Second)

	// start informer & controller
	informerFactory.Start(tCtx.Done())
	go epsmController.Run(tCtx, 1)

	// dynamic base config for Endpoints
	fmt.Println(ctestglobals.StartSeparator)
	epItem, found := ctestutils.GetItemByExactTestInfo(getHardCodedConfigInfoEndpoints(), "default endpoints")
	if !found {
		t.Fatalf("default endpoints config not found")
	}
	baseEpObjs, epJson, err := ctest.GenerateEffectiveConfigReturnType[corev1.Endpoints](epItem, ctest.OverrideOnly)
	if err != nil {
		t.Fatalf("endpoints config generation failed: %v", err)
	}
	fmt.Println(ctestglobals.DebugPrefix(), "endpoints config json:", string(epJson))
	baseEndpoint := corev1.Endpoints{}
	if len(baseEpObjs) > 0 {
		baseEndpoint = baseEpObjs[0]
	}
	fmt.Println(ctestglobals.EndSeparator)

	testCases := []struct {
		testName      string
		tweakEndpoint func(ep *corev1.Endpoints)
	}{
		{
			testName: "Update labels",
			tweakEndpoint: func(ep *corev1.Endpoints) {
				if ep.Labels == nil {
					ep.Labels = map[string]string{}
				}
				ep.Labels["foo"] = "bar"
			},
		},
		{
			testName: "Update annotations",
			tweakEndpoint: func(ep *corev1.Endpoints) {
				if ep.Annotations == nil {
					ep.Annotations = map[string]string{}
				}
				ep.Annotations["foo2"] = "bar2"
			},
		},
		{
			testName: "Update annotations but triggertime",
			tweakEndpoint: func(ep *corev1.Endpoints) {
				if ep.Annotations == nil {
					ep.Annotations = map[string]string{}
				}
				ep.Annotations["foo2"] = "bar2"
				ep.Annotations[corev1.EndpointsLastChangeTriggerTime] = "date"
			},
		},
		{
			testName: "Update addresses",
			tweakEndpoint: func(ep *corev1.Endpoints) {
				ep.Subsets[0].Addresses = []corev1.EndpointAddress{{IP: "1.2.3.4"}, {IP: "1.2.3.6"}}
			},
		},
		// Edge case: remove all addresses
		{
			testName: "Remove all addresses",
			tweakEndpoint: func(ep *corev1.Endpoints) {
				ep.Subsets[0].Addresses = []corev1.EndpointAddress{}
			},
		},
	}

	for i, tc := range testCases {
		t.Run(tc.testName, func(t *testing.T) {
			ns := framework.CreateNamespaceOrDie(client, fmt.Sprintf("test-endpointslice-mirroring-%d", i), t)
			defer framework.DeleteNamespaceOrDie(client, ns, t)

			// create Service (static)
			service := &corev1.Service{
				ObjectMeta: metav1.ObjectMeta{
					Name:      "test-123",
					Namespace: ns.Name,
				},
				Spec: corev1.ServiceSpec{
					Ports: []corev1.ServicePort{{Port: int32(80)}},
				},
			}
			_, err = client.CoreV1().Services(ns.Name).Create(tCtx, service, metav1.CreateOptions{})
			if err != nil {
				t.Fatalf("Error creating service: %v", err)
			}

			// create Endpoints from dynamic base
			ep := baseEndpoint.DeepCopy()
			ep.Name = "test-123"
			ep.Namespace = ns.Name
			_, err = client.CoreV1().Endpoints(ns.Name).Create(tCtx, ep, metav1.CreateOptions{})
			if err != nil {
				t.Fatalf("Error creating endpoints: %v", err)
			}

			// apply tweak
			tc.tweakEndpoint(ep)
			_, err = client.CoreV1().Endpoints(ns.Name).Update(tCtx, ep, metav1.UpdateOptions{})
			if err != nil {
				t.Fatalf("Error updating endpoints: %v", err)
			}

			// verify mirroring
			err = wait.PollImmediate(1*time.Second, wait.ForeverTestTimeout, func() (bool, error) {
				lSelector := discovery.LabelServiceName + "=" + service.Name
				esList, err := client.DiscoveryV1().EndpointSlices(ns.Name).List(tCtx, metav1.ListOptions{LabelSelector: lSelector})
				if err != nil {
					t.Logf("Error listing EndpointSlices: %v", err)
					return false, err
				}
				if len(esList.Items) == 0 {
					t.Logf("Waiting for EndpointSlice to be created")
					return false, nil
				}
				for _, endpointSlice := range esList.Items {
					if endpointSlice.Labels[discovery.LabelManagedBy] != "endpointslicemirroring-controller.k8s.io" {
						return false, fmt.Errorf("Expected EndpointSlice managed by endpointslicemirroring-controller.k8s.io, got %s", endpointSlice.Labels[discovery.LabelManagedBy])
					}
					// compare addresses
					epAddresses := []string{}
					for _, a := range ep.Subsets[0].Addresses {
						epAddresses = append(epAddresses, a.IP)
					}
					sliceAddresses := []string{}
					for _, se := range endpointSlice.Endpoints {
						sliceAddresses = append(sliceAddresses, se.Addresses...)
					}
					sort.Strings(epAddresses)
					sort.Strings(sliceAddresses)
					if !apiequality.Semantic.DeepEqual(epAddresses, sliceAddresses) {
						t.Logf("Expected addresses %v, got %v", epAddresses, sliceAddresses)
						return false, nil
					}
					// check labels mirrored
					if !isSubset(ep.Labels, endpointSlice.Labels) {
						t.Logf("Expected labels %v to be subset of %v", ep.Labels, endpointSlice.Labels)
						return false, nil
					}
					// check annotations (excluding last change trigger time)
					expAnno := map[string]string{}
					for k, v := range ep.Annotations {
						if k == corev1.EndpointsLastChangeTriggerTime {
							continue
						}
						expAnno[k] = v
					}
					if !apiequality.Semantic.DeepEqual(expAnno, endpointSlice.Annotations) {
						t.Logf("Expected annotations %v, got %v", expAnno, endpointSlice.Annotations)
						return false, nil
					}
				}
				return true, nil
			})
			if err != nil {
				t.Fatalf("Timed out waiting for conditions: %v", err)
			}
		})
	}
}

func TestCtestEndpointSliceMirroringSelectorTransition(t *testing.T) {
	// Disable ServiceAccount admission plugin as we don't have serviceaccount controller running.
	server := kubeapiservertesting.StartTestServerOrDie(t, nil, framework.DefaultTestServerFlags(), framework.SharedEtcd())
	defer server.TearDownFn()

	client, err := clientset.NewForConfig(server.ClientConfig)
	if err != nil {
		t.Fatalf("Error creating clientset: %v", err)
	}

	resyncPeriod := 12 * time.Hour
	informerFactory := informers.NewSharedInformerFactory(client, resyncPeriod)

	tCtx := ktesting.Init(t)
	epsmController := endpointslicemirroring.NewController(
		tCtx,
		informerFactory.Core().V1().Endpoints(),
		informerFactory.Discovery().V1().EndpointSlices(),
		informerFactory.Core().V1().Services(),
		int32(100),
		client,
		1*time.Second)

	// start informer & controller
	informerFactory.Start(tCtx.Done())
	go epsmController.Run(tCtx, 1)

	// dynamic base configs
	fmt.Println(ctestglobals.StartSeparator)
	svcItem, found := ctestutils.GetItemByExactTestInfo(getHardCodedConfigInfoService(), "default service")
	if !found {
		t.Fatalf("default service config not found")
	}
	svcObjs, svcJson, err := ctest.GenerateEffectiveConfigReturnType[corev1.Service](svcItem, ctest.OverrideOnly)
	if err != nil {
		t.Fatalf("service config generation failed: %v", err)
	}
	fmt.Println(ctestglobals.DebugPrefix(), "service config json:", string(svcJson))

	epItem, found := ctestutils.GetItemByExactTestInfo(getHardCodedConfigInfoEndpoints(), "default endpoints")
	if !found {
		t.Fatalf("default endpoints config not found")
	}
	epObjs, epJson, err := ctest.GenerateEffectiveConfigReturnType[corev1.Endpoints](epItem, ctest.OverrideOnly)
	if err != nil {
		t.Fatalf("endpoints config generation failed: %v", err)
	}
	fmt.Println(ctestglobals.DebugPrefix(), "endpoints config json:", string(epJson))
	fmt.Println(ctestglobals.EndSeparator)

	baseService := corev1.Service{}
	if len(svcObjs) > 0 {
		baseService = svcObjs[0]
	}
	baseEndpoints := corev1.Endpoints{}
	if len(epObjs) > 0 {
		baseEndpoints = epObjs[0]
	}

	testCases := []struct {
		testName               string
		startingSelector       map[string]string
		startingMirroredSlices int
		endingSelector         map[string]string
		endingMirroredSlices   int
	}{
		{
			testName:               "nil -> {foo: bar} selector",
			startingSelector:       nil,
			startingMirroredSlices: 1,
			endingSelector:         map[string]string{"foo": "bar"},
			endingMirroredSlices:   0,
		},
		{
			testName:               "{foo: bar} -> nil selector",
			startingSelector:       map[string]string{"foo": "bar"},
			startingMirroredSlices: 0,
			endingSelector:         nil,
			endingMirroredSlices:   1,
		},
		{
			testName:               "{} -> {foo: bar} selector",
			startingSelector:       map[string]string{},
			startingMirroredSlices: 1,
			endingSelector:         map[string]string{"foo": "bar"},
			endingMirroredSlices:   0,
		},
		{
			testName:               "{foo: bar} -> {} selector",
			startingSelector:       map[string]string{"foo": "bar"},
			startingMirroredSlices: 0,
			endingSelector:         map[string]string{},
			endingMirroredSlices:   1,
		},
		// Edge case: transition from non-nil to empty map
		{
			testName:               "non-nil -> empty map selector",
			startingSelector:       map[string]string{"a": "b"},
			startingMirroredSlices: 0,
			endingSelector:         map[string]string{},
			endingMirroredSlices:   1,
		},
	}

	for i, tc := range testCases {
		t.Run(tc.testName, func(t *testing.T) {
			ns := framework.CreateNamespaceOrDie(client, fmt.Sprintf("test-endpointslice-mirroring-%d", i), t)
			defer framework.DeleteNamespaceOrDie(client, ns, t)

			// Service from dynamic base
			svc := baseService.DeepCopy()
			svc.Name = "test-123"
			svc.Namespace = ns.Name
			svc.Spec.Ports = []corev1.ServicePort{{Port: int32(80)}}
			svc.Spec.Selector = tc.startingSelector
			_, err = client.CoreV1().Services(ns.Name).Create(context.TODO(), svc, metav1.CreateOptions{})
			if err != nil {
				t.Fatalf("Error creating service: %v", err)
			}

			// Endpoints from dynamic base
			ep := baseEndpoints.DeepCopy()
			ep.Name = "test-123"
			ep.Namespace = ns.Name
			ep.Subsets = []corev1.EndpointSubset{{
				Ports:     []corev1.EndpointPort{{Port: 80}},
				Addresses: []corev1.EndpointAddress{{IP: "10.0.0.1"}},
			}}
			_, err = client.CoreV1().Endpoints(ns.Name).Create(context.TODO(), ep, metav1.CreateOptions{})
			if err != nil {
				t.Fatalf("Error creating endpoints: %v", err)
			}

			// verify initial mirrored slices
			if err = waitForMirroredSlices(t, client, ns.Name, svc.Name, tc.startingMirroredSlices); err != nil {
				t.Fatalf("Timed out waiting for initial mirrored slices: %v", err)
			}

			// update selector
			svc.Spec.Selector = tc.endingSelector
			_, err = client.CoreV1().Services(ns.Name).Update(context.TODO(), svc, metav1.UpdateOptions{})
			if err != nil {
				t.Fatalf("Error updating service: %v", err)
			}

			// verify final mirrored slices
			if err = waitForMirroredSlices(t, client, ns.Name, svc.Name, tc.endingMirroredSlices); err != nil {
				t.Fatalf("Timed out waiting for final mirrored slices: %v", err)
			}
		})
	}
}

// Helper to retrieve hard‑coded Service config.
func getHardCodedConfigInfoService() ctestglobals.HardcodedConfig {
	return ctestglobals.HardcodedConfig{
		{
			FixtureFileName: "test_fixture.json",
			TestInfo:        []string{"default service"},
			Field:           "spec",
			K8sObjects:      []string{"services"},
			HardcodedConfig: corev1.Service{
				Spec: corev1.ServiceSpec{
					Ports: []corev1.ServicePort{{Port: int32(80)}},
				},
			},
		},
	}
}

// Helper to retrieve hard‑coded Endpoints config.
func getHardCodedConfigInfoEndpoints() ctestglobals.HardcodedConfig {
	return ctestglobals.HardcodedConfig{
		{
			FixtureFileName: "test_fixture.json",
			TestInfo:        []string{"default endpoints"},
			Field:           "subsets",
			K8sObjects:      []string{"endpoints"},
			HardcodedConfig: corev1.Endpoints{
				Subsets: []corev1.EndpointSubset{{
					Ports:     []corev1.EndpointPort{{Port: 80}},
					Addresses: []corev1.EndpointAddress{{IP: "10.0.0.1"}},
				}},
			},
		},
	}
}
