package endpointslice

import (
	"context"
	"fmt"
	"reflect"
	"testing"
	"time"

	corev1 "k8s.io/api/core/v1"
	discovery "k8s.io/api/discovery/v1"
	metav1 "k8s.io/apimachinery/pkg/apis/meta/v1"
	"k8s.io/apimachinery/pkg/util/intstr"
	"k8s.io/apimachinery/pkg/util/wait"
	"k8s.io/client-go/informers"
	clientset "k8s.io/client-go/kubernetes"
	kubeapiservertesting "k8s.io/kubernetes/cmd/kube-apiserver/app/testing"
	"k8s.io/kubernetes/pkg/controller/endpointslice"
	"k8s.io/kubernetes/test/integration/framework"
	"k8s.io/kubernetes/test/utils/ktesting"
	"k8s.io/utils/ptr"

	// "github.com/onsi/ginkgo/v2"
	// "github.com/onsi/gomega"

	ctest "k8s.io/kubernetes/test/ctest"
	ctestglobals "k8s.io/kubernetes/test/ctest/ctestglobals"
	ctestutils "k8s.io/kubernetes/test/ctest/utils"
	// "k8s.io/apimachinery/pkg/util/uuid"
)

// TestCtestEndpointSliceTerminating rewrites the original test to use dynamic configuration
// and adds edge cases for pod status.
func TestCtestEndpointSliceTerminating(t *testing.T) {
	fmt.Println(ctestglobals.StartOverrideModeSeparator)

	// Retrieve hard‑coded pod statuses from fixtures.
	hardcoded := getHardCodedConfigInfoEndpointSliceTerminating()
	testInfos := []string{
		"ready terminating pod",
		"not ready terminating pod",
	}
	var podStatuses []corev1.PodStatus
	for _, ti := range testInfos {
		item, found := ctestutils.GetItemByExactTestInfo(hardcoded, ti)
		if !found {
			fmt.Println(ctestglobals.DebugPrefix(), "fixture not found for", ti)
			continue
		}
		objs, cfgJSON, err := ctest.GenerateEffectiveConfigReturnType[corev1.PodStatus](item, ctest.OverrideOnly)
		if err != nil {
			fmt.Println(ctestglobals.DebugPrefix(), "failed to generate config:", err)
			continue
		}
		fmt.Println(ctestglobals.DebugPrefix(), "generated config JSON:", string(cfgJSON))
		if len(objs) > 0 {
			podStatuses = append(podStatuses, objs[0])
		}
	}
	if podStatuses == nil {
		fmt.Println(ctestglobals.DebugPrefix(), "Skipping test execution. No new configurations generated.")
		return
	}
	fmt.Println(ctestglobals.DebugPrefix(), "Number of generated pod status configs:", len(podStatuses))

	// Build test cases from generated pod statuses and add edge case.
	type testCase struct {
		name              string
		podStatus         corev1.PodStatus
		expectedEndpoints []discovery.Endpoint
	}
	var testcases []testCase

	// Helper to compute expected EndpointSlice from pod status.
	computeExpected := func(name string, status corev1.PodStatus) []discovery.Endpoint {
		if status.PodIP == "" {
			return []discovery.Endpoint{}
		}
		ready := false
		for _, c := range status.Conditions {
			if c.Type == corev1.PodReady && c.Status == corev1.ConditionTrue {
				ready = true
				break
			}
		}
		serving := ready
		return []discovery.Endpoint{
			{
				Addresses: []string{status.PodIP},
				Conditions: discovery.EndpointConditions{
					Ready:       ptr.To(false),
					Serving:     ptr.To(serving),
					Terminating: ptr.To(true),
				},
			},
		}
	}

	// Create test cases from generated configs.
	for i, ps := range podStatuses {
		name := fmt.Sprintf("generated case %d", i)
		testcases = append(testcases, testCase{
			name:              name,
			podStatus:         ps,
			expectedEndpoints: computeExpected(name, ps),
		})
	}

	// Edge case: pod with empty IP and no conditions.
	emptyStatus := corev1.PodStatus{
		Phase: corev1.PodRunning,
	}
	testcases = append(testcases, testCase{
		name:              "edge case empty pod IP",
		podStatus:         emptyStatus,
		expectedEndpoints: []discovery.Endpoint{},
	})

	for _, testcase := range testcases {
		t.Run(testcase.name, func(t *testing.T) {
			// Disable ServiceAccount admission plugin as we don't have serviceaccount controller running.
			server := kubeapiservertesting.StartTestServerOrDie(t, nil, framework.DefaultTestServerFlags(), framework.SharedEtcd())
			defer server.TearDownFn()

			client, err := clientset.NewForConfig(server.ClientConfig)
			if err != nil {
				t.Fatalf("Error creating clientset: %v", err)
			}

			resyncPeriod := 12 * time.Hour
			informers := informers.NewSharedInformerFactory(client, resyncPeriod)

			tCtx := ktesting.Init(t)
			epsController := endpointslice.NewController(
				tCtx,
				informers.Core().V1().Pods(),
				informers.Core().V1().Services(),
				informers.Core().V1().Nodes(),
				informers.Discovery().V1().EndpointSlices(),
				int32(100),
				client,
				1*time.Second)

			// Start informer and controllers
			informers.Start(tCtx.Done())
			go epsController.Run(tCtx, 1)

			// Create namespace
			ns := framework.CreateNamespaceOrDie(client, "test-endpoints-terminating", t)
			defer framework.DeleteNamespaceOrDie(client, ns, t)

			node := &corev1.Node{
				ObjectMeta: metav1.ObjectMeta{
					Name: "fake-node",
				},
			}

			_, err = client.CoreV1().Nodes().Create(context.TODO(), node, metav1.CreateOptions{})
			if err != nil {
				t.Fatalf("Failed to create test node: %v", err)
			}

			svc := &corev1.Service{
				ObjectMeta: metav1.ObjectMeta{
					Name:      "test-service",
					Namespace: ns.Name,
					Labels: map[string]string{
						"foo": "bar",
					},
				},
				Spec: corev1.ServiceSpec{
					Selector: map[string]string{
						"foo": "bar",
					},
					Ports: []corev1.ServicePort{
						{Name: "port-443", Port: 443, Protocol: "TCP", TargetPort: intstr.FromInt32(443)},
					},
				},
			}

			_, err = client.CoreV1().Services(ns.Name).Create(context.TODO(), svc, metav1.CreateOptions{})
			if err != nil {
				t.Fatalf("Failed to create test Service: %v", err)
			}

			pod := &corev1.Pod{
				ObjectMeta: metav1.ObjectMeta{
					Name: "test-pod",
					Labels: map[string]string{
						"foo": "bar",
					},
				},
				Spec: corev1.PodSpec{
					NodeName: "fake-node",
					Containers: []corev1.Container{
						{
							Name:  "fakename",
							Image: "fakeimage",
							Ports: []corev1.ContainerPort{
								{
									Name:          "port-443",
									ContainerPort: 443,
								},
							},
						},
					},
				},
			}

			pod, err = client.CoreV1().Pods(ns.Name).Create(context.TODO(), pod, metav1.CreateOptions{})
			if err != nil {
				t.Fatalf("Failed to create test ready pod: %v", err)
			}

			// Apply dynamically generated pod status.
			pod.Status = testcase.podStatus
			_, err = client.CoreV1().Pods(ns.Name).UpdateStatus(context.TODO(), pod, metav1.UpdateOptions{})
			if err != nil {
				t.Fatalf("Failed to update status for test pod: %v", err)
			}

			// first check that endpoints are included, test should always have 1 initial endpoint
			err = wait.PollImmediate(1*time.Second, 10*time.Second, func() (bool, error) {
				esList, err := client.DiscoveryV1().EndpointSlices(ns.Name).List(context.TODO(), metav1.ListOptions{
					LabelSelector: discovery.LabelServiceName + "=" + svc.Name,
				})

				if err != nil {
					return false, err
				}

				if len(esList.Items) == 0 {
					return false, nil
				}

				numEndpoints := 0
				for _, slice := range esList.Items {
					numEndpoints += len(slice.Endpoints)
				}

				if numEndpoints > 0 {
					return true, nil
				}

				return false, nil
			})
			if err != nil {
				t.Errorf("Error waiting for endpoint slices: %v", err)
			}

			// Delete pod and check endpoints slice conditions
			err = client.CoreV1().Pods(ns.Name).Delete(context.TODO(), pod.Name, metav1.DeleteOptions{})
			if err != nil {
				t.Fatalf("Failed to delete pod in terminating state: %v", err)
			}

			// Validate that terminating the endpoint will result in the expected endpoints in EndpointSlice.
			var endpoints []discovery.Endpoint
			err = wait.PollImmediate(1*time.Second, 10*time.Second, func() (bool, error) {
				esList, err := client.DiscoveryV1().EndpointSlices(ns.Name).List(context.TODO(), metav1.ListOptions{
					LabelSelector: discovery.LabelServiceName + "=" + svc.Name,
				})

				if err != nil {
					return false, err
				}

				if len(esList.Items) == 0 {
					return false, nil
				}

				endpoints = esList.Items[0].Endpoints
				if len(endpoints) != len(testcase.expectedEndpoints) {
					return false, nil
				}
				if len(endpoints) == 0 && len(testcase.expectedEndpoints) == 0 {
					return true, nil
				}
				if !reflect.DeepEqual(endpoints[0].Addresses, testcase.expectedEndpoints[0].Addresses) {
					return false, nil
				}
				if !reflect.DeepEqual(endpoints[0].Conditions, testcase.expectedEndpoints[0].Conditions) {
					return false, nil
				}
				return true, nil
			})
			if err != nil {
				t.Logf("actual endpoints: %v", endpoints)
				t.Logf("expected endpoints: %v", testcase.expectedEndpoints)
				t.Errorf("unexpected endpoints: %v", err)
			}
		})
	}
	fmt.Println(ctestglobals.EndSeparator)
}

// getHardCodedConfigInfoEndpointSliceTerminating provides hard‑coded pod statuses
// used by the dynamic test above.
func getHardCodedConfigInfoEndpointSliceTerminating() ctestglobals.HardcodedConfig {
	return ctestglobals.HardcodedConfig{
		{
			FixtureFileName: "test_fixture.json",
			TestInfo:        []string{"ready terminating pod"},
			Field:           "status",
			K8sObjects:      []string{"pods"},
			HardcodedConfig: corev1.PodStatus{
				Phase: corev1.PodRunning,
				Conditions: []corev1.PodCondition{
					{
						Type:   corev1.PodReady,
						Status: corev1.ConditionTrue,
					},
				},
				PodIP: "10.0.0.1",
				PodIPs: []corev1.PodIP{
					{IP: "10.0.0.1"},
				},
			},
		},
		{
			FixtureFileName: "test_fixture.json",
			TestInfo:        []string{"not ready terminating pod"},
			Field:           "status",
			K8sObjects:      []string{"pods"},
			HardcodedConfig: corev1.PodStatus{
				Phase: corev1.PodRunning,
				Conditions: []corev1.PodCondition{
					{
						Type:   corev1.PodReady,
						Status: corev1.ConditionFalse,
					},
				},
				PodIP: "10.0.0.1",
				PodIPs: []corev1.PodIP{
					{IP: "10.0.0.1"},
				},
			},
		},
	}
}
