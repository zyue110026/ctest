package configmap

import (
	"context"
	"fmt"
	"testing"

	"k8s.io/api/core/v1"
	metav1 "k8s.io/apimachinery/pkg/apis/meta/v1"
	"k8s.io/apimachinery/pkg/util/uuid"
	clientset "k8s.io/client-go/kubernetes"
	kubeapiservertesting "k8s.io/kubernetes/cmd/kube-apiserver/app/testing"
	"k8s.io/kubernetes/test/integration"
	itframework "k8s.io/kubernetes/test/integration/framework"

	ctest "k8s.io/kubernetes/test/ctest"
	ctestglobals "k8s.io/kubernetes/test/ctest/ctestglobals"
	ctestutils "k8s.io/kubernetes/test/ctest/utils"
)

func TestCtestConfigMap(t *testing.T) {
	fmt.Println(ctestglobals.StartSeparator)

	// start test server
	server := kubeapiservertesting.StartTestServerOrDie(t, nil, itframework.DefaultTestServerFlags(), itframework.SharedEtcd())
	defer server.TearDownFn()

	client := clientset.NewForConfigOrDie(server.ClientConfig)

	ns := itframework.CreateNamespaceOrDie(client, "config-map", t)
	defer itframework.DeleteNamespaceOrDie(client, ns, t)

	// ----------- ConfigMap Data Configurations -----------
	cfgDataObjs, cfgDataJSON, err := getConfigMapDataFromFixtureOverrideMode("default configmap data")
	if err != nil {
		t.Fatalf("failed to get configmap data fixtures: %v", err)
	}
	if cfgDataObjs == nil {
		fmt.Println(ctestglobals.DebugPrefix(), "Skipping ConfigMap data driven part: no fixtures")
	}
	fmt.Println(ctestglobals.DebugPrefix(), "ConfigMap data JSON:", string(cfgDataJSON))
	fmt.Println(ctestglobals.DebugPrefix(), "Number of ConfigMap data test cases:", len(cfgDataObjs))

	// add edge case manually if not present
	edgeCfgData := []map[string]string{
		{},                // empty data map
		{"empty-key": ""}, // key with empty value
	}
	cfgDataObjs = append(cfgDataObjs, edgeCfgData...)

	// ----------- PodSpec Configurations -----------
	podSpecObjs, podSpecJSON, err := getPodSpecFromFixtureOverrideMode("default pod spec")
	if err != nil {
		t.Fatalf("failed to get podspec fixtures: %v", err)
	}
	if podSpecObjs == nil {
		fmt.Println(ctestglobals.DebugPrefix(), "Skipping PodSpec driven part: no fixtures")
	}
	fmt.Println(ctestglobals.DebugPrefix(), "PodSpec JSON:", string(podSpecJSON))
	fmt.Println(ctestglobals.DebugPrefix(), "Number of PodSpec test cases:", len(podSpecObjs))

	// edge podspecs
	edgePodSpecs := []v1.PodSpec{
		{
			Containers: []v1.Container{
				{
					Name:  "no-env-container",
					Image: "busybox",
				},
			},
			RestartPolicy: v1.RestartPolicyNever,
		},
	}
	podSpecObjs = append(podSpecObjs, edgePodSpecs...)

	// Run matrix of ConfigMap data x PodSpec
	for i, cfgData := range cfgDataObjs {
		cmName := "configmap-" + string(uuid.NewUUID())
		cm := &v1.ConfigMap{
			ObjectMeta: metav1.ObjectMeta{
				Name:      cmName,
				Namespace: ns.Name,
			},
			Data: cfgData,
		}
		if _, err := client.CoreV1().ConfigMaps(cm.Namespace).Create(context.TODO(), cm, metav1.CreateOptions{}); err != nil {
			t.Fatalf("failed to create ConfigMap %s: %v", cmName, err)
		}
		defer deleteConfigMapOrErrorf(t, client, cm.Namespace, cm.Name)

		for j, podSpec := range podSpecObjs {
			fmt.Printf("Running ConfigMap case %d / PodSpec case %d\n", i, j)
			// Ensure pod name is unique
			podName := "pod-" + string(uuid.NewUUID())
			// Override Env references to use the current ConfigMap name
			if len(podSpec.Containers) > 0 {
				env := []v1.EnvVar{
					{
						Name: "CONFIG_DATA_1",
						ValueFrom: &v1.EnvVarSource{
							ConfigMapKeyRef: &v1.ConfigMapKeySelector{
								LocalObjectReference: v1.LocalObjectReference{Name: cmName},
								Key:                  "data-1",
							},
						},
					},
					{
						Name: "CONFIG_DATA_2",
						ValueFrom: &v1.EnvVarSource{
							ConfigMapKeyRef: &v1.ConfigMapKeySelector{
								LocalObjectReference: v1.LocalObjectReference{Name: cmName},
								Key:                  "data-2",
							},
						},
					},
					{
						Name: "CONFIG_DATA_3",
						ValueFrom: &v1.EnvVarSource{
							ConfigMapKeyRef: &v1.ConfigMapKeySelector{
								LocalObjectReference: v1.LocalObjectReference{Name: cmName},
								Key:                  "data-3",
							},
						},
					},
				}
				podSpec.Containers[0].Env = env
			}
			podSpec.Containers[0].Image = "busybox"
			pod := &v1.Pod{
				ObjectMeta: metav1.ObjectMeta{
					Name:      podName,
					Namespace: ns.Name,
				},
				Spec: podSpec,
			}
			if _, err := client.CoreV1().Pods(ns.Name).Create(context.TODO(), pod, metav1.CreateOptions{}); err != nil {
				t.Fatalf("failed to create pod %s: %v", podName, err)
			}
			defer integration.DeletePodOrErrorf(t, client, ns.Name, pod.Name)
		}
	}
	fmt.Println(ctestglobals.EndSeparator)
}

// Hardcoded ConfigInfo for ConfigMap Data
func getHardCodedConfigInfoConfigMapData() ctestglobals.HardcodedConfig {
	return ctestglobals.HardcodedConfig{
		{
			FixtureFileName: "test_fixture.json",
			TestInfo:        []string{"default configmap data"},
			Field:           "data",
			K8sObjects: []string{
				"configmaps",
			},
			HardcodedConfig: map[string]string{
				"data-1": "value-1",
				"data-2": "value-2",
				"data-3": "value-3",
			},
		},
	}
}

// Hardcoded ConfigInfo for PodSpec used in the test
func getHardCodedConfigInfoPodSpec() ctestglobals.HardcodedConfig {
	return ctestglobals.HardcodedConfig{
		{
			FixtureFileName: "test_fixture.json",
			TestInfo:        []string{"default pod spec"},
			Field:           "spec",
			K8sObjects: []string{
				"pods",
				"deployments",
				"statefulsets",
				"daemonsets",
				"replicasets",
			},
			HardcodedConfig: v1.PodSpec{
				Containers: []v1.Container{
					{
						Name:  "test-container",
						Image: "busybox",
					},
				},
				RestartPolicy: v1.RestartPolicyNever,
			},
		},
	}
}

// Retrieve ConfigMap data fixtures using OverrideOnly mode
func getConfigMapDataFromFixtureOverrideMode(testinfo string) ([]map[string]string, []byte, error) {
	hc := getHardCodedConfigInfoConfigMapData()
	item, found := ctestutils.GetItemByExactTestInfo(hc, testinfo)
	if !found {
		fmt.Println(ctestglobals.DebugPrefix(), "Failed to find config item by TestInfo")
		return nil, nil, fmt.Errorf("hardcoded config not found")
	}
	fmt.Println(ctestglobals.DebugPrefix(), "matched config item:", item)
	fmt.Println(ctestglobals.StartOverrideModeSeparator)
	objs, jsonData, err := ctest.GenerateEffectiveConfigReturnType[map[string]string](item, ctest.OverrideOnly)
	if err != nil {
		fmt.Println(ctestglobals.DebugPrefix(), "failed to generate config:", err)
		return nil, nil, err
	}
	return objs, jsonData, nil
}

// Retrieve PodSpec fixtures using OverrideOnly mode
func getPodSpecFromFixtureOverrideMode(testinfo string) ([]v1.PodSpec, []byte, error) {
	hc := getHardCodedConfigInfoPodSpec()
	item, found := ctestutils.GetItemByExactTestInfo(hc, testinfo)
	if !found {
		fmt.Println(ctestglobals.DebugPrefix(), "Failed to find config item by TestInfo")
		return nil, nil, fmt.Errorf("hardcoded config not found")
	}
	fmt.Println(ctestglobals.DebugPrefix(), "matched config item:", item)
	fmt.Println(ctestglobals.StartOverrideModeSeparator)
	objs, jsonData, err := ctest.GenerateEffectiveConfigReturnType[v1.PodSpec](item, ctest.OverrideOnly)
	if err != nil {
		fmt.Println(ctestglobals.DebugPrefix(), "failed to generate config:", err)
		return nil, nil, err
	}
	return objs, jsonData, nil
}
