package quota

import (
	"context"
	// "errors"
	"fmt"
	"os"
	"testing"
	"time"

	// "k8s.io/apimachinery/pkg/api/errors"
	"k8s.io/apimachinery/pkg/api/resource"
	metav1 "k8s.io/apimachinery/pkg/apis/meta/v1"
	"k8s.io/apimachinery/pkg/util/uuid"
	"k8s.io/apimachinery/pkg/util/wait"
	"k8s.io/apimachinery/pkg/watch"
	"k8s.io/client-go/informers"
	clientset "k8s.io/client-go/kubernetes"
	watchtools "k8s.io/client-go/tools/watch"
	"k8s.io/kubernetes/cmd/kube-apiserver/app/options"
	"k8s.io/kubernetes/pkg/controller"
	replicationcontroller "k8s.io/kubernetes/pkg/controller/replication"
	resourcequotacontroller "k8s.io/kubernetes/pkg/controller/resourcequota"
	quotainstall "k8s.io/kubernetes/pkg/quota/v1/install"
	"k8s.io/kubernetes/test/integration/framework"
	"k8s.io/kubernetes/test/utils/ktesting"

	v1 "k8s.io/api/core/v1"
	"k8s.io/apiserver/pkg/quota/v1/generic"

	ctest "k8s.io/kubernetes/test/ctest"
	ctestglobals "k8s.io/kubernetes/test/ctest/ctestglobals"
	ctestutils "k8s.io/kubernetes/test/ctest/utils"
)

// ---------- TestQuota ----------

func TestCtestQuota(t *testing.T) {
	ctx := ktesting.Init(t)

	_, kubeConfig, tearDownFn := framework.StartTestServer(ctx, t, framework.TestServerSetup{
		ModifyServerRunOptions: func(opts *options.ServerRunOptions) {
			opts.Admission.GenericAdmission.DisablePlugins = []string{"ServiceAccount"}
		},
	})
	defer tearDownFn()

	cs := clientset.NewForConfigOrDie(kubeConfig)

	ns := framework.CreateNamespaceOrDie(cs, "quotaed", t)
	defer framework.DeleteNamespaceOrDie(cs, ns, t)
	ns2 := framework.CreateNamespaceOrDie(cs, "non-quotaed", t)
	defer framework.DeleteNamespaceOrDie(cs, ns2, t)

	informerFactory := informers.NewSharedInformerFactory(cs, controller.NoResyncPeriodFunc())
	rm := replicationcontroller.NewReplicationManager(
		ctx,
		informerFactory.Core().V1().Pods(),
		informerFactory.Core().V1().ReplicationControllers(),
		cs,
		replicationcontroller.BurstReplicas,
	)
	go rm.Run(ctx, 3)

	discoveryFunc := cs.Discovery().ServerPreferredNamespacedResources
	listerFunc := generic.ListerFuncForResourceFunc(informerFactory.ForResource)
	qc := quotainstall.NewQuotaConfigurationForControllers(listerFunc)

	informersStarted := make(chan struct{})
	rqOpts := &resourcequotacontroller.ControllerOptions{
		QuotaClient:               cs.CoreV1(),
		ResourceQuotaInformer:     informerFactory.Core().V1().ResourceQuotas(),
		ResyncPeriod:              controller.NoResyncPeriodFunc,
		InformerFactory:           informerFactory,
		ReplenishmentResyncPeriod: controller.NoResyncPeriodFunc,
		DiscoveryFunc:             discoveryFunc,
		IgnoredResourcesFunc:      qc.IgnoredResources,
		InformersStarted:          informersStarted,
		Registry:                  generic.NewRegistry(qc.Evaluators()),
	}
	rqCtrl, err := resourcequotacontroller.NewController(ctx, rqOpts)
	if err != nil {
		t.Fatalf("unexpected err: %v", err)
	}
	go rqCtrl.Run(ctx, 2)
	go rqCtrl.Sync(ctx, discoveryFunc, 30*time.Second)

	informerFactory.Start(ctx.Done())
	close(informersStarted)

	// ---------- scale without quota ----------
	start := time.Now()
	scaleWithDynamicSpec(t, ns2.Name, cs, getHardCodedConfigInfoRC())
	end := time.Now()
	t.Logf("Took %v to scale up without quota", end.Sub(start))

	// ---------- create quota ----------
	quotaSpecObjs, quotaJson, err := ctest.GenerateEffectiveConfigReturnType[v1.ResourceQuotaSpec](getHardCodedConfigInfoQuota(), ctest.ExtendOnly)
	if err != nil {
		t.Fatalf("failed to generate quota spec: %v", err)
	}
	if quotaSpecObjs == nil {
		fmt.Println(ctestglobals.DebugPrefix(), "Skipping quota creation, no generated config")
	} else {
		fmt.Println(ctestglobals.DebugPrefix(), "New Json Quota Configs:", string(quotaJson))
		for _, qs := range quotaSpecObjs {
			quota := &v1.ResourceQuota{
				ObjectMeta: metav1.ObjectMeta{
					Name:      "quota",
					Namespace: ns.Name,
				},
				Spec: qs,
			}
			waitForQuota(t, quota, cs)
		}
	}

	// ---------- scale with quota ----------
	start = time.Now()
	scaleWithDynamicSpec(t, "quotaed", cs, getHardCodedConfigInfoRC())
	end = time.Now()
	t.Logf("Took %v to scale up with quota", end.Sub(start))
}

// scaleWithDynamicSpec creates a ReplicationController from dynamically generated
// ReplicationControllerSpec(s) and watches until the desired replica count is reached.
func scaleWithDynamicSpec(t *testing.T, namespace string, cs *clientset.Clientset, cfgInfo ctestglobals.HardcodedConfig) {
	fmt.Println(ctestglobals.StartExtendModeSeparator)
	fmt.Println(ctestglobals.DebugPrefix(), "Fetching RC config")
	item, found := ctestutils.GetItemByExactTestInfo(cfgInfo, "default rc spec")
	if !found {
		fmt.Println(ctestglobals.DebugPrefix(), "Failed to find RC config")
		t.Fatalf("hardcoded RC config missing")
	}
	fmt.Println(ctestglobals.DebugPrefix(), "RC config item:", item)

	specObjs, specJson, err := ctest.GenerateEffectiveConfigReturnType[v1.ReplicationControllerSpec](item, ctest.ExtendOnly)
	if err != nil {
		t.Fatalf("error generating RC specs: %v", err)
	}
	if specObjs == nil {
		fmt.Println(ctestglobals.DebugPrefix(), "Skipping RC creation, no generated specs")
		return
	}
	fmt.Println(ctestglobals.DebugPrefix(), "New Json RC Specs:", string(specJson))
	fmt.Println(ctestglobals.DebugPrefix(), "Number of RC specs:", len(specObjs))

	for i, rcSpec := range specObjs {
		fmt.Printf("Running %d th RC spec\n", i)
		rcName := "rc-" + string(uuid.NewUUID())
		rc := &v1.ReplicationController{
			ObjectMeta: metav1.ObjectMeta{
				Name:      rcName,
				Namespace: namespace,
			},
			Spec: rcSpec,
		}
		w, err := cs.CoreV1().ReplicationControllers(namespace).Watch(context.TODO(),
			metav1.SingleObject(metav1.ObjectMeta{Name: rc.Name}))
		if err != nil {
			t.Fatalf("watch error: %v", err)
		}
		if _, err := cs.CoreV1().ReplicationControllers(namespace).Create(context.TODO(), rc, metav1.CreateOptions{}); err != nil {
			t.Fatalf("create rc error: %v", err)
		}
		ctx, cancel := context.WithTimeout(context.Background(), 3*time.Minute)
		defer cancel()
		_, err = watchtools.UntilWithoutRetry(ctx, w, func(event watch.Event) (bool, error) {
			if event.Type != watch.Modified {
				return false, nil
			}
			casted, ok := event.Object.(*v1.ReplicationController)
			if !ok {
				return false, nil
			}
			target := int32(100)
			if casted.Status.Replicas == target {
				return true, nil
			}
			fmt.Printf("Found %d of %d replicas\n", casted.Status.Replicas, target)
			return false, nil
		})
		if err != nil {
			pods, _ := cs.CoreV1().Pods(namespace).List(context.TODO(),
				metav1.ListOptions{LabelSelector: "", FieldSelector: ""})
			t.Fatalf("scale error: %v, ended with %d pods", err, len(pods.Items))
		}
	}
}

// ---------- TestQuotaLimitedResourceDenial ----------

func TestCtestQuotaLimitedResourceDenial(t *testing.T) {
	admissionConfigFile, err := os.CreateTemp("", "admission-config.yaml")
	if err != nil {
		t.Fatal(err)
	}
	defer os.Remove(admissionConfigFile.Name())
	if err := os.WriteFile(admissionConfigFile.Name(), []byte(`
apiVersion: apiserver.k8s.io/v1alpha1
kind: AdmissionConfiguration
plugins:
- name: ResourceQuota
  configuration:
    apiVersion: apiserver.config.k8s.io/v1
    kind: ResourceQuotaConfiguration
    limitedResources:
    - resource: pods
      matchContains:
      - pods
`), 0644); err != nil {
		t.Fatal(err)
	}

	tCtx := ktesting.Init(t)

	_, kubeConfig, tearDownFn := framework.StartTestServer(tCtx, t, framework.TestServerSetup{
		ModifyServerRunOptions: func(opts *options.ServerRunOptions) {
			opts.Admission.GenericAdmission.DisablePlugins = []string{"ServiceAccount"}
			opts.Admission.GenericAdmission.ConfigFile = admissionConfigFile.Name()
		},
	})
	defer tearDownFn()

	cs := clientset.NewForConfigOrDie(kubeConfig)

	ns := framework.CreateNamespaceOrDie(cs, "quota", t)
	defer framework.DeleteNamespaceOrDie(cs, ns, t)

	informerFactory := informers.NewSharedInformerFactory(cs, controller.NoResyncPeriodFunc())
	rm := replicationcontroller.NewReplicationManager(
		tCtx,
		informerFactory.Core().V1().Pods(),
		informerFactory.Core().V1().ReplicationControllers(),
		cs,
		replicationcontroller.BurstReplicas,
	)
	go rm.Run(tCtx, 3)

	discoveryFunc := cs.Discovery().ServerPreferredNamespacedResources
	listerFunc := generic.ListerFuncForResourceFunc(informerFactory.ForResource)
	qc := quotainstall.NewQuotaConfigurationForControllers(listerFunc)

	informersStarted := make(chan struct{})
	rqOpts := &resourcequotacontroller.ControllerOptions{
		QuotaClient:               cs.CoreV1(),
		ResourceQuotaInformer:     informerFactory.Core().V1().ResourceQuotas(),
		ResyncPeriod:              controller.NoResyncPeriodFunc,
		InformerFactory:           informerFactory,
		ReplenishmentResyncPeriod: controller.NoResyncPeriodFunc,
		DiscoveryFunc:             discoveryFunc,
		IgnoredResourcesFunc:      qc.IgnoredResources,
		InformersStarted:          informersStarted,
		Registry:                  generic.NewRegistry(qc.Evaluators()),
	}
	rqCtrl, err := resourcequotacontroller.NewController(tCtx, rqOpts)
	if err != nil {
		t.Fatalf("unexpected err: %v", err)
	}
	go rqCtrl.Run(tCtx, 2)
	go rqCtrl.Sync(tCtx, discoveryFunc, 30*time.Second)

	informerFactory.Start(tCtx.Done())
	close(informersStarted)

	// ---------- create pod ----------
	podSpecs, podJson, err := ctest.GenerateEffectiveConfigReturnType[v1.PodSpec](getHardCodedConfigInfoLimitedPod(), ctest.ExtendOnly)
	if err != nil {
		t.Fatalf("failed to generate pod spec: %v", err)
	}
	if podSpecs == nil {
		fmt.Println(ctestglobals.DebugPrefix(), "Skipping pod creation, no generated spec")
	} else {
		fmt.Println(ctestglobals.DebugPrefix(), "New Json Pod Specs:", string(podJson))
		for _, ps := range podSpecs {
			pod := &v1.Pod{
				ObjectMeta: metav1.ObjectMeta{
					Name:      "foo-" + string(uuid.NewUUID()),
					Namespace: ns.Name,
				},
				Spec: ps,
			}
			if _, err := cs.CoreV1().Pods(ns.Name).Create(tCtx, pod, metav1.CreateOptions{}); err == nil {
				t.Fatalf("expected error for insufficient quota")
			}
		}
	}

	// ---------- create covering quota ----------
	quotaSpecObjs, quotaJson, err := ctest.GenerateEffectiveConfigReturnType[v1.ResourceQuotaSpec](getHardCodedConfigInfoQuotaLimited(), ctest.ExtendOnly)
	if err != nil {
		t.Fatalf("failed to generate quota spec: %v", err)
	}
	if quotaSpecObjs == nil {
		fmt.Println(ctestglobals.DebugPrefix(), "Skipping quota creation, no generated config")
	} else {
		fmt.Println(ctestglobals.DebugPrefix(), "New Json Quota Specs:", string(quotaJson))
		for _, qs := range quotaSpecObjs {
			quota := &v1.ResourceQuota{
				ObjectMeta: metav1.ObjectMeta{
					Name:      "quota",
					Namespace: ns.Name,
				},
				Spec: qs,
			}
			waitForQuota(t, quota, cs)
		}
	}

	// ---------- retry pod creation ----------
	err = wait.PollImmediate(5*time.Second, time.Minute, func() (bool, error) {
		pod := &v1.Pod{
			ObjectMeta: metav1.ObjectMeta{
				Name:      "retry-" + string(uuid.NewUUID()),
				Namespace: ns.Name,
			},
			Spec: v1.PodSpec{
				Containers: []v1.Container{
					{
						Name:  "container",
						Image: "busybox",
					},
				},
			},
		}
		if _, err := cs.CoreV1().Pods(ns.Name).Create(tCtx, pod, metav1.CreateOptions{}); err == nil {
			return true, nil
		}
		return false, nil
	})
	if err != nil {
		t.Fatalf("unexpected error: %v", err)
	}
}

// ---------- TestQuotaLimitService ----------

func TestCtestQuotaLimitService(t *testing.T) {
	admissionConfigFile, err := os.CreateTemp("", "admission-config.yaml")
	if err != nil {
		t.Fatal(err)
	}
	defer os.Remove(admissionConfigFile.Name())
	if err := os.WriteFile(admissionConfigFile.Name(), []byte(`
apiVersion: apiserver.k8s.io/v1alpha1
kind: AdmissionConfiguration
plugins:
- name: ResourceQuota
  configuration:
    apiVersion: apiserver.config.k8s.io/v1
    kind: ResourceQuotaConfiguration
    limitedResources:
    - resource: pods
      matchContains:
      - pods
`), 0644); err != nil {
		t.Fatal(err)
	}

	tCtx := ktesting.Init(t)

	_, kubeConfig, tearDownFn := framework.StartTestServer(tCtx, t, framework.TestServerSetup{
		ModifyServerRunOptions: func(opts *options.ServerRunOptions) {
			opts.Admission.GenericAdmission.DisablePlugins = []string{"ServiceAccount"}
			opts.Admission.GenericAdmission.ConfigFile = admissionConfigFile.Name()
		},
	})
	defer tearDownFn()

	cs := clientset.NewForConfigOrDie(kubeConfig)

	ns := framework.CreateNamespaceOrDie(cs, "quota", t)
	defer framework.DeleteNamespaceOrDie(cs, ns, t)

	informerFactory := informers.NewSharedInformerFactory(cs, controller.NoResyncPeriodFunc())
	rm := replicationcontroller.NewReplicationManager(
		tCtx,
		informerFactory.Core().V1().Pods(),
		informerFactory.Core().V1().ReplicationControllers(),
		cs,
		replicationcontroller.BurstReplicas,
	)
	go rm.Run(tCtx, 3)

	discoveryFunc := cs.Discovery().ServerPreferredNamespacedResources
	listerFunc := generic.ListerFuncForResourceFunc(informerFactory.ForResource)
	qc := quotainstall.NewQuotaConfigurationForControllers(listerFunc)

	informersStarted := make(chan struct{})
	rqOpts := &resourcequotacontroller.ControllerOptions{
		QuotaClient:               cs.CoreV1(),
		ResourceQuotaInformer:     informerFactory.Core().V1().ResourceQuotas(),
		ResyncPeriod:              controller.NoResyncPeriodFunc,
		InformerFactory:           informerFactory,
		ReplenishmentResyncPeriod: controller.NoResyncPeriodFunc,
		DiscoveryFunc:             discoveryFunc,
		IgnoredResourcesFunc:      qc.IgnoredResources,
		InformersStarted:          informersStarted,
		Registry:                  generic.NewRegistry(qc.Evaluators()),
	}
	rqCtrl, err := resourcequotacontroller.NewController(tCtx, rqOpts)
	if err != nil {
		t.Fatalf("unexpected err: %v", err)
	}
	go rqCtrl.Run(tCtx, 2)
	go rqCtrl.Sync(tCtx, discoveryFunc, 30*time.Second)

	informerFactory.Start(tCtx.Done())
	close(informersStarted)

	// ---------- create covering quota ----------
	quotaSpecObjs, quotaJson, err := ctest.GenerateEffectiveConfigReturnType[v1.ResourceQuotaSpec](getHardCodedConfigInfoServiceQuota(), ctest.ExtendOnly)
	if err != nil {
		t.Fatalf("failed to generate service quota spec: %v", err)
	}
	if quotaSpecObjs == nil {
		fmt.Println(ctestglobals.DebugPrefix(), "Skipping service quota creation, no generated config")
	} else {
		fmt.Println(ctestglobals.DebugPrefix(), "New Json Service Quota Specs:", string(quotaJson))
		for _, qs := range quotaSpecObjs {
			quota := &v1.ResourceQuota{
				ObjectMeta: metav1.ObjectMeta{
					Name:      "quota",
					Namespace: ns.Name,
				},
				Spec: qs,
			}
			waitForQuota(t, quota, cs)
		}
	}

	// ---------- services ----------
	// NodePort service
	np := newService("np-svc", v1.ServiceTypeNodePort, true)
	if _, err := cs.CoreV1().Services(ns.Name).Create(tCtx, np, metav1.CreateOptions{}); err != nil {
		t.Errorf("creating first node port Service should not have returned error: %v", err)
	}
	// LoadBalancer service with nodeport
	lb1 := newService("lb-svc-withnp1", v1.ServiceTypeLoadBalancer, true)
	if _, err := cs.CoreV1().Services(ns.Name).Create(tCtx, lb1, metav1.CreateOptions{}); err != nil {
		t.Errorf("creating first loadbalancer Service should not have returned error: %v", err)
	}
	// Wait for quota usage
	expected := v1.ResourceList{
		v1.ResourceServices:              resource.MustParse("2"),
		v1.ResourceServicesNodePorts:     resource.MustParse("2"),
		v1.ResourceServicesLoadBalancers: resource.MustParse("1"),
	}
	waitForUsedResourceQuota(t, cs, ns.Name, "quota", expected)

	// LoadBalancer service exceeding nodeport quota
	lb2 := newService("lb-svc-withnp2", v1.ServiceTypeLoadBalancer, true)
	testServiceForbidden(cs, ns.Name, lb2, t)

	// LoadBalancer without nodeport
	lbNoNP := newService("lb-svc-wonp1", v1.ServiceTypeLoadBalancer, false)
	if _, err := cs.CoreV1().Services(ns.Name).Create(tCtx, lbNoNP, metav1.CreateOptions{}); err != nil {
		t.Errorf("creating loadbalancer Service without node ports should not have returned error: %v", err)
	}
	expected = v1.ResourceList{
		v1.ResourceServices:              resource.MustParse("3"),
		v1.ResourceServicesNodePorts:     resource.MustParse("2"),
		v1.ResourceServicesLoadBalancers: resource.MustParse("2"),
	}
	waitForUsedResourceQuota(t, cs, ns.Name, "quota", expected)

	// ClusterIP services
	cp1 := newService("clusterip-svc1", v1.ServiceTypeClusterIP, false)
	if _, err := cs.CoreV1().Services(ns.Name).Create(tCtx, cp1, metav1.CreateOptions{}); err != nil {
		t.Errorf("creating a cluster IP Service should not have returned error: %v", err)
	}
	expected = v1.ResourceList{
		v1.ResourceServices:              resource.MustParse("4"),
		v1.ResourceServicesNodePorts:     resource.MustParse("2"),
		v1.ResourceServicesLoadBalancers: resource.MustParse("2"),
	}
	waitForUsedResourceQuota(t, cs, ns.Name, "quota", expected)

	cp2 := newService("clusterip-svc2", v1.ServiceTypeClusterIP, false)
	testServiceForbidden(cs, ns.Name, cp2, t)
}

// ---------- Helper Functions ----------

func getHardCodedConfigInfoRC() ctestglobals.HardcodedConfig {
	return ctestglobals.HardcodedConfig{
		{
			FixtureFileName: "test_fixture.json",
			TestInfo:        []string{"default rc spec"},
			Field:           "spec",
			K8sObjects:      []string{"replicasets", "deployments", "statefulsets", "daemonsets", "replicationcontrollers", "pods"},
			HardcodedConfig: v1.ReplicationControllerSpec{
				Replicas: func() *int32 { i := int32(100); return &i }(),
				Selector: map[string]string{"foo": "bar"},
				Template: &v1.PodTemplateSpec{
					ObjectMeta: metav1.ObjectMeta{
						Labels: map[string]string{"foo": "bar"},
					},
					Spec: v1.PodSpec{
						Containers: []v1.Container{
							{
								Name:  "container",
								Image: "busybox",
							},
						},
					},
				},
			},
		},
	}
}

func getHardCodedConfigInfoQuota() ctestglobals.HardcodedConfig {
	return ctestglobals.HardcodedConfig{
		{
			FixtureFileName: "test_fixture.json",
			TestInfo:        []string{"default quota spec"},
			Field:           "spec",
			K8sObjects:      []string{"resourcequotas"},
			HardcodedConfig: v1.ResourceQuotaSpec{
				Hard: v1.ResourceList{
					v1.ResourcePods: resource.MustParse("1000"),
				},
			},
		},
	}
}

func getHardCodedConfigInfoLimitedPod() ctestglobals.HardcodedConfig {
	return ctestglobals.HardcodedConfig{
		{
			FixtureFileName: "test_fixture.json",
			TestInfo:        []string{"default limited pod"},
			Field:           "spec",
			K8sObjects:      []string{"pods"},
			HardcodedConfig: v1.PodSpec{
				Containers: []v1.Container{
					{
						Name:  "container",
						Image: "busybox",
					},
				},
			},
		},
	}
}

func getHardCodedConfigInfoQuotaLimited() ctestglobals.HardcodedConfig {
	return ctestglobals.HardcodedConfig{
		{
			FixtureFileName: "test_fixture.json",
			TestInfo:        []string{"default quota limited"},
			Field:           "spec",
			K8sObjects:      []string{"resourcequotas"},
			HardcodedConfig: v1.ResourceQuotaSpec{
				Hard: v1.ResourceList{
					v1.ResourcePods:               resource.MustParse("1000"),
					v1.ResourceName("count/pods"): resource.MustParse("1000"),
				},
			},
		},
	}
}

func getHardCodedConfigInfoServiceQuota() ctestglobals.HardcodedConfig {
	return ctestglobals.HardcodedConfig{
		{
			FixtureFileName: "test_fixture.json",
			TestInfo:        []string{"default service quota"},
			Field:           "spec",
			K8sObjects:      []string{"resourcequotas"},
			HardcodedConfig: v1.ResourceQuotaSpec{
				Hard: v1.ResourceList{
					v1.ResourceServices:              resource.MustParse("4"),
					v1.ResourceServicesNodePorts:     resource.MustParse("2"),
					v1.ResourceServicesLoadBalancers: resource.MustParse("2"),
				},
			},
		},
	}
}
