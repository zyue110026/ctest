package scale

import (
	"context"
	"encoding/json"
	"fmt"
	// "io"
	"path"
	"strings"
	"testing"

	// "google.golang.org/grpc/grpclog"

	appsv1 "k8s.io/api/apps/v1"
	corev1 "k8s.io/api/core/v1"
	metav1 "k8s.io/apimachinery/pkg/apis/meta/v1"
	"k8s.io/apimachinery/pkg/apis/meta/v1/unstructured"
	"k8s.io/apimachinery/pkg/runtime/schema"
	"k8s.io/apimachinery/pkg/util/uuid"
	// "k8s.io/client-go/kubernetes"
	// apitesting "k8s.io/kubernetes/cmd/kube-apiserver/app/testing"
	// "k8s.io/kubernetes/test/integration/framework"

	ctest "k8s.io/kubernetes/test/ctest"
	ctestglobals "k8s.io/kubernetes/test/ctest/ctestglobals"
	ctestutils "k8s.io/kubernetes/test/ctest/utils"
)

// Rewritten test with dynamic configuration and edge cases
func TestCtestScaleSubresources(t *testing.T) {
	clientSet, tearDown := setupWithOptions(t, nil, []string{
		"--runtime-config",
		"api/all=true",
	})
	defer tearDown()

	_, resourceLists, err := clientSet.Discovery().ServerGroupsAndResources()
	if err != nil {
		t.Fatal(err)
	}

	expectedScaleSubresources := map[schema.GroupVersionResource]schema.GroupVersionKind{
		makeGVR("", "v1", "replicationcontrollers/scale"): makeGVK("autoscaling", "v1", "Scale"),
		makeGVR("apps", "v1", "deployments/scale"):        makeGVK("autoscaling", "v1", "Scale"),
		makeGVR("apps", "v1", "replicasets/scale"):        makeGVK("autoscaling", "v1", "Scale"),
		makeGVR("apps", "v1", "statefulsets/scale"):       makeGVK("autoscaling", "v1", "Scale"),
	}

	autoscalingGVK := schema.GroupVersionKind{Group: "autoscaling", Version: "v1", Kind: "Scale"}

	discoveredScaleSubresources := map[schema.GroupVersionResource]schema.GroupVersionKind{}
	for _, resourceList := range resourceLists {
		containingGV, err := schema.ParseGroupVersion(resourceList.GroupVersion)
		if err != nil {
			t.Fatalf("error getting group version for %#v: %v", resourceList, err)
		}
		for _, resource := range resourceList.APIResources {
			if !strings.HasSuffix(resource.Name, "/scale") {
				continue
			}
			gvr := containingGV.WithResource(resource.Name)
			if _, exists := discoveredScaleSubresources[gvr]; exists {
				t.Errorf("scale subresource %#v listed multiple times in discovery", gvr)
				continue
			}
			gvk := containingGV.WithKind(resource.Kind)
			if resource.Group != "" {
				gvk.Group = resource.Group
			}
			if resource.Version != "" {
				gvk.Version = resource.Version
			}
			discoveredScaleSubresources[gvr] = gvk
		}
	}

	// Ensure nothing is missing
	for gvr, gvk := range expectedScaleSubresources {
		if _, ok := discoveredScaleSubresources[gvr]; !ok {
			t.Errorf("expected scale subresource %#v of kind %#v was missing from discovery", gvr, gvk)
		}
	}

	// Ensure discovery lists expected types
	for gvr, gvk := range discoveredScaleSubresources {
		if expectedGVK, expected := expectedScaleSubresources[gvr]; !expected {
			if gvk == autoscalingGVK {
				t.Errorf("unexpected scale subresource %#v of kind %#v. new scale subresource should be added to expectedScaleSubresources", gvr, gvk)
			} else {
				t.Errorf("unexpected scale subresource %#v of kind %#v. new scale resources are expected to use Scale from the autoscaling/v1 API group", gvr, gvk)
			}
			continue
		} else if expectedGVK != gvk {
			t.Errorf("scale subresource %#v should be of kind %#v, but %#v was listed in discovery", gvr, expectedGVK, gvk)
			continue
		}
	}

	// -------------------------------
	// Dynamic creation of required objects
	fmt.Println(ctestglobals.StartExtendModeSeparator)
	hc := getHardCodedConfigInfoScaleSubresources()

	// ReplicationController
	if item, found := ctestutils.GetItemByExactTestInfo(hc, "rc baseline"); found {
		fmt.Println(ctestglobals.DebugPrefix(), "rc baseline config:", item)
		rcObjs, rcJson, err := ctest.GenerateEffectiveConfigReturnType[corev1.ReplicationController](item, ctest.ExtendOnly)
		if err != nil {
			t.Fatalf("error generating rc config: %v", err)
		}
		fmt.Println(ctestglobals.DebugPrefix(), "New Json Test Configs:", string(rcJson))
		if rcObjs != nil {
			for i, rc := range rcObjs {
				// unique name
				rc.Name = "rc-" + fmt.Sprintf("%d-%s", i, string(uuid.NewUUID()))
				fmt.Printf("Running rc config #%d\n", i)
				fmt.Println(rc)
				if _, err = clientSet.CoreV1().ReplicationControllers("default").Create(context.TODO(), &rc, metav1.CreateOptions{}); err != nil {
					t.Fatalf("failed to create rc: %v", err)
				}
			}
		}
	} else {
		fmt.Println(ctestglobals.DebugPrefix(), "rc baseline config not found")
	}
	// Edge case: zero replicas
	zeroReplicas := int32(0)
	rcZero := corev1.ReplicationController{
		ObjectMeta: metav1.ObjectMeta{Name: "rc-zero-" + string(uuid.NewUUID())},
		Spec: corev1.ReplicationControllerSpec{
			Selector: map[string]string{"foo": "bar"},
			Replicas: &zeroReplicas,
			Template: &corev1.PodTemplateSpec{
				ObjectMeta: metav1.ObjectMeta{Labels: map[string]string{"foo": "bar"}},
				Spec:       corev1.PodSpec{Containers: []corev1.Container{{Name: "test", Image: "busybox"}}},
			},
		},
	}
	if _, err = clientSet.CoreV1().ReplicationControllers("default").Create(context.TODO(), &rcZero, metav1.CreateOptions{}); err != nil {
		t.Fatalf("failed to create rc with zero replicas: %v", err)
	}

	// ReplicaSet
	if item, found := ctestutils.GetItemByExactTestInfo(hc, "replicaset baseline"); found {
		rsObjs, rsJson, err := ctest.GenerateEffectiveConfigReturnType[appsv1.ReplicaSet](item, ctest.ExtendOnly)
		if err != nil {
			t.Fatalf("error generating rs config: %v", err)
		}
		fmt.Println(ctestglobals.DebugPrefix(), "New Json Test Configs:", string(rsJson))
		if rsObjs != nil {
			for i, rs := range rsObjs {
				rs.Name = "rs-" + fmt.Sprintf("%d-%s", i, string(uuid.NewUUID()))
				fmt.Printf("Running rs config #%d\n", i)
				fmt.Println(rs)
				if _, err = clientSet.AppsV1().ReplicaSets("default").Create(context.TODO(), &rs, metav1.CreateOptions{}); err != nil {
					t.Fatalf("failed to create rs: %v", err)
				}
			}
		}
	}
	// Edge case: large replica count
	largeReplicas := int32(1000)
	rsLarge := appsv1.ReplicaSet{
		ObjectMeta: metav1.ObjectMeta{Name: "rs-large-" + string(uuid.NewUUID())},
		Spec: appsv1.ReplicaSetSpec{
			Selector: &metav1.LabelSelector{MatchLabels: map[string]string{"foo": "bar"}},
			Replicas: &largeReplicas,
			Template: corev1.PodTemplateSpec{
				ObjectMeta: metav1.ObjectMeta{Labels: map[string]string{"foo": "bar"}},
				Spec:       corev1.PodSpec{Containers: []corev1.Container{{Name: "test", Image: "busybox"}}},
			},
		},
	}
	if _, err = clientSet.AppsV1().ReplicaSets("default").Create(context.TODO(), &rsLarge, metav1.CreateOptions{}); err != nil {
		t.Fatalf("failed to create rs with large replicas: %v", err)
	}

	// Deployment
	if item, found := ctestutils.GetItemByExactTestInfo(hc, "deployment baseline"); found {
		deployObjs, depJson, err := ctest.GenerateEffectiveConfigReturnType[appsv1.Deployment](item, ctest.ExtendOnly)
		if err != nil {
			t.Fatalf("error generating deployment config: %v", err)
		}
		fmt.Println(ctestglobals.DebugPrefix(), "New Json Test Configs:", string(depJson))
		if deployObjs != nil {
			for i, dep := range deployObjs {
				dep.Name = "dep-" + fmt.Sprintf("%d-%s", i, string(uuid.NewUUID()))
				fmt.Printf("Running deployment config #%d\n", i)
				fmt.Println(dep)
				if _, err = clientSet.AppsV1().Deployments("default").Create(context.TODO(), &dep, metav1.CreateOptions{}); err != nil {
					t.Fatalf("failed to create deployment: %v", err)
				}
			}
		}
	}
	// Edge case: nil selector (invalid, should be rejected)
	depNilSel := appsv1.Deployment{
		ObjectMeta: metav1.ObjectMeta{Name: "dep-nilsel-" + string(uuid.NewUUID())},
		Spec: appsv1.DeploymentSpec{
			// Selector left nil
			Replicas: &largeReplicas,
			Template: corev1.PodTemplateSpec{
				ObjectMeta: metav1.ObjectMeta{Labels: map[string]string{"foo": "bar"}},
				Spec:       corev1.PodSpec{Containers: []corev1.Container{{Name: "test", Image: "busybox"}}},
			},
		},
	}
	if _, err = clientSet.AppsV1().Deployments("default").Create(context.TODO(), &depNilSel, metav1.CreateOptions{}); err == nil {
		t.Fatalf("expected failure when creating deployment with nil selector, but succeeded")
	}

	// StatefulSet
	if item, found := ctestutils.GetItemByExactTestInfo(hc, "statefulset baseline"); found {
		ssObjs, ssJson, err := ctest.GenerateEffectiveConfigReturnType[appsv1.StatefulSet](item, ctest.ExtendOnly)
		if err != nil {
			t.Fatalf("error generating statefulset config: %v", err)
		}
		fmt.Println(ctestglobals.DebugPrefix(), "New Json Test Configs:", string(ssJson))
		if ssObjs != nil {
			for i, ss := range ssObjs {
				ss.Name = "ss-" + fmt.Sprintf("%d-%s", i, string(uuid.NewUUID()))
				fmt.Printf("Running statefulset config #%d\n", i)
				fmt.Println(ss)
				if _, err = clientSet.AppsV1().StatefulSets("default").Create(context.TODO(), &ss, metav1.CreateOptions{}); err != nil {
					t.Fatalf("failed to create statefulset: %v", err)
				}
			}
		}
	}
	// Edge case: negative replica count (invalid)
	negReplicas := int32(-1)
	ssNeg := appsv1.StatefulSet{
		ObjectMeta: metav1.ObjectMeta{Name: "ss-neg-" + string(uuid.NewUUID())},
		Spec: appsv1.StatefulSetSpec{
			Selector: &metav1.LabelSelector{MatchLabels: map[string]string{"foo": "bar"}},
			Replicas: &negReplicas,
			Template: corev1.PodTemplateSpec{
				ObjectMeta: metav1.ObjectMeta{Labels: map[string]string{"foo": "bar"}},
				Spec:       corev1.PodSpec{Containers: []corev1.Container{{Name: "test", Image: "busybox"}}},
			},
		},
	}
	if _, err = clientSet.AppsV1().StatefulSets("default").Create(context.TODO(), &ssNeg, metav1.CreateOptions{}); err == nil {
		t.Fatalf("expected failure when creating statefulset with negative replicas, but succeeded")
	}
	fmt.Println(ctestglobals.EndSeparator)

	// Ensure scale subresources return and accept expected kinds
	for gvr, gvk := range discoveredScaleSubresources {
		prefix := "/apis"
		if gvr.Group == corev1.GroupName {
			prefix = "/api"
		}
		resourceParts := strings.SplitN(gvr.Resource, "/", 2)
		urlPath := path.Join(prefix, gvr.Group, gvr.Version, "namespaces", "default", resourceParts[0], "test", resourceParts[1])
		obj := &unstructured.Unstructured{}
		getData, err := clientSet.CoreV1().RESTClient().Get().AbsPath(urlPath).DoRaw(context.TODO())
		if err != nil {
			t.Errorf("error fetching %s: %v", urlPath, err)
			continue
		}
		if err = json.Unmarshal(getData, obj); err != nil {
			t.Errorf("error decoding %s: %v", urlPath, err)
			t.Log(string(getData))
			continue
		}
		if obj.GetObjectKind().GroupVersionKind() != gvk {
			t.Errorf("expected %#v, got %#v from %s", gvk, obj.GetObjectKind().GroupVersionKind(), urlPath)
			t.Log(string(getData))
			continue
		}
		updateData, err := clientSet.CoreV1().RESTClient().Put().AbsPath(urlPath).Body(getData).DoRaw(context.TODO())
		if err != nil {
			t.Errorf("error putting to %s: %v", urlPath, err)
			t.Log(string(getData))
			t.Log(string(updateData))
			continue
		}
	}
}

// Hardcoded configuration definitions for dynamic generation
func getHardCodedConfigInfoScaleSubresources() ctestglobals.HardcodedConfig {
	return ctestglobals.HardcodedConfig{
		{
			FixtureFileName: "test_fixture.json",
			TestInfo:        []string{"rc baseline"},
			Field:           "replicationcontrollers",
			K8sObjects:      []string{"replicationcontrollers", "pods"},
			HardcodedConfig: corev1.ReplicationController{
				ObjectMeta: metav1.ObjectMeta{Name: "test"},
				Spec: corev1.ReplicationControllerSpec{
					Selector: map[string]string{"foo": "bar"},
					Replicas: func() *int32 { i := int32(1); return &i }(),
					Template: &corev1.PodTemplateSpec{
						ObjectMeta: metav1.ObjectMeta{Labels: map[string]string{"foo": "bar"}},
						Spec: corev1.PodSpec{
							Containers: []corev1.Container{{Name: "test", Image: "busybox"}},
						},
					},
				},
			},
		},
		{
			FixtureFileName: "test_fixture.json",
			TestInfo:        []string{"replicaset baseline"},
			Field:           "replicasets",
			K8sObjects:      []string{"replicasets", "pods"},
			HardcodedConfig: appsv1.ReplicaSet{
				ObjectMeta: metav1.ObjectMeta{Name: "test"},
				Spec: appsv1.ReplicaSetSpec{
					Selector: &metav1.LabelSelector{MatchLabels: map[string]string{"foo": "bar"}},
					Replicas: func() *int32 { i := int32(1); return &i }(),
					Template: corev1.PodTemplateSpec{
						ObjectMeta: metav1.ObjectMeta{Labels: map[string]string{"foo": "bar"}},
						Spec: corev1.PodSpec{
							Containers: []corev1.Container{{Name: "test", Image: "busybox"}},
						},
					},
				},
			},
		},
		{
			FixtureFileName: "test_fixture.json",
			TestInfo:        []string{"deployment baseline"},
			Field:           "deployments",
			K8sObjects:      []string{"deployments", "pods"},
			HardcodedConfig: appsv1.Deployment{
				ObjectMeta: metav1.ObjectMeta{Name: "test"},
				Spec: appsv1.DeploymentSpec{
					Selector: &metav1.LabelSelector{MatchLabels: map[string]string{"foo": "bar"}},
					Replicas: func() *int32 { i := int32(1); return &i }(),
					Template: corev1.PodTemplateSpec{
						ObjectMeta: metav1.ObjectMeta{Labels: map[string]string{"foo": "bar"}},
						Spec: corev1.PodSpec{
							Containers: []corev1.Container{{Name: "test", Image: "busybox"}},
						},
					},
				},
			},
		},
		{
			FixtureFileName: "test_fixture.json",
			TestInfo:        []string{"statefulset baseline"},
			Field:           "statefulsets",
			K8sObjects:      []string{"statefulsets", "pods"},
			HardcodedConfig: appsv1.StatefulSet{
				ObjectMeta: metav1.ObjectMeta{Name: "test"},
				Spec: appsv1.StatefulSetSpec{
					Selector: &metav1.LabelSelector{MatchLabels: map[string]string{"foo": "bar"}},
					Replicas: func() *int32 { i := int32(1); return &i }(),
					Template: corev1.PodTemplateSpec{
						ObjectMeta: metav1.ObjectMeta{Labels: map[string]string{"foo": "bar"}},
						Spec: corev1.PodSpec{
							Containers: []corev1.Container{{Name: "test", Image: "busybox"}},
						},
					},
				},
			},
		},
	}
}
