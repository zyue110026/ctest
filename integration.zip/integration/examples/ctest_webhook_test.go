package apiserver

import (
	"fmt"
	"sync/atomic"
	"testing"
	"time"

	"github.com/google/uuid"

	admissionregistrationv1 "k8s.io/api/admissionregistration/v1"
	v1 "k8s.io/api/core/v1"
	metav1 "k8s.io/apimachinery/pkg/apis/meta/v1"
	"k8s.io/apimachinery/pkg/util/wait"
	auditinternal "k8s.io/apiserver/pkg/apis/audit"
	"k8s.io/apiserver/pkg/audit"
	"k8s.io/apiserver/pkg/authorization/authorizer"
	"k8s.io/kubernetes/cmd/kube-apiserver/app/options"
	"k8s.io/kubernetes/pkg/controlplane"
	"k8s.io/kubernetes/pkg/controlplane/reconcilers"
	"k8s.io/kubernetes/test/integration/framework"
	"k8s.io/kubernetes/test/utils/ktesting"

	ctest "k8s.io/kubernetes/test/ctest"
	ctestglobals "k8s.io/kubernetes/test/ctest/ctestglobals"
	ctestutils "k8s.io/kubernetes/test/ctest/utils"
)

func TestCtestWebhookLoopback(t *testing.T) {
	fmt.Println(ctestglobals.StartExtendModeSeparator)

	// Load base configuration from hard‑coded fixture
	baseCfgs, cfgJSON, err := getWebhookConfigs()
	if err != nil {
		t.Fatalf("failed to generate webhook configs: %v", err)
	}
	if baseCfgs == nil {
		fmt.Println(ctestglobals.DebugPrefix(), "Skipping test execution. No new configurations generated.")
		return
	}
	fmt.Println(ctestglobals.DebugPrefix(), "New Json Test Configs:", string(cfgJSON))
	fmt.Println(ctestglobals.DebugPrefix(), "Number of test cases:", len(baseCfgs))

	// Build edge/invalid variants of the base configuration
	var testCfgs []admissionregistrationv1.MutatingWebhookConfiguration
	for _, c := range baseCfgs {
		// base
		testCfgs = append(testCfgs, c)

		// variant: nil FailurePolicy
		clone1 := c.DeepCopy()
		clone1.Webhooks[0].FailurePolicy = nil
		testCfgs = append(testCfgs, *clone1)

		// variant: empty Service.Namespace
		clone2 := c.DeepCopy()
		if clone2.Webhooks[0].ClientConfig.Service != nil {
			clone2.Webhooks[0].ClientConfig.Service.Namespace = ""
		}
		testCfgs = append(testCfgs, *clone2)

		// variant: nil SideEffects
		clone3 := c.DeepCopy()
		clone3.Webhooks[0].SideEffects = nil
		testCfgs = append(testCfgs, *clone3)
	}

	for i, cfg := range testCfgs {
		fmt.Printf("Running %d th test cases.\n", i)
		fmt.Println(cfg)

		// unique identifiers per sub‑test
		uniqueID := uuid.New().String()
		webhookPath := "/webhook-test-" + uniqueID
		webhookName := "webhooktest.example.com-" + uniqueID

		// adjust config for this run
		cfg.ObjectMeta.Name = webhookName
		if len(cfg.Webhooks) == 0 {
			t.Fatalf("unexpected empty webhooks slice in config")
		}
		cfg.Webhooks[0].Name = webhookName
		if cfg.Webhooks[0].ClientConfig.Service == nil {
			cfg.Webhooks[0].ClientConfig.Service = &admissionregistrationv1.ServiceReference{}
		}
		cfg.Webhooks[0].ClientConfig.Service.Namespace = "default"
		cfg.Webhooks[0].ClientConfig.Service.Name = "kubernetes"
		cfg.Webhooks[0].ClientConfig.Service.Path = &webhookPath

		// run sub‑test
		t.Run(webhookName, func(t *testing.T) {
			var called int32 = 0

			// start apiserver with audit hook that counts webhook invocations
			tCtx := ktesting.Init(t)
			client, _, tearDownFn := framework.StartTestServer(tCtx, t, framework.TestServerSetup{
				ModifyServerRunOptions: func(opts *options.ServerRunOptions) {},
				ModifyServerConfig: func(config *controlplane.Config) {
					config.Extra.EndpointReconcilerType = reconcilers.NoneEndpointReconcilerType
					config.ControlPlane.Generic.AuditBackend = auditSinkFunc(func(events ...*auditinternal.Event) {})
					config.ControlPlane.Generic.AuditPolicyRuleEvaluator = auditPolicyRuleEvaluator(func(attrs authorizer.Attributes) audit.RequestAuditConfig {
						if attrs.GetPath() == webhookPath {
							if attrs.GetUser().GetName() != "system:apiserver" {
								t.Errorf("expected user %q, got %q", "system:apiserver", attrs.GetUser().GetName())
							}
							atomic.AddInt32(&called, 1)
						}
						return audit.RequestAuditConfig{
							Level: auditinternal.LevelNone,
						}
					})
				},
			})
			defer tearDownFn()

			// create the mutating webhook configuration
			_, err := client.AdmissionregistrationV1().MutatingWebhookConfigurations().Create(tCtx, &cfg, metav1.CreateOptions{})
			if err != nil {
				t.Fatalf("failed to create MutatingWebhookConfiguration: %v", err)
			}

			// attempt to create a ConfigMap that should be rejected by the webhook
			err = wait.PollImmediate(100*time.Millisecond, 30*time.Second, func() (bool, error) {
				_, err = client.CoreV1().ConfigMaps("default").Create(tCtx, &v1.ConfigMap{
					ObjectMeta: metav1.ObjectMeta{Name: "webhook-test"},
					Data:       map[string]string{"invalid key": "value"},
				}, metav1.CreateOptions{})
				if err == nil {
					t.Fatal("unexpected success creating ConfigMap")
				}
				if atomic.LoadInt32(&called) > 0 {
					return true, nil
				}
				t.Logf("%v", err)
				t.Logf("webhook not called yet, continuing...")
				return false, nil
			})
			if err != nil {
				t.Fatalf("polling error: %v", err)
			}
		})
	}
}

// getHardCodedConfigInfoWebhook returns the minimal hard‑coded configuration
// required for the webhook test.
func getHardCodedConfigInfoWebhook() ctestglobals.HardcodedConfig {
	fail := admissionregistrationv1.Fail
	noSideEffects := admissionregistrationv1.SideEffectClassNone
	path := "/placeholder" // will be overwritten per test
	return ctestglobals.HardcodedConfig{
		{
			FixtureFileName: "test_fixture.json",
			TestInfo:        []string{"webhook loopback default config"},
			Field:           "webhooks",
			K8sObjects:      []string{"mutatingwebhookconfigurations"},
			HardcodedConfig: admissionregistrationv1.MutatingWebhookConfiguration{
				ObjectMeta: metav1.ObjectMeta{Name: "webhooktest.example.com"},
				Webhooks: []admissionregistrationv1.MutatingWebhook{
					{
						Name: "webhooktest.example.com",
						ClientConfig: admissionregistrationv1.WebhookClientConfig{
							Service: &admissionregistrationv1.ServiceReference{
								Namespace: "default",
								Name:      "kubernetes",
								Path:      &path,
							},
						},
						Rules: []admissionregistrationv1.RuleWithOperations{
							{
								Operations: []admissionregistrationv1.OperationType{admissionregistrationv1.OperationAll},
								Rule: admissionregistrationv1.Rule{
									APIGroups:   []string{""},
									APIVersions: []string{"v1"},
									Resources:   []string{"configmaps"},
								},
							},
						},
						FailurePolicy:           &fail,
						SideEffects:             &noSideEffects,
						AdmissionReviewVersions: []string{"v1"},
					},
				},
			},
		},
	}
}

// getWebhookConfigs generates configuration objects using the ctest framework.
func getWebhookConfigs() ([]admissionregistrationv1.MutatingWebhookConfiguration, []byte, error) {
	hc := getHardCodedConfigInfoWebhook()
	item, found := ctestutils.GetItemByExactTestInfo(hc, "webhook loopback default config")
	if !found {
		return nil, nil, fmt.Errorf("hard‑coded config not found")
	}
	fmt.Println(ctestglobals.DebugPrefix(), "get default configs:", item)
	cfgObjs, cfgJSON, err := ctest.GenerateEffectiveConfigReturnType[admissionregistrationv1.MutatingWebhookConfiguration](item, ctest.ExtendOnly)
	if err != nil {
		return nil, nil, err
	}
	return cfgObjs, cfgJSON, nil
}
