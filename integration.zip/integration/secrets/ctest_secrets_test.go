package secrets

import (
	"context"
	"encoding/json"
	"fmt"
	"testing"

	v1 "k8s.io/api/core/v1"
	metav1 "k8s.io/apimachinery/pkg/apis/meta/v1"
	"k8s.io/apimachinery/pkg/types"
	"k8s.io/apimachinery/pkg/util/uuid"
	clientset "k8s.io/client-go/kubernetes"
	kubeapiservertesting "k8s.io/kubernetes/cmd/kube-apiserver/app/testing"
	"k8s.io/kubernetes/test/integration"
	"k8s.io/kubernetes/test/integration/framework"

	ctest "k8s.io/kubernetes/test/ctest"
	ctestglobals "k8s.io/kubernetes/test/ctest/ctestglobals"
	ctestutils "k8s.io/kubernetes/test/ctest/utils"
)

func TestCtestSecrets(t *testing.T) {
	// Setup test apiserver.
	server := kubeapiservertesting.StartTestServerOrDie(t, nil, framework.DefaultTestServerFlags(), framework.SharedEtcd())
	defer server.TearDownFn()
	client := clientset.NewForConfigOrDie(server.ClientConfig)

	ns := framework.CreateNamespaceOrDie(client, "secret", t)
	defer framework.DeleteNamespaceOrDie(client, ns, t)

	fmt.Println(ctestglobals.DebugPrefix(), "Start Secrets test with dynamic config")
	// --------------------------------------------------------------------
	// 1. Load secret configurations (regular and immutable)
	// --------------------------------------------------------------------
	secretCfgs := getHardCodedConfigInfoSecret()
	secretItem, found := ctestutils.GetItemByExactTestInfo(secretCfgs, "default secret")
	if !found {
		t.Fatalf("failed to find default secret config")
	}
	secretObjs, secretJson, err := ctest.GenerateEffectiveConfigReturnType[v1.Secret](secretItem, ctest.Union)
	if err != nil {
		t.Fatalf("GenerateEffectiveConfigReturnType error: %v", err)
	}
	fmt.Println(ctestglobals.DebugPrefix(), "New Json Test Configs (secret):", string(secretJson))
	fmt.Println(ctestglobals.DebugPrefix(), "Number of secret test cases:", len(secretObjs))

	immItem, found := ctestutils.GetItemByExactTestInfo(secretCfgs, "immutable empty secret")
	if !found {
		t.Fatalf("failed to find immutable secret config")
	}
	immObjs, immJson, err := ctest.GenerateEffectiveConfigReturnType[v1.Secret](immItem, ctest.Union)
	if err != nil {
		t.Fatalf("GenerateEffectiveConfigReturnType error: %v", err)
	}
	fmt.Println(ctestglobals.DebugPrefix(), "New Json Test Configs (immutable):", string(immJson))
	fmt.Println(ctestglobals.DebugPrefix(), "Number of immutable secret test cases:", len(immObjs))

	// --------------------------------------------------------------------
	// 2. Load pod spec configuration
	// --------------------------------------------------------------------
	podSpecCfgs := getHardCodedConfigInfoPodSpec()
	podItem, found := ctestutils.GetItemByExactTestInfo(podSpecCfgs, "pod using secret")
	if !found {
		t.Fatalf("failed to find pod spec config")
	}
	podSpecObjs, podSpecJson, err := ctest.GenerateEffectiveConfigReturnType[v1.PodSpec](podItem, ctest.Union)
	if err != nil {
		t.Fatalf("GenerateEffectiveConfigReturnType error: %v", err)
	}
	fmt.Println(ctestglobals.DebugPrefix(), "New Json Test Configs (podSpec):", string(podSpecJson))
	fmt.Println(ctestglobals.DebugPrefix(), "Number of podSpec test cases:", len(podSpecObjs))

	// --------------------------------------------------------------------
	// 3. Execute regular secret tests
	// --------------------------------------------------------------------
	if len(secretObjs) > 0 && len(podSpecObjs) > 0 {
		for i, sec := range secretObjs {
			secName := "secret-" + string(uuid.NewUUID())
			sec.ObjectMeta.Name = secName
			sec.ObjectMeta.Namespace = ns.Name

			fmt.Printf("Running regular secret test case #%d\n", i)
			if _, err := client.CoreV1().Secrets(ns.Name).Create(context.TODO(), &sec, metav1.CreateOptions{}); err != nil {
				t.Fatalf("failed to create secret %s: %v", secName, err)
			}
			defer deleteSecretOrErrorf(t, client, sec.Namespace, sec.Name)

			for j, podSpec := range podSpecObjs {
				// Adjust pod spec to reference the created secret
				if len(podSpec.Volumes) > 0 && podSpec.Volumes[0].VolumeSource.Secret != nil {
					podSpec.Volumes[0].VolumeSource.Secret.SecretName = secName
				}
				pod := &v1.Pod{
					ObjectMeta: metav1.ObjectMeta{
						Name:      "pod-uses-secret-" + string(uuid.NewUUID()),
						Namespace: ns.Name,
					},
					Spec: podSpec,
				}
				fmt.Printf("  Creating pod #%d using secret %s\n", j, secName)
				if _, err := client.CoreV1().Pods(ns.Name).Create(context.TODO(), pod, metav1.CreateOptions{}); err != nil {
					t.Fatalf("failed to create pod %s: %v", pod.Name, err)
				}
				defer integration.DeletePodOrErrorf(t, client, ns.Name, pod.Name)

				// Pod that uses a non‑existent secret
				nonExistPod := pod.DeepCopy()
				nonExistPod.ObjectMeta.Name = "pod-nonexistent-" + string(uuid.NewUUID())
				if len(nonExistPod.Spec.Volumes) > 0 && nonExistPod.Spec.Volumes[0].VolumeSource.Secret != nil {
					nonExistPod.Spec.Volumes[0].VolumeSource.Secret.SecretName = "nonexistent-" + secName
				}
				if _, err := client.CoreV1().Pods(ns.Name).Create(context.TODO(), nonExistPod, metav1.CreateOptions{}); err != nil {
					t.Fatalf("failed to create pod with non‑existent secret %s: %v", nonExistPod.Name, err)
				}
				defer integration.DeletePodOrErrorf(t, client, ns.Name, nonExistPod.Name)
			}
		}
	} else {
		fmt.Println(ctestglobals.DebugPrefix(), "Skipping regular secret tests: no configs generated")
	}

	// --------------------------------------------------------------------
	// 4. Execute immutable‑secret‑with‑empty‑value test (including edge cases)
	// --------------------------------------------------------------------
	if len(immObjs) > 0 {
		for i, immSec := range immObjs {
			immName := "imm-secret-" + string(uuid.NewUUID())
			immSec.ObjectMeta.Name = immName
			immSec.ObjectMeta.Namespace = ns.Name

			fmt.Printf("Running immutable secret test case #%d\n", i)
			if _, err := client.CoreV1().Secrets(ns.Name).Create(context.TODO(), &immSec, metav1.CreateOptions{}); err != nil {
				t.Fatalf("failed to create immutable secret %s: %v", immName, err)
			}
			defer deleteSecretOrErrorf(t, client, immSec.Namespace, immSec.Name)

			// Create a patch that adds a label but keeps Immutable true and empty data
			patchSec := immSec.DeepCopy()
			if patchSec.Labels == nil {
				patchSec.Labels = map[string]string{}
			}
			patchSec.Labels["foo"] = "bar"

			patchBytes, err := json.Marshal(patchSec)
			if err != nil {
				t.Fatalf("failed to marshal patch secret: %v", err)
			}
			if _, err := client.CoreV1().Secrets(ns.Name).Patch(context.TODO(), immName, types.StrategicMergePatchType, patchBytes, metav1.PatchOptions{}); err != nil {
				t.Fatalf("patching immutable secret %s failed: %v", immName, err)
			}
		}
	} else {
		fmt.Println(ctestglobals.DebugPrefix(), "Skipping immutable secret tests: no configs generated")
	}
	fmt.Println(ctestglobals.EndSeparator)
}

// --------------------------------------------------------------------
// Hardcoded configuration definitions
// --------------------------------------------------------------------
func getHardCodedConfigInfoSecret() ctestglobals.HardcodedConfig {
	trueVal := true
	return ctestglobals.HardcodedConfig{
		{
			FixtureFileName: "test_fixture.json",
			TestInfo:        []string{"default secret"},
			Field:           "data",
			K8sObjects:      []string{"secrets"},
			HardcodedConfig: v1.Secret{
				ObjectMeta: metav1.ObjectMeta{
					Name: "secret",
				},
				Data: map[string][]byte{
					"data": []byte("value1\n"),
				},
			},
		},
		{
			FixtureFileName: "test_fixture.json",
			TestInfo:        []string{"immutable empty secret"},
			Field:           "data",
			K8sObjects:      []string{"secrets"},
			HardcodedConfig: v1.Secret{
				ObjectMeta: metav1.ObjectMeta{
					Name: "secret",
				},
				Immutable: &trueVal,
				Data: map[string][]byte{
					"emptyData": {},
				},
			},
		},
	}
}

func getHardCodedConfigInfoPodSpec() ctestglobals.HardcodedConfig {
	return ctestglobals.HardcodedConfig{
		{
			FixtureFileName: "test_fixture.json",
			TestInfo:        []string{"pod using secret"},
			Field:           "spec",
			K8sObjects: []string{
				"pods", "deployments", "statefulsets", "daemonsets", "replicasets",
			},
			HardcodedConfig: v1.PodSpec{
				Volumes: []v1.Volume{
					{
						Name: "secvol",
						VolumeSource: v1.VolumeSource{
							Secret: &v1.SecretVolumeSource{
								SecretName: "secret",
							},
						},
					},
				},
				Containers: []v1.Container{
					{
						Name:  "fake-name",
						Image: "fakeimage",
						VolumeMounts: []v1.VolumeMount{
							{
								Name:      "secvol",
								MountPath: "/fake/path",
								ReadOnly:  true,
							},
						},
					},
				},
			},
		},
	}
}
