package evictions

import (
	"context"
	// "encoding/json"
	"fmt"
	// "reflect"
	// "strings"
	"sync"
	"sync/atomic"
	"testing"
	"time"

	// "golang.org/x/net/context"

	v1 "k8s.io/api/core/v1"
	policyv1 "k8s.io/api/policy/v1"
	// policyv1beta1 "k8s.io/api/policy/v1beta1"
	apierrors "k8s.io/apimachinery/pkg/api/errors"
	metav1 "k8s.io/apimachinery/pkg/apis/meta/v1"
	// "k8s.io/apimachinery/pkg/apis/meta/v1/unstructured"
	// "k8s.io/apimachinery/pkg/runtime"
	// "k8s.io/apimachinery/pkg/runtime/schema"
	// "k8s.io/apimachinery/pkg/types"
	utilerrors "k8s.io/apimachinery/pkg/util/errors"
	"k8s.io/apimachinery/pkg/util/intstr"
	// "k8s.io/apimachinery/pkg/util/uuid"
	"k8s.io/apimachinery/pkg/util/wait"
	// cacheddiscovery "k8s.io/client-go/discovery/cached/memory"
	// "k8s.io/client-go/dynamic"
	// "k8s.io/client-go/informers"
	// clientset "k8s.io/client-go/kubernetes"
	// policyv1client "k8s.io/client-go/kubernetes/typed/policy/v1"
	// restclient "k8s.io/client-go/rest"
	// "k8s.io/client-go/restmapper"
	// "k8s.io/client-go/scale"
	// "k8s.io/client-go/tools/cache"
	// "k8s.io/klog/v2"
	// kubeapiservertesting "k8s.io/kubernetes/cmd/kube-apiserver/app/testing"
	// podutil "k8s.io/kubernetes/pkg/api/v1/pod"
	// "k8s.io/kubernetes/pkg/controller/disruption"
	"k8s.io/kubernetes/test/integration/framework"
	"k8s.io/kubernetes/test/utils/ktesting"

	ctest "k8s.io/kubernetes/test/ctest"
	ctestglobals "k8s.io/kubernetes/test/ctest/ctestglobals"
	ctestutils "k8s.io/kubernetes/test/ctest/utils"
)

// -----------------------------------------------------------------------------
// Dynamic configuration helpers
// -----------------------------------------------------------------------------

func getHardCodedConfigInfoPodSpec() ctestglobals.HardcodedConfig {
	return ctestglobals.HardcodedConfig{{
		FixtureFileName: "test_fixture.json",
		TestInfo:        []string{"default pod spec for evictions"},
		Field:           "spec",
		K8sObjects:      []string{"pods"},
		HardcodedConfig: v1.PodSpec{
			Containers: []v1.Container{
				{
					Name:  "fake-name",
					Image: "fakeimage",
				},
			},
		},
	}}
}

func getHardCodedConfigInfoPDBSpec() ctestglobals.HardcodedConfig {
	return ctestglobals.HardcodedConfig{{
		FixtureFileName: "test_fixture.json",
		TestInfo:        []string{"default pdb spec for evictions"},
		Field:           "spec",
		K8sObjects:      []string{"pods"},
		HardcodedConfig: policyv1.PodDisruptionBudgetSpec{
			MinAvailable: &intstr.IntOrString{
				Type:   intstr.Int,
				IntVal: 0,
			},
			Selector: &metav1.LabelSelector{
				MatchLabels: map[string]string{"app": "test-evictions"},
			},
		},
	}}
}

// -----------------------------------------------------------------------------
// Rewritten tests
// -----------------------------------------------------------------------------

func TestCtestConcurrentEvictionRequests(t *testing.T) {
	fmt.Println(ctestglobals.StartExtendModeSeparator)

	// Load dynamic pod spec configuration
	cfgInfo := getHardCodedConfigInfoPodSpec()
	item, found := ctestutils.GetItemByExactTestInfo(cfgInfo, "default pod spec for evictions")
	if !found {
		fmt.Println(ctestglobals.DebugPrefix(), "Failed to find pod spec config")
		t.Skip("no pod spec configuration available")
	}
	podSpecs, cfgJSON, err := ctest.GenerateEffectiveConfigReturnType[v1.PodSpec](item, ctest.ExtendOnly)
	if err != nil {
		t.Fatalf("failed to generate pod specs: %v", err)
	}
	fmt.Println(ctestglobals.DebugPrefix(), "New Json Test Configs:", string(cfgJSON))
	if podSpecs == nil {
		fmt.Println(ctestglobals.DebugPrefix(), "Skipping test execution. No new configurations generated.")
		return
	}
	fmt.Println(ctestglobals.DebugPrefix(), "Number of pod spec test cases:", len(podSpecs))

	for cfgIdx, podSpec := range podSpecs {
		fmt.Printf("Running pod spec config #%d\n", cfgIdx)

		podNameFormat := "test-pod-%d"
		tCtx := ktesting.Init(t)
		closeFn, rm, informers, _, clientSet := rmSetup(tCtx, t)
		defer closeFn()

		ns := framework.CreateNamespaceOrDie(clientSet, fmt.Sprintf("concurrent-eviction-requests-%d", cfgIdx), t)
		defer framework.DeleteNamespaceOrDie(clientSet, ns, t)
		defer tCtx.Cancel("test has completed")

		informers.Start(tCtx.Done())
		go rm.Run(tCtx)

		var gracePeriodSeconds int64 = 30
		deleteOption := metav1.DeleteOptions{
			GracePeriodSeconds: &gracePeriodSeconds,
		}

		// Create pods using dynamic spec
		for i := 0; i < numOfEvictions; i++ {
			podName := fmt.Sprintf(podNameFormat, i)
			pod := &v1.Pod{
				ObjectMeta: metav1.ObjectMeta{
					Name:   podName,
					Labels: map[string]string{"app": "test-evictions"},
				},
				Spec: podSpec,
			}
			if _, err := clientSet.CoreV1().Pods(ns.Name).Create(context.TODO(), pod, metav1.CreateOptions{}); err != nil {
				t.Fatalf("Failed to create pod: %v", err)
			}
			pod.Status.Phase = v1.PodRunning
			addPodConditionReady(pod)
			if _, err := clientSet.CoreV1().Pods(ns.Name).UpdateStatus(context.TODO(), pod, metav1.UpdateOptions{}); err != nil {
				t.Fatal(err)
			}
		}

		waitToObservePods(t, informers.Core().V1().Pods().Informer(), numOfEvictions, v1.PodRunning)

		// PDB uses static helper (no hardcoded config needed for this test)
		pdb := newPDB()
		if _, err := clientSet.PolicyV1().PodDisruptionBudgets(ns.Name).Create(context.TODO(), pdb, metav1.CreateOptions{}); err != nil {
			t.Fatalf("Failed to create PodDisruptionBudget: %v", err)
		}

		waitPDBStable(t, clientSet, ns.Name, pdb.Name, numOfEvictions)

		var numberPodsEvicted uint32
		errCh := make(chan error, 3*numOfEvictions)
		var wg sync.WaitGroup
		for i := 0; i < numOfEvictions; i++ {
			wg.Add(1)
			go func(id int, errCh chan error) {
				defer wg.Done()
				podName := fmt.Sprintf(podNameFormat, id)
				eviction := newV1Eviction(ns.Name, podName, deleteOption)

				err := wait.PollImmediate(5*time.Second, 60*time.Second, func() (bool, error) {
					e := clientSet.PolicyV1().Evictions(ns.Name).Evict(context.TODO(), eviction)
					switch {
					case apierrors.IsTooManyRequests(e):
						return false, nil
					case apierrors.IsConflict(e):
						return false, fmt.Errorf("Unexpected Conflict (409) error caused by failing to handle concurrent PDB updates: %v", e)
					case e == nil:
						return true, nil
					default:
						return false, e
					}
				})

				if err != nil {
					errCh <- err
				}

				_, err = clientSet.CoreV1().Pods(ns.Name).Get(context.TODO(), podName, metav1.GetOptions{})
				switch {
				case apierrors.IsNotFound(err):
					atomic.AddUint32(&numberPodsEvicted, 1)
					return
				case err == nil:
					errCh <- fmt.Errorf("Pod %q is expected to be evicted", podName)
				default:
					errCh <- err
				}

				// cleanup if needed
				if e := clientSet.CoreV1().Pods(ns.Name).Delete(context.TODO(), podName, deleteOption); e != nil {
					errCh <- e
				}
			}(i, errCh)
		}
		wg.Wait()
		close(errCh)

		var errList []error
		if err := clientSet.PolicyV1().PodDisruptionBudgets(ns.Name).Delete(context.TODO(), pdb.Name, deleteOption); err != nil {
			errList = append(errList, fmt.Errorf("Failed to delete PodDisruptionBudget: %v", err))
		}
		for err := range errCh {
			errList = append(errList, err)
		}
		if len(errList) > 0 {
			t.Fatal(utilerrors.NewAggregate(errList))
		}
		if atomic.LoadUint32(&numberPodsEvicted) != numOfEvictions {
			t.Fatalf("fewer number of successful evictions than expected : %d", numberPodsEvicted)
		}
	}
}
