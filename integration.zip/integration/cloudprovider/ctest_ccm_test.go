package cloudprovider

import (
	"context"
	"fmt"
	"io"
	"os"
	"reflect"
	"strings"
	"testing"
	"time"

	v1 "k8s.io/api/core/v1"
	metav1 "k8s.io/apimachinery/pkg/apis/meta/v1"
	"k8s.io/apimachinery/pkg/types"
	"k8s.io/apimachinery/pkg/util/wait"
	clientset "k8s.io/client-go/kubernetes"
	// "k8s.io/client-go/rest"
	clientcmd "k8s.io/client-go/tools/clientcmd"
	clientcmdapi "k8s.io/client-go/tools/clientcmd/api"
	cloudprovider "k8s.io/cloud-provider"
	cloudproviderapi "k8s.io/cloud-provider/api"
	ccmservertesting "k8s.io/cloud-provider/app/testing"
	fakecloud "k8s.io/cloud-provider/fake"
	kubeapiservertesting "k8s.io/kubernetes/cmd/kube-apiserver/app/testing"
	"k8s.io/kubernetes/pkg/controller/nodeipam/ipam"
	"k8s.io/kubernetes/test/integration/framework"

	ctest "k8s.io/kubernetes/test/ctest"
	ctestglobals "k8s.io/kubernetes/test/ctest/ctestglobals"
	ctestutils "k8s.io/kubernetes/test/ctest/utils"
)

func getHardCodedConfigInfoNodeSpec() ctestglobals.HardcodedConfig {
	return ctestglobals.HardcodedConfig{{
		FixtureFileName: "test_fixture.json",
		TestInfo:        []string{"node spec with external taint"},
		Field:           "taints",
		K8sObjects:      []string{"nodes"},
		HardcodedConfig: v1.NodeSpec{
			Taints: []v1.Taint{{
				Key:    cloudproviderapi.TaintExternalCloudProvider,
				Value:  "true",
				Effect: v1.TaintEffectNoSchedule,
			}},
		},
	}}
}

func getHardCodedConfigInfoNodeAddresses() ctestglobals.HardcodedConfig {
	return ctestglobals.HardcodedConfig{{
		FixtureFileName: "test_fixture.json",
		TestInfo:        []string{"default node addresses"},
		Field:           "addresses",
		K8sObjects:      []string{"nodes"},
		HardcodedConfig: []v1.NodeAddress{
			{Type: v1.NodeHostName, Address: "node.cloud.internal"},
			{Type: v1.NodeInternalIP, Address: "10.0.0.1"},
			{Type: v1.NodeInternalIP, Address: "172.16.0.1"},
			{Type: v1.NodeInternalIP, Address: "fd00:1:2:3:4::"},
			{Type: v1.NodeInternalIP, Address: "192.168.0.1"},
			{Type: v1.NodeInternalIP, Address: "2001:db2::1"},
			{Type: v1.NodeExternalIP, Address: "132.143.154.163"},
		},
	}}
}

func TestCtestRemoveExternalCloudProviderTaint(t *testing.T) {
	ctx, cancel := context.WithCancel(context.Background())
	defer cancel()

	server := kubeapiservertesting.StartTestServerOrDie(t, nil, framework.DefaultTestServerFlags(), framework.SharedEtcd())
	defer server.TearDownFn()

	client := clientset.NewForConfigOrDie(server.ClientConfig)

	// create kubeconfig file (inline version of createKubeconfigFileForRestConfig)
	clusters := map[string]*clientcmdapi.Cluster{
		"default-cluster": {
			Server:                   server.ClientConfig.Host,
			TLSServerName:            server.ClientConfig.ServerName,
			CertificateAuthorityData: server.ClientConfig.CAData,
		},
	}
	contexts := map[string]*clientcmdapi.Context{
		"default-context": {
			Cluster:  "default-cluster",
			AuthInfo: "default-user",
		},
	}
	authInfos := map[string]*clientcmdapi.AuthInfo{
		"default-user": {
			ClientCertificateData: server.ClientConfig.CertData,
			ClientKeyData:         server.ClientConfig.KeyData,
			Token:                 server.ClientConfig.BearerToken,
		},
	}
	kubeConfig := clientcmdapi.Config{
		Kind:           "Config",
		APIVersion:     "v1",
		Clusters:       clusters,
		Contexts:       contexts,
		CurrentContext: "default-context",
		AuthInfos:      authInfos,
	}
	kubeConfigFile, err := os.CreateTemp("", "kubeconfig")
	if err != nil {
		t.Fatalf("failed to create temp kubeconfig: %v", err)
	}
	defer os.Remove(kubeConfigFile.Name())
	if err := clientcmd.WriteToFile(kubeConfig, kubeConfigFile.Name()); err != nil {
		t.Fatalf("failed to write kubeconfig: %v", err)
	}

	args := []string{
		"--kubeconfig=" + kubeConfigFile.Name(),
		"--cloud-provider=fakeCloudTaints",
		"--cidr-allocator-type=" + string(ipam.RangeAllocatorType),
		"--configure-cloud-routes=false",
	}

	// dynamic node spec configuration
	fmt.Println(ctestglobals.StartSeparator)
	hc := getHardCodedConfigInfoNodeSpec()
	item, found := ctestutils.GetItemByExactTestInfo(hc, "node spec with external taint")
	if !found {
		fmt.Println(ctestglobals.DebugPrefix(), "Failed to find config for node spec")
		t.Fatalf("hardcoded config not found")
	}
	configObjs, configJSON, err := ctest.GenerateEffectiveConfigReturnType[v1.NodeSpec](item, ctest.ExtendOnly)
	if err != nil {
		fmt.Println(ctestglobals.DebugPrefix(), "GenerateEffectiveConfig error:", err)
		t.Fatalf("config generation failed")
	}
	if configObjs == nil {
		fmt.Println(ctestglobals.DebugPrefix(), "Skipping test execution. No new configurations generated.")
		return
	}
	fmt.Println(ctestglobals.DebugPrefix(), "New Json Test Configs:", string(configJSON))
	fmt.Println(ctestglobals.DebugPrefix(), "Number of config objects:", len(configObjs))

	// fake cloud provider (same as original)
	fakeCloud := &fakecloud.Cloud{
		Zone: cloudprovider.Zone{
			FailureDomain: "zone-0",
			Region:        "region-1",
		},
		EnableInstancesV2:  true,
		ExistsByProviderID: true,
		ProviderID: map[types.NodeName]string{
			types.NodeName("node0"): "12345",
		},
		InstanceTypes: map[types.NodeName]string{
			types.NodeName("node0"): "t1.micro",
		},
		ExtID: map[types.NodeName]string{
			types.NodeName("node0"): "12345",
		},
		Addresses: []v1.NodeAddress{
			{Type: v1.NodeHostName, Address: "node0.cloud.internal"},
			{Type: v1.NodeInternalIP, Address: "10.0.0.1"},
			{Type: v1.NodeInternalIP, Address: "192.168.0.1"},
			{Type: v1.NodeExternalIP, Address: "132.143.154.163"},
		},
		ErrByProviderID: nil,
		Err:             nil,
	}
	cloudprovider.RegisterCloudProvider(
		"fakeCloudTaints",
		func(config io.Reader) (cloudprovider.Interface, error) {
			return fakeCloud, nil
		})

	ccm := ccmservertesting.StartTestServerOrDie(ctx, args)
	defer ccm.TearDownFn()

	for i, cfg := range configObjs {
		nodeName := fmt.Sprintf("node-%d", i)
		node := &v1.Node{
			ObjectMeta: metav1.ObjectMeta{
				Name: nodeName,
			},
			Spec: cfg,
		}
		_, err := client.CoreV1().Nodes().Create(ctx, node, metav1.CreateOptions{})
		if err != nil {
			t.Fatalf("Failed to create Node %v: %v", nodeName, err)
		}

		// poll for expected taint and address count
		err = wait.PollUntilContextTimeout(ctx, 1*time.Second, 50*time.Second, true, func(ctx context.Context) (bool, error) {
			n, err := client.CoreV1().Nodes().Get(ctx, nodeName, metav1.GetOptions{})
			if err != nil {
				return false, err
			}
			if len(n.Spec.Taints) != 1 {
				return false, nil
			}
			if n.Spec.Taints[0].Key != v1.TaintNodeNotReady {
				return false, nil
			}
			if len(n.Status.Addresses) != 4 {
				return false, nil
			}
			return true, nil
		})
		if err != nil {
			t.Logf("Fake Cloud Provider calls: %v", fakeCloud.Calls)
			t.Fatalf("expected node to not have Taint: %v", err)
		}
	}
	fmt.Println(ctestglobals.EndSeparator)
}

func TestCtestExternalCloudProviderNodeAddresses(t *testing.T) {
	ctx, cancel := context.WithCancel(context.Background())
	defer cancel()

	server := kubeapiservertesting.StartTestServerOrDie(t, nil, framework.DefaultTestServerFlags(), framework.SharedEtcd())
	defer server.TearDownFn()

	client := clientset.NewForConfigOrDie(server.ClientConfig)

	// kubeconfig inline
	clusters := map[string]*clientcmdapi.Cluster{
		"default-cluster": {
			Server:                   server.ClientConfig.Host,
			TLSServerName:            server.ClientConfig.ServerName,
			CertificateAuthorityData: server.ClientConfig.CAData,
		},
	}
	contexts := map[string]*clientcmdapi.Context{
		"default-context": {
			Cluster:  "default-cluster",
			AuthInfo: "default-user",
		},
	}
	authInfos := map[string]*clientcmdapi.AuthInfo{
		"default-user": {
			ClientCertificateData: server.ClientConfig.CertData,
			ClientKeyData:         server.ClientConfig.KeyData,
			Token:                 server.ClientConfig.BearerToken,
		},
	}
	kubeConfig := clientcmdapi.Config{
		Kind:           "Config",
		APIVersion:     "v1",
		Clusters:       clusters,
		Contexts:       contexts,
		CurrentContext: "default-context",
		AuthInfos:      authInfos,
	}
	kcFile, err := os.CreateTemp("", "kubeconfig")
	if err != nil {
		t.Fatalf("temp file error: %v", err)
	}
	defer os.Remove(kcFile.Name())
	if err := clientcmd.WriteToFile(kubeConfig, kcFile.Name()); err != nil {
		t.Fatalf("write kubeconfig error: %v", err)
	}

	args := []string{
		"--kubeconfig=" + kcFile.Name(),
		"--cloud-provider=fakeCloud",
		"--cidr-allocator-type=" + string(ipam.RangeAllocatorType),
		"--configure-cloud-routes=false",
	}

	// dynamic addresses config
	fmt.Println(ctestglobals.StartSeparator)
	addrHC := getHardCodedConfigInfoNodeAddresses()
	item, found := ctestutils.GetItemByExactTestInfo(addrHC, "default node addresses")
	if !found {
		fmt.Println(ctestglobals.DebugPrefix(), "Failed to find config for addresses")
		t.Fatalf("hardcoded address config not found")
	}
	addrObjs, addrJSON, err := ctest.GenerateEffectiveConfigReturnType[[]v1.NodeAddress](item, ctest.ExtendOnly)
	if err != nil {
		fmt.Println(ctestglobals.DebugPrefix(), "GenerateEffectiveConfig error:", err)
		t.Fatalf("address config generation failed")
	}
	if addrObjs == nil {
		fmt.Println(ctestglobals.DebugPrefix(), "Skipping test execution. No new address configurations generated.")
		return
	}
	fmt.Println(ctestglobals.DebugPrefix(), "New Json Address Configs:", string(addrJSON))
	fmt.Println(ctestglobals.DebugPrefix(), "Number of address config objects:", len(addrObjs))

	// prepare fake cloud provider (addresses will be overridden per config)
	fakeCloud := &fakecloud.Cloud{
		Zone: cloudprovider.Zone{
			FailureDomain: "zone-0",
			Region:        "region-1",
		},
		EnableInstancesV2:  true,
		ExistsByProviderID: true,
		ProviderID: map[types.NodeName]string{
			types.NodeName("node-0"): "12345",
			types.NodeName("node-1"): "12345",
			types.NodeName("node-2"): "12345",
			types.NodeName("node-3"): "12345",
			types.NodeName("node-4"): "12345",
		},
		Addresses:       nil, // will be set dynamically
		ErrByProviderID: nil,
		Err:             nil,
	}
	cloudprovider.RegisterCloudProvider(
		"fakeCloud",
		func(config io.Reader) (cloudprovider.Interface, error) {
			return fakeCloud, nil
		})

	ccm := ccmservertesting.StartTestServerOrDie(ctx, args)
	defer ccm.TearDownFn()

	// original test cases plus edge cases
	origCases := []struct {
		name    string
		nodeIPs string
	}{
		{name: "IPv4", nodeIPs: "192.168.0.1"},
		{name: "IPv6", nodeIPs: "2001:db2::1"},
		{name: "IPv6-IPv4", nodeIPs: "2001:db2::1,172.16.0.1"},
		{name: "IPv4-IPv6", nodeIPs: "192.168.0.1,fd00:1:2:3:4::"},
	}
	edgeCases := []struct {
		name    string
		nodeIPs string
	}{
		{name: "Empty", nodeIPs: ""},
		{name: "Invalid", nodeIPs: "invalid-ip"},
		{name: "MixedInvalid", nodeIPs: "192.168.0.1,invalid-ip"},
	}
	testCases := append(origCases, edgeCases...)

	for _, addrObj := range addrObjs {
		// override fake cloud addresses
		fakeCloud.Addresses = addrObj

		for d, tc := range testCases {
			t.Run(tc.name, func(t *testing.T) {
				nodeName := fmt.Sprintf("node-%d-%d", d, time.Now().UnixNano())

				// dynamic node spec (same as hardcoded spec with external taint)
				nodeSpec := v1.NodeSpec{
					Taints: []v1.Taint{{
						Key:    cloudproviderapi.TaintExternalCloudProvider,
						Value:  "true",
						Effect: v1.TaintEffectNoSchedule,
					}},
				}
				node := &v1.Node{
					ObjectMeta: metav1.ObjectMeta{
						Name:        nodeName,
						Annotations: map[string]string{cloudproviderapi.AnnotationAlphaProvidedIPAddr: tc.nodeIPs},
					},
					Spec: nodeSpec,
				}
				_, err := client.CoreV1().Nodes().Create(ctx, node, metav1.CreateOptions{})
				if err != nil {
					t.Fatalf("Failed to create Node %v: %v", nodeName, err)
				}
				defer func() {
					if err := client.CoreV1().Nodes().Delete(ctx, node.Name, metav1.DeleteOptions{}); err != nil {
						t.Fatalf("Failed to delete Node %v: %v", node.Name, err)
					}
				}()

				err = wait.PollUntilContextTimeout(ctx, 1*time.Second, 50*time.Second, true, func(ctx context.Context) (bool, error) {
					n, err := client.CoreV1().Nodes().Get(ctx, nodeName, metav1.GetOptions{})
					if err != nil {
						return false, err
					}
					if len(n.Spec.Taints) != 1 {
						return false, nil
					}
					if n.Spec.Taints[0].Key != v1.TaintNodeNotReady {
						return false, nil
					}
					gotInternalIPs := []string{}
					for _, address := range n.Status.Addresses {
						if address.Type == v1.NodeInternalIP {
							gotInternalIPs = append(gotInternalIPs, address.Address)
						}
					}
					expectedIPs := strings.Split(tc.nodeIPs, ",")
					if !reflect.DeepEqual(gotInternalIPs, expectedIPs) {
						t.Logf("got node InternalIPs: %v expected: %v", gotInternalIPs, expectedIPs)
						return false, nil
					}
					return true, nil
				})
				if err != nil {
					t.Logf("Fake Cloud Provider calls: %v", fakeCloud.Calls)
					t.Fatalf("unexpected error: %v", err)
				}
			})
		}
	}
	fmt.Println(ctestglobals.EndSeparator)
}
