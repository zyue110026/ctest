package dryrun

import (
	"context"
	"fmt"
	"testing"

	// "k8s.io/apimachinery/pkg/util/uuid"
	// "k8s.io/apimachinery/pkg/util/sets"
	// "k8s.io/apimachinery/pkg/apis/meta/v1/unstructured"
	"k8s.io/apimachinery/pkg/runtime/schema"
	// "k8s.io/apimachinery/pkg/types"
	// "k8s.io/apimachinery/pkg/api/errors"
	metav1 "k8s.io/apimachinery/pkg/apis/meta/v1"
	"k8s.io/client-go/dynamic"
	"k8s.io/client-go/kubernetes"
	// "k8s.io/client-go/util/retry"

	apiextensionsclientset "k8s.io/apiextensions-apiserver/pkg/client/clientset/clientset"
	kubeapiservertesting "k8s.io/kubernetes/cmd/kube-apiserver/app/testing"
	"k8s.io/kubernetes/test/integration/etcd"
	"k8s.io/kubernetes/test/integration/framework"

	v1 "k8s.io/api/core/v1"

	ctest "k8s.io/kubernetes/test/ctest"
	ctestglobals "k8s.io/kubernetes/test/ctest/ctestglobals"
	ctestutils "k8s.io/kubernetes/test/ctest/utils"
)

const defaultTestNamespace = "dryrunnamespace"

func TestCtestDryRun(t *testing.T) {
	fmt.Println(ctestglobals.StartSeparator)

	// Load hard‑coded namespace configurations.
	hc := getHardCodedConfigInfoNamespace()
	item, found := ctestutils.GetItemByExactTestInfo(hc, "default dryrun namespace")
	if !found {
		fmt.Println(ctestglobals.DebugPrefix(), "Failed to find default namespace config")
		t.Fatalf("hard‑coded namespace config not found")
	}
	fmt.Println(ctestglobals.DebugPrefix(), "default namespace config item:", item)

	// Generate namespace variations (extend to add edge cases).
	nsObjs, nsJSON, err := ctest.GenerateEffectiveConfigReturnType[string](item, ctest.Union)
	if err != nil {
		fmt.Println(ctestglobals.DebugPrefix(), "Failed to generate namespace configs:", err)
		t.Fatalf("namespace config generation error: %v", err)
	}
	if nsObjs == nil || len(nsObjs) == 0 {
		fmt.Println(ctestglobals.DebugPrefix(), "Skipping test execution. No namespace configs generated.")
		return
	}
	fmt.Println(ctestglobals.DebugPrefix(), "New Json Namespace Configs:", string(nsJSON))
	fmt.Println(ctestglobals.DebugPrefix(), "Number of namespace test cases:", len(nsObjs))

	for i, ns := range nsObjs {
		fmt.Printf("Running namespace test case %d: %s\n", i, ns)
		runDryRunScenario(t, ns)
	}
	fmt.Println(ctestglobals.EndSeparator)
}

// runDryRunScenario executes the original dry‑run scenario using the provided namespace.
func runDryRunScenario(t *testing.T, testNamespace string) {
	// start API server
	s, err := kubeapiservertesting.StartTestServer(t, kubeapiservertesting.NewDefaultTestServerOptions(), []string{
		"--disable-admission-plugins=ServiceAccount,StorageObjectInUseProtection",
		"--runtime-config=api/all=true",
	}, framework.SharedEtcd())
	if err != nil {
		t.Fatal(err)
	}
	defer s.TearDownFn()

	client, err := kubernetes.NewForConfig(s.ClientConfig)
	if err != nil {
		t.Fatal(err)
	}
	dynamicClient, err := dynamic.NewForConfig(s.ClientConfig)
	if err != nil {
		t.Fatal(err)
	}

	// create CRDs so we can make sure that custom resources do not get lost
	etcd.CreateTestCRDs(t, apiextensionsclientset.NewForConfigOrDie(s.ClientConfig), false, etcd.GetCustomResourceDefinitionData()...)

	if _, err := client.CoreV1().Namespaces().Create(context.TODO(), &v1.Namespace{ObjectMeta: metav1.ObjectMeta{Name: testNamespace}}, metav1.CreateOptions{}); err != nil {
		t.Fatal(err)
	}

	dryrunData := etcd.GetEtcdStorageData()

	// dry run specific stub overrides (namespace‑aware)
	for resource, stub := range map[schema.GroupVersionResource]string{
		gvr("", "v1", "events"): fmt.Sprintf(`{"involvedObject": {"namespace": "%s"}, "message": "some data here", "metadata": {"name": "event1"}}`, testNamespace),
	} {
		data := dryrunData[resource]
		data.Stub = stub
		dryrunData[resource] = data
	}

	_, resources, err := client.Discovery().ServerGroupsAndResources()
	if err != nil {
		t.Fatalf("Failed to get ServerGroupsAndResources with error: %+v", err)
	}

	for _, resourceToTest := range etcd.GetResources(t, resources) {
		t.Run(resourceToTest.Mapping.Resource.String(), func(t *testing.T) {
			mapping := resourceToTest.Mapping
			kind := mapping.GroupVersionKind.Kind

			if kindAllowList.Has(kind) {
				t.Skip("allowlisted")
			}

			testData, hasTest := dryrunData[resourceToTest.Mapping.Resource]
			if !hasTest {
				t.Fatalf("no test data for %s. Please add a test for your new type to etcd.GetEtcdStorageData().", resourceToTest.Mapping.Resource)
			}

			rsc, obj, err := etcd.JSONToUnstructured(testData.Stub, testNamespace, mapping, dynamicClient)
			if err != nil {
				t.Fatalf("failed to unmarshal stub (%v): %v", testData.Stub, err)
			}

			name := obj.GetName()

			DryRunCreateTest(t, rsc, obj, resourceToTest.Mapping.Resource)

			if _, err := rsc.Create(context.TODO(), obj, metav1.CreateOptions{}); err != nil {
				t.Fatalf("failed to create stub for %s: %#v", resourceToTest.Mapping.Resource, err)
			}

			DryRunUpdateTest(t, rsc, name)
			DryRunPatchTest(t, rsc, name)
			DryRunScalePatchTest(t, rsc, name)
			DryRunScaleUpdateTest(t, rsc, name)
			if resourceToTest.HasDeleteCollection {
				DryRunDeleteCollectionTest(t, rsc, name)
			}
			DryRunDeleteTest(t, rsc, name)

			if err = rsc.Delete(context.TODO(), obj.GetName(), *metav1.NewDeleteOptions(0)); err != nil {
				t.Fatalf("deleting final object failed: %v", err)
			}
		})
	}
}

// ---------------------------------------------------------------------------
// Hard‑coded configuration extraction
// ---------------------------------------------------------------------------

func getHardCodedConfigInfoNamespace() ctestglobals.HardcodedConfig {
	return ctestglobals.HardcodedConfig{
		{
			FixtureFileName: "test_fixture.json",
			TestInfo:        []string{"default dryrun namespace"},
			Field:           "namespace",
			K8sObjects:      []string{"namespaces"},
			HardcodedConfig: defaultTestNamespace,
		},
	}
}
