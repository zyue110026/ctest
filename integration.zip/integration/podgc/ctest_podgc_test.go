package podgc

import (
	"context"
	"fmt"
	"testing"
	"time"

	"github.com/google/go-cmp/cmp"
	"github.com/google/go-cmp/cmp/cmpopts"
	// "github.com/onsi/gomega"
	// "github.com/onsi/gomega/types"
	"k8s.io/apimachinery/pkg/api/errors"
	metav1 "k8s.io/apimachinery/pkg/apis/meta/v1"
	utilversion "k8s.io/apimachinery/pkg/util/version"
	"k8s.io/apimachinery/pkg/util/wait"
	"k8s.io/apiserver/pkg/util/feature"
	// "k8s.io/client-go/informers"
	featuregatetesting "k8s.io/component-base/featuregate/testing"
	// "k8s.io/klog/v2"
	podutil "k8s.io/kubernetes/pkg/api/v1/pod"
	// "k8s.io/kubernetes/pkg/controller/podgc"
	"k8s.io/kubernetes/pkg/features"
	testutils "k8s.io/kubernetes/test/integration/util"
	"k8s.io/utils/ptr"

	v1 "k8s.io/api/core/v1"
	"k8s.io/apimachinery/pkg/util/uuid"

	ctest "k8s.io/kubernetes/test/ctest"
	ctestglobals "k8s.io/kubernetes/test/ctest/ctestglobals"
	ctestutils "k8s.io/kubernetes/test/ctest/utils"
)

// TestCtestPodGcOrphanedPodsWithFinalizer rewrites TestPodGcOrphanedPodsWithFinalizer with dynamic config and edge cases.
func TestCtestPodGcOrphanedPodsWithFinalizer(t *testing.T) {
	// Base test matrix (original semantics)
	baseTests := []struct {
		name                 string
		phase                v1.PodPhase
		wantPhase            v1.PodPhase
		wantDisruptionTarget *v1.PodCondition
	}{
		{
			name:      "pending pod",
			phase:     v1.PodPending,
			wantPhase: v1.PodFailed,
			wantDisruptionTarget: &v1.PodCondition{
				Type:               v1.DisruptionTarget,
				Status:             v1.ConditionTrue,
				ObservedGeneration: 1,
				Reason:             "DeletionByPodGC",
				Message:            "PodGC: node no longer exists",
			},
		},
		{
			name:      "succeeded pod",
			phase:     v1.PodSucceeded,
			wantPhase: v1.PodSucceeded,
		},
		{
			name:      "failed pod",
			phase:     v1.PodFailed,
			wantPhase: v1.PodFailed,
		},
		// Edge case: unknown phase (should remain unchanged)
		{
			name:      "unknown phase",
			phase:     v1.PodUnknown,
			wantPhase: v1.PodUnknown,
		},
		// Edge case: empty phase (zero value)
		{
			name:      "empty phase",
			phase:     "",
			wantPhase: "",
		},
	}

	fmt.Println(ctestglobals.DebugPrefix(), "Start TestCtestPodGcOrphanedPodsWithFinalizer")
	hc := getHardCodedConfigInfoPodGcOrphaned()

	item, found := ctestutils.GetItemByExactTestInfo(hc, "orphaned pod spec")
	if !found {
		t.Fatalf("hardcoded config not found")
	}
	fmt.Println(ctestglobals.DebugPrefix(), "Matched config:", item)

	configObjs, configJSON, err := ctest.GenerateEffectiveConfigReturnType[v1.PodSpec](item, ctest.ExtendOnly)
	if err != nil {
		t.Fatalf("GenerateEffectiveConfigReturnType failed: %v", err)
	}
	if configObjs == nil {
		fmt.Println(ctestglobals.DebugPrefix(), "Skipping test execution. No new configurations generated.")
		return
	}
	fmt.Println(ctestglobals.DebugPrefix(), "New Json Test Configs:", string(configJSON))
	fmt.Println(ctestglobals.DebugPrefix(), "Number of test configs:", len(configObjs))

	for i, cfg := range configObjs {
		fmt.Printf("Running config #%d\n", i)
		for _, tt := range baseTests {
			tt := tt // capture
			t.Run(fmt.Sprintf("%s-config%d", tt.name, i), func(t *testing.T) {
				ctx, cancel := context.WithCancel(context.Background())
				defer cancel()
				testCtx := setup(t, "podgc-orphaned")
				cs := testCtx.ClientSet

				// Create node (dynamic name)
				node := &v1.Node{
					ObjectMeta: metav1.ObjectMeta{
						Name: "node-" + string(uuid.NewUUID()),
					},
					Status: v1.NodeStatus{
						Conditions: []v1.NodeCondition{
							{
								Type:   v1.NodeReady,
								Status: v1.ConditionTrue,
							},
						},
					},
				}
				node, err = cs.CoreV1().Nodes().Create(ctx, node, metav1.CreateOptions{})
				if err != nil {
					t.Fatalf("Failed to create node: %v", err)
				}

				// Build pod from config template
				podSpec := cfg
				podSpec.NodeName = node.Name
				if len(podSpec.Containers) == 0 {
					// Edge case: ensure at least one container exists
					podSpec.Containers = []v1.Container{{Name: "default", Image: "busybox"}}
				}
				pod := &v1.Pod{
					ObjectMeta: metav1.ObjectMeta{
						Name:       "testpod-" + string(uuid.NewUUID()),
						Namespace:  testCtx.NS.Name,
						Finalizers: []string{"test.k8s.io/finalizer"},
					},
					Spec: podSpec,
				}
				pod, err = cs.CoreV1().Pods(testCtx.NS.Name).Create(ctx, pod, metav1.CreateOptions{})
				if err != nil {
					t.Fatalf("Error creating pod: %v", err)
				}
				defer testutils.RemovePodFinalizers(ctx, cs, t, *pod)

				// Set phase per matrix
				pod.Status.Phase = tt.phase
				if _, err := cs.CoreV1().Pods(testCtx.NS.Name).UpdateStatus(ctx, pod, metav1.UpdateOptions{}); err != nil {
					t.Fatalf("Error updating pod status: %v", err)
				}

				// Delete node to orphan pod
				if err := cs.CoreV1().Nodes().Delete(ctx, node.Name, metav1.DeleteOptions{}); err != nil {
					t.Fatalf("Failed to delete node: %v", err)
				}

				// Wait for eviction
				if err := wait.PollUntilContextTimeout(ctx, time.Second, 15*time.Second, true,
					testutils.PodIsGettingEvicted(cs, pod.Namespace, pod.Name)); err != nil {
					t.Fatalf("Error waiting for eviction: %v", err)
				}

				// Refresh pod
				pod, err = cs.CoreV1().Pods(testCtx.NS.Name).Get(ctx, pod.Name, metav1.GetOptions{})
				if err != nil {
					t.Fatalf("Error getting pod: %v", err)
				}
				_, gotDisruption := podutil.GetPodCondition(&pod.Status, v1.DisruptionTarget)
				if diff := cmp.Diff(tt.wantDisruptionTarget, gotDisruption, cmpopts.IgnoreFields(v1.PodCondition{}, "LastTransitionTime")); diff != "" {
					t.Errorf("DisruptionTarget diff: %s", diff)
				}
				if pod.Status.Phase != tt.wantPhase {
					t.Errorf("Phase mismatch: got %v, want %v", pod.Status.Phase, tt.wantPhase)
				}
			})
		}
	}
	fmt.Println(ctestglobals.EndSeparator)
}

// TestCtestTerminatingOnOutOfServiceNode rewrites TestTerminatingOnOutOfServiceNode with dynamic config and edge cases.
func TestCtestTerminatingOnOutOfServiceNode(t *testing.T) {
	baseTests := []struct {
		name                          string
		enableJobPodReplacementPolicy bool
		withFinalizer                 bool
		wantPhase                     v1.PodPhase
	}{
		{
			name:          "pod has phase changed to Failed",
			withFinalizer: true,
			wantPhase:     v1.PodFailed,
		},
		{
			name:          "pod is getting deleted when no finalizer",
			withFinalizer: false,
		},
		{
			name:                          "pod has phase changed when JobPodReplacementPolicy enabled",
			enableJobPodReplacementPolicy: true,
			withFinalizer:                 true,
			wantPhase:                     v1.PodFailed,
		},
		// Edge: enable policy but no finalizer (should not change phase)
		{
			name:                          "policy enabled without finalizer",
			enableJobPodReplacementPolicy: true,
			withFinalizer:                 false,
		},
	}

	fmt.Println(ctestglobals.DebugPrefix(), "Start TestCtestTerminatingOnOutOfServiceNode")
	hc := getHardCodedConfigInfoTerminating()

	item, found := ctestutils.GetItemByExactTestInfo(hc, "terminating pod spec")
	if !found {
		t.Fatalf("hardcoded config not found")
	}
	fmt.Println(ctestglobals.DebugPrefix(), "Matched config:", item)

	configObjs, configJSON, err := ctest.GenerateEffectiveConfigReturnType[v1.PodSpec](item, ctest.ExtendOnly)
	if err != nil {
		t.Fatalf("GenerateEffectiveConfigReturnType failed: %v", err)
	}
	if configObjs == nil {
		fmt.Println(ctestglobals.DebugPrefix(), "Skipping test execution. No new configurations generated.")
		return
	}
	fmt.Println(ctestglobals.DebugPrefix(), "New Json Test Configs:", string(configJSON))
	fmt.Println(ctestglobals.DebugPrefix(), "Number of test configs:", len(configObjs))

	for i, cfg := range configObjs {
		fmt.Printf("Running config #%d\n", i)
		for _, tt := range baseTests {
			tt := tt
			t.Run(fmt.Sprintf("%s-config%d", tt.name, i), func(t *testing.T) {
				if !tt.enableJobPodReplacementPolicy {
					featuregatetesting.SetFeatureGateEmulationVersionDuringTest(t, feature.DefaultFeatureGate, utilversion.MustParse("1.33"))
				}
				featuregatetesting.SetFeatureGateDuringTest(t, feature.DefaultFeatureGate, features.JobPodReplacementPolicy, tt.enableJobPodReplacementPolicy)

				ctx, cancel := context.WithCancel(context.Background())
				defer cancel()
				testCtx := setup(t, "podgc-out-of-service")
				cs := testCtx.ClientSet

				// Create node (out-of-service later)
				node := &v1.Node{
					ObjectMeta: metav1.ObjectMeta{
						Name: "node-" + string(uuid.NewUUID()),
					},
					Status: v1.NodeStatus{
						Conditions: []v1.NodeCondition{
							{
								Type:   v1.NodeReady,
								Status: v1.ConditionFalse,
							},
						},
					},
				}
				node, err := cs.CoreV1().Nodes().Create(ctx, node, metav1.CreateOptions{})
				if err != nil {
					t.Fatalf("Failed to create node: %v", err)
				}

				// Build pod from config
				podSpec := cfg
				podSpec.NodeName = node.Name
				if len(podSpec.Containers) == 0 {
					podSpec.Containers = []v1.Container{{Name: "default", Image: "busybox"}}
				}
				pod := &v1.Pod{
					ObjectMeta: metav1.ObjectMeta{
						Name:      "testpod-" + string(uuid.NewUUID()),
						Namespace: testCtx.NS.Name,
					},
					Spec: podSpec,
					Status: v1.PodStatus{
						Phase: v1.PodRunning,
					},
				}
				if tt.withFinalizer {
					pod.Finalizers = []string{"test.k8s.io/finalizer"}
				}
				pod, err = cs.CoreV1().Pods(testCtx.NS.Name).Create(ctx, pod, metav1.CreateOptions{})
				if err != nil {
					t.Fatalf("Error creating pod: %v", err)
				}
				if tt.withFinalizer {
					defer testutils.RemovePodFinalizers(ctx, cs, t, *pod)
				}

				// Delete pod with long grace period
				err = cs.CoreV1().Pods(testCtx.NS.Name).Delete(ctx, pod.Name, metav1.DeleteOptions{GracePeriodSeconds: ptr.To[int64](300)})
				if err != nil {
					t.Fatalf("Error deleting pod: %v", err)
				}

				// Wait for terminating state
				if err := wait.PollUntilContextTimeout(ctx, time.Second, 15*time.Second, true,
					testutils.PodIsGettingEvicted(cs, pod.Namespace, pod.Name)); err != nil {
					t.Fatalf("Error waiting for pod to be terminating: %v", err)
				}

				// Taint node out-of-service
				if err := testutils.AddTaintToNode(cs, pod.Spec.NodeName, v1.Taint{Key: v1.TaintNodeOutOfService, Value: "", Effect: v1.TaintEffectNoExecute}); err != nil {
					t.Fatalf("Failed to taint node: %v", err)
				}

				if tt.withFinalizer {
					// Wait for phase change
					err = wait.Poll(time.Second, 15*time.Second, func() (bool, error) {
						updatedPod, e := cs.CoreV1().Pods(pod.Namespace).Get(ctx, pod.Name, metav1.GetOptions{})
						if e != nil {
							return false, e
						}
						return updatedPod.Status.Phase == tt.wantPhase, nil
					})
					if err != nil && tt.wantPhase != "" {
						t.Errorf("Error waiting for phase %v: %v", tt.wantPhase, err)
					}
					if tt.wantPhase != "" {
						updatedPod, _ := cs.CoreV1().Pods(pod.Namespace).Get(ctx, pod.Name, metav1.GetOptions{})
						if _, cond := podutil.GetPodCondition(&updatedPod.Status, v1.DisruptionTarget); cond != nil {
							t.Errorf("Unexpected DisruptionTarget condition")
						}
					}
				} else {
					// Expect deletion
					err = wait.PollImmediate(time.Second, 15*time.Second, func() (bool, error) {
						_, e := cs.CoreV1().Pods(pod.Namespace).Get(ctx, pod.Name, metav1.GetOptions{})
						if e == nil {
							return false, nil
						}
						if errors.IsNotFound(e) {
							return true, nil
						}
						return false, e
					})
					if err != nil {
						t.Errorf("Error waiting for pod deletion: %v", err)
					}
				}
			})
		}
	}
	fmt.Println(ctestglobals.EndSeparator)
}

// TestCtestPodGcForPodsWithDuplicatedFieldKeys rewrites TestPodGcForPodsWithDuplicatedFieldKeys with dynamic config and edge cases.
func TestCtestPodGcForPodsWithDuplicatedFieldKeys(t *testing.T) {
	baseTests := []struct {
		name          string
		podTemplate   *v1.Pod
		wantCondition *v1.PodCondition
	}{
		{
			name: "Orphan pod with duplicated env vars",
			podTemplate: &v1.Pod{
				ObjectMeta: metav1.ObjectMeta{
					Name:       "testpod",
					Finalizers: []string{"test.k8s.io/finalizer"},
				},
				Spec: v1.PodSpec{
					NodeName: "non-existing-node",
					Containers: []v1.Container{
						{
							Name:  "foo",
							Image: "bar",
							Env: []v1.EnvVar{
								{Name: "XYZ", Value: "1"},
								{Name: "XYZ", Value: "2"},
							},
						},
					},
				},
			},
			wantCondition: &v1.PodCondition{
				Type:               v1.DisruptionTarget,
				Status:             v1.ConditionTrue,
				ObservedGeneration: 1,
				Reason:             "DeletionByPodGC",
				Message:            "PodGC: node no longer exists",
			},
		},
		{
			name: "Orphan pod with duplicated ports",
			podTemplate: &v1.Pod{
				ObjectMeta: metav1.ObjectMeta{
					Name:       "testpod",
					Finalizers: []string{"test.k8s.io/finalizer"},
				},
				Spec: v1.PodSpec{
					NodeName: "non-existing-node",
					Containers: []v1.Container{
						{
							Name:  "foo",
							Image: "bar",
							Ports: []v1.ContainerPort{
								{ContainerPort: 93, HostPort: 9376},
								{ContainerPort: 93, HostPort: 9377},
							},
						},
					},
				},
			},
			wantCondition: &v1.PodCondition{
				Type:               v1.DisruptionTarget,
				Status:             v1.ConditionTrue,
				ObservedGeneration: 1,
				Reason:             "DeletionByPodGC",
				Message:            "PodGC: node no longer exists",
			},
		},
		// Edge: empty container list (should still be evicted)
		{
			name: "Orphan pod with empty containers",
			podTemplate: &v1.Pod{
				ObjectMeta: metav1.ObjectMeta{
					Name:       "testpod",
					Finalizers: []string{"test.k8s.io/finalizer"},
				},
				Spec: v1.PodSpec{
					NodeName:   "non-existing-node",
					Containers: []v1.Container{},
				},
			},
			wantCondition: &v1.PodCondition{
				Type:               v1.DisruptionTarget,
				Status:             v1.ConditionTrue,
				ObservedGeneration: 1,
				Reason:             "DeletionByPodGC",
				Message:            "PodGC: node no longer exists",
			},
		},
	}

	fmt.Println(ctestglobals.DebugPrefix(), "Start TestCtestPodGcForPodsWithDuplicatedFieldKeys")
	hc := getHardCodedConfigInfoDuplicatedFields()

	item, found := ctestutils.GetItemByExactTestInfo(hc, "duplicated fields pod spec")
	if !found {
		t.Fatalf("hardcoded config not found")
	}
	fmt.Println(ctestglobals.DebugPrefix(), "Matched config:", item)

	// For this test we only need the pod template; use Override mode to allow modifications.
	configObjs, configJSON, err := ctest.GenerateEffectiveConfigReturnType[*v1.Pod](item, ctest.OverrideOnly)
	if err != nil {
		t.Fatalf("GenerateEffectiveConfigReturnType failed: %v", err)
	}
	if configObjs == nil {
		fmt.Println(ctestglobals.DebugPrefix(), "Skipping test execution. No new configurations generated.")
		return
	}
	fmt.Println(ctestglobals.DebugPrefix(), "New Json Test Configs:", string(configJSON))
	fmt.Println(ctestglobals.DebugPrefix(), "Number of test configs:", len(configObjs))

	for i, podTemplate := range configObjs {
		fmt.Printf("Running config #%d\n", i)
		for _, tt := range baseTests {
			tt := tt
			t.Run(fmt.Sprintf("%s-config%d", tt.name, i), func(t *testing.T) {
				ctx, cancel := context.WithCancel(context.Background())
				defer cancel()
				testCtx := setup(t, "podgc-orphaned")
				cs := testCtx.ClientSet

				// Apply dynamic name/namespace
				pod := podTemplate.DeepCopy()
				if pod == nil {
					// fallback to test's podTemplate if config generation returned nil
					pod = tt.podTemplate.DeepCopy()
				}
				pod.ObjectMeta.Name = "testpod-" + string(uuid.NewUUID())
				pod.ObjectMeta.Namespace = testCtx.NS.Name

				// Ensure finalizer present (original tests required it)
				if len(pod.ObjectMeta.Finalizers) == 0 {
					pod.ObjectMeta.Finalizers = []string{"test.k8s.io/finalizer"}
				}
				// Ensure non-existing node name is unique per run
				pod.Spec.NodeName = "nonexistent-" + string(uuid.NewUUID())

				createdPod, err := cs.CoreV1().Pods(testCtx.NS.Name).Create(ctx, pod, metav1.CreateOptions{})
				if err != nil {
					t.Fatalf("Error creating pod: %v", err)
				}
				defer testutils.RemovePodFinalizers(ctx, cs, t, *createdPod)

				// Wait for eviction due to non-existing node
				if err := wait.PollUntilContextTimeout(ctx, time.Second, 15*time.Second, true,
					testutils.PodIsGettingEvicted(cs, createdPod.Namespace, createdPod.Name)); err != nil {
					t.Fatalf("Error waiting for eviction: %v", err)
				}

				// Verify condition
				gotPod, err := cs.CoreV1().Pods(testCtx.NS.Name).Get(ctx, createdPod.Name, metav1.GetOptions{})
				if err != nil {
					t.Fatalf("Error fetching pod: %v", err)
				}
				_, gotCond := podutil.GetPodCondition(&gotPod.Status, v1.DisruptionTarget)
				if diff := cmp.Diff(tt.wantCondition, gotCond, cmpopts.IgnoreFields(v1.PodCondition{}, "LastTransitionTime")); diff != "" {
					t.Errorf("DisruptionTarget diff: %s", diff)
				}
				if gotCond != nil && gotCond.LastTransitionTime.IsZero() {
					t.Errorf("Condition missing LastTransitionTime")
				}
				if gotPod.Status.Phase != v1.PodFailed {
					t.Errorf("Expected pod phase Failed, got %v", gotPod.Status.Phase)
				}
			})
		}
	}
	fmt.Println(ctestglobals.EndSeparator)
}

// Helper to produce hardcoded config for orphaned pod spec (used in TestCtestPodGcOrphanedPodsWithFinalizer)
func getHardCodedConfigInfoPodGcOrphaned() ctestglobals.HardcodedConfig {
	return ctestglobals.HardcodedConfig{
		{
			FixtureFileName: "test_fixture.json",
			TestInfo:        []string{"orphaned pod spec"},
			Field:           "spec",
			K8sObjects:      []string{"pods"},
			HardcodedConfig: v1.PodSpec{
				Containers: []v1.Container{
					{
						Name:  "foo",
						Image: "bar",
					},
				},
			},
		},
	}
}

// Helper to produce hardcoded config for terminating pod spec (used in TestCtestTerminatingOnOutOfServiceNode)
func getHardCodedConfigInfoTerminating() ctestglobals.HardcodedConfig {
	return ctestglobals.HardcodedConfig{
		{
			FixtureFileName: "test_fixture.json",
			TestInfo:        []string{"terminating pod spec"},
			Field:           "spec",
			K8sObjects:      []string{"pods", "nodes"},
			HardcodedConfig: v1.PodSpec{
				Containers: []v1.Container{
					{
						Name:  "foo",
						Image: "bar",
					},
				},
			},
		},
	}
}

// Helper to produce hardcoded config for duplicated fields pod spec (used in TestCtestPodGcForPodsWithDuplicatedFieldKeys)
func getHardCodedConfigInfoDuplicatedFields() ctestglobals.HardcodedConfig {
	return ctestglobals.HardcodedConfig{
		{
			FixtureFileName: "test_fixture.json",
			TestInfo:        []string{"duplicated fields pod spec"},
			Field:           "spec",
			K8sObjects:      []string{"pods"},
			HardcodedConfig: v1.PodSpec{
				Containers: []v1.Container{
					{
						Name:  "foo",
						Image: "bar",
						Env: []v1.EnvVar{
							{Name: "XYZ", Value: "1"},
							{Name: "XYZ", Value: "2"},
						},
						Ports: []v1.ContainerPort{
							{ContainerPort: 93, HostPort: 9376},
							{ContainerPort: 93, HostPort: 9377},
						},
					},
				},
				NodeName: "non-existing-node",
			},
		},
	}
}
