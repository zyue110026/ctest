package client

import (
	"context"
	"encoding/json"
	"fmt"
	// "net/http"
	"reflect"
	"testing"
	"time"

	corev1 "k8s.io/api/core/v1"
	// "k8s.io/apimachinery/pkg/api/errors"
	metav1 "k8s.io/apimachinery/pkg/apis/meta/v1"
	"k8s.io/apimachinery/pkg/apis/meta/v1/unstructured"
	"k8s.io/apimachinery/pkg/runtime"
	"k8s.io/apimachinery/pkg/runtime/schema"
	"k8s.io/apimachinery/pkg/util/uuid"
	"k8s.io/apimachinery/pkg/util/wait"
	"k8s.io/apimachinery/pkg/watch"
	metav1ac "k8s.io/client-go/applyconfigurations/meta/v1"
	"k8s.io/client-go/discovery"
	"k8s.io/client-go/dynamic"
	clientset "k8s.io/client-go/kubernetes"
	// "k8s.io/client-go/rest"
	"k8s.io/apimachinery/pkg/fields"
	"k8s.io/apimachinery/pkg/types"
	kubeapiservertesting "k8s.io/kubernetes/cmd/kube-apiserver/app/testing"
	"k8s.io/kubernetes/test/integration/framework"

	ctest "k8s.io/kubernetes/test/ctest"
	ctestglobals "k8s.io/kubernetes/test/ctest/ctestglobals"
	ctestutils "k8s.io/kubernetes/test/ctest/utils"
)

func TestCtestDynamicClient(t *testing.T) {
	fmt.Println(ctestglobals.StartSeparator)

	result := kubeapiservertesting.StartTestServerOrDie(t, nil, framework.DefaultTestServerFlags(), framework.SharedEtcd())
	defer result.TearDownFn()

	client := clientset.NewForConfigOrDie(result.ClientConfig)
	dynamicClient, err := dynamic.NewForConfig(result.ClientConfig)
	if err != nil {
		t.Fatalf("unexpected error creating dynamic client: %v", err)
	}

	resource := schema.GroupVersionResource{Group: "", Version: "v1", Resource: "pods"}

	// --- generate pod spec configs -------------------------------------------------
	hardcoded := getHardCodedConfigInfoDynamicClientPodSpec()
	item, found := ctestutils.GetItemByExactTestInfo(hardcoded, "default pod spec")
	if !found {
		t.Fatalf("hardcoded config not found")
	}
	fmt.Println(ctestglobals.DebugPrefix(), "matched config:", item)
	configObjs, configJSON, err := ctest.GenerateEffectiveConfigReturnType[corev1.PodSpec](item, ctest.ExtendOnly)
	if err != nil {
		t.Fatalf("generate config error: %v", err)
	}
	fmt.Println(ctestglobals.DebugPrefix(), "New Json Test Configs:", string(configJSON))
	if configObjs == nil || len(configObjs) == 0 {
		fmt.Println(ctestglobals.DebugPrefix(), "Skipping test execution. No new configurations generated.")
		return
	}
	fmt.Println(ctestglobals.DebugPrefix(), "Number of test cases:", len(configObjs))

	for i, podSpec := range configObjs {
		fmt.Printf("Running %d th test case.\n", i)
		fmt.Println(podSpec)

		podName := "test-" + string(uuid.NewUUID())
		pod := &corev1.Pod{
			ObjectMeta: metav1.ObjectMeta{
				Name: podName,
			},
			Spec: podSpec,
		}

		// create via typed client
		actual, err := client.CoreV1().Pods("default").Create(context.TODO(), pod, metav1.CreateOptions{})
		if err != nil {
			t.Fatalf("unexpected error when creating pod: %v", err)
		}

		// dynamic list
		unstructuredList, err := dynamicClient.Resource(resource).Namespace("default").List(context.TODO(), metav1.ListOptions{})
		if err != nil {
			t.Fatalf("unexpected error when listing pods: %v", err)
		}
		if len(unstructuredList.Items) != 1 {
			t.Fatalf("expected one pod, got %d", len(unstructuredList.Items))
		}
		got, err := unstructuredToPod(&unstructuredList.Items[0])
		if err != nil {
			t.Fatalf("unexpected error converting Unstructured to v1.Pod: %v", err)
		}
		if !reflect.DeepEqual(actual, got) {
			t.Fatalf("unexpected pod in list. wanted %#v, got %#v", actual, got)
		}

		// dynamic get
		unstruct, err := dynamicClient.Resource(resource).Namespace("default").Get(context.TODO(), actual.Name, metav1.GetOptions{})
		if err != nil {
			t.Fatalf("unexpected error when getting pod %q: %v", actual.Name, err)
		}
		got, err = unstructuredToPod(unstruct)
		if err != nil {
			t.Fatalf("unexpected error converting Unstructured to v1.Pod: %v", err)
		}
		if !reflect.DeepEqual(actual, got) {
			t.Fatalf("unexpected pod after get. wanted %#v, got %#v", actual, got)
		}

		// dynamic delete
		err = dynamicClient.Resource(resource).Namespace("default").Delete(context.TODO(), actual.Name, metav1.DeleteOptions{})
		if err != nil {
			t.Fatalf("unexpected error when deleting pod: %v", err)
		}
		list, err := client.CoreV1().Pods("default").List(context.TODO(), metav1.ListOptions{})
		if err != nil {
			t.Fatalf("unexpected error when listing pods: %v", err)
		}
		if len(list.Items) != 0 {
			t.Fatalf("expected zero pods, got %d", len(list.Items))
		}
	}
	fmt.Println(ctestglobals.EndSeparator)
}

func TestCtestDynamicClientWatch(t *testing.T) {
	fmt.Println(ctestglobals.StartSeparator)

	result := kubeapiservertesting.StartTestServerOrDie(t, nil, framework.DefaultTestServerFlags(), framework.SharedEtcd())
	defer result.TearDownFn()

	client := clientset.NewForConfigOrDie(result.ClientConfig)
	dynamicClient, err := dynamic.NewForConfig(result.ClientConfig)
	if err != nil {
		t.Fatalf("unexpected error creating dynamic client: %v", err)
	}

	// generate event configs
	hardcoded := getHardCodedConfigInfoEvent()
	item, found := ctestutils.GetItemByExactTestInfo(hardcoded, "default event")
	if !found {
		t.Fatalf("hardcoded config not found")
	}
	fmt.Println(ctestglobals.DebugPrefix(), "matched config:", item)
	eventObjs, eventJSON, err := ctest.GenerateEffectiveConfigReturnType[corev1.Event](item, ctest.ExtendOnly)
	if err != nil {
		t.Fatalf("generate config error: %v", err)
	}
	fmt.Println(ctestglobals.DebugPrefix(), "New Json Test Configs:", string(eventJSON))
	if eventObjs == nil || len(eventObjs) == 0 {
		fmt.Println(ctestglobals.DebugPrefix(), "Skipping test execution. No new configurations generated.")
		return
	}
	fmt.Println(ctestglobals.DebugPrefix(), "Number of test cases:", len(eventObjs))

	resource := corev1.SchemeGroupVersion.WithResource("events")
	var rv1 string

	for i, ev := range eventObjs {
		name := fmt.Sprintf("event-%d", i)
		ev.ObjectMeta.Name = name
		ev.ObjectMeta.Namespace = "default"
		ev.InvolvedObject = corev1.ObjectReference{
			Namespace: "default",
			Name:      name,
		}
		ev.Reason = fmt.Sprintf("event %d", i)

		created, err := client.CoreV1().Events("default").Create(context.TODO(), &ev, metav1.CreateOptions{})
		if err != nil {
			t.Fatalf("Failed creating event %q: %v", ev.Name, err)
		}
		if rv1 == "" {
			rv1 = created.ResourceVersion
			if rv1 == "" {
				t.Fatal("did not get a resource version.")
			}
		}
	}

	w, err := dynamicClient.Resource(resource).Namespace("default").Watch(context.TODO(), metav1.ListOptions{
		ResourceVersion: rv1,
		Watch:           true,
		FieldSelector:   fields.OneTermEqualSelector("metadata.name", "event-9").String(),
	})
	if err != nil {
		t.Fatalf("Failed watch: %v", err)
	}
	defer w.Stop()

	select {
	case <-time.After(wait.ForeverTestTimeout):
		t.Fatalf("watch took longer than %s", wait.ForeverTestTimeout.String())
	case got, ok := <-w.ResultChan():
		if !ok {
			t.Fatal("Watch channel closed unexpectedly.")
		}
		if e, a := watch.Added, got.Type; e != a {
			t.Errorf("Wanted %v, got %v", e, a)
		}
		unstructured, ok := got.Object.(*unstructured.Unstructured)
		if !ok {
			t.Fatalf("Unexpected watch event containing object %#q", got.Object)
		}
		event, err := unstructuredToEvent(unstructured)
		if err != nil {
			t.Fatalf("unexpected error converting Unstructured to v1.Event: %v", err)
		}
		if e, a := "event-9", event.Name; e != a {
			t.Errorf("Wanted %v, got %v", e, a)
		}
	}
	fmt.Println(ctestglobals.EndSeparator)
}

func TestCtestUnstructuredExtract(t *testing.T) {
	fmt.Println(ctestglobals.StartSeparator)

	result := kubeapiservertesting.StartTestServerOrDie(t, nil, framework.DefaultTestServerFlags(), framework.SharedEtcd())
	defer result.TearDownFn()

	dynamicClient, err := dynamic.NewForConfig(result.ClientConfig)
	if err != nil {
		t.Fatalf("unexpected error creating dynamic client: %v", err)
	}

	// generate pod spec configs
	hardcoded := getHardCodedConfigInfoDynamicClientPodSpec()
	item, found := ctestutils.GetItemByExactTestInfo(hardcoded, "default pod spec")
	if !found {
		t.Fatalf("hardcoded config not found")
	}
	fmt.Println(ctestglobals.DebugPrefix(), "matched config:", item)
	podSpecs, podJSON, err := ctest.GenerateEffectiveConfigReturnType[corev1.PodSpec](item, ctest.ExtendOnly)
	if err != nil {
		t.Fatalf("generate config error: %v", err)
	}
	fmt.Println(ctestglobals.DebugPrefix(), "New Json Test Configs:", string(podJSON))
	if podSpecs == nil || len(podSpecs) == 0 {
		fmt.Println(ctestglobals.DebugPrefix(), "Skipping test execution. No new configurations generated.")
		return
	}
	fmt.Println(ctestglobals.DebugPrefix(), "Number of test cases:", len(podSpecs))

	resource := schema.GroupVersionResource{Group: "", Version: "v1", Resource: "pods"}
	mgr := "testManager"

	for i, spec := range podSpecs {
		name := fmt.Sprintf("test-pod-%d", i)
		podObj := &corev1.Pod{
			TypeMeta:   metav1.TypeMeta{APIVersion: "v1", Kind: "Pod"},
			ObjectMeta: metav1.ObjectMeta{Name: name, Namespace: "default"},
			Spec:       spec,
		}
		unstructuredMap, err := runtime.DefaultUnstructuredConverter.ToUnstructured(podObj)
		if err != nil {
			t.Fatalf("failed to convert pod to unstructured: %v", err)
		}
		unstructuredPod := &unstructured.Unstructured{Object: unstructuredMap}

		podData, err := json.Marshal(unstructuredPod)
		if err != nil {
			t.Fatalf("failed to marshal pod into bytes: %v", err)
		}

		actual, err := dynamicClient.Resource(resource).Namespace("default").Patch(
			context.TODO(),
			name,
			types.ApplyPatchType,
			podData,
			metav1.PatchOptions{FieldManager: mgr},
		)
		if err != nil {
			t.Fatalf("unexpected error when creating pod: %v", err)
		}

		discoveryClient := discovery.NewDiscoveryClientForConfigOrDie(result.ClientConfig)
		extractor, err := metav1ac.NewUnstructuredExtractor(discoveryClient)
		if err != nil {
			t.Fatalf("unexpected error when constructing extractor: %v", err)
		}
		extracted, err := extractor.Extract(actual, mgr)
		if err != nil {
			t.Fatalf("unexpected error when extracting: %v", err)
		}
		if !reflect.DeepEqual(podObj, extracted) {
			t.Fatalf("extracted pod doesn't equal applied pod. wanted:\n %v\n, got:\n %v\n", podObj, extracted)
		}
	}
	fmt.Println(ctestglobals.EndSeparator)
}

// hardcoded config generators ----------------------------------------------------

func getHardCodedConfigInfoDynamicClientPodSpec() ctestglobals.HardcodedConfig {
	return ctestglobals.HardcodedConfig{
		{
			FixtureFileName: "test_fixture.json",
			TestInfo:        []string{"default pod spec"},
			Field:           "containers",
			K8sObjects:      []string{"pods", "deployments", "statefulsets", "daemonsets", "replicasets"},
			HardcodedConfig: corev1.PodSpec{
				Containers: []corev1.Container{
					{
						Name:  "test",
						Image: "test-image",
					},
				},
				RestartPolicy: corev1.RestartPolicyNever,
			},
		},
	}
}

func getHardCodedConfigInfoEvent() ctestglobals.HardcodedConfig {
	return ctestglobals.HardcodedConfig{
		{
			FixtureFileName: "test_fixture.json",
			TestInfo:        []string{"default event"},
			Field:           "metadata",
			K8sObjects:      []string{"events"},
			HardcodedConfig: corev1.Event{
				ObjectMeta: metav1.ObjectMeta{
					Name:      "placeholder",
					Namespace: "default",
				},
				Reason: "placeholder",
			},
		},
	}
}
