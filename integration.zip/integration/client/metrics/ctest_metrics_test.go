package metrics

import (
	"context"
	"fmt"
	"strconv"
	// "strings"
	"testing"

	"k8s.io/apiextensions-apiserver/pkg/client/clientset/clientset"
	apierrors "k8s.io/apimachinery/pkg/api/errors"
	metav1 "k8s.io/apimachinery/pkg/apis/meta/v1"
	"k8s.io/apiserver/pkg/util/feature"
	featuregatetesting "k8s.io/component-base/featuregate/testing"
	"k8s.io/component-base/metrics/legacyregistry"
	apiregistrationv1 "k8s.io/kube-aggregator/pkg/apis/apiregistration/v1"
	aggregatorclient "k8s.io/kube-aggregator/pkg/client/clientset_generated/clientset"
	kubeapiservertesting "k8s.io/kubernetes/cmd/kube-apiserver/app/testing"
	"k8s.io/kubernetes/test/integration/framework"

	_ "k8s.io/component-base/metrics/prometheus/restclient"

	"k8s.io/apimachinery/pkg/util/uuid"

	ctest "k8s.io/kubernetes/test/ctest"
	ctestglobals "k8s.io/kubernetes/test/ctest/ctestglobals"
	ctestutils "k8s.io/kubernetes/test/ctest/utils"
)

func TestCtestAPIServerTransportMetrics(t *testing.T) {
	featuregatetesting.SetFeatureGateDuringTest(t, feature.DefaultFeatureGate, "AllAlpha", true)
	featuregatetesting.SetFeatureGateDuringTest(t, feature.DefaultFeatureGate, "AllBeta", true)

	legacyregistry.Reset()

	flags := framework.DefaultTestServerFlags()
	flags = append(flags, "--runtime-config=api/all=true,api/beta=true")
	result := kubeapiservertesting.StartTestServerOrDie(t, nil, flags, framework.SharedEtcd())
	defer result.TearDownFn()

	client := clientset.NewForConfigOrDie(result.ClientConfig)

	hits1, misses1, entries1 := checkTransportMetrics(t, client)
	if (hits1*100)/(hits1+misses1) < 85 {
		t.Fatalf("transport cache hit ratio %d lower than 90 percent", (hits1*100)/(hits1+misses1))
	}

	aggregatorClient := aggregatorclient.NewForConfigOrDie(result.ClientConfig)

	fmt.Println(ctestglobals.StartOverrideModeSeparator)
	hardcodedCfg := getHardCodedConfigInfoAPIServerTransportMetrics()
	item, found := ctestutils.GetItemByExactTestInfo(hardcodedCfg, "default apiservice spec")
	if !found {
		fmt.Println(ctestglobals.DebugPrefix(), "Failed to find config item by TestInfo")
		t.Fatalf("hardcoded config not found")
	}
	fmt.Println(ctestglobals.DebugPrefix(), "get default configs:", item)
	fmt.Println(ctestglobals.StartOverrideModeSeparator)
	specObjs, specJson, err := ctest.GenerateEffectiveConfigReturnType[apiregistrationv1.APIServiceSpec](item, ctest.OverrideOnly)
	if err != nil {
		fmt.Println(ctestglobals.DebugPrefix(), "Failed to get matched fixtures: %v", err)
		t.Fatalf("fixture generation error: %v", err)
	}
	if specObjs == nil {
		fmt.Println(ctestglobals.DebugPrefix(), "Skipping test execution. No new configurations generated.")
		// fallback to original hardcoded spec
		specObjs = []apiregistrationv1.APIServiceSpec{{
			Service: &apiregistrationv1.ServiceReference{
				Namespace: "kube-wardle",
				Name:      "api",
			},
			Group:                "wardle.example.com",
			Version:              "v1alpha1",
			GroupPriorityMinimum: 200,
			VersionPriority:      200,
		}}
	}
	fmt.Println(ctestglobals.DebugPrefix(), "New Json Test Configs:", string(specJson))
	fmt.Println(ctestglobals.DebugPrefix(), "Number of Test Cases:", len(specObjs))

	// add edge variations manually (valid but different values)
	edgeSpec := apiregistrationv1.APIServiceSpec{
		Service: &apiregistrationv1.ServiceReference{
			Namespace: "kube-wardle",
			Name:      "api",
		},
		Group:                "wardle.example.com",
		Version:              "v1alpha1",
		GroupPriorityMinimum: 0,
		VersionPriority:      0,
	}
	specObjs = append(specObjs, edgeSpec)

	for i, spec := range specObjs {
		fmt.Printf("Running %d th test case.\n", i)
		fmt.Println(spec)

		apiServiceObj := &apiregistrationv1.APIService{
			ObjectMeta: metav1.ObjectMeta{
				Name: fmt.Sprintf("v1alpha1-wardle-%s-%s", string(uuid.NewUUID()), strconv.Itoa(i)),
			},
			Spec: spec,
		}
		_, err := aggregatorClient.ApiregistrationV1().APIServices().Create(context.Background(), apiServiceObj, metav1.CreateOptions{})
		if err != nil {
			t.Fatalf("create apiservice failed: %v", err)
		}

		requests := 30
		errors := 0
		for j := 0; j < requests; j++ {
			apiService, err := aggregatorClient.ApiregistrationV1().APIServices().Get(context.Background(), apiServiceObj.Name, metav1.GetOptions{})
			if err != nil {
				t.Fatalf("get apiservice failed: %v", err)
			}
			apiService.Labels = map[string]string{"key": fmt.Sprintf("val%d", j)}
			_, err = aggregatorClient.ApiregistrationV1().APIServices().Update(context.Background(), apiService, metav1.UpdateOptions{})
			if err != nil && !apierrors.IsConflict(err) {
				t.Logf("unexpected error: %v", err)
				errors++
			}
		}
		if (errors*100)/requests > 20 {
			t.Fatalf("high number of errors during the test %d out of %d", errors, requests)
		}

		hits2, misses2, entries2 := checkTransportMetrics(t, client)
		if entries2-entries1 > 10 {
			t.Fatalf("possible transport leak, number of new cache entries increased by %d", entries2-entries1)
		}
		if (hits2*100)/(hits2+misses2) < 85 {
			t.Fatalf("transport cache hit ratio %d lower than 95 percent", (hits2*100)/(hits2+misses2))
		}
	}
}

func getHardCodedConfigInfoAPIServerTransportMetrics() ctestglobals.HardcodedConfig {
	return ctestglobals.HardcodedConfig{{
		FixtureFileName: "test_fixture.json",
		TestInfo:        []string{"default apiservice spec"},
		Field:           "spec",
		K8sObjects:      []string{"services"},
		HardcodedConfig: apiregistrationv1.APIServiceSpec{
			Service: &apiregistrationv1.ServiceReference{
				Namespace: "kube-wardle",
				Name:      "api",
			},
			Group:                "wardle.example.com",
			Version:              "v1alpha1",
			GroupPriorityMinimum: 200,
			VersionPriority:      200,
		},
	}}
}
