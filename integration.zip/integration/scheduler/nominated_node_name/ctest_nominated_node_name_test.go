package nominatednodename

import (
	"context"
	"fmt"
	"testing"
	// "time"

	// "github.com/onsi/gomega"
	"k8s.io/apimachinery/pkg/runtime"
	"k8s.io/apimachinery/pkg/util/uuid"
	"k8s.io/apiserver/pkg/util/feature"
	featuregatetesting "k8s.io/component-base/featuregate/testing"
	fwk "k8s.io/kube-scheduler/framework"
	"k8s.io/kubernetes/pkg/features"
	"k8s.io/kubernetes/pkg/scheduler"
	"k8s.io/kubernetes/pkg/scheduler/framework"
	frameworkruntime "k8s.io/kubernetes/pkg/scheduler/framework/runtime"
	schedulerutils "k8s.io/kubernetes/test/integration/scheduler"
	testutils "k8s.io/kubernetes/test/integration/util"

	ctest "k8s.io/kubernetes/test/ctest"
	ctestglobals "k8s.io/kubernetes/test/ctest/ctestglobals"
	ctestutils "k8s.io/kubernetes/test/ctest/utils"
	// "k8s.io/api/core/v1"
	// "k8s.io/kubernetes/pkg/scheduler/framework"
)

// TestCtestPutNominatedNodeNameInBindingCycle makes sure that nominatedNodeName is set in the binding cycle
// when the PreBind or Permit plugin (WaitOnPermit) is going to work.
func TestCtestPutNominatedNodeNameInBindingCycle(t *testing.T) {
	cancel := make(chan struct{})
	// Original test cases plus an edge case where Permit plugin returns an error status.
	tests := []struct {
		name                    string
		plugin                  framework.Plugin
		expectNominatedNodeName bool
		cleanup                 func()
	}{
		{
			name:                    "NominatedNodeName is put if PreBindPlugin will run",
			plugin:                  &RunForeverPreBindPlugin{cancel: cancel},
			expectNominatedNodeName: true,
			cleanup: func() {
				close(cancel)
			},
		},
		{
			name:                    "NominatedNodeName is put if PermitPlugin will run at WaitOnPermit",
			expectNominatedNodeName: true,
			plugin: &FakePermitPlugin{
				code: fwk.Wait,
			},
		},
		{
			name: "NominatedNodeName is not put if PermitPlugin won't run at WaitOnPermit",
			plugin: &FakePermitPlugin{
				code: fwk.Success,
			},
		},
		{
			name:   "NominatedNodeName is not put if PermitPlugin nor PreBindPlugin will run",
			plugin: nil,
		},
		{
			name:                    "Edge: PermitPlugin returns error status, no nominatedNodeName expected",
			plugin:                  &FakePermitPlugin{code: fwk.Error},
			expectNominatedNodeName: false,
		},
	}

	fmt.Println(ctestglobals.StartExtendModeSeparator)
	hardcodedCfg := getHardCodedConfigInfoPausePod()
	item, found := ctestutils.GetItemByExactTestInfo(hardcodedCfg, "default pause pod")
	if !found {
		t.Fatalf("Hardcoded config for pause pod not found")
	}
	fmt.Println(ctestglobals.DebugPrefix(), "matched config item:", item)

	cfgObjs, cfgJSON, err := ctest.GenerateEffectiveConfigReturnType[map[string]string](item, ctest.ExtendOnly)
	if err != nil {
		t.Fatalf("Failed to generate config: %v", err)
	}
	if cfgObjs == nil {
		fmt.Println(ctestglobals.DebugPrefix(), "Skipping test execution. No new configurations generated.")
		return
	}
	fmt.Println(ctestglobals.DebugPrefix(), "New Json Test Configs:", string(cfgJSON))
	fmt.Println(ctestglobals.DebugPrefix(), "Number of test configs:", len(cfgObjs))

	for _, test := range tests {
		t.Run(test.name, func(t *testing.T) {
			featuregatetesting.SetFeatureGateDuringTest(t, feature.DefaultFeatureGate, features.NominatedNodeNameForExpectation, true)

			testContext := testutils.InitTestAPIServer(t, "nnn-test", nil)
			if test.cleanup != nil {
				defer test.cleanup()
			}

			pf := func(plugin framework.Plugin) frameworkruntime.PluginFactory {
				return func(_ context.Context, _ runtime.Object, fh framework.Handle) (framework.Plugin, error) {
					return plugin, nil
				}
			}

			plugins := []framework.Plugin{&NoNNNPostBindPlugin{cancel: testContext.Ctx.Done(), t: t}}
			if test.plugin != nil {
				plugins = append(plugins, test.plugin)
			}

			registry, prof := schedulerutils.InitRegistryAndConfig(t, pf, plugins...)

			testCtx, teardown := schedulerutils.InitTestSchedulerForFrameworkTest(t, testContext, 10, true,
				scheduler.WithProfiles(prof),
				scheduler.WithFrameworkOutOfTreeRegistry(registry))
			defer teardown()

			// Build pod name from dynamic config (if any) or fallback.
			podName := "test-pod-" + string(uuid.NewUUID())
			if len(cfgObjs) > 0 {
				if v, ok := cfgObjs[0]["name"]; ok && v != "" {
					podName = v + "-" + string(uuid.NewUUID())
				}
			}
			pod, err := testutils.CreatePausePod(testCtx.ClientSet,
				testutils.InitPausePod(&testutils.PausePodConfig{
					Name:      podName,
					Namespace: testCtx.NS.Name,
				}))
			if err != nil {
				t.Fatalf("Error while creating a test pod: %v", err)
			}

			if test.expectNominatedNodeName {
				if err := testutils.WaitForNominatedNodeName(testCtx.Ctx, testCtx.ClientSet, pod); err != nil {
					t.Errorf(".status.nominatedNodeName was not set for pod %v/%v: %v", pod.Namespace, pod.Name, err)
				}
			} else {
				if err := testutils.WaitForPodToSchedule(testCtx.Ctx, testCtx.ClientSet, pod); err != nil {
					t.Errorf("Pod %v/%v was not scheduled: %v", pod.Namespace, pod.Name, err)
				}
			}
		})
	}
}

// getHardCodedConfigInfoPausePod returns the minimal hardcoded configuration for a pause pod used in the test.
// The configuration is limited to the pod name, which is dynamically overridden in the test.
func getHardCodedConfigInfoPausePod() ctestglobals.HardcodedConfig {
	return ctestglobals.HardcodedConfig{
		{
			FixtureFileName: "test_fixture.json",
			TestInfo:        []string{"default pause pod"},
			Field:           "name",
			K8sObjects:      []string{"pods"},
			HardcodedConfig: map[string]string{
				"name": "test-pod",
			},
		},
	}
}
