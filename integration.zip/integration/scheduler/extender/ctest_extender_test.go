package extender

import (
	"context"
	// "encoding/json"
	"fmt"
	"net/http"
	"net/http/httptest"
	// "strings"
	"testing"
	"time"

	v1 "k8s.io/api/core/v1"
	"k8s.io/apimachinery/pkg/api/resource"
	metav1 "k8s.io/apimachinery/pkg/apis/meta/v1"
	"k8s.io/apimachinery/pkg/util/uuid"
	"k8s.io/apimachinery/pkg/util/wait"
	"k8s.io/client-go/kubernetes"
	// extenderv1 "k8s.io/kube-scheduler/extender/v1"
	"k8s.io/kubernetes/pkg/scheduler"
	schedulerapi "k8s.io/kubernetes/pkg/scheduler/apis/config"
	testutils "k8s.io/kubernetes/test/integration/util"
	imageutils "k8s.io/kubernetes/test/utils/image"

	ctest "k8s.io/kubernetes/test/ctest"
	ctestglobals "k8s.io/kubernetes/test/ctest/ctestglobals"
	// ctestutils "k8s.io/kubernetes/test/ctest/utils"
)

func TestCtestSchedulerExtender(t *testing.T) {
	testCtx := testutils.InitTestAPIServer(t, "scheduler-extender", nil)
	clientSet := testCtx.ClientSet

	extender1 := &Extender{
		name:         "extender1",
		predicates:   []fitPredicate{machine1_2_3Predicate},
		prioritizers: []priorityConfig{{machine2Prioritizer, 1}},
	}
	es1 := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, req *http.Request) {
		extender1.serveHTTP(t, w, req)
	}))
	defer es1.Close()

	extender2 := &Extender{
		name:         "extender2",
		predicates:   []fitPredicate{machine2_3_5Predicate},
		prioritizers: []priorityConfig{{machine3Prioritizer, 1}},
		Client:       clientSet,
	}
	es2 := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, req *http.Request) {
		extender2.serveHTTP(t, w, req)
	}))
	defer es2.Close()

	extender3 := &Extender{
		name:             "extender3",
		predicates:       []fitPredicate{machine1_2_3Predicate},
		prioritizers:     []priorityConfig{{machine2Prioritizer, 5}},
		nodeCacheCapable: true,
	}
	es3 := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, req *http.Request) {
		extender3.serveHTTP(t, w, req)
	}))
	defer es3.Close()

	extenders := []schedulerapi.Extender{
		{
			URLPrefix:      es1.URL,
			FilterVerb:     filter,
			PrioritizeVerb: prioritize,
			Weight:         3,
			EnableHTTPS:    false,
		},
		{
			URLPrefix:      es2.URL,
			FilterVerb:     filter,
			PrioritizeVerb: prioritize,
			BindVerb:       bind,
			Weight:         4,
			EnableHTTPS:    false,
			ManagedResources: []schedulerapi.ExtenderManagedResource{
				{
					Name:               extendedResourceName,
					IgnoredByScheduler: true,
				},
			},
		},
		{
			URLPrefix:        es3.URL,
			FilterVerb:       filter,
			PrioritizeVerb:   prioritize,
			Weight:           10,
			EnableHTTPS:      false,
			NodeCacheCapable: true,
		},
	}

	testCtx = testutils.InitTestSchedulerWithOptions(t, testCtx, 0, scheduler.WithExtenders(extenders...))
	testutils.SyncSchedulerInformerFactory(testCtx)
	go testCtx.Scheduler.Run(testCtx.Ctx)

	DoCtestPodScheduling(testCtx.NS, t, clientSet)
}

// Dynamic scheduling test with generated node and pod configurations.
func DoCtestPodScheduling(ns *v1.Namespace, t *testing.T, cs kubernetes.Interface) {
	// Cleanup nodes after test.
	defer cs.CoreV1().Nodes().DeleteCollection(context.TODO(), metav1.DeleteOptions{}, metav1.ListOptions{})

	fmt.Println(ctestglobals.DebugPrefix(), "Generating node configurations")
	nodeConfigs, nodeJson, err := ctest.GenerateEffectiveConfigReturnType[v1.Node](getHardCodedConfigInfoNode()[0], ctest.ExtendOnly)
	if err != nil {
		t.Fatalf("failed to generate node configs: %v", err)
	}
	fmt.Println(ctestglobals.DebugPrefix(), "Node configs JSON:", string(nodeJson))
	if nodeConfigs == nil || len(nodeConfigs) == 0 {
		fmt.Println(ctestglobals.DebugPrefix(), "Skipping node creation, no configs generated")
		return
	}
	fmt.Println(ctestglobals.DebugPrefix(), "Number of node configs:", len(nodeConfigs))

	// Generate pod spec configs.
	fmt.Println(ctestglobals.DebugPrefix(), "Generating pod spec configurations")
	podSpecs, podJson, err := ctest.GenerateEffectiveConfigReturnType[v1.PodSpec](getHardCodedConfigInfoPodSpec()[0], ctest.ExtendOnly)
	if err != nil {
		t.Fatalf("failed to generate pod specs: %v", err)
	}
	fmt.Println(ctestglobals.DebugPrefix(), "Pod spec configs JSON:", string(podJson))
	if podSpecs == nil || len(podSpecs) == 0 {
		fmt.Println(ctestglobals.DebugPrefix(), "Skipping pod creation, no pod specs generated")
		return
	}
	fmt.Println(ctestglobals.DebugPrefix(), "Number of pod spec configs:", len(podSpecs))

	for i, node := range nodeConfigs {
		node.Name = fmt.Sprintf("machine%d", i+1)
		if _, err := createNode(cs, &node); err != nil {
			t.Fatalf("Failed to create node %s: %v", node.Name, err)
		}
	}

	for _, podSpec := range podSpecs {
		pod := &v1.Pod{
			ObjectMeta: metav1.ObjectMeta{
				Name: fmt.Sprintf("extender-test-pod-%s", string(uuid.NewUUID())),
			},
			Spec: podSpec,
		}
		createdPod, err := cs.CoreV1().Pods(ns.Name).Create(context.TODO(), pod, metav1.CreateOptions{})
		if err != nil {
			t.Fatalf("Failed to create pod: %v", err)
		}
		if err := wait.PollUntilContextTimeout(context.TODO(), time.Second, wait.ForeverTestTimeout, false,
			testutils.PodScheduled(cs, createdPod.Namespace, createdPod.Name)); err != nil {
			t.Fatalf("Failed to schedule pod: %v", err)
		}
		gotPod, err := cs.CoreV1().Pods(ns.Name).Get(context.TODO(), createdPod.Name, metav1.GetOptions{})
		if err != nil {
			t.Fatalf("Failed to get pod after scheduling: %v", err)
		}
		if gotPod.Spec.NodeName != "machine2" {
			t.Fatalf("Expected pod to be scheduled to machine2, got %s", gotPod.Spec.NodeName)
		}
		var zero int64
		if err := cs.CoreV1().Pods(ns.Name).Delete(context.TODO(), gotPod.Name, metav1.DeleteOptions{GracePeriodSeconds: &zero}); err != nil {
			t.Fatalf("Failed to delete pod: %v", err)
		}
		_, err = cs.CoreV1().Pods(ns.Name).Get(context.TODO(), gotPod.Name, metav1.GetOptions{})
		if err == nil {
			t.Fatalf("Pod still exists after deletion")
		}
		t.Logf("Scheduled pod using extenders")
	}
}

// Hardcoded node configuration for dynamic generation.
func getHardCodedConfigInfoNode() ctestglobals.HardcodedConfig {
	return ctestglobals.HardcodedConfig{
		{
			FixtureFileName: "test_fixture.json",
			TestInfo:        []string{"default node config"},
			Field:           "spec",
			K8sObjects:      []string{"nodes"},
			HardcodedConfig: v1.Node{
				Spec: v1.NodeSpec{Unschedulable: false},
				Status: v1.NodeStatus{
					Capacity: v1.ResourceList{
						v1.ResourcePods: *resource.NewQuantity(32, resource.DecimalSI),
					},
					Conditions: []v1.NodeCondition{
						{
							Type:   v1.NodeReady,
							Status: v1.ConditionTrue,
							Reason: "schedulable condition",
						},
					},
				},
			},
		},
	}
}

// Hardcoded pod spec configuration for dynamic generation.
func getHardCodedConfigInfoPodSpec() ctestglobals.HardcodedConfig {
	return ctestglobals.HardcodedConfig{
		{
			FixtureFileName: "test_fixture.json",
			TestInfo:        []string{"default pod spec"},
			Field:           "spec",
			K8sObjects: []string{
				"pods", "deployments", "statefulsets", "daemonsets", "replicasets",
			},
			HardcodedConfig: v1.PodSpec{
				Containers: []v1.Container{
					{
						Name:  "container",
						Image: imageutils.GetPauseImageName(),
						Resources: v1.ResourceRequirements{
							Limits: v1.ResourceList{
								extendedResourceName: *resource.NewQuantity(1, resource.DecimalSI),
							},
						},
					},
				},
			},
		},
	}
}
