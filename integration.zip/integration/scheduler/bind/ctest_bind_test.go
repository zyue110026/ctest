package bind

import (
	"fmt"
	"testing"

	corev1 "k8s.io/api/core/v1"
	metav1 "k8s.io/apimachinery/pkg/apis/meta/v1"
	utilfeature "k8s.io/apiserver/pkg/util/feature"
	featuregatetesting "k8s.io/component-base/featuregate/testing"
	fwk "k8s.io/kube-scheduler/framework"
	"k8s.io/kubernetes/pkg/features"
	framework "k8s.io/kubernetes/pkg/scheduler/framework"
	// st "k8s.io/kubernetes/pkg/scheduler/testing"
	testutil "k8s.io/kubernetes/test/integration/util"
	"k8s.io/kubernetes/test/utils/ktesting"

	"github.com/google/uuid"

	ctest "k8s.io/kubernetes/test/ctest"
	ctestglobals "k8s.io/kubernetes/test/ctest/ctestglobals"
	ctestutils "k8s.io/kubernetes/test/ctest/utils"
)

func TestCtestDefaultBinder(t *testing.T) {
	fmt.Println(ctestglobals.StartSeparator)
	configs := getHardCodedConfigInfoBinder()

	// -------- Node config ----------
	nodeItem, found := ctestutils.GetItemByExactTestInfo(configs, "default node")
	if !found {
		fmt.Println(ctestglobals.DebugPrefix(), "Node config not found, skipping test.")
		fmt.Println(ctestglobals.EndSeparator)
		return
	}
	nodeObjs, nodeJson, err := ctest.GenerateEffectiveConfigReturnType[corev1.Node](nodeItem, ctest.ExtendOnly)
	if err != nil {
		fmt.Println(ctestglobals.DebugPrefix(), "Failed to generate node config:", err)
		fmt.Println(ctestglobals.EndSeparator)
		return
	}
	if nodeObjs == nil || len(nodeObjs) == 0 {
		fmt.Println(ctestglobals.DebugPrefix(), "No node config objects generated, skipping.")
		fmt.Println(ctestglobals.EndSeparator)
		return
	}
	fmt.Println(ctestglobals.DebugPrefix(), "New Json Node Configs:", string(nodeJson))
	fmt.Println(ctestglobals.DebugPrefix(), "Number of node configs:", len(nodeObjs))

	// -------- Pod config ----------
	podItem, found := ctestutils.GetItemByExactTestInfo(configs, "default pause pod")
	if !found {
		fmt.Println(ctestglobals.DebugPrefix(), "Pod config not found, skipping test.")
		fmt.Println(ctestglobals.EndSeparator)
		return
	}
	podObjs, podJson, err := ctest.GenerateEffectiveConfigReturnType[corev1.Pod](podItem, ctest.ExtendOnly)
	if err != nil {
		fmt.Println(ctestglobals.DebugPrefix(), "Failed to generate pod config:", err)
		fmt.Println(ctestglobals.EndSeparator)
		return
	}
	if podObjs == nil || len(podObjs) == 0 {
		fmt.Println(ctestglobals.DebugPrefix(), "No pod config objects generated, skipping.")
		fmt.Println(ctestglobals.EndSeparator)
		return
	}
	fmt.Println(ctestglobals.DebugPrefix(), "New Json Pod Configs:", string(podJson))
	fmt.Println(ctestglobals.DebugPrefix(), "Number of pod configs:", len(podObjs))

	// Use the first generated node and pod as base objects.
	baseNode := nodeObjs[0]
	basePod := podObjs[0]

	for _, asyncAPICallsEnabled := range []bool{true, false} {
		t.Run(fmt.Sprintf("Async API calls enabled: %v", asyncAPICallsEnabled), func(t *testing.T) {
			featuregatetesting.SetFeatureGateDuringTest(t, utilfeature.DefaultFeatureGate, features.SchedulerAsyncAPICalls, asyncAPICallsEnabled)

			testCtx := testutil.InitTestSchedulerWithOptions(t, testutil.InitTestAPIServer(t, "", nil), 0)
			testutil.SyncSchedulerInformerFactory(testCtx)
			if testCtx.Scheduler.APIDispatcher != nil {
				logger, _ := ktesting.NewTestContext(t)
				testCtx.Scheduler.APIDispatcher.Run(logger)
				defer testCtx.Scheduler.APIDispatcher.Close()
			}

			// Create node from base config (extend with a unique suffix)
			node := baseNode.DeepCopy()
			node.Name = fmt.Sprintf("testnode-%s", uuid.New().String())
			createdNode, err := testutil.CreateNode(testCtx.ClientSet, node)
			if err != nil {
				t.Fatalf("Failed to create node: %v", err)
			}
			_ = createdNode // node name already set above

			// Define test cases, including edge case with empty node name.
			tests := map[string]struct {
				anotherUID     bool
				emptyNodeName  bool
				wantStatusCode fwk.Code
			}{
				"same UID": {
					wantStatusCode: fwk.Success,
				},
				"different UID": {
					anotherUID:     true,
					wantStatusCode: fwk.Error,
				},
				"empty node name": {
					emptyNodeName:  true,
					wantStatusCode: fwk.Error,
				},
			}
			for name, tc := range tests {
				t.Run(name, func(t *testing.T) {
					// Create pod from base config
					pod := basePod.DeepCopy()
					pod.Namespace = testCtx.NS.Name
					pod.Name = fmt.Sprintf("fixed-name-%s", uuid.New().String())
					createdPod, err := testutil.CreatePausePodWithResource(testCtx.ClientSet, pod.Name, testCtx.NS.Name, nil)
					if err != nil {
						t.Fatalf("Failed to create pod: %v", err)
					}
					defer testutil.CleanupPods(testCtx.Ctx, testCtx.ClientSet, t, []*corev1.Pod{createdPod})

					podCopy := createdPod.DeepCopy()
					if tc.anotherUID {
						podCopy.UID = "another"
					}
					if tc.emptyNodeName {
						node.Name = ""
					}

					status := testCtx.Scheduler.Profiles["default-scheduler"].RunBindPlugins(testCtx.Ctx, framework.NewCycleState(), podCopy, node.Name)
					if code := status.Code(); code != tc.wantStatusCode {
						t.Errorf("Bind returned code %s, want %s", code, tc.wantStatusCode)
					}
				})
			}
		})
	}
}

// fmt.Println(ctestglobals.EndSeparator)

// Hardcoded configuration definitions for dynamic test generation.
func getHardCodedConfigInfoBinder() ctestglobals.HardcodedConfig {
	return ctestglobals.HardcodedConfig{
		{
			FixtureFileName: "test_fixture.json",
			TestInfo:        []string{"default node"},
			Field:           "name",
			K8sObjects:      []string{"nodes"},
			HardcodedConfig: corev1.Node{
				ObjectMeta: metav1.ObjectMeta{
					Name: "testnode",
				},
			},
		},
		{
			FixtureFileName: "test_fixture.json",
			TestInfo:        []string{"default pause pod"},
			Field:           "metadata.name",
			K8sObjects:      []string{"pods"},
			HardcodedConfig: corev1.Pod{
				ObjectMeta: metav1.ObjectMeta{
					Name: "fixed-name",
				},
				Spec: corev1.PodSpec{
					Containers: []corev1.Container{
						{
							Name:  "pause",
							Image: "k8s.gcr.io/pause:3.2",
						},
					},
					RestartPolicy: corev1.RestartPolicyNever,
				},
			},
		},
	}
}
