package openapi

import (
	"context"
	"encoding/json"
	"fmt"
	"strings"
	"testing"
	"time"

	apiextensionsv1 "k8s.io/apiextensions-apiserver/pkg/apis/apiextensions/v1"
	"k8s.io/apiextensions-apiserver/pkg/client/clientset/clientset"
	"k8s.io/apiextensions-apiserver/test/integration/fixtures"
	ctest "k8s.io/kubernetes/test/ctest"
	ctestglobals "k8s.io/kubernetes/test/ctest/ctestglobals"
	ctestutils "k8s.io/kubernetes/test/ctest/utils"
	metav1 "k8s.io/apimachinery/pkg/apis/meta/v1"
	"k8s.io/apimachinery/pkg/util/wait"
	"k8s.io/client-go/dynamic"
	kubernetes "k8s.io/client-go/kubernetes"
	"k8s.io/kube-openapi/pkg/validation/spec"
	apiservertesting "k8s.io/kubernetes/cmd/kube-apiserver/app/testing"
	"k8s.io/kubernetes/test/integration/framework"
)

func TestCtestOpenAPIV2CRDMergeNoDuplicateTypes(t *testing.T) {
	fmt.Println(ctestglobals.StartSeparator)

	// Retrieve hardcoded config for the CRD merge test
	hc := getHardCodedConfigInfoCRDMerge()
	item, found := ctestutils.GetItemByExactTestInfo(hc, "foo baz crd merge")
	if !found {
		fmt.Println(ctestglobals.DebugPrefix(), "Failed to find config item by TestInfo")
		t.Fatalf("Failed to find hardcoded config for CRD merge test")
	}
	fmt.Println(ctestglobals.DebugPrefix(), "get default configs:", item)

	// Generate effective configuration (override mode)
	configObjs, configJson, err := ctest.GenerateEffectiveConfigReturnType[*apiextensionsv1.CustomResourceDefinition](item, ctest.OverrideOnly)
	if err != nil {
		fmt.Println(ctestglobals.DebugPrefix(), "Failed to generate config:", err)
		t.Fatalf("Failed to generate config: %v", err)
	}
	if configObjs == nil {
		fmt.Println(ctestglobals.DebugPrefix(), "Skipping test execution. No new config objs found.")
		fmt.Println(ctestglobals.EndSeparator)
		return
	}
	fmt.Println(ctestglobals.DebugPrefix(), "New Json Test Configs:", string(configJson))
	fmt.Println(ctestglobals.DebugPrefix(), "Number of test cases:", len(configObjs))

	// Start test API server
	server, err := apiservertesting.StartTestServer(t, apiservertesting.NewDefaultTestServerOptions(), nil, framework.SharedEtcd())
	if err != nil {
		t.Fatal(err)
	}
	defer server.TearDownFn()
	config := server.ClientConfig

	apiExtensionClient, err := clientset.NewForConfig(config)
	if err != nil {
		t.Fatal(err)
	}
	dynamicClient, err := dynamic.NewForConfig(config)
	if err != nil {
		t.Fatal(err)
	}
	clientset, err := kubernetes.NewForConfig(config)
	if err != nil {
		t.Fatal(err)
	}

	// Create each CRD from the generated configs
	for i, crd := range configObjs {
		fmt.Printf("Creating CRD #%d: %s\n", i, crd.Name)
		_, err = fixtures.CreateNewV1CustomResourceDefinition(crd, apiExtensionClient, dynamicClient)
		if err != nil {
			t.Fatalf("failed to create CRD %s: %v", crd.Name, err)
		}
	}

	// Poll for OpenAPI v2 to be updated with the new CRDs
	var openAPISpec spec.Swagger
	wait.Poll(time.Second*1, wait.ForeverTestTimeout, func() (bool, error) {
		jsonData, err := clientset.RESTClient().Get().AbsPath("/openapi/v2").Do(context.TODO()).Raw()
		if err != nil {
			return false, err
		}
		openAPISpec = spec.Swagger{}
		if err = json.Unmarshal(jsonData, &openAPISpec); err != nil {
			return false, err
		}
		for schemaName := range openAPISpec.Definitions {
			if strings.HasPrefix(schemaName, "com.bar.cr.v1.BazSub") {
				return true, nil
			}
		}
		return false, nil
	})

	// Verify that no _v2 type definitions exist
	for schemaName := range openAPISpec.Definitions {
		if strings.HasSuffix(schemaName, "_v2") {
			t.Errorf("Error: Expected no _v2 types, got %s", schemaName)
		}
	}

	fmt.Println(ctestglobals.EndSeparator)
}

// Hardcoded configurations for the CRD merge test.
// Includes two normal CRDs (foo, baz) and an additional edge‑case CRD.
func getHardCodedConfigInfoCRDMerge() ctestglobals.HardcodedConfig {
	return ctestglobals.HardcodedConfig{
		{
			FixtureFileName: "test_fixture.json",
			TestInfo:        []string{"foo baz crd merge"},
			Field:           "spec",
			K8sObjects:      []string{"customresourcedefinitions"},
			HardcodedConfig: &apiextensionsv1.CustomResourceDefinition{
				ObjectMeta: metav1.ObjectMeta{
					Name: "foosubs.cr.bar.com",
				},
				Spec: apiextensionsv1.CustomResourceDefinitionSpec{
					Group: "cr.bar.com",
					Scope: apiextensionsv1.NamespaceScoped,
					Names: apiextensionsv1.CustomResourceDefinitionNames{
						Plural: "foosubs",
						Kind:   "FooSub",
					},
					Versions: []apiextensionsv1.CustomResourceDefinitionVersion{
						{
							Name:    "v1",
							Served:  true,
							Storage: true,
							Schema: &apiextensionsv1.CustomResourceValidation{
								OpenAPIV3Schema: &apiextensionsv1.JSONSchemaProps{
									Type: "object",
									Properties: map[string]apiextensionsv1.JSONSchemaProps{
										"spec": {
											Type: "object",
											Properties: map[string]apiextensionsv1.JSONSchemaProps{
												"replicas": {Type: "integer"},
											},
										},
										"status": {
											Type: "object",
											Properties: map[string]apiextensionsv1.JSONSchemaProps{
												"replicas": {Type: "integer"},
											},
										},
									},
								},
							},
							Subresources: &apiextensionsv1.CustomResourceSubresources{
								Status: &apiextensionsv1.CustomResourceSubresourceStatus{},
								Scale: &apiextensionsv1.CustomResourceSubresourceScale{
									SpecReplicasPath:   ".spec.replicas",
									StatusReplicasPath: ".status.replicas",
								},
							},
						},
					},
				},
			},
		},
		{
			FixtureFileName: "test_fixture.json",
			TestInfo:        []string{"foo baz crd merge"},
			Field:           "spec",
			K8sObjects:      []string{"customresourcedefinitions"},
			HardcodedConfig: &apiextensionsv1.CustomResourceDefinition{
				ObjectMeta: metav1.ObjectMeta{
					Name: "bazsubs.cr.bar.com",
				},
				Spec: apiextensionsv1.CustomResourceDefinitionSpec{
					Group: "cr.bar.com",
					Scope: apiextensionsv1.NamespaceScoped,
					Names: apiextensionsv1.CustomResourceDefinitionNames{
						Plural: "bazsubs",
						Kind:   "BazSub",
					},
					Versions: []apiextensionsv1.CustomResourceDefinitionVersion{
						{
							Name:    "v1",
							Served:  true,
							Storage: true,
							Schema: &apiextensionsv1.CustomResourceValidation{
								OpenAPIV3Schema: &apiextensionsv1.JSONSchemaProps{
									Type: "object",
									Properties: map[string]apiextensionsv1.JSONSchemaProps{
										"spec": {
											Type: "object",
											Properties: map[string]apiextensionsv1.JSONSchemaProps{
												"replicas": {Type: "integer"},
											},
										},
										"status": {
											Type: "object",
											Properties: map[string]apiextensionsv1.JSONSchemaProps{
												"replicas": {Type: "integer"},
											},
										},
									},
								},
							},
							Subresources: &apiextensionsv1.CustomResourceSubresources{
								Status: &apiextensionsv1.CustomResourceSubresourceStatus{},
								Scale: &apiextensionsv1.CustomResourceSubresourceScale{
									SpecReplicasPath:   ".spec.replicas",
									StatusReplicasPath: ".status.replicas",
								},
							},
						},
					},
				},
			},
		},
		{
			// Edge‑case: CRD without schema/subresources
			FixtureFileName: "test_fixture.json",
			TestInfo:        []string{"foo baz crd merge"},
			Field:           "spec",
			K8sObjects:      []string{"customresourcedefinitions"},
			HardcodedConfig: &apiextensionsv1.CustomResourceDefinition{
				ObjectMeta: metav1.ObjectMeta{
					Name: "emptycrd.cr.bar.com",
				},
				Spec: apiextensionsv1.CustomResourceDefinitionSpec{
					Group: "cr.bar.com",
					Scope: apiextensionsv1.NamespaceScoped,
					Names: apiextensionsv1.CustomResourceDefinitionNames{
						Plural: "emptycrds",
						Kind:   "EmptyCRD",
					},
					Versions: []apiextensionsv1.CustomResourceDefinitionVersion{
						{
							Name:    "v1",
							Served:  true,
							Storage: true,
							// No schema or subresources; tests should still pass
						},
					},
				},
			},
		},
	}
}