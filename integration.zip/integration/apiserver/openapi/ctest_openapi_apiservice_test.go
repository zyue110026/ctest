package openapi

import (
	"bytes"
	"context"
	"fmt"
	"net/http"
	"testing"
	"time"

	"github.com/stretchr/testify/require"
	// apiextensions "k8s.io/apiextensions-apiserver/pkg/client/clientset/clientset"
	metav1 "k8s.io/apimachinery/pkg/apis/meta/v1"
	"k8s.io/apimachinery/pkg/util/wait"
	// "k8s.io/client-go/discovery"
	// "k8s.io/client-go/dynamic"
	// kubernetes "k8s.io/client-go/kubernetes"
	// apiregistrationv1 "k8s.io/kube-aggregator/pkg/apis/apiregistration/v1"
	// aggregator "k8s.io/kube-aggregator/pkg/client/clientset_generated/clientset"
	"k8s.io/kube-openapi/pkg/validation/spec"
	kubeapiservertesting "k8s.io/kubernetes/cmd/kube-apiserver/app/testing"
	testdiscovery "k8s.io/kubernetes/test/integration/apiserver/discovery"
	"k8s.io/kubernetes/test/integration/framework"

	ctest "k8s.io/kubernetes/test/ctest"
	ctestglobals "k8s.io/kubernetes/test/ctest/ctestglobals"
	ctestutils "k8s.io/kubernetes/test/ctest/utils"
)

func TestCtestSlowAPIServiceOpenAPIDoesNotBlockHealthCheck(t *testing.T) {
	fmt.Println(ctestglobals.StartSeparator)
	hardcoded := getHardCodedConfigInfoSwaggerSpecBlock()
	item, found := ctestutils.GetItemByExactTestInfo(hardcoded, "slow api service swagger block")
	if !found {
		fmt.Println(ctestglobals.DebugPrefix(), "Failed to find config item")
		t.Skip("no config")
	}
	fmt.Println(ctestglobals.DebugPrefix(), "matched config:", item)
	fmt.Println(ctestglobals.StartOverrideModeSeparator)
	configObjs, configJSON, err := ctest.GenerateEffectiveConfigReturnType[*spec.Swagger](item, ctest.OverrideOnly)
	if err != nil {
		fmt.Println(ctestglobals.DebugPrefix(), "Generate config error:", err)
		t.Fatalf("generate config: %v", err)
	}
	if configObjs == nil {
		fmt.Println(ctestglobals.DebugPrefix(), "Skipping test execution. No new configurations generated.")
		return
	}
	fmt.Println(ctestglobals.DebugPrefix(), "New Json Test Configs:", string(configJSON))
	fmt.Println(ctestglobals.DebugPrefix(), "Number of test cases:", len(configObjs))

	for i, cfg := range configObjs {
		fmt.Printf("Running %d th test case.\n", i)
		fmt.Println(cfg)
		ctx, cancelCtx := context.WithCancel(context.Background())
		defer cancelCtx()

		etcd := framework.SharedEtcd()
		setupServer := kubeapiservertesting.StartTestServerOrDie(t, nil, framework.DefaultTestServerFlags(), etcd)
		client := generateTestClient(t, setupServer)

		service := testdiscovery.NewFakeService("test-server", client, http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
			if r.URL.Path != "/openapi/v2" {
				return
			}
			<-ctx.Done()
			data, err := cfg.MarshalJSON()
			if err != nil {
				t.Error(err)
			}
			http.ServeContent(w, r, "/openapi/v2", time.Now(), bytes.NewReader(data))
		}))
		go func() {
			if err := service.Run(ctx); err != nil {
				t.Errorf("unexpected error %v", err)
			}
		}()
		require.NoError(t, service.WaitForReady(ctx))

		groupVersion := metav1.GroupVersion{
			Group:   "wardle.example.com",
			Version: "v1alpha1",
		}
		require.NoError(t, registerAPIService(ctx, client, groupVersion, service))

		setupServer.TearDownFn()
		server := kubeapiservertesting.StartTestServerOrDie(t, nil, framework.DefaultTestServerFlags(), etcd)
		t.Cleanup(server.TearDownFn)
		client2 := generateTestClient(t, server)

		err = wait.PollUntilContextTimeout(context.Background(), 100*time.Millisecond, 1*time.Second, true, func(context.Context) (bool, error) {
			var statusCode int
			client2.AdmissionregistrationV1().RESTClient().Get().AbsPath("/healthz").Do(context.TODO()).StatusCode(&statusCode)
			if statusCode == 200 {
				return true, nil
			}
			return false, nil
		})
		require.NoError(t, err)
	}
	fmt.Println(ctestglobals.EndSeparator)
}

func TestCtestFetchingOpenAPIBeforeReady(t *testing.T) {
	fmt.Println(ctestglobals.StartSeparator)
	hardcoded := getHardCodedConfigInfoSwaggerSpecReady()
	item, found := ctestutils.GetItemByExactTestInfo(hardcoded, "fetching openapi before ready")
	if !found {
		fmt.Println(ctestglobals.DebugPrefix(), "Failed to find config item")
		t.Skip("no config")
	}
	fmt.Println(ctestglobals.DebugPrefix(), "matched config:", item)
	fmt.Println(ctestglobals.StartOverrideModeSeparator)
	configObjs, configJSON, err := ctest.GenerateEffectiveConfigReturnType[*spec.Swagger](item, ctest.OverrideOnly)
	if err != nil {
		fmt.Println(ctestglobals.DebugPrefix(), "Generate config error:", err)
		t.Fatalf("generate config: %v", err)
	}
	if configObjs == nil {
		fmt.Println(ctestglobals.DebugPrefix(), "Skipping test execution. No new configurations generated.")
		return
	}
	fmt.Println(ctestglobals.DebugPrefix(), "New Json Test Configs:", string(configJSON))
	fmt.Println(ctestglobals.DebugPrefix(), "Number of test cases:", len(configObjs))

	for i, cfg := range configObjs {
		fmt.Printf("Running %d th test case.\n", i)
		fmt.Println(cfg)
		ctx, cancelCtx := context.WithCancel(context.Background())
		defer cancelCtx()

		server := kubeapiservertesting.StartTestServerOrDie(t, nil, framework.DefaultTestServerFlags(), framework.SharedEtcd())
		t.Cleanup(server.TearDownFn)
		client := generateTestClient(t, server)

		readyCh := make(chan bool)
		defer close(readyCh)
		go func() {
			select {
			case <-readyCh:
			default:
				_, _ = client.Discovery().RESTClient().Get().AbsPath("/openapi/v2").Do(context.TODO()).Raw()
			}
		}()

		service := testdiscovery.NewFakeService("test-server", client, http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
			data, err := cfg.MarshalJSON()
			if err != nil {
				t.Error(err)
			}
			http.ServeContent(w, r, "/openapi/v2", time.Now(), bytes.NewReader(data))
		}))
		go func() {
			if err := service.Run(ctx); err != nil {
				t.Errorf("unexpected error %v", err)
			}
		}()
		require.NoError(t, service.WaitForReady(ctx))

		groupVersion := metav1.GroupVersion{
			Group:   "wardle.example.com",
			Version: "v1alpha1",
		}
		require.NoError(t, registerAPIService(ctx, client, groupVersion, service))
		defer func() {
			require.NoError(t, unregisterAPIService(ctx, client, groupVersion))
		}()

		err = wait.PollUntilContextTimeout(context.Background(), time.Millisecond*10, time.Second, true, func(context.Context) (bool, error) {
			b, err := client.Discovery().RESTClient().Get().AbsPath("/openapi/v2").Do(context.TODO()).Raw()
			require.NoError(t, err)
			var openapi spec.Swagger
			require.NoError(t, openapi.UnmarshalJSON(b))
			if _, ok := openapi.Paths.Paths["/apis/wardle.example.com/v1alpha1/"]; ok {
				return true, nil
			}
			return false, nil
		})
		require.NoError(t, err)
	}
	fmt.Println(ctestglobals.EndSeparator)
}

/* Hardcoded config generators */

func getHardCodedConfigInfoSwaggerSpecBlock() ctestglobals.HardcodedConfig {
	return ctestglobals.HardcodedConfig{{
		FixtureFileName: "test_fixture.json",
		TestInfo:        []string{"slow api service swagger block"},
		Field:           "paths",
		K8sObjects: []string{
			"pods", "deployments", "statefulsets", "daemonsets", "replicasets",
		},
		HardcodedConfig: &spec.Swagger{
			SwaggerProps: spec.SwaggerProps{
				Paths: &spec.Paths{
					Paths: map[string]spec.PathItem{
						"/apis/wardle.example.com/v1alpha1": {},
					},
				},
			},
		},
	}}
}

func getHardCodedConfigInfoSwaggerSpecReady() ctestglobals.HardcodedConfig {
	return ctestglobals.HardcodedConfig{{
		FixtureFileName: "test_fixture.json",
		TestInfo:        []string{"fetching openapi before ready"},
		Field:           "paths",
		K8sObjects: []string{
			"pods", "deployments", "statefulsets", "daemonsets", "replicasets",
		},
		HardcodedConfig: &spec.Swagger{
			SwaggerProps: spec.SwaggerProps{
				Paths: &spec.Paths{
					Paths: map[string]spec.PathItem{
						"/apis/wardle.example.com/v1alpha1/": {},
					},
				},
			},
		},
	}}
}
