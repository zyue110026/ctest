package apiserver

import (
	"bytes"
	"context"
	"fmt"
	"strings"
	"testing"
	"time"

	"github.com/google/go-cmp/cmp"

	corev1 "k8s.io/api/core/v1"
	"k8s.io/apimachinery/pkg/api/equality"
	"k8s.io/apimachinery/pkg/api/errors"
	metav1 "k8s.io/apimachinery/pkg/apis/meta/v1"
	"k8s.io/apimachinery/pkg/apis/meta/v1/unstructured"
	// "k8s.io/apimachinery/pkg/runtime"
	// "k8s.io/apimachinery/pkg/runtime/schema"
	"k8s.io/apimachinery/pkg/runtime/serializer/cbor"
	"k8s.io/apimachinery/pkg/runtime/serializer/cbor/direct"
	"k8s.io/apimachinery/pkg/runtime/serializer/streaming"
	"k8s.io/apimachinery/pkg/types"
	"k8s.io/apiserver/pkg/features"
	utilfeature "k8s.io/apiserver/pkg/util/feature"
	clientfeatures "k8s.io/client-go/features"
	clientfeaturestesting "k8s.io/client-go/features/testing"
	"k8s.io/client-go/kubernetes/scheme"
	corev1client "k8s.io/client-go/kubernetes/typed/core/v1"
	"k8s.io/client-go/rest"
	featuregatetesting "k8s.io/component-base/featuregate/testing"
	kubeapiservertesting "k8s.io/kubernetes/cmd/kube-apiserver/app/testing"
	"k8s.io/kubernetes/test/integration/framework"
	"k8s.io/utils/ptr"

	"k8s.io/apimachinery/pkg/util/uuid"
	ctest "k8s.io/kubernetes/test/ctest"
	ctestglobals "k8s.io/kubernetes/test/ctest/ctestglobals"
	ctestutils "k8s.io/kubernetes/test/ctest/utils"
)

func TestCtestNondeterministicResponseEncoding(t *testing.T) {
	const defaultNTrials = 40

	featuregatetesting.SetFeatureGateDuringTest(t, utilfeature.DefaultFeatureGate, features.CBORServingAndStorage, true)
	clientfeaturestesting.SetFeatureDuringTest(t, clientfeatures.ClientsAllowCBOR, true)
	clientfeaturestesting.SetFeatureDuringTest(t, clientfeatures.ClientsPreferCBOR, true)

	// -------------------------------------------------------------------------
	// Load dynamic namespace fixture configurations (annotations only)
	// -------------------------------------------------------------------------
	fmt.Println(ctestglobals.StartExtendModeSeparator)
	hardcodedCfg := getHardCodedConfigInfoNondeterministicResponseEncoding()
	item, found := ctestutils.GetItemByExactTestInfo(hardcodedCfg, "default namespace fixture")
	if !found {
		fmt.Println(ctestglobals.DebugPrefix(), "Failed to find config item by TestInfo")
		t.Fatalf("hardcoded config not found")
	}
	fmt.Println(ctestglobals.DebugPrefix(), "get default configs:", item)
	configObjs, configJson, err := ctest.GenerateEffectiveConfigReturnType[corev1.Namespace](item, ctest.OverrideOnly)
	if err != nil {
		fmt.Println(ctestglobals.DebugPrefix(), "Failed to get matched fixtures: %v", err)
		t.Fatalf("fixture generation error: %v", err)
	}
	if configObjs == nil {
		fmt.Println(ctestglobals.DebugPrefix(), "Skipping test execution. No new configurations generated.")
		return
	}
	fmt.Println(ctestglobals.DebugPrefix(), "New Json Test Configs:", string(configJson))
	fmt.Println(ctestglobals.DebugPrefix(), "Number of test cases:", len(configObjs))

	// -------------------------------------------------------------------------
	// Edge case definitions (modify annotations)
	// -------------------------------------------------------------------------
	edgeCases := []struct {
		name   string
		modify func(*corev1.Namespace)
	}{
		{
			name: "empty annotations map",
			modify: func(ns *corev1.Namespace) {
				ns.Annotations = map[string]string{}
			},
		},
		{
			name: "nil annotations map",
			modify: func(ns *corev1.Namespace) {
				ns.Annotations = nil
			},
		},
		{
			name: "large annotation value",
			modify: func(ns *corev1.Namespace) {
				if ns.Annotations == nil {
					ns.Annotations = map[string]string{}
				}
				ns.Annotations["large"] = strings.Repeat("x", 1024)
			},
		},
		{
			name: "special unicode characters",
			modify: func(ns *corev1.Namespace) {
				if ns.Annotations == nil {
					ns.Annotations = map[string]string{}
				}
				ns.Annotations["unicode"] = "😀🚀"
			},
		},
	}

	// -------------------------------------------------------------------------
	// Execute test for each fixture combined with edge cases
	// -------------------------------------------------------------------------
	for i, baseNS := range configObjs {
		fmt.Printf("Running fixture #%d\n", i)
		fmt.Println(baseNS)
		for _, ec := range edgeCases {
			fmt.Println(ctestglobals.DebugPrefix(), "Edge case:", ec.name)
			nsCopy := baseNS.DeepCopy()
			nsCopy.Name = "test-nondeterministic-" + string(uuid.NewUUID())
			ec.modify(nsCopy)

			// -----------------------------------------------------------------
			// Start server & client
			// -----------------------------------------------------------------
			server := kubeapiservertesting.StartTestServerOrDie(t, nil, framework.DefaultTestServerFlags(), framework.SharedEtcd())
			t.Cleanup(server.TearDownFn)

			config := rest.CopyConfig(server.ClientConfig)
			config.AcceptContentTypes = "application/cbor"
			client, err := corev1client.NewForConfig(config)
			if err != nil {
				t.Fatalf("client creation failed: %v", err)
			}

			// Create namespace with dynamic annotations
			ns, err := client.Namespaces().Create(context.TODO(), nsCopy, metav1.CreateOptions{})
			if err != nil {
				t.Fatalf("failed to create namespace: %v", err)
			}

			// -----------------------------------------------------------------
			// Perform nondeterministic response encoding checks (original logic)
			// -----------------------------------------------------------------
			NTrials := defaultNTrials
			responseDiff := false
			for i := 0; i < NTrials && !responseDiff; i++ {
				request := client.RESTClient().Get().Resource("namespaces").Name(ns.GetName())
				result := request.Do(context.TODO())
				raw1, err := result.Raw()
				if err != nil {
					t.Fatalf("raw1 error: %v", err)
				}
				if err := result.Into(ns); err != nil {
					t.Fatalf("into error: %v", err)
				}
				trial := request.VersionedParams(&metav1.GetOptions{ResourceVersion: ns.ResourceVersion}, scheme.ParameterCodec).Do(context.TODO())
				var trialObject corev1.Namespace
				if err := trial.Into(&trialObject); err != nil {
					if errors.IsResourceExpired(err) {
						t.Logf("retrying: %v", err)
						continue
					}
					t.Fatalf("trial into error: %v", err)
				}
				if !equality.Semantic.DeepEqual(ns, &trialObject) {
					t.Fatalf("objects differed semantically between runs:\n%s", cmp.Diff(ns, trialObject))
				}
				raw2, err := trial.Raw()
				if err != nil {
					t.Fatalf("raw2 error: %v", err)
				}
				if !bytes.Equal(raw1, raw2) {
					responseDiff = true
				}
			}
			if !responseDiff {
				t.Errorf("performed %d consecutive get requests to the same resource and observed identical response bodies each time", NTrials)
			}

			// Watch event nondeterminism
			eventDiff := false
			objDiff := false
			for i := 0; i < NTrials && (!eventDiff || !objDiff); i++ {
				ns, err = client.Namespaces().Get(context.TODO(), ns.GetName(), metav1.GetOptions{})
				if err != nil {
					t.Fatalf("get namespace error: %v", err)
				}
				patched, err := client.Namespaces().Patch(context.TODO(), ns.GetName(), types.JSONPatchType,
					[]byte(fmt.Sprintf(`[{"op":"add","path":"/metadata/annotations/edge-%d","value":"%d"}]`, i, i)),
					metav1.PatchOptions{})
				if err != nil {
					t.Fatalf("patch error: %v", err)
				}
				request := client.RESTClient().Get().Resource("namespaces")
				getRawEventAndRawObject := func() ([]byte, []byte, error) {
					ctx, cancel := context.WithTimeout(context.TODO(), 6*time.Second)
					defer cancel()
					rc, err := request.
						VersionedParams(&metav1.ListOptions{
							ResourceVersion: ns.ResourceVersion,
							Watch:           true,
							TimeoutSeconds:  ptr.To(int64(5)),
							FieldSelector:   fmt.Sprintf("metadata.name=%s", ns.GetName()),
						}, scheme.ParameterCodec).
						Stream(ctx)
					if err != nil {
						return nil, nil, err
					}
					defer rc.Close()
					d := &rawCapturingDecoder{delegate: cbor.NewSerializer(scheme.Scheme, scheme.Scheme, cbor.Transcode(false))}
					sd := streaming.NewDecoder(rc, d)
					for {
						var event metav1.WatchEvent
						got, _, err := sd.Decode(nil, &event)
						if err != nil {
							return nil, nil, err
						}
						if got != &event {
							return nil, nil, fmt.Errorf("unexpected decoder return")
						}
						var u map[string]interface{}
						if err := direct.Unmarshal(event.Object.Raw, &u); err != nil {
							return nil, nil, err
						}
						rv, ok, err := unstructured.NestedString(u, "metadata", "resourceVersion")
						if err != nil {
							return nil, nil, err
						}
						if !ok {
							return nil, nil, fmt.Errorf("watch event missing resource version")
						}
						if rv == patched.ResourceVersion {
							return d.raw, event.Object.Raw, nil
						}
					}
				}
				event1, raw1, err := getRawEventAndRawObject()
				if err != nil {
					if errors.IsResourceExpired(err) {
						t.Logf("retrying: %v", err)
						continue
					}
					t.Fatalf("first event capture error: %v", err)
				}
				var obj1 map[string]interface{}
				if err := direct.Unmarshal(raw1, &obj1); err != nil {
					t.Fatalf("unmarshal obj1 error: %v", err)
				}
				event2, raw2, err := getRawEventAndRawObject()
				if err != nil {
					if errors.IsResourceExpired(err) {
						t.Logf("retrying: %v", err)
						continue
					}
					t.Fatalf("second event capture error: %v", err)
				}
				var obj2 map[string]interface{}
				if err := direct.Unmarshal(raw2, &obj2); err != nil {
					t.Fatalf("unmarshal obj2 error: %v", err)
				}
				if !equality.Semantic.DeepEqual(obj1, obj2) {
					t.Fatalf("objects differed semantically between runs:\n%s", cmp.Diff(obj1, obj2))
				}
				if !bytes.Equal(raw1, raw2) {
					objDiff = true
				}
				event1 = bytes.Replace(event1, raw1, nil, 1)
				event2 = bytes.Replace(event2, raw2, nil, 1)
				if !bytes.Equal(event1, event2) {
					eventDiff = true
				}
			}
			if !eventDiff {
				t.Errorf("watch event encoded identically over %d consecutive watch requests", NTrials)
			}
			if !objDiff {
				t.Errorf("watch event embedded object encoded identically over %d consecutive watch requests", NTrials)
			}
		}
	}
	fmt.Println(ctestglobals.EndSeparator)
}

// getHardCodedConfigInfoNondeterministicResponseEncoding returns the minimal
// hard‑coded namespace configuration used by the test.
func getHardCodedConfigInfoNondeterministicResponseEncoding() ctestglobals.HardcodedConfig {
	return ctestglobals.HardcodedConfig{
		{
			FixtureFileName: "test_fixture.json",
			TestInfo:        []string{"default namespace fixture"},
			Field:           "annotations",
			K8sObjects:      []string{"namespaces"},
			HardcodedConfig: corev1.Namespace{
				ObjectMeta: metav1.ObjectMeta{
					Annotations: map[string]string{
						"hello": "world",
					},
				},
			},
		},
	}
}
