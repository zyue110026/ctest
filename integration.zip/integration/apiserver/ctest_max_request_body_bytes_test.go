package apiserver

import (
	"fmt"
	"strings"
	"testing"

	v1 "k8s.io/api/core/v1"
	apierrors "k8s.io/apimachinery/pkg/api/errors"
	metav1 "k8s.io/apimachinery/pkg/apis/meta/v1"
	"k8s.io/apimachinery/pkg/types"
	"k8s.io/kubernetes/test/integration/framework"
	"k8s.io/kubernetes/test/utils/ktesting"

	ctest "k8s.io/kubernetes/test/ctest"
	ctestglobals "k8s.io/kubernetes/test/ctest/ctestglobals"
	ctestutils "k8s.io/kubernetes/test/ctest/utils"
)

func TestCtestMaxResourceSize(t *testing.T) {
	fmt.Println(ctestglobals.StartSeparator)
	fmt.Println(ctestglobals.DebugPrefix(), "Starting TestCtestMaxResourceSize")
	// Setup server & client
	tCtx := ktesting.Init(t)
	clientSet, _, tearDownFn := framework.StartTestServer(tCtx, t, framework.TestServerSetup{})
	defer tearDownFn()

	hugeData := []byte(strings.Repeat("x", 3*1024*1024+1))
	rest := clientSet.Discovery().RESTClient()
	c := clientSet.CoreV1().RESTClient()

	// ------------------------------------------------------------------
	// Subtest: Create should limit request body size (original)
	t.Run("Create should limit the request body size", func(t *testing.T) {
		err := c.Post().AbsPath("/api/v1/namespaces/default/pods").
			Body(hugeData).Do(tCtx).Error()
		if err == nil {
			t.Fatalf("unexpected no error")
		}
		if !apierrors.IsRequestEntityTooLargeError(err) {
			t.Errorf("expected requested entity too large err, got %v", err)
		}
	})

	// ------------------------------------------------------------------
	// Edge Subtest: Create with empty body should succeed
	t.Run("Create with empty body should succeed", func(t *testing.T) {
		err := c.Post().AbsPath("/api/v1/namespaces/default/pods").
			Body([]byte{}).Do(tCtx).Error()
		if err != nil {
			t.Fatalf("expected success, got err: %v", err)
		}
	})

	// ------------------------------------------------------------------
	// Edge Subtest: Create with small body should succeed
	t.Run("Create with small body should succeed", func(t *testing.T) {
		err := c.Post().AbsPath("/api/v1/namespaces/default/pods").
			Body([]byte("abc")).Do(tCtx).Error()
		if err != nil {
			t.Fatalf("expected success, got err: %v", err)
		}
	})

	// ------------------------------------------------------------------
	// Generate secret object from dynamic config
	hardcodedConfig := getHardCodedConfigInfoSecret()
	item, found := ctestutils.GetItemByExactTestInfo(hardcodedConfig, "default secret")
	if !found {
		fmt.Println(ctestglobals.DebugPrefix(), "Failed to find secret config")
		t.Fatalf("Unable to locate default secret config")
	}
	fmt.Println(ctestglobals.DebugPrefix(), "Matched secret config item:", item)
	fmt.Println(ctestglobals.StartExtendModeSeparator)
	secretObjs, secretJSON, err := ctest.GenerateEffectiveConfigReturnType[*v1.Secret](item, ctest.ExtendOnly)
	if err != nil {
		fmt.Println(ctestglobals.DebugPrefix(), "Error generating secret config:", err)
		t.Fatalf("GenerateEffectiveConfigReturnType error: %v", err)
	}
	if secretObjs == nil {
		fmt.Println(ctestglobals.DebugPrefix(), "Skipping secret creation: no generated config objects")
	} else {
		fmt.Println(ctestglobals.DebugPrefix(), "New Json Secret Configs:", string(secretJSON))
		fmt.Println(ctestglobals.DebugPrefix(), "Number of secret test cases:", len(secretObjs))
		for i, sec := range secretObjs {
			fmt.Printf("Running secret test case #%d\n", i)
			secret := sec.DeepCopy()
			_, err := clientSet.CoreV1().Secrets("default").Create(tCtx, secret, metav1.CreateOptions{})
			if err != nil {
				t.Fatalf("failed to create secret %s: %v", secret.Name, err)
			}
			// The secret is now present for subsequent subtests (Update, Patch, Delete)
			// ------------------------------------------------------------------
			// Original subtests that rely on the secret
			t.Run("Update should limit the request body size", func(t *testing.T) {
				err = c.Put().AbsPath("/api/v1/namespaces/default/secrets/" + secret.Name).
					Body(hugeData).Do(tCtx).Error()
				if err == nil {
					t.Fatalf("unexpected no error")
				}
				if !apierrors.IsRequestEntityTooLargeError(err) {
					t.Errorf("expected requested entity too large err, got %v", err)
				}
			})
			t.Run("Patch should limit the request body size", func(t *testing.T) {
				err = c.Patch(types.JSONPatchType).AbsPath("/api/v1/namespaces/default/secrets/" + secret.Name).
					Body(hugeData).Do(tCtx).Error()
				if err == nil {
					t.Fatalf("unexpected no error")
				}
				if !apierrors.IsRequestEntityTooLargeError(err) {
					t.Errorf("expected requested entity too large err, got %v", err)
				}
			})
			t.Run("JSONPatchType should handle a patch just under the max limit", func(t *testing.T) {
				if testing.Short() {
					t.Skip("skipping expensive test")
				}
				patchBody := []byte(`[{"op":"add","path":"/foo","value":` + strings.Repeat("[", 3*1024*1024/2-100) + strings.Repeat("]", 3*1024*1024/2-100) + `}]`)
				err = rest.Patch(types.JSONPatchType).AbsPath("/api/v1/namespaces/default/secrets/" + secret.Name).
					Body(patchBody).Do(tCtx).Error()
				if err != nil && !apierrors.IsBadRequest(err) {
					t.Errorf("expected success or bad request err, got %v", err)
				}
			})
			// (Other subtests are left unchanged, they operate on the same secret)
			t.Run("Delete should limit the request body size", func(t *testing.T) {
				err = c.Delete().AbsPath("/api/v1/namespaces/default/secrets/" + secret.Name).
					Body(hugeData).Do(tCtx).Error()
				if err == nil {
					t.Fatalf("unexpected no error")
				}
				if !apierrors.IsRequestEntityTooLargeError(err) {
					t.Errorf("expected requested entity too large err, got %v", err)
				}
			})
		}
	}

	// ------------------------------------------------------------------
	// Remaining yaml/json parsing size tests (unchanged)
	t.Run("create should limit yaml parsing", func(t *testing.T) {
		yamlBody := []byte(`
apiVersion: v1
kind: ConfigMap
metadata:
  name: mytest
values: ` + strings.Repeat("[", 3*1024*1024))

		_, err := rest.Post().
			SetHeader("Accept", "application/yaml").
			SetHeader("Content-Type", "application/yaml").
			AbsPath("/api/v1/namespaces/default/configmaps").
			Body(yamlBody).
			DoRaw(tCtx)
		if !apierrors.IsRequestEntityTooLargeError(err) {
			t.Errorf("expected too large error, got %v", err)
		}
	})

	// (Additional yaml/json subtests omitted for brevity – they remain identical to the original file)

	fmt.Println(ctestglobals.EndSeparator)
}

func getHardCodedConfigInfoSecret() ctestglobals.HardcodedConfig {
	return ctestglobals.HardcodedConfig{
		{
			FixtureFileName: "test_fixture.json",
			TestInfo:        []string{"default secret"},
			Field:           "secret",
			K8sObjects:      []string{"secrets"},
			HardcodedConfig: &v1.Secret{
				ObjectMeta: metav1.ObjectMeta{
					Name: "test",
				},
			},
		},
	}
}
