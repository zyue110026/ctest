package apiserver

import (
	"context"
	"fmt"
	// "sync"
	"testing"
	"time"

	// "k8s.io/apimachinery/pkg/api/errors"
	metav1 "k8s.io/apimachinery/pkg/apis/meta/v1"
	"k8s.io/apimachinery/pkg/util/wait"
	"k8s.io/client-go/kubernetes"
	// "k8s.io/client-go/rest"
	// "k8s.io/client-go/tools/leaderelection"
	// "k8s.io/client-go/tools/leaderelection/resourcelock"
	// "k8s.io/klog/v2"
	apiservertesting "k8s.io/kubernetes/cmd/kube-apiserver/app/testing"
	"k8s.io/kubernetes/pkg/controlplane/apiserver"
	"k8s.io/kubernetes/test/integration/framework"

	v1 "k8s.io/api/coordination/v1"
	v1beta1 "k8s.io/api/coordination/v1beta1"

	apierrors "k8s.io/apimachinery/pkg/api/errors"
	"k8s.io/apimachinery/pkg/util/uuid"
	"k8s.io/utils/ptr"

	genericfeatures "k8s.io/apiserver/pkg/features"
	utilfeature "k8s.io/apiserver/pkg/util/feature"
	featuregatetesting "k8s.io/component-base/featuregate/testing"

	ctest "k8s.io/kubernetes/test/ctest"
	ctestglobals "k8s.io/kubernetes/test/ctest/ctestglobals"
	ctestutils "k8s.io/kubernetes/test/ctest/utils"
)

func TestCtestSingleLeaseCandidate(t *testing.T) {
	tests := []struct {
		name                   string
		preferredStrategy      v1.CoordinatedLeaseStrategy
		expectedHolderIdentity *string
	}{
		{
			name:                   "default strategy, has lease identity",
			preferredStrategy:      v1.OldestEmulationVersion,
			expectedHolderIdentity: ptr.To("foo1"),
		},
		// Edge case: empty strategy (should behave like default)
		{
			name:                   "empty strategy, fallback to default",
			preferredStrategy:      v1.CoordinatedLeaseStrategy(""),
			expectedHolderIdentity: ptr.To("foo1"),
		},
	}
	featuregatetesting.SetFeatureGateDuringTest(t, utilfeature.DefaultFeatureGate, genericfeatures.CoordinatedLeaderElection, true)

	flags := []string{fmt.Sprintf("--runtime-config=%s=true", v1beta1.SchemeGroupVersion)}
	server, err := apiservertesting.StartTestServer(t, apiservertesting.NewDefaultTestServerOptions(), flags, framework.SharedEtcd())
	if err != nil {
		t.Fatal(err)
	}
	defer server.TearDownFn()
	config := server.ClientConfig

	for _, tc := range tests {
		t.Run(tc.name, func(t *testing.T) {
			ctx, cancel := context.WithCancel(context.Background())
			defer cancel()

			cletest := setupCLE(config, ctx, t)
			defer cletest.cleanup()
			go cletest.createAndRunFakeController("foo1", "default", "foo", "1.20.0", "1.20.0", tc.preferredStrategy)
			cletest.pollForLease(ctx, "foo", "default", tc.expectedHolderIdentity)
		})
	}
}

func TestCtestSingleLeaseCandidateUsingThirdPartyStrategy(t *testing.T) {
	tests := []struct {
		name                   string
		preferredStrategy      v1.CoordinatedLeaseStrategy
		expectedHolderIdentity *string
	}{
		{
			name:                   "third party strategy, no holder identity",
			preferredStrategy:      v1.CoordinatedLeaseStrategy("foo.com/bar"),
			expectedHolderIdentity: nil,
		},
		// Edge case: unknown third‑party strategy string
		{
			name:                   "unknown third‑party strategy, no holder identity",
			preferredStrategy:      v1.CoordinatedLeaseStrategy("unknown/strategy"),
			expectedHolderIdentity: nil,
		},
	}
	featuregatetesting.SetFeatureGateDuringTest(t, utilfeature.DefaultFeatureGate, genericfeatures.CoordinatedLeaderElection, true)
	flags := []string{fmt.Sprintf("--runtime-config=%s=true", v1beta1.SchemeGroupVersion)}
	server, err := apiservertesting.StartTestServer(t, apiservertesting.NewDefaultTestServerOptions(), flags, framework.SharedEtcd())
	if err != nil {
		t.Fatal(err)
	}
	defer server.TearDownFn()
	config := server.ClientConfig

	for _, tc := range tests {
		t.Run(tc.name, func(t *testing.T) {
			ctx, cancel := context.WithCancel(context.Background())
			defer cancel()

			cletest := setupCLE(config, ctx, t)
			defer cletest.cleanup()
			go cletest.createAndRunFakeController("foo1", "default", "foo", "1.20.0", "1.20.0", tc.preferredStrategy)
			cletest.pollForLease(ctx, "foo", "default", tc.expectedHolderIdentity)
		})
	}
}

func TestCtestMultipleLeaseCandidate(t *testing.T) {
	tests := []struct {
		name                   string
		preferredStrategy      v1.CoordinatedLeaseStrategy
		expectedHolderIdentity *string
	}{
		{
			name:                   "default strategy, has lease identity",
			preferredStrategy:      v1.OldestEmulationVersion,
			expectedHolderIdentity: ptr.To("baz3"),
		},
		// Edge case: nil strategy (should default)
		{
			name:                   "nil strategy, fallback to default",
			preferredStrategy:      v1.CoordinatedLeaseStrategy(""),
			expectedHolderIdentity: ptr.To("baz3"),
		},
	}
	featuregatetesting.SetFeatureGateDuringTest(t, utilfeature.DefaultFeatureGate, genericfeatures.CoordinatedLeaderElection, true)

	flags := []string{fmt.Sprintf("--runtime-config=%s=true", v1beta1.SchemeGroupVersion)}
	server, err := apiservertesting.StartTestServer(t, apiservertesting.NewDefaultTestServerOptions(), flags, framework.SharedEtcd())
	if err != nil {
		t.Fatal(err)
	}
	defer server.TearDownFn()
	config := server.ClientConfig

	for _, tc := range tests {
		t.Run(tc.name, func(t *testing.T) {
			ctx, cancel := context.WithCancel(context.Background())
			defer cancel()

			cletest := setupCLE(config, ctx, t)
			defer cletest.cleanup()
			go cletest.createAndRunFakeController("baz1", "default", "baz", "1.20.0", "1.20.0", tc.preferredStrategy)
			go cletest.createAndRunFakeController("baz2", "default", "baz", "1.20.0", "1.19.0", tc.preferredStrategy)
			go cletest.createAndRunFakeController("baz3", "default", "baz", "1.19.0", "1.19.0", tc.preferredStrategy)
			go cletest.createAndRunFakeController("baz4", "default", "baz", "1.20.0", "1.19.0", tc.preferredStrategy)
			cletest.pollForLease(ctx, "baz", "default", tc.expectedHolderIdentity)
		})
	}
}

func TestCtestMultipleLeaseCandidateUsingThirdPartyStrategy(t *testing.T) {
	tests := []struct {
		name                   string
		preferredStrategy      v1.CoordinatedLeaseStrategy
		expectedHolderIdentity *string
	}{
		{
			name:                   "third party strategy, no holder identity",
			preferredStrategy:      v1.CoordinatedLeaseStrategy("foo.com/bar"),
			expectedHolderIdentity: nil,
		},
		// Edge case: malformed third‑party strategy
		{
			name:                   "malformed third‑party strategy, no holder identity",
			preferredStrategy:      v1.CoordinatedLeaseStrategy(":::"),
			expectedHolderIdentity: nil,
		},
	}
	featuregatetesting.SetFeatureGateDuringTest(t, utilfeature.DefaultFeatureGate, genericfeatures.CoordinatedLeaderElection, true)
	flags := []string{fmt.Sprintf("--runtime-config=%s=true", v1beta1.SchemeGroupVersion)}

	server, err := apiservertesting.StartTestServer(t, apiservertesting.NewDefaultTestServerOptions(), flags, framework.SharedEtcd())
	if err != nil {
		t.Fatal(err)
	}
	defer server.TearDownFn()
	config := server.ClientConfig

	for _, tc := range tests {
		t.Run(tc.name, func(t *testing.T) {
			ctx, cancel := context.WithCancel(context.Background())
			defer cancel()

			cletest := setupCLE(config, ctx, t)
			defer cletest.cleanup()
			go cletest.createAndRunFakeController("baz1", "default", "baz", "1.20.0", "1.20.0", tc.preferredStrategy)
			go cletest.createAndRunFakeController("baz2", "default", "baz", "1.20.0", "1.19.0", tc.preferredStrategy)
			go cletest.createAndRunFakeController("baz3", "default", "baz", "1.19.0", "1.19.0", tc.preferredStrategy)
			go cletest.createAndRunFakeController("baz4", "default", "baz", "1.2.0", "1.19.0", tc.preferredStrategy)
			go cletest.createAndRunFakeController("baz5", "default", "baz", "1.20.0", "1.19.0", tc.preferredStrategy)
			cletest.pollForLease(ctx, "baz", "default", tc.expectedHolderIdentity)
		})
	}
}

func TestCtestLeaseSwapIfBetterAvailable(t *testing.T) {
	featuregatetesting.SetFeatureGateDuringTest(t, utilfeature.DefaultFeatureGate, genericfeatures.CoordinatedLeaderElection, true)

	flags := []string{fmt.Sprintf("--runtime-config=%s=true", v1beta1.SchemeGroupVersion)}
	server, err := apiservertesting.StartTestServer(t, apiservertesting.NewDefaultTestServerOptions(), flags, framework.SharedEtcd())
	if err != nil {
		t.Fatal(err)
	}
	defer server.TearDownFn()
	config := server.ClientConfig

	ctx, cancel := context.WithCancel(context.Background())
	defer cancel()
	cletest := setupCLE(config, ctx, t)
	defer cletest.cleanup()

	go cletest.createAndRunFakeController("bar1", "default", "bar", "1.20.0", "1.20.0", v1.OldestEmulationVersion)
	cletest.pollForLease(ctx, "bar", "default", ptr.To("bar1"))
	go cletest.createAndRunFakeController("bar2", "default", "bar", "1.19.0", "1.19.0", v1.OldestEmulationVersion)
	cletest.pollForLease(ctx, "bar", "default", ptr.To("bar2"))
}

func TestCtestUpgradeSkew(t *testing.T) {
	featuregatetesting.SetFeatureGateDuringTest(t, utilfeature.DefaultFeatureGate, genericfeatures.CoordinatedLeaderElection, true)

	flags := []string{fmt.Sprintf("--runtime-config=%s=true", v1beta1.SchemeGroupVersion)}
	server, err := apiservertesting.StartTestServer(t, apiservertesting.NewDefaultTestServerOptions(), flags, framework.SharedEtcd())
	if err != nil {
		t.Fatal(err)
	}
	defer server.TearDownFn()
	config := server.ClientConfig

	ctx, cancel := context.WithCancel(context.Background())
	defer cancel()
	cletest := setupCLE(config, ctx, t)
	defer cletest.cleanup()

	go cletest.createAndRunFakeLegacyController("foo1-130", "default", "foobar")
	cletest.pollForLease(ctx, "foobar", "default", ptr.To("foo1-130"))
	go cletest.createAndRunFakeController("foo1-131", "default", "foobar", "1.31.0", "1.31.0", v1.OldestEmulationVersion)
	// running a new controller should not kick off old leader
	cletest.pollForLease(ctx, "foobar", "default", ptr.To("foo1-130"))
	cletest.cancelController("foo1-130", "default")
	cletest.pollForLease(ctx, "foobar", "default", ptr.To("foo1-131"))
}

func TestCtestLeaseCandidateCleanup(t *testing.T) {
	featuregatetesting.SetFeatureGateDuringTest(t, utilfeature.DefaultFeatureGate, genericfeatures.CoordinatedLeaderElection, true)
	apiserver.LeaseCandidateGCPeriod = 1 * time.Second

	defer func() {
		apiserver.LeaseCandidateGCPeriod = 30 * time.Minute
	}()

	flags := []string{fmt.Sprintf("--runtime-config=%s=true", v1beta1.SchemeGroupVersion)}
	server, err := apiservertesting.StartTestServer(t, apiservertesting.NewDefaultTestServerOptions(), flags, framework.SharedEtcd())
	if err != nil {
		t.Fatal(err)
	}
	defer server.TearDownFn()
	config := server.ClientConfig
	clientset, err := kubernetes.NewForConfig(config)
	if err != nil {
		t.Fatal(err)
	}

	fmt.Println(ctestglobals.StartExtendModeSeparator)
	hardcoded := getHardCodedConfigInfoLeaseCandidate()
	item, found := ctestutils.GetItemByExactTestInfo(hardcoded, "lease candidate cleanup")
	if !found {
		fmt.Println(ctestglobals.DebugPrefix(), "Failed to find config item by TestInfo")
		t.Fatalf("Unable to find hardcoded config")
	}
	fmt.Println(ctestglobals.DebugPrefix(), "Matched config item:", item)

	configObjs, configJson, err := ctest.GenerateEffectiveConfigReturnType[v1beta1.LeaseCandidateSpec](item, ctest.ExtendOnly)
	if err != nil {
		fmt.Println(ctestglobals.DebugPrefix(), "Failed to generate configs:", err)
		t.Fatalf("Failed to generate configs")
	}
	if configObjs == nil {
		fmt.Println(ctestglobals.DebugPrefix(), "No dynamic configs generated, skipping test")
		t.Skip("No dynamic configs")
	}
	fmt.Println(ctestglobals.DebugPrefix(), "New Json Test Configs:", string(configJson))
	fmt.Println(ctestglobals.DebugPrefix(), "Number of test cases:", len(configObjs))

	for i, spec := range configObjs {
		fmt.Printf("Running %d th test case.\n", i)
		lc := &v1beta1.LeaseCandidate{
			ObjectMeta: metav1.ObjectMeta{
				Name:      fmt.Sprintf("expired-%s", string(uuid.NewUUID())),
				Namespace: "default",
			},
			Spec: spec,
		}
		ctx := context.Background()
		_, err = clientset.CoordinationV1beta1().LeaseCandidates("default").Create(ctx, lc, metav1.CreateOptions{})
		if err != nil {
			t.Fatal(err)
		}

		err = wait.PollUntilContextTimeout(ctx, 1000*time.Millisecond, 5*time.Second, true, func(ctx context.Context) (bool, error) {
			_, err = clientset.CoordinationV1beta1().LeaseCandidates("default").Get(ctx, lc.Name, metav1.GetOptions{})
			if apierrors.IsNotFound(err) {
				return true, nil
			}
			return false, nil
		})
		if err != nil {
			t.Fatalf("Timeout waiting for lease gc: %v", err)
		}
	}
}

func getHardCodedConfigInfoLeaseCandidate() ctestglobals.HardcodedConfig {
	return ctestglobals.HardcodedConfig{
		{
			FixtureFileName: "test_fixture.json",
			TestInfo:        []string{"lease candidate cleanup"},
			Field:           "spec",
			K8sObjects:      []string{"leasecandidates"},
			HardcodedConfig: v1beta1.LeaseCandidateSpec{
				LeaseName:        "foobaz",
				BinaryVersion:    "0.1.0",
				EmulationVersion: "0.1.0",
				Strategy:         v1.OldestEmulationVersion,
				RenewTime:        &metav1.MicroTime{Time: time.Now().Add(-2 * time.Hour)},
				PingTime:         &metav1.MicroTime{Time: time.Now().Add(-1 * time.Hour)},
			},
		},
	}
}
