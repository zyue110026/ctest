package apiserver

import (
	// "context"
	"fmt"
	// "sync"
	"testing"
	"time"

	"k8s.io/apimachinery/pkg/util/uuid"

	v1 "k8s.io/api/core/v1"
	metav1 "k8s.io/apimachinery/pkg/apis/meta/v1"
	"k8s.io/apimachinery/pkg/util/wait"
	// clientset "k8s.io/client-go/kubernetes"
	// "k8s.io/klog/v2"
	// "k8s.io/kubernetes/cmd/kube-apiserver/app/options"
	// "k8s.io/kubernetes/pkg/controlplane"
	// "k8s.io/kubernetes/pkg/controlplane/reconcilers"
	// "k8s.io/kubernetes/test/integration/framework"
	"k8s.io/kubernetes/test/utils/ktesting"

	ctest "k8s.io/kubernetes/test/ctest"
	ctestglobals "k8s.io/kubernetes/test/ctest/ctestglobals"
	ctestutils "k8s.io/kubernetes/test/ctest/utils"
)

// TestCtestWatchCacheUpdatedByEtcd validates watch cache synchronization for different resource
// types when they are stored in separate etcd backends. It dynamically generates ConfigMap,
// Secret and Event objects from fixture data and adds edge cases such as empty names.
func TestCtestWatchCacheUpdatedByEtcd(t *testing.T) {
	tCtx := ktesting.Init(t)
	c, closeFn := multiEtcdSetup(tCtx, t)
	defer closeFn()

	fmt.Println(ctestglobals.DebugPrefix(), "Fetching ConfigMap configs")
	cmConfigs, err := getConfigs[v1.ConfigMap]("default configmap")
	if err != nil {
		t.Fatalf("Failed to get ConfigMap configs: %v", err)
	}
	edgeCmConfigs, _ := getConfigs[v1.ConfigMap]("empty name configmap")
	cmConfigs = append(cmConfigs, edgeCmConfigs...)

	fmt.Println(ctestglobals.DebugPrefix(), "Fetching Secret configs")
	secretConfigs, err := getConfigs[v1.Secret]("default secret")
	if err != nil {
		t.Fatalf("Failed to get Secret configs: %v", err)
	}
	edgeSecretConfigs, _ := getConfigs[v1.Secret]("empty name secret")
	secretConfigs = append(secretConfigs, edgeSecretConfigs...)

	fmt.Println(ctestglobals.DebugPrefix(), "Fetching Event configs")
	eventConfigs, err := getConfigs[v1.Event]("default event")
	if err != nil {
		t.Fatalf("Failed to get Event configs: %v", err)
	}
	edgeEventConfigs, _ := getConfigs[v1.Event]("empty name event")
	eventConfigs = append(eventConfigs, edgeEventConfigs...)

	// Helper to create object with optional uuid suffix
	createObjName := func(base string) string {
		if base == "" {
			return ""
		}
		return base + "-" + string(uuid.NewUUID())
	}

	// Create ConfigMaps
	for i, cfg := range cmConfigs {
		fmt.Printf("Running ConfigMap test case #%d\n", i)
		name := createObjName(cfg.Name)
		if name != "" {
			cfg.Name = name
		}
		_, err := c.CoreV1().ConfigMaps("default").Create(tCtx, &cfg, metav1.CreateOptions{})
		if err != nil {
			if cfg.Name == "" {
				// Expected failure for empty name
				t.Logf("Expected failure creating ConfigMap with empty name: %v", err)
				continue
			}
			t.Errorf("Couldn't create configmap: %v", err)
			continue
		}
		// Wait for watch cache sync
		listOptions := metav1.ListOptions{
			ResourceVersion:      "0",
			ResourceVersionMatch: metav1.ResourceVersionMatchNotOlderThan,
		}
		if err := wait.Poll(100*time.Millisecond, wait.ForeverTestTimeout, func() (bool, error) {
			res, err := c.CoreV1().ConfigMaps("default").List(tCtx, listOptions)
			if err != nil {
				return false, nil
			}
			return res.ResourceVersion != "", nil
		}); err != nil {
			t.Errorf("Failed to wait for configmaps watchcache synced: %v", err)
		}
	}

	// Create Events
	for i, cfg := range eventConfigs {
		fmt.Printf("Running Event test case #%d\n", i)
		name := createObjName(cfg.Name)
		if name != "" {
			cfg.Name = name
		}
		_, err := c.CoreV1().Events("default").Create(tCtx, &cfg, metav1.CreateOptions{})
		if err != nil {
			if cfg.Name == "" {
				t.Logf("Expected failure creating Event with empty name: %v", err)
				continue
			}
			t.Errorf("Couldn't create event: %v", err)
			continue
		}
	}

	// Verify ConfigMap watchcache sync after Event creation
	for i, cfg := range cmConfigs {
		if cfg.Name == "" {
			continue
		}
		listOptions := metav1.ListOptions{
			ResourceVersion:      "0",
			ResourceVersionMatch: metav1.ResourceVersionMatchNotOlderThan,
		}
		if err := wait.Poll(100*time.Millisecond, wait.ForeverTestTimeout, func() (bool, error) {
			res, err := c.CoreV1().ConfigMaps("default").List(tCtx, listOptions)
			if err != nil {
				return false, nil
			}
			return res.ResourceVersion != "", nil
		}); err != nil {
			t.Errorf("Failed to wait for configmaps watchcache synced after events: %v", err)
		}
		_ = i
	}

	// Create Secrets (stored in same etcd as ConfigMaps)
	for i, cfg := range secretConfigs {
		fmt.Printf("Running Secret test case #%d\n", i)
		name := createObjName(cfg.Name)
		if name != "" {
			cfg.Name = name
		}
		_, err := c.CoreV1().Secrets("default").Create(tCtx, &cfg, metav1.CreateOptions{})
		if err != nil {
			if cfg.Name == "" {
				t.Logf("Expected failure creating Secret with empty name: %v", err)
				continue
			}
			t.Errorf("Couldn't create secret: %v", err)
			continue
		}
		// Wait for ConfigMap watchcache to sync to Secret's resourceVersion
		listOptions := metav1.ListOptions{
			ResourceVersion:      "0",
			ResourceVersionMatch: metav1.ResourceVersionMatchNotOlderThan,
		}
		if err := wait.Poll(100*time.Millisecond, wait.ForeverTestTimeout, func() (bool, error) {
			res, err := c.CoreV1().ConfigMaps("default").List(tCtx, listOptions)
			if err != nil {
				return false, nil
			}
			return res.ResourceVersion != "", nil
		}); err != nil {
			t.Errorf("Failed to wait for configmaps watchcache synced after secret: %v", err)
		}
		// Ensure events watchcache does NOT sync to secret's version
		if err := wait.Poll(100*time.Millisecond, 5*time.Second, func() (bool, error) {
			res, err := c.CoreV1().Events("default").List(tCtx, listOptions)
			if err != nil {
				return false, nil
			}
			return res.ResourceVersion == "", nil
		}); err != nil && err != wait.ErrWaitTimeout {
			t.Errorf("Events watchcache unexpectedly synced after secret: %v", err)
		}
	}
}

// getConfigs returns effective configuration objects for a given test info string.
func getConfigs[T any](testinfo string) ([]T, error) {
	hc := getHardCodedConfigInfoWatchCache()
	item, found := ctestutils.GetItemByExactTestInfo(hc, testinfo)
	if !found {
		return nil, fmt.Errorf("hardcoded config not found for %s", testinfo)
	}
	objs, _, err := ctest.GenerateEffectiveConfigReturnType[T](item, ctest.OverrideOnly)
	if err != nil {
		return nil, err
	}
	return objs, nil
}

// getHardCodedConfigInfoWatchCache provides hardcoded fixture data for ConfigMap, Secret, and Event objects.
func getHardCodedConfigInfoWatchCache() ctestglobals.HardcodedConfig {
	return ctestglobals.HardcodedConfig{
		{
			FixtureFileName: "test_fixture.json",
			TestInfo:        []string{"default configmap"},
			Field:           "metadata.name",
			K8sObjects:      []string{"configmaps"},
			HardcodedConfig: v1.ConfigMap{
				ObjectMeta: metav1.ObjectMeta{Name: "name"},
			},
		},
		{
			FixtureFileName: "test_fixture.json",
			TestInfo:        []string{"empty name configmap"},
			Field:           "metadata.name",
			K8sObjects:      []string{"configmaps"},
			HardcodedConfig: v1.ConfigMap{
				ObjectMeta: metav1.ObjectMeta{Name: ""},
			},
		},
		{
			FixtureFileName: "test_fixture.json",
			TestInfo:        []string{"default secret"},
			Field:           "metadata.name",
			K8sObjects:      []string{"secrets"},
			HardcodedConfig: v1.Secret{
				ObjectMeta: metav1.ObjectMeta{Name: "name"},
			},
		},
		{
			FixtureFileName: "test_fixture.json",
			TestInfo:        []string{"empty name secret"},
			Field:           "metadata.name",
			K8sObjects:      []string{"secrets"},
			HardcodedConfig: v1.Secret{
				ObjectMeta: metav1.ObjectMeta{Name: ""},
			},
		},
		{
			FixtureFileName: "test_fixture.json",
			TestInfo:        []string{"default event"},
			Field:           "metadata.name",
			K8sObjects:      []string{"events"},
			HardcodedConfig: v1.Event{
				ObjectMeta: metav1.ObjectMeta{Name: "name"},
			},
		},
		{
			FixtureFileName: "test_fixture.json",
			TestInfo:        []string{"empty name event"},
			Field:           "metadata.name",
			K8sObjects:      []string{"events"},
			HardcodedConfig: v1.Event{
				ObjectMeta: metav1.ObjectMeta{Name: ""},
			},
		},
	}
}
