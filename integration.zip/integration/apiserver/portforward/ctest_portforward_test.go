package portforward

import (
	// "bufio"
	"bytes"
	"context"
	"fmt"
	"io"
	// "net"
	"net/http"
	"net/http/httptest"
	"net/url"
	"strconv"
	// "strings"
	"sync"
	"testing"
	"time"

	"github.com/stretchr/testify/require"

	corev1 "k8s.io/api/core/v1"
	metav1 "k8s.io/apimachinery/pkg/apis/meta/v1"
	"k8s.io/apimachinery/pkg/types"
	"k8s.io/apimachinery/pkg/util/remotecommand"
	"k8s.io/apimachinery/pkg/util/wait"
	utilfeature "k8s.io/apiserver/pkg/util/feature"
	"k8s.io/cli-runtime/pkg/genericiooptions"
	"k8s.io/client-go/kubernetes"
	featuregatetesting "k8s.io/component-base/featuregate/testing"
	"k8s.io/kubectl/pkg/cmd/portforward"
	kubeletportforward "k8s.io/kubelet/pkg/cri/streaming/portforward"
	kastesting "k8s.io/kubernetes/cmd/kube-apiserver/app/testing"
	kubefeatures "k8s.io/kubernetes/pkg/features"

	"k8s.io/kubernetes/test/integration/framework"

	ctest "k8s.io/kubernetes/test/ctest"
	ctestglobals "k8s.io/kubernetes/test/ctest/ctestglobals"
	ctestutils "k8s.io/kubernetes/test/ctest/utils"

	"k8s.io/apimachinery/pkg/util/uuid"
)

func TestCtestPortforward(t *testing.T) {
	featuregatetesting.SetFeatureGateDuringTest(t, utilfeature.DefaultFeatureGate, kubefeatures.PortForwardWebsockets, true)
	t.Setenv("KUBECTL_PORT_FORWARD_WEBSOCKETS", "true")

	// -------------------------------------------------------------------------
	// Load dynamic Node configurations (override mode)
	fmt.Println(ctestglobals.DebugPrefix(), "Loading Node configs")
	nodeConfigs, err := getNodeConfigs()
	if err != nil {
		t.Fatalf("failed to get node configs: %v", err)
	}
	if nodeConfigs == nil || len(nodeConfigs) == 0 {
		fmt.Println(ctestglobals.DebugPrefix(), "Skipping test execution. No node configs generated.")
		return
	}
	fmt.Println(ctestglobals.DebugPrefix(), "Node config count:", len(nodeConfigs))

	// Load dynamic PodSpec configurations (override mode)
	fmt.Println(ctestglobals.DebugPrefix(), "Loading PodSpec configs")
	podSpecs, err := getPodSpecs()
	if err != nil {
		t.Fatalf("failed to get pod specs: %v", err)
	}
	if podSpecs == nil || len(podSpecs) == 0 {
		fmt.Println(ctestglobals.DebugPrefix(), "Skipping test execution. No pod specs generated.")
		return
	}
	fmt.Println(ctestglobals.DebugPrefix(), "PodSpec config count:", len(podSpecs))

	// -------------------------------------------------------------------------
	// Iterate over cross‑product of node and pod configs
	for iNode, node := range nodeConfigs {
		for iPod, podSpec := range podSpecs {
			fmt.Printf("Running node config #%d, pod spec #%d\n", iNode, iPod)

			// -----------------------------------------------------------------
			// Test environment setup (etcd, apiserver, client)
			etcd := framework.SharedEtcd()
			server := kastesting.StartTestServerOrDie(t, nil, framework.DefaultTestServerFlags(), etcd)
			defer server.TearDownFn()

			adminClient, err := kubernetes.NewForConfig(server.ClientConfig)
			require.NoError(t, err)

			// -----------------------------------------------------------------
			// Create Node
			if node.Name == "" {
				node.Name = fmt.Sprintf("node-%s", string(uuid.NewUUID()))
			}
			if _, err := adminClient.CoreV1().Nodes().Create(context.Background(), &node, metav1.CreateOptions{}); err != nil {
				t.Fatalf("failed to create node: %v", err)
			}

			// -----------------------------------------------------------------
			// Create Pod using the generated spec
			podName := fmt.Sprintf("pod-%s", string(uuid.NewUUID()))
			pod := &corev1.Pod{
				ObjectMeta: metav1.ObjectMeta{
					Namespace: "default",
					Name:      podName,
				},
				Spec: podSpec,
			}
			if pod.Spec.NodeName == "" {
				pod.Spec.NodeName = node.Name
			}
			if _, err := adminClient.CoreV1().Pods("default").Create(context.Background(), pod, metav1.CreateOptions{}); err != nil {
				t.Fatalf("failed to create pod: %v", err)
			}
			// Mark pod as Running
			if _, err := adminClient.CoreV1().Pods("default").Patch(context.Background(),
				podName, types.MergePatchType,
				[]byte(`{"status":{"phase":"Running"}}`),
				metav1.PatchOptions{}, "status"); err != nil {
				t.Fatalf("failed to patch pod status: %v", err)
			}

			// -----------------------------------------------------------------
			// Backend server to simulate kubelet port‑forward endpoint
			backendServer := httptest.NewTLSServer(http.HandlerFunc(func(w http.ResponseWriter, req *http.Request) {
				t.Logf("backend saw request: %v", req.URL.String())
				kubeletportforward.ServePortForward(
					w,
					req,
					&dummyPortForwarder{t: t},
					podName,
					pod.UID,
					&kubeletportforward.V4Options{},
					wait.ForeverTestTimeout,
					remotecommand.DefaultStreamCreationTimeout,
					[]string{kubeletportforward.ProtocolV1Name},
				)
			}))
			defer backendServer.Close()
			backendURL, _ := url.Parse(backendServer.URL)
			backendHost := backendURL.Hostname()
			backendPort, _ := strconv.Atoi(backendURL.Port())

			// Update node DaemonEndpoint to point to the test backend
			// (this mirrors the original test's manual node status mutation)
			if _, err := adminClient.CoreV1().Nodes().Patch(context.Background(),
				node.Name, types.MergePatchType,
				[]byte(fmt.Sprintf(`{"status":{"daemonEndpoints":{"kubeletEndpoint":{"port":%d}},"addresses":[{"type":"InternalIP","address":"%s"}]}}`, backendPort, backendHost)),
				metav1.PatchOptions{}, "status"); err != nil {
				t.Fatalf("failed to patch node status: %v", err)
			}

			// -----------------------------------------------------------------
			// Port‑forward setup (mirrors original logic)
			localRemotePort := fmt.Sprintf(":%s", remotePort)
			out := &mBuffer{buffer: bytes.Buffer{}}
			errOut := &bytes.Buffer{}
			streams := genericiooptions.IOStreams{
				In:     &bytes.Buffer{},
				Out:    out,
				ErrOut: errOut,
			}
			portForwardOptions := portforward.NewDefaultPortForwardOptions(streams)
			portForwardOptions.Namespace = "default"
			portForwardOptions.PodName = podName
			portForwardOptions.RESTClient = adminClient.CoreV1().RESTClient()
			portForwardOptions.Config = server.ClientConfig
			portForwardOptions.PodClient = adminClient.CoreV1()
			portForwardOptions.Address = []string{"127.0.0.1"}
			portForwardOptions.Ports = []string{localRemotePort}
			portForwardOptions.StopChannel = make(chan struct{}, 1)
			portForwardOptions.ReadyChannel = make(chan struct{})

			if err := portForwardOptions.Validate(); err != nil {
				t.Fatalf("validate failed: %v", err)
			}

			ctx, cancel := context.WithCancel(context.Background())
			defer cancel()

			wg := sync.WaitGroup{}
			wg.Add(1)
			go func() {
				defer wg.Done()
				if err := portForwardOptions.RunPortForwardContext(ctx); err != nil {
					t.Error(err)
				}
			}()

			t.Log("waiting for port forward to be ready")
			select {
			case <-portForwardOptions.ReadyChannel:
				t.Log("port forward was ready")
			case <-time.After(wait.ForeverTestTimeout):
				t.Error("port forward was never ready")
			}

			// Parse randomly selected local port
			localPort, err := parsePort(out.String())
			require.NoError(t, err)
			t.Logf("Local Port: %s", localPort)

			timeoutContext, cleanupTimeoutContext := context.WithDeadline(context.Background(), time.Now().Add(5*time.Second))
			defer cleanupTimeoutContext()
			testReq, _ := http.NewRequest("GET", fmt.Sprintf("http://127.0.0.1:%s/test", localPort), nil)
			testReq = testReq.WithContext(timeoutContext)
			testResp, err := http.DefaultClient.Do(testReq)
			if err != nil {
				t.Error(err)
			} else {
				t.Log(testResp.StatusCode)
				data, err := io.ReadAll(testResp.Body)
				if err != nil {
					t.Error(err)
				} else {
					t.Log("client saw response:", string(data))
				}
				if string(data) != fmt.Sprintf("request to %s was ok", remotePort) {
					t.Errorf("unexpected data")
				}
				if testResp.StatusCode != 200 {
					t.Error("expected success")
				}
			}

			cancel()
			wg.Wait()
			t.Logf("stdout: %s", out.String())
			t.Logf("stderr: %s", errOut.String())
		}
	}
}

// -------------------------------------------------------------------------
// Dynamic configuration helpers

func getNodeConfigs() ([]corev1.Node, error) {
	fmt.Println(ctestglobals.DebugPrefix(), "Fetching node config item")
	hc := getHardCodedConfigInfoPortforward()
	item, found := ctestutils.GetItemByExactTestInfo(hc, "default node for portforward")
	if !found {
		return nil, fmt.Errorf("node config not found")
	}
	fmt.Println(ctestglobals.DebugPrefix(), "node config item:", item)
	fmt.Println(ctestglobals.StartOverrideModeSeparator)
	nodes, cfgJSON, err := ctest.GenerateEffectiveConfigReturnType[corev1.Node](item, ctest.OverrideOnly)
	if err != nil {
		return nil, err
	}
	fmt.Println(ctestglobals.DebugPrefix(), "Node JSON:", string(cfgJSON))
	fmt.Println(ctestglobals.DebugPrefix(), "Number of node configs:", len(nodes))
	return nodes, nil
}

func getPodSpecs() ([]corev1.PodSpec, error) {
	fmt.Println(ctestglobals.DebugPrefix(), "Fetching pod spec config item")
	hc := getHardCodedConfigInfoPortforward()
	item, found := ctestutils.GetItemByExactTestInfo(hc, "default pod for portforward")
	if !found {
		return nil, fmt.Errorf("pod spec config not found")
	}
	fmt.Println(ctestglobals.DebugPrefix(), "pod spec item:", item)
	fmt.Println(ctestglobals.StartOverrideModeSeparator)
	pods, cfgJSON, err := ctest.GenerateEffectiveConfigReturnType[corev1.PodSpec](item, ctest.OverrideOnly)
	if err != nil {
		return nil, err
	}
	fmt.Println(ctestglobals.DebugPrefix(), "PodSpec JSON:", string(cfgJSON))
	fmt.Println(ctestglobals.DebugPrefix(), "Number of pod specs:", len(pods))
	return pods, nil
}

// -------------------------------------------------------------------------

func getHardCodedConfigInfoPortforward() ctestglobals.HardcodedConfig {
	return ctestglobals.HardcodedConfig{
		{
			FixtureFileName: "test_fixture.json",
			TestInfo:        []string{"default node for portforward"},
			Field:           "status",
			K8sObjects: []string{
				"nodes",
			},
			HardcodedConfig: corev1.Node{
				ObjectMeta: metav1.ObjectMeta{
					Name: "mynode",
				},
				Status: corev1.NodeStatus{
					DaemonEndpoints: corev1.NodeDaemonEndpoints{
						KubeletEndpoint: corev1.DaemonEndpoint{
							Port: 0, // will be overridden by test backend port
						},
					},
					Addresses: []corev1.NodeAddress{
						{
							Type:    corev1.NodeInternalIP,
							Address: "127.0.0.1",
						},
					},
				},
			},
		},
		{
			FixtureFileName: "test_fixture.json",
			TestInfo:        []string{"default pod for portforward"},
			Field:           "spec",
			K8sObjects: []string{
				"pods",
				"deployments",
				"statefulsets",
				"daemonsets",
				"replicasets",
			},
			HardcodedConfig: corev1.PodSpec{
				NodeName: "mynode",
				Containers: []corev1.Container{
					{
						Name:  "test",
						Image: "test",
					},
				},
			},
		},
	}
}
