package anonymous

import (
	// "context"
	// "crypto/tls"
	"fmt"
	// "net/http"
	// "os"
	"testing"

	"github.com/stretchr/testify/require"
	ctest "k8s.io/kubernetes/test/ctest"
	ctestglobals "k8s.io/kubernetes/test/ctest/ctestglobals"
	ctestutils "k8s.io/kubernetes/test/ctest/utils"
	// rbacv1 "k8s.io/api/rbac/v1"
	// metav1 "k8s.io/apimachinery/pkg/apis/meta/v1"
	// "k8s.io/apimachinery/pkg/util/uuid"
	// "k8s.io/client-go/kubernetes"
	_ "k8s.io/client-go/plugin/pkg/client/auth/oidc"
	kubeapiserverapptesting "k8s.io/kubernetes/cmd/kube-apiserver/app/testing"
	// "k8s.io/kubernetes/pkg/apis/rbac"
	// "k8s.io/kubernetes/test/integration/authutil"
	"k8s.io/kubernetes/test/integration/framework"
)

func TestCtestStructuredAuthenticationConfig(t *testing.T) {
	t.Log("Testing anonymous authenticator with authentication config (dynamic)")

	// ---- Static test cases (original) ----
	staticTestCases := []struct {
		desc            string
		authConfig      string
		additionalFlags []string
		assertErrFn     func(t *testing.T, errorToCheck error)
		assertFn        func(t *testing.T, server kubeapiserverapptesting.TestServer)
	}{
		{
			desc: "valid config no conditions",
			authConfig: `
apiVersion: apiserver.config.k8s.io/v1beta1
kind: AuthenticationConfiguration
anonymous:
  enabled: true
`,
			assertErrFn: func(t *testing.T, errorToCheck error) {
				require.NoError(t, errorToCheck)
			},
			assertFn: func(t *testing.T, server kubeapiserverapptesting.TestServer) {
				configureRBAC(t, server)

				client := insecureHTTPClient(t)

				resp, err := client.Get(server.ClientConfig.Host + "/api/v1/namespaces/default/pods")
				require.NoError(t, err)
				defer resp.Body.Close() //nolint:errcheck
				require.Equal(t, 200, resp.StatusCode)

				resp, err = client.Get(server.ClientConfig.Host + "/livez")
				require.NoError(t, err)
				defer resp.Body.Close() //nolint:errcheck
				require.Equal(t, 200, resp.StatusCode)

				resp, err = client.Get(server.ClientConfig.Host + "/healthz")
				require.NoError(t, err)
				defer resp.Body.Close() //nolint:errcheck
				require.Equal(t, 200, resp.StatusCode)
			},
			additionalFlags: nil,
		},
		{
			desc: "valid config with conditions",
			authConfig: `
apiVersion: apiserver.config.k8s.io/v1beta1
kind: AuthenticationConfiguration
anonymous:
  enabled: true
  conditions:
  - path: "/livez"
`,
			assertErrFn: func(t *testing.T, errorToCheck error) {
				require.NoError(t, errorToCheck)
			},
			assertFn: func(t *testing.T, server kubeapiserverapptesting.TestServer) {
				client := insecureHTTPClient(t)

				resp, err := client.Get(server.ClientConfig.Host + "/api/v1/namespaces/default/pods")
				require.NoError(t, err)
				defer resp.Body.Close() //nolint:errcheck
				require.Equal(t, 401, resp.StatusCode)

				resp, err = client.Get(server.ClientConfig.Host + "/livez")
				require.NoError(t, err)
				defer resp.Body.Close() //nolint:errcheck
				require.Equal(t, 200, resp.StatusCode)

				resp, err = client.Get(server.ClientConfig.Host + "/healthz")
				require.NoError(t, err)
				defer resp.Body.Close() //nolint:errcheck
				require.Equal(t, 401, resp.StatusCode)
			},
			additionalFlags: nil,
		},
	}

	// ---- Dynamic config generation ----
	fmt.Println(ctestglobals.DebugPrefix(), "Start dynamic config generation for authentication config")
	hardcodedConfig := getHardCodedConfigInfoAuthenticationConfig()
	item, found := ctestutils.GetItemByExactTestInfo(hardcodedConfig, "default anonymous auth config")
	if !found {
		fmt.Println(ctestglobals.DebugPrefix(), "Failed to find config item by TestInfo")
		t.Fatalf("hardcoded config not found")
	}
	fmt.Println(ctestglobals.DebugPrefix(), "get default configs:", item)
	fmt.Println(ctestglobals.StartExtendModeSeparator)
	configObjs, configJson, err := ctest.GenerateEffectiveConfigReturnType[string](item, ctest.ExtendOnly)
	if err != nil {
		fmt.Println(ctestglobals.DebugPrefix(), "Failed to get matched fixtures: %v", err)
		t.Fatalf("config generation error: %v", err)
	}
	if configObjs == nil {
		fmt.Println(ctestglobals.DebugPrefix(), "Skipping test execution. No new configurations generated.")
	} else {
		fmt.Println(ctestglobals.DebugPrefix(), "New Json Test Configs:", string(configJson))
		fmt.Println(ctestglobals.DebugPrefix(), "Number of dynamic test configs:", len(configObjs))
	}

	// ---- Edge cases ----
	edgeTestCases := []struct {
		desc        string
		authConfig  string
		expectError bool
	}{
		{
			desc:        "empty config",
			authConfig:  ``,
			expectError: true,
		},
		{
			desc: "invalid yaml",
			authConfig: `
apiVersion: apiserver.config.k8s.io/v1beta1
kind: AuthenticationConfiguration
anonymous:
  enabled true   # missing colon
`,
			expectError: true,
		},
		{
			desc: "unknown field",
			authConfig: `
apiVersion: apiserver.config.k8s.io/v1beta1
kind: AuthenticationConfiguration
anonymous:
  enabled: true
  foo: bar
`,
			expectError: true,
		},
		{
			desc: "condition with unsupported path",
			authConfig: `
apiVersion: apiserver.config.k8s.io/v1beta1
kind: AuthenticationConfiguration
anonymous:
  enabled: true
  conditions:
  - path: "/unsupported"
`,
			// Server starts fine, but should reject all non‑/unsupported paths -> 401
			expectError: false,
		},
	}

	// Combine all test cases
	var allTestCases []struct {
		desc            string
		authConfig      string
		additionalFlags []string
		assertErrFn     func(t *testing.T, errorToCheck error)
		assertFn        func(t *testing.T, server kubeapiserverapptesting.TestServer)
	}
	// static ones
	for _, tc := range staticTestCases {
		allTestCases = append(allTestCases, tc)
	}
	// dynamic ones (treat as valid config without conditions)
	for i, cfg := range configObjs {
		idx := i // capture
		allTestCases = append(allTestCases, struct {
			desc            string
			authConfig      string
			additionalFlags []string
			assertErrFn     func(t *testing.T, errorToCheck error)
			assertFn        func(t *testing.T, server kubeapiserverapptesting.TestServer)
		}{
			desc:       fmt.Sprintf("dynamic config %d", idx),
			authConfig: cfg,
			assertErrFn: func(t *testing.T, err error) {
				require.NoError(t, err)
			},
			assertFn: func(t *testing.T, server kubeapiserverapptesting.TestServer) {
				// No conditions => all endpoints should succeed
				configureRBAC(t, server)
				client := insecureHTTPClient(t)

				resp, err := client.Get(server.ClientConfig.Host + "/api/v1/namespaces/default/pods")
				require.NoError(t, err)
				defer resp.Body.Close() //nolint:errcheck
				require.Equal(t, 200, resp.StatusCode)

				resp, err = client.Get(server.ClientConfig.Host + "/livez")
				require.NoError(t, err)
				defer resp.Body.Close() //nolint:errcheck
				require.Equal(t, 200, resp.StatusCode)

				resp, err = client.Get(server.ClientConfig.Host + "/healthz")
				require.NoError(t, err)
				defer resp.Body.Close() //nolint:errcheck
				require.Equal(t, 200, resp.StatusCode)
			},
			additionalFlags: nil,
		})
	}
	// edge cases
	for _, ec := range edgeTestCases {
		expectErr := ec.expectError
		allTestCases = append(allTestCases, struct {
			desc            string
			authConfig      string
			additionalFlags []string
			assertErrFn     func(t *testing.T, errorToCheck error)
			assertFn        func(t *testing.T, server kubeapiserverapptesting.TestServer)
		}{
			desc:       ec.desc,
			authConfig: ec.authConfig,
			assertErrFn: func(t *testing.T, err error) {
				if expectErr {
					require.Error(t, err)
				} else {
					require.NoError(t, err)
				}
			},
			assertFn: func(t *testing.T, server kubeapiserverapptesting.TestServer) {
				if expectErr {
					t.Fatalf("unexpected success for edge case %s", ec.desc)
				}
				// For unsupported‑path condition, only /livez should succeed
				client := insecureHTTPClient(t)

				resp, err := client.Get(server.ClientConfig.Host + "/livez")
				require.NoError(t, err)
				defer resp.Body.Close() //nolint:errcheck
				require.Equal(t, 200, resp.StatusCode)

				resp, err = client.Get(server.ClientConfig.Host + "/api/v1/namespaces/default/pods")
				require.NoError(t, err)
				defer resp.Body.Close() //nolint:errcheck
				require.Equal(t, 401, resp.StatusCode)

				resp, err = client.Get(server.ClientConfig.Host + "/healthz")
				require.NoError(t, err)
				defer resp.Body.Close() //nolint:errcheck
				require.Equal(t, 401, resp.StatusCode)
			},
			additionalFlags: nil,
		})
	}

	// ---- Execute all test cases ----
	for _, tc := range allTestCases {
		t.Run(tc.desc, func(t *testing.T) {
			flags := []string{"--authorization-mode=RBAC"}
			flags = append(flags, fmt.Sprintf("--authentication-config=%s", writeTempFile(t, tc.authConfig)))
			flags = append(flags, tc.additionalFlags...)

			server, err := kubeapiserverapptesting.StartTestServer(
				t,
				kubeapiserverapptesting.NewDefaultTestServerOptions(),
				flags,
				framework.SharedEtcd(),
			)

			tc.assertErrFn(t, err)

			if tc.assertFn == nil {
				return
			}
			defer server.TearDownFn()
			tc.assertFn(t, server)
		})
	}
	fmt.Println(ctestglobals.EndSeparator)
}

// getHardCodedConfigInfoAuthenticationConfig returns the minimal hard‑coded authentication
// configuration used as a baseline for dynamic generation.
func getHardCodedConfigInfoAuthenticationConfig() ctestglobals.HardcodedConfig {
	return ctestglobals.HardcodedConfig{
		{
			FixtureFileName: "test_fixture.json",
			TestInfo:        []string{"default anonymous auth config"},
			Field:           "authenticationConfig",
			K8sObjects:      []string{},
			HardcodedConfig: `
apiVersion: apiserver.config.k8s.io/v1beta1
kind: AuthenticationConfiguration
anonymous:
  enabled: true
`,
		},
	}
}
