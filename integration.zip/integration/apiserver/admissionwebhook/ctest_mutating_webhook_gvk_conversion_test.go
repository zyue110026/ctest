package admissionwebhook

import (
	"context"
	"crypto/tls"
	"crypto/x509"
	// "encoding/json"
	"fmt"
	// "io"
	// "net/http"
	"net/http/httptest"
	// "sync"
	"testing"
	"time"

	// admissionv1 "k8s.io/api/admission/v1"
	admissionregistrationv1 "k8s.io/api/admissionregistration/v1"
	corev1 "k8s.io/api/core/v1"
	// apiextensionsv1 "k8s.io/apiextensions-apiserver/pkg/apis/apiextensions/v1"
	apiextensionsclientset "k8s.io/apiextensions-apiserver/pkg/client/clientset/clientset"
	// "k8s.io/apiextensions-apiserver/test/integration/fixtures"
	metav1 "k8s.io/apimachinery/pkg/apis/meta/v1"
	"k8s.io/apimachinery/pkg/apis/meta/v1/unstructured"
	// "k8s.io/apimachinery/pkg/runtime"
	// "k8s.io/apimachinery/pkg/runtime/serializer"
	"k8s.io/apimachinery/pkg/runtime/schema"
	"k8s.io/apimachinery/pkg/types"
	"k8s.io/apimachinery/pkg/util/wait"
	"k8s.io/client-go/dynamic"
	clientset "k8s.io/client-go/kubernetes"
	apiservertesting "k8s.io/kubernetes/cmd/kube-apiserver/app/testing"
	"k8s.io/kubernetes/test/integration/etcd"
	"k8s.io/kubernetes/test/integration/framework"

	ctest "k8s.io/kubernetes/test/ctest"
	ctestglobals "k8s.io/kubernetes/test/ctest/ctestglobals"
	ctestutils "k8s.io/kubernetes/test/ctest/utils"
	// "k8s.io/apimachinery/pkg/util/uuid"
)

// TestCtestMutatingWebhookConvertsGVKWithMatchPolicyEquivalent tests if a equivalent resource is properly converted between mutating webhooks
func TestCtestMutatingWebhookConvertsGVKWithMatchPolicyEquivalent(t *testing.T) {
	fmt.Println(ctestglobals.StartSeparator)

	// ----------- generate dynamic MutatingWebhookConfiguration -------------
	hcWebhook, err := getHardCodedConfigInfoMutatingWebhook()
	if err != nil {
		t.Fatalf("failed to get hardcoded config info: %v", err)
	}
	item, found := ctestutils.GetItemByExactTestInfo(hcWebhook, "mutating webhook config")
	if !found {
		t.Fatalf("hardcoded config not found")
	}
	fmt.Println(ctestglobals.DebugPrefix(), "matched webhook config:", item)
	fmt.Println(ctestglobals.StartExtendModeSeparator)
	webhookObjs, webhookJson, err := ctest.GenerateEffectiveConfigReturnType[admissionregistrationv1.MutatingWebhookConfiguration](item, ctest.ExtendOnly)
	if err != nil {
		t.Fatalf("failed to generate webhook config: %v", err)
	}
	fmt.Println(ctestglobals.DebugPrefix(), "Webhook Config JSON:", string(webhookJson))
	if len(webhookObjs) == 0 {
		t.Fatalf("no webhook configs generated")
	}
	mutatingWebhook := webhookObjs[0]

	// ----------- generate dynamic marker pod -------------
	hcPod, err := getHardCodedConfigInfoMarkerPod()
	if err != nil {
		t.Fatalf("failed to get pod config info: %v", err)
	}
	itemPod, found := ctestutils.GetItemByExactTestInfo(hcPod, "marker pod")
	if !found {
		t.Fatalf("marker pod config not found")
	}
	fmt.Println(ctestglobals.DebugPrefix(), "matched pod config:", itemPod)
	fmt.Println(ctestglobals.StartExtendModeSeparator)
	podObjs, podJson, err := ctest.GenerateEffectiveConfigReturnType[corev1.Pod](itemPod, ctest.ExtendOnly)
	if err != nil {
		t.Fatalf("failed to generate pod config: %v", err)
	}
	fmt.Println(ctestglobals.DebugPrefix(), "Pod Config JSON:", string(podJson))
	if len(podObjs) == 0 {
		t.Fatalf("no pod configs generated")
	}
	markerPod := podObjs[0]

	// --------------------------------------------------------------------
	roots := x509.NewCertPool()
	if !roots.AppendCertsFromPEM(localhostCert) {
		t.Fatal("Failed to append Cert from PEM")
	}
	cert, err := tls.X509KeyPair(localhostCert, localhostKey)
	if err != nil {
		t.Fatalf("Failed to build cert: %v", err)
	}
	typeChecker := &admissionTypeChecker{}
	webhookServer := httptest.NewUnstartedServer(newAdmissionTypeCheckerHandler(typeChecker))
	webhookServer.TLS = &tls.Config{
		RootCAs:      roots,
		Certificates: []tls.Certificate{cert},
	}
	webhookServer.StartTLS()
	defer webhookServer.Close()

	upCh := typeChecker.Reset()
	server, err := apiservertesting.StartTestServer(t, nil, []string{
		"--disable-admission-plugins=ServiceAccount",
	}, framework.SharedEtcd())
	if err != nil {
		t.Fatalf("failed to start apiserver: %v", err)
	}
	defer server.TearDownFn()

	etcd.CreateTestCRDs(t, apiextensionsclientset.NewForConfigOrDie(server.ClientConfig), false, versionedCustomResourceDefinition())
	if err != nil {
		t.Fatalf("failed to create CRDs: %v", err)
	}
	config := server.ClientConfig
	client, err := clientset.NewForConfig(config)
	if err != nil {
		t.Fatalf("failed to create clientset: %v", err)
	}

	// marker namespace
	markerNs := "marker"
	_, err = client.CoreV1().Namespaces().Create(context.TODO(), &corev1.Namespace{
		ObjectMeta: metav1.ObjectMeta{Name: markerNs},
	}, metav1.CreateOptions{})
	if err != nil {
		t.Fatalf("failed to create marker ns: %v", err)
	}
	// create marker pod
	markerPod.ObjectMeta.Namespace = markerNs
	_, err = client.CoreV1().Pods(markerNs).Create(context.TODO(), &markerPod, metav1.CreateOptions{})
	if err != nil {
		t.Fatalf("failed to create marker pod: %v", err)
	}

	// create mutating webhook configuration
	mutatingCfg, err := client.AdmissionregistrationV1().MutatingWebhookConfigurations().Create(context.TODO(), &mutatingWebhook, metav1.CreateOptions{})
	if err != nil {
		t.Fatalf("failed to create mutating webhook config: %v", err)
	}
	defer func() {
		_ = client.AdmissionregistrationV1().MutatingWebhookConfigurations().Delete(context.TODO(), mutatingCfg.GetName(), metav1.DeleteOptions{})
	}()

	// wait for webhook to become effective via marker pod patch
	if err := wait.PollImmediate(time.Millisecond*5, wait.ForeverTestTimeout, func() (bool, error) {
		_, err = client.CoreV1().Pods(markerNs).Patch(context.TODO(), markerPod.Name, types.JSONPatchType, []byte("[]"), metav1.PatchOptions{})
		select {
		case <-upCh:
			return true, nil
		default:
			t.Logf("Waiting for webhook to become effective, patch error: %v", err)
			return false, nil
		}
	}); err != nil {
		t.Fatalf("webhook never became effective: %v", err)
	}

	dynamicClient, err := dynamic.NewForConfig(config)
	if err != nil {
		t.Fatalf("failed to create dynamic client: %v", err)
	}
	// create v1 resource
	v1Resource := &unstructured.Unstructured{
		Object: map[string]interface{}{
			"apiVersion": "awesome.example.com/v1",
			"kind":       "Panda",
			"metadata": map[string]interface{}{
				"name": "v1-bears",
			},
		},
	}
	// create v2 resource
	v2Resource := &unstructured.Unstructured{
		Object: map[string]interface{}{
			"apiVersion": "awesome.example.com/v2",
			"kind":       "Panda",
			"metadata": map[string]interface{}{
				"name": "v2-bears",
			},
		},
	}
	_, err = dynamicClient.Resource(schema.GroupVersionResource{Group: "awesome.example.com", Version: "v1", Resource: "pandas"}).Create(context.TODO(), v1Resource, metav1.CreateOptions{})
	if err != nil {
		t.Errorf("error creating v1 resource: %v", err)
	}
	_, err = dynamicClient.Resource(schema.GroupVersionResource{Group: "awesome.example.com", Version: "v2", Resource: "pandas"}).Create(context.TODO(), v2Resource, metav1.CreateOptions{})
	if err != nil {
		t.Errorf("error creating v2 resource: %v", err)
	}
	if len(typeChecker.requests) != 4 {
		t.Errorf("expected 4 admission requests, got %d", len(typeChecker.requests))
	}
	fmt.Println(ctestglobals.EndSeparator)
}

// ---------- hardcoded config providers ----------
func getHardCodedConfigInfoMutatingWebhook() (ctestglobals.HardcodedConfig, error) {
	equiv := admissionregistrationv1.Equivalent
	ignore := admissionregistrationv1.Ignore
	v1Endpoint := "https://placeholder/v1"
	v2Endpoint := "https://placeholder/v2"
	markerEndpoint := "https://placeholder/marker"
	return ctestglobals.HardcodedConfig{
		{
			FixtureFileName: "test_fixture.json",
			TestInfo:        []string{"mutating webhook config"},
			Field:           "webhooks",
			K8sObjects:      []string{"mutatingwebhookconfigurations"},
			HardcodedConfig: &admissionregistrationv1.MutatingWebhookConfiguration{
				ObjectMeta: metav1.ObjectMeta{
					Name: "admission.integration.test",
				},
				Webhooks: []admissionregistrationv1.MutatingWebhook{
					{
						Name: "admission.integration.test.v2",
						Rules: []admissionregistrationv1.RuleWithOperations{{
							Operations: []admissionregistrationv1.OperationType{admissionregistrationv1.Create},
							Rule: admissionregistrationv1.Rule{
								APIGroups:   []string{"awesome.example.com"},
								APIVersions: []string{"v2"},
								Resources:   []string{"*/*"},
							},
						}},
						MatchPolicy: &equiv,
						ClientConfig: admissionregistrationv1.WebhookClientConfig{
							URL:      &v2Endpoint,
							CABundle: localhostCert,
						},
						FailurePolicy:           &ignore,
						SideEffects:             &noSideEffects,
						AdmissionReviewVersions: []string{"v1"},
						MatchConditions: []admissionregistrationv1.MatchCondition{
							{
								Name:       "test-v2",
								Expression: "object.apiVersion == 'awesome.example.com/v2'",
							},
						},
					},
					{
						Name: "admission.integration.test",
						Rules: []admissionregistrationv1.RuleWithOperations{{
							Operations: []admissionregistrationv1.OperationType{admissionregistrationv1.Create},
							Rule: admissionregistrationv1.Rule{
								APIGroups:   []string{"awesome.example.com"},
								APIVersions: []string{"v1"},
								Resources:   []string{"*/*"},
							},
						}},
						MatchPolicy: &equiv,
						ClientConfig: admissionregistrationv1.WebhookClientConfig{
							URL:      &v1Endpoint,
							CABundle: localhostCert,
						},
						SideEffects:             &noSideEffects,
						AdmissionReviewVersions: []string{"v1"},
						MatchConditions: []admissionregistrationv1.MatchCondition{
							{
								Name:       "test-v1",
								Expression: "object.apiVersion == 'awesome.example.com/v1'",
							},
						},
					},
					{
						Name: "admission.integration.test.marker",
						Rules: []admissionregistrationv1.RuleWithOperations{{
							Operations: []admissionregistrationv1.OperationType{admissionregistrationv1.OperationAll},
							Rule:       admissionregistrationv1.Rule{APIGroups: []string{""}, APIVersions: []string{"v1"}, Resources: []string{"pods"}},
						}},
						ClientConfig: admissionregistrationv1.WebhookClientConfig{
							URL:      &markerEndpoint,
							CABundle: localhostCert,
						},
						NamespaceSelector: &metav1.LabelSelector{
							MatchLabels: map[string]string{
								corev1.LabelMetadataName: "marker",
							},
						},
						ObjectSelector: &metav1.LabelSelector{
							MatchLabels: map[string]string{"marker": "true"},
						},
						SideEffects:             &noSideEffects,
						AdmissionReviewVersions: []string{"v1"},
					},
				},
			},
		},
	}, nil
}

func getHardCodedConfigInfoMarkerPod() (ctestglobals.HardcodedConfig, error) {
	return ctestglobals.HardcodedConfig{
		{
			FixtureFileName: "test_fixture.json",
			TestInfo:        []string{"marker pod"},
			Field:           "spec",
			K8sObjects:      []string{"pods"},
			HardcodedConfig: &corev1.Pod{
				ObjectMeta: metav1.ObjectMeta{
					Name: "marker",
					Labels: map[string]string{
						"marker": "true",
					},
				},
				Spec: corev1.PodSpec{
					Containers: []corev1.Container{
						{
							Name:  "fake-name",
							Image: "fakeimage",
						},
					},
				},
			},
		},
	}, nil
}
