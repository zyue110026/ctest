package admissionwebhook

import (
	"bytes"
	"context"
	"crypto/tls"
	"crypto/x509"
	// "encoding/json"
	"fmt"
	// "io"
	// "net/http"
	"net/http/httptest"
	"strings"
	"testing"
	"time"

	// v1 "k8s.io/api/admission/v1"
	admissionv1 "k8s.io/api/admissionregistration/v1"
	corev1 "k8s.io/api/core/v1"
	metav1 "k8s.io/apimachinery/pkg/apis/meta/v1"
	"k8s.io/apimachinery/pkg/types"
	"k8s.io/apimachinery/pkg/util/uuid"
	"k8s.io/apimachinery/pkg/util/wait"
	"k8s.io/apiserver/pkg/endpoints/handlers"
	clientset "k8s.io/client-go/kubernetes"
	restclient "k8s.io/client-go/rest"
	kubeapiservertesting "k8s.io/kubernetes/cmd/kube-apiserver/app/testing"
	"k8s.io/kubernetes/test/integration/framework"

	ctest "k8s.io/kubernetes/test/ctest"
	ctestglobals "k8s.io/kubernetes/test/ctest/ctestglobals"
	ctestutils "k8s.io/kubernetes/test/ctest/utils"
)

func TestCtestMutatingWebhookDuplicateOwnerReferences(t *testing.T) {
	roots := x509.NewCertPool()
	if !roots.AppendCertsFromPEM(localhostCert) {
		t.Fatal("Failed to append Cert from PEM")
	}
	cert, err := tls.X509KeyPair(localhostCert, localhostKey)
	if err != nil {
		t.Fatalf("Failed to build cert with error: %+v", err)
	}
	webhookServer := httptest.NewUnstartedServer(newDuplicateOwnerReferencesWebhookHandler(t))
	webhookServer.TLS = &tls.Config{
		RootCAs:      roots,
		Certificates: []tls.Certificate{cert},
	}
	webhookServer.StartTLS()
	defer webhookServer.Close()

	s := kubeapiservertesting.StartTestServerOrDie(t,
		kubeapiservertesting.NewDefaultTestServerOptions(), []string{
			"--disable-admission-plugins=ServiceAccount",
		}, framework.SharedEtcd())
	defer s.TearDownFn()

	b := &bytes.Buffer{}
	warningWriter := restclient.NewWarningWriter(b, restclient.WarningWriterOptions{})
	s.ClientConfig.WarningHandler = warningWriter
	client := clientset.NewForConfigOrDie(s.ClientConfig)

	// Create MutatingWebhookConfiguration
	fail := admissionv1.Fail
	none := admissionv1.SideEffectClassNone
	mutatingCfg, err := client.AdmissionregistrationV1().MutatingWebhookConfigurations().Create(context.TODO(), &admissionv1.MutatingWebhookConfiguration{
		ObjectMeta: metav1.ObjectMeta{Name: "dup-owner-references.admission.integration.test"},
		Webhooks: []admissionv1.MutatingWebhook{{
			Name: "dup-owner-references.admission.integration.test",
			ClientConfig: admissionv1.WebhookClientConfig{
				URL:      &webhookServer.URL,
				CABundle: localhostCert,
			},
			Rules: []admissionv1.RuleWithOperations{{
				Operations: []admissionv1.OperationType{admissionv1.Create, admissionv1.Update},
				Rule:       admissionv1.Rule{APIGroups: []string{""}, APIVersions: []string{"v1"}, Resources: []string{"pods"}},
			}},
			FailurePolicy:           &fail,
			AdmissionReviewVersions: []string{"v1", "v1beta1"},
			SideEffects:             &none,
		}},
	}, metav1.CreateOptions{})
	if err != nil {
		t.Fatal(err)
	}
	defer func() {
		_ = client.AdmissionregistrationV1().MutatingWebhookConfigurations().Delete(context.TODO(), mutatingCfg.GetName(), metav1.DeleteOptions{})
	}()

	// Edge test cases
	edgeCases := []struct {
		name               string
		ownerRefs          []metav1.OwnerReference
		expectWarningCount int
	}{
		{
			name: "pod has existing owner reference (duplicate expected)",
			ownerRefs: []metav1.OwnerReference{{
				APIVersion: "v1",
				Kind:       "Node",
				Name:       "fake-node",
				UID:        uuid.NewUUID(),
			}},
			expectWarningCount: 1,
		},
		{
			name:               "pod has no owner references (no duplicate)",
			ownerRefs:          nil,
			expectWarningCount: 0,
		},
		{
			name: "pod has duplicate owner references (no additional warning)",
			ownerRefs: []metav1.OwnerReference{
				{
					APIVersion: "v1",
					Kind:       "Node",
					Name:       "fake-node",
					UID:        uuid.NewUUID(),
				},
				{
					APIVersion: "v1",
					Kind:       "Node",
					Name:       "fake-node",
					UID:        uuid.NewUUID(),
				},
			},
			expectWarningCount: 0,
		},
		{
			name: "owner reference with empty UID (no duplicate warning)",
			ownerRefs: []metav1.OwnerReference{{
				APIVersion: "v1",
				Kind:       "Node",
				Name:       "fake-node",
				UID:        "",
			}},
			expectWarningCount: 0,
		},
	}

	fmt.Println(ctestglobals.StartExtendModeSeparator)
	for i, tc := range edgeCases {
		fmt.Printf("Running edge case %d: %s\n", i, tc.name)

		// Load base fixture and extend it
		hardcoded := getHardCodedConfigInfoDuplicateOwnerReferences()
		item, found := ctestutils.GetItemByExactTestInfo(hardcoded, "duplicate-owner-references-marker")
		if !found {
			t.Fatalf("Hardcoded config not found for edge case")
		}
		fmt.Println(ctestglobals.DebugPrefix(), "matched config:", item)
		configObjs, configJson, err := ctest.GenerateEffectiveConfigReturnType[corev1.Pod](item, ctest.ExtendOnly)
		if err != nil {
			t.Fatalf("GenerateEffectiveConfigReturnType failed: %v", err)
		}
		if configObjs == nil || len(configObjs) == 0 {
			fmt.Println(ctestglobals.DebugPrefix(), "Skipping test execution. No new configurations generated.")
			continue
		}
		fmt.Println(ctestglobals.DebugPrefix(), "New Json Test Configs:", string(configJson))
		fmt.Println(ctestglobals.DebugPrefix(), "Number of test cases:", len(configObjs))

		for _, basePod := range configObjs {
			// customize per edge case
			basePod.ObjectMeta.Name = "dup-owner-" + string(uuid.NewUUID())
			basePod.ObjectMeta.Namespace = "default"
			basePod.ObjectMeta.OwnerReferences = tc.ownerRefs
			// ensure container exists
			if len(basePod.Spec.Containers) == 0 {
				basePod.Spec.Containers = []corev1.Container{{Name: "c", Image: "busybox"}}
			}

			// Create marker pod
			_, err := client.CoreV1().Pods("default").Create(context.TODO(), &basePod, metav1.CreateOptions{})
			if err != nil {
				t.Fatalf("Failed to create marker pod: %v", err)
			}

			// Expect warning format (only when ownerRefs non‑empty)
			var expectedWarning string
			if len(tc.ownerRefs) > 0 {
				expectedWarning = fmt.Sprintf(handlers.DuplicateOwnerReferencesAfterMutatingAdmissionWarningFormat,
					tc.ownerRefs[0].UID)
			}

			// Patch request to trigger webhook
			var pod *corev1.Pod
			var lastErr string
			if err := wait.PollImmediate(time.Millisecond*5, wait.ForeverTestTimeout, func() (bool, error) {
				pod, err = client.CoreV1().Pods("default").Patch(context.TODO(),
					basePod.Name, types.JSONPatchType, []byte("[]"), metav1.PatchOptions{})
				if err != nil {
					return false, err
				}
				if warningWriter.WarningCount() < tc.expectWarningCount {
					lastErr = fmt.Sprintf("expected %d warnings, got %d", tc.expectWarningCount, warningWriter.WarningCount())
					return false, nil
				}
				if expectedWarning != "" && !strings.Contains(b.String(), expectedWarning) {
					lastErr = fmt.Sprintf("expected warning %q not found in %q", expectedWarning, b.String())
					return false, nil
				}
				if expectedWarning != "" && len(pod.OwnerReferences) != 1 {
					lastErr = fmt.Sprintf("expected single owner reference after dedup, got %v", pod.OwnerReferences)
					return false, nil
				}
				return true, nil
			}); err != nil {
				t.Fatalf("edge case %q failed: %v, last error: %v", tc.name, err, lastErr)
			}
			b.Reset()
			// warningWriter.Reset()

			// Cleanup marker pod
			_ = client.CoreV1().Pods("default").Delete(context.TODO(), basePod.Name, metav1.DeleteOptions{})
		}
	}
	fmt.Println(ctestglobals.EndSeparator)
}

// getHardCodedConfigInfoDuplicateOwnerReferences returns the minimal fixture used for the test.
func getHardCodedConfigInfoDuplicateOwnerReferences() ctestglobals.HardcodedConfig {
	return ctestglobals.HardcodedConfig{
		{
			FixtureFileName: "test_fixture.json",
			TestInfo:        []string{"duplicate-owner-references-marker"},
			Field:           "ownerReferences",
			K8sObjects:      []string{"pods"},
			HardcodedConfig: corev1.Pod{
				ObjectMeta: metav1.ObjectMeta{
					Name:      "duplicate-owner-references-test-marker",
					Namespace: "default",
					OwnerReferences: []metav1.OwnerReference{{
						APIVersion: "v1",
						Kind:       "Node",
						Name:       "fake-node",
						UID:        uuid.NewUUID(),
					}},
				},
				Spec: corev1.PodSpec{
					Containers: []corev1.Container{{Name: "fake-name", Image: "fakeimage"}},
				},
			},
		},
	}
}
