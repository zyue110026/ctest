package admissionwebhook

import (
	"context"
	"fmt"
	"testing"
	"time"

	admissionregistrationv1 "k8s.io/api/admissionregistration/v1"
	appsv1 "k8s.io/api/apps/v1"
	corev1 "k8s.io/api/core/v1"
	metav1 "k8s.io/apimachinery/pkg/apis/meta/v1"
	"k8s.io/apimachinery/pkg/util/uuid"
	"k8s.io/client-go/kubernetes"
	kubeapiservertesting "k8s.io/kubernetes/cmd/kube-apiserver/app/testing"
	"k8s.io/kubernetes/test/integration/framework"

	ctest "k8s.io/kubernetes/test/ctest"
	ctestglobals "k8s.io/kubernetes/test/ctest/ctestglobals"
	ctestutils "k8s.io/kubernetes/test/ctest/utils"
)

func TestCtestBrokenWebhook(t *testing.T) {
	var tearDownFn kubeapiservertesting.TearDownFunc
	defer func() {
		if tearDownFn != nil {
			tearDownFn()
		}
	}()

	etcdConfig := framework.SharedEtcd()
	server := kubeapiservertesting.StartTestServerOrDie(t, nil, framework.DefaultTestServerFlags(), etcdConfig)
	tearDownFn = server.TearDownFn

	client, err := kubernetes.NewForConfig(server.ClientConfig)
	if err != nil {
		t.Fatalf("unexpected error: %v", err)
	}

	// ------------------------------------------------------------
	// 1. Verify apiserver works before webhook registration
	// ------------------------------------------------------------
	fmt.Println(ctestglobals.StartExtendModeSeparator)
	fmt.Println(ctestglobals.DebugPrefix(), "Generating base deployment config")
	deployItem, found := ctestutils.GetItemByExactTestInfo(getHardCodedConfigInfoDeployment(), "default deployment")
	if !found {
		t.Fatalf("hardcoded deployment config not found")
	}
	baseDeployObjs, deployJson, err := ctest.GenerateEffectiveConfigReturnType[appsv1.Deployment](deployItem, ctest.ExtendOnly)
	if err != nil {
		t.Fatalf("failed to generate deployment config: %v", err)
	}
	fmt.Println(ctestglobals.DebugPrefix(), "New Json Test Configs:", string(deployJson))
	fmt.Println(ctestglobals.DebugPrefix(), "Number of deployment test cases:", len(baseDeployObjs))

	if len(baseDeployObjs) == 0 {
		t.Fatalf("no deployment configs generated")
	}
	// use first generated deployment as sanity check
	sanityDep := baseDeployObjs[0]
	sanityDep.ObjectMeta.Name = fmt.Sprintf("%s-%s", deploymentNamePrefix, string(uuid.NewUUID()))
	sanityDep.ObjectMeta.Namespace = "default"

	_, err = client.AppsV1().Deployments("default").Create(context.TODO(), &sanityDep, metav1.CreateOptions{})
	if err != nil {
		t.Fatalf("Failed to create deployment before webhook: %v", err)
	}
	// ------------------------------------------------------------
	// 2. Create the broken webhook
	// ------------------------------------------------------------
	fmt.Println(ctestglobals.StartOverrideModeSeparator)
	fmt.Println(ctestglobals.DebugPrefix(), "Generating broken webhook config")
	webhookItem, found := ctestutils.GetItemByExactTestInfo(getHardCodedConfigInfoBrokenWebhook(), "default broken webhook")
	if !found {
		t.Fatalf("hardcoded webhook config not found")
	}
	webhookObjs, webhookJson, err := ctest.GenerateEffectiveConfigReturnType[admissionregistrationv1.ValidatingWebhookConfiguration](webhookItem, ctest.OverrideOnly)
	if err != nil {
		t.Fatalf("failed to generate webhook config: %v", err)
	}
	fmt.Println(ctestglobals.DebugPrefix(), "New Json Webhook Configs:", string(webhookJson))
	fmt.Println(ctestglobals.DebugPrefix(), "Number of webhook configs:", len(webhookObjs))
	if len(webhookObjs) == 0 {
		t.Fatalf("no webhook configs generated")
	}
	brokenWebhook := webhookObjs[0]
	_, err = client.AdmissionregistrationV1().ValidatingWebhookConfigurations().Create(context.TODO(), &brokenWebhook, metav1.CreateOptions{})
	if err != nil {
		t.Fatalf("Failed to register broken webhook: %v", err)
	}
	time.Sleep(10 * time.Second)

	// ------------------------------------------------------------
	// 3. Attempt to create deployments that should be blocked
	// ------------------------------------------------------------
	edgeDeployments := []appsv1.Deployment{}

	// base configs
	for _, d := range baseDeployObjs {
		edgeDeployments = append(edgeDeployments, d)
	}
	// edge case: zero replicas
	zeroReplicas := baseDeployObjs[0]
	zero := int32(0)
	zeroReplicas.Spec.Replicas = &zero
	edgeDeployments = append(edgeDeployments, zeroReplicas)

	// edge case: different container image
	altImage := baseDeployObjs[0]
	altImage.Spec.Template.Spec.Containers[0].Image = "busybox"
	edgeDeployments = append(edgeDeployments, altImage)

	// edge case: missing labels (still valid)
	missingLabels := baseDeployObjs[0]
	missingLabels.Spec.Selector = &metav1.LabelSelector{}
	missingLabels.Spec.Template.ObjectMeta.Labels = map[string]string{}
	edgeDeployments = append(edgeDeployments, missingLabels)

	for i, dep := range edgeDeployments {
		fmt.Printf("Running deployment edge case #%d\n", i)
		depCopy := dep
		depCopy.ObjectMeta.Name = fmt.Sprintf("%s-%s-%d", deploymentNamePrefix, string(uuid.NewUUID()), i)
		depCopy.ObjectMeta.Namespace = "default"
		_, err = client.AppsV1().Deployments("default").Create(context.TODO(), &depCopy, metav1.CreateOptions{})
		if err == nil {
			t.Fatalf("Expected broken webhook to block deployment creation (case %d), but succeeded", i)
		}
	}

	// ------------------------------------------------------------
	// 4. Restart apiserver and verify blockage persists
	// ------------------------------------------------------------
	fmt.Println(ctestglobals.DebugPrefix(), "Restarting apiserver")
	tearDownFn = nil
	server.TearDownFn()
	server = kubeapiservertesting.StartTestServerOrDie(t, nil, framework.DefaultTestServerFlags(), etcdConfig)
	tearDownFn = server.TearDownFn

	client, err = kubernetes.NewForConfig(server.ClientConfig)
	if err != nil {
		t.Fatalf("unexpected error after restart: %v", err)
	}

	// re-use one edge deployment after restart
	retryDep := edgeDeployments[0]
	retryDep.ObjectMeta.Name = fmt.Sprintf("%s-retry-%s", deploymentNamePrefix, string(uuid.NewUUID()))
	retryDep.ObjectMeta.Namespace = "default"
	_, err = client.AppsV1().Deployments("default").Create(context.TODO(), &retryDep, metav1.CreateOptions{})
	if err == nil {
		t.Fatalf("Expected broken webhook to block deployment after restart, but succeeded")
	}

	// ------------------------------------------------------------
	// 5. Delete webhook and verify deployments succeed
	// ------------------------------------------------------------
	fmt.Println(ctestglobals.DebugPrefix(), "Deleting broken webhook")
	err = client.AdmissionregistrationV1().ValidatingWebhookConfigurations().Delete(context.TODO(), brokenWebhookName, metav1.DeleteOptions{})
	if err != nil {
		t.Fatalf("Failed to delete broken webhook: %v", err)
	}
	time.Sleep(10 * time.Second)

	// create deployment post‑deletion (should succeed)
	finalDep := baseDeployObjs[0]
	finalDep.ObjectMeta.Name = fmt.Sprintf("%s-final-%s", deploymentNamePrefix, string(uuid.NewUUID()))
	finalDep.ObjectMeta.Namespace = "default"
	_, err = client.AppsV1().Deployments("default").Create(context.TODO(), &finalDep, metav1.CreateOptions{})
	if err != nil {
		t.Fatalf("Failed to create deployment after webhook deletion: %v", err)
	}
}

// ---------------------------------------------------------------------------
// Hardcoded configuration for base Deployment
// ---------------------------------------------------------------------------
func getHardCodedConfigInfoDeployment() ctestglobals.HardcodedConfig {
	return ctestglobals.HardcodedConfig{
		{
			FixtureFileName: "test_fixture.json",
			TestInfo:        []string{"default deployment"},
			Field:           "spec",
			K8sObjects:      []string{"deployments", "statefulsets", "daemonsets", "replicasets", "pods"},
			HardcodedConfig: appsv1.Deployment{
				TypeMeta: metav1.TypeMeta{
					Kind:       "Deployment",
					APIVersion: "apps/v1",
				},
				ObjectMeta: metav1.ObjectMeta{
					Namespace: "default",
				},
				Spec: appsv1.DeploymentSpec{
					Replicas: func() *int32 { i := int32(1); return &i }(),
					Selector: &metav1.LabelSelector{
						MatchLabels: map[string]string{"foo": "bar"},
					},
					Template: corev1.PodTemplateSpec{
						ObjectMeta: metav1.ObjectMeta{
							Labels: map[string]string{"foo": "bar"},
						},
						Spec: corev1.PodSpec{
							Containers: []corev1.Container{
								{
									Name:  "foo",
									Image: "foo",
								},
							},
						},
					},
				},
			},
		},
	}
}

// ---------------------------------------------------------------------------
// Hardcoded configuration for the broken webhook
// ---------------------------------------------------------------------------
func getHardCodedConfigInfoBrokenWebhook() ctestglobals.HardcodedConfig {
	return ctestglobals.HardcodedConfig{
		{
			FixtureFileName: "test_fixture.json",
			TestInfo:        []string{"default broken webhook"},
			Field:           "webhooks",
			K8sObjects:      []string{"validatingwebhookconfigurations"},
			HardcodedConfig: admissionregistrationv1.ValidatingWebhookConfiguration{
				ObjectMeta: metav1.ObjectMeta{
					Name: brokenWebhookName,
				},
				Webhooks: []admissionregistrationv1.ValidatingWebhook{
					{
						Name: "broken-webhook.k8s.io",
						Rules: []admissionregistrationv1.RuleWithOperations{{
							Operations: []admissionregistrationv1.OperationType{admissionregistrationv1.OperationAll},
							Rule: admissionregistrationv1.Rule{
								APIGroups:   []string{"*"},
								APIVersions: []string{"*"},
								Resources:   []string{"*/*"},
							},
						}},
						ClientConfig: admissionregistrationv1.WebhookClientConfig{
							Service: &admissionregistrationv1.ServiceReference{
								Namespace: "default",
								Name:      "invalid-webhook-service",
								Path:      func() *string { p := ""; return &p }(),
							},
							CABundle: nil,
						},
						FailurePolicy: func() *admissionregistrationv1.FailurePolicyType { p := admissionregistrationv1.Fail; return &p }(),
						SideEffects: func() *admissionregistrationv1.SideEffectClass {
							p := admissionregistrationv1.SideEffectClassNone
							return &p
						}(),
						AdmissionReviewVersions: []string{"v1"},
					},
				},
			},
		},
	}
}
