package admissionwebhook

import (
	"context"
	"crypto/tls"
	"crypto/x509"
	// "encoding/json"
	"fmt"
	// "io"
	"net"
	"net/http"
	// "net/url"
	"sync"
	"sync/atomic"
	"testing"
	"time"

	// "k8s.io/api/admission/v1beta1"
	admissionregistrationv1 "k8s.io/api/admissionregistration/v1"
	corev1 "k8s.io/api/core/v1"
	metav1 "k8s.io/apimachinery/pkg/apis/meta/v1"
	"k8s.io/apimachinery/pkg/types"
	"k8s.io/apimachinery/pkg/util/wait"
	"k8s.io/client-go/kubernetes"
	"k8s.io/client-go/rest"
	"k8s.io/kubernetes/cmd/kube-apiserver/app"
	kubeapiservertesting "k8s.io/kubernetes/cmd/kube-apiserver/app/testing"
	"k8s.io/kubernetes/test/integration/framework"

	// "k8s.io/apimachinery/pkg/util/uuid"
	ctest "k8s.io/kubernetes/test/ctest"
	ctestglobals "k8s.io/kubernetes/test/ctest/ctestglobals"
	ctestutils "k8s.io/kubernetes/test/ctest/utils"
)

// TestCtestWebhookLoadBalance ensures that the admission webhook opens multiple connections to backends to satisfy concurrent requests
func TestCtestWebhookLoadBalance(t *testing.T) {
	fmt.Println(ctestglobals.StartSeparator)
	roots := x509.NewCertPool()
	if !roots.AppendCertsFromPEM(localhostCert) {
		t.Fatal("Failed to append Cert from PEM")
	}
	cert, err := tls.X509KeyPair(localhostCert, localhostKey)
	if err != nil {
		t.Fatalf("Failed to build cert with error: %+v", err)
	}

	// original test cases + an edge case (lower bound for http1)
	tests := []struct {
		name     string
		http2    bool
		expected int64
	}{
		{
			name:     "10 connections when using http1",
			http2:    false,
			expected: 10,
		},
		{
			name:     "1 connections when using http2",
			http2:    true,
			expected: 1,
		},
		{
			name:     "1 connection when using http1 (edge lower bound)",
			http2:    false,
			expected: 1,
		},
	}

	for _, tc := range tests {
		t.Run(tc.name, func(t *testing.T) {
			// ---- setup server and webhook ----
			localListener, err := net.Listen("tcp", "127.0.0.1:0")
			if err != nil {
				if localListener, err = net.Listen("tcp6", "[::1]:0"); err != nil {
					t.Fatal(err)
				}
			}
			trackingListener := &connectionTrackingListener{delegate: localListener}

			recorder := &connectionRecorder{}
			handler := newLoadBalanceWebhookHandler(recorder)
			httpServer := &http.Server{
				Handler: handler,
				TLSConfig: &tls.Config{
					RootCAs:      roots,
					Certificates: []tls.Certificate{cert},
				},
			}
			go func() {
				_ = httpServer.ServeTLS(trackingListener, "", "")
			}()
			defer func() { _ = httpServer.Close() }()

			webhookURL := "https://" + localListener.Addr().String()
			t.Cleanup(app.SetServiceResolverForTests(staticURLServiceResolver(webhookURL)))

			s := kubeapiservertesting.StartTestServerOrDie(t, kubeapiservertesting.NewDefaultTestServerOptions(), []string{
				"--disable-admission-plugins=ServiceAccount",
			}, framework.SharedEtcd())
			defer s.TearDownFn()

			// client config
			clientConfig := rest.CopyConfig(s.ClientConfig)
			clientConfig.QPS = 100
			clientConfig.Burst = 200
			clientConfig.Impersonate.UserName = testLoadBalanceClientUsername
			clientConfig.Impersonate.Groups = []string{"system:masters", "system:authenticated"}
			client, err := kubernetes.NewForConfig(clientConfig)
			if err != nil {
				t.Fatalf("unexpected error: %v", err)
			}

			// ---- create marker pod using dynamic config ----
			markerSpec, err := getPodSpecFromFixture("marker pod")
			if err != nil {
				t.Fatalf("failed to get marker pod spec: %v", err)
			}
			markerPod := &corev1.Pod{
				ObjectMeta: metav1.ObjectMeta{
					Namespace: "default",
					Name:      "marker",
				},
				Spec: *markerSpec,
			}
			_, err = client.CoreV1().Pods("default").Create(context.TODO(), markerPod, metav1.CreateOptions{})
			if err != nil {
				t.Fatal(err)
			}

			upCh := recorder.Reset()
			ns := "load-balance"
			_, err = client.CoreV1().Namespaces().Create(context.TODO(), &corev1.Namespace{ObjectMeta: metav1.ObjectMeta{Name: ns}}, metav1.CreateOptions{})
			if err != nil {
				t.Fatal(err)
			}

			// ---- webhook configuration ----
			webhooksClientConfig := admissionregistrationv1.WebhookClientConfig{
				CABundle: localhostCert,
			}
			if tc.http2 {
				webhooksClientConfig.URL = &webhookURL
			} else {
				webhooksClientConfig.Service = &admissionregistrationv1.ServiceReference{
					Namespace: "test",
					Name:      "webhook",
				}
			}
			fail := admissionregistrationv1.Fail
			mutatingCfg, err := client.AdmissionregistrationV1().MutatingWebhookConfigurations().Create(context.TODO(), &admissionregistrationv1.MutatingWebhookConfiguration{
				ObjectMeta: metav1.ObjectMeta{Name: "admission.integration.test"},
				Webhooks: []admissionregistrationv1.MutatingWebhook{{
					Name:         "admission.integration.test",
					ClientConfig: webhooksClientConfig,
					Rules: []admissionregistrationv1.RuleWithOperations{{
						Operations: []admissionregistrationv1.OperationType{admissionregistrationv1.OperationAll},
						Rule:       admissionregistrationv1.Rule{APIGroups: []string{""}, APIVersions: []string{"v1"}, Resources: []string{"pods"}},
					}},
					FailurePolicy:           &fail,
					AdmissionReviewVersions: []string{"v1beta1"},
					SideEffects:             &noSideEffects,
				}},
			}, metav1.CreateOptions{})
			if err != nil {
				t.Fatal(err)
			}
			defer func() {
				_ = client.AdmissionregistrationV1().MutatingWebhookConfigurations().Delete(context.TODO(), mutatingCfg.GetName(), metav1.DeleteOptions{})
			}()

			// wait for webhook to become effective
			if err := wait.PollUntilContextTimeout(context.TODO(), time.Millisecond*5, wait.ForeverTestTimeout, true, func(ctx context.Context) (bool, error) {
				_, err = client.CoreV1().Pods("default").Patch(ctx, markerPod.Name, types.JSONPatchType, []byte("[]"), metav1.PatchOptions{})
				select {
				case <-upCh:
					return true, nil
				default:
					t.Logf("Waiting for webhook to become effective, getting marker object: %v", err)
					return false, nil
				}
			}); err != nil {
				t.Fatal(err)
			}

			// ---- pod creation used for load test (dynamic config) ----
			testPodSpec, err := getPodSpecFromFixture("test pod")
			if err != nil {
				t.Fatalf("failed to get test pod spec: %v", err)
			}
			podFactory := func() *corev1.Pod {
				return &corev1.Pod{
					ObjectMeta: metav1.ObjectMeta{
						Namespace:    ns,
						GenerateName: "loadbalance-",
					},
					Spec: *testPodSpec,
				}
			}

			// Submit 10 parallel requests
			wg := &sync.WaitGroup{}
			for j := 0; j < 10; j++ {
				wg.Add(1)
				go func() {
					defer wg.Done()
					if _, err := client.CoreV1().Pods(ns).Create(context.TODO(), podFactory(), metav1.CreateOptions{}); err != nil {
						t.Error(err)
					}
				}()
			}
			wg.Wait()

			actual := atomic.LoadInt64(&trackingListener.connections)
			if tc.http2 && actual != tc.expected {
				t.Errorf("expected %d connections, got %d", tc.expected, actual)
			}
			if !tc.http2 && actual < tc.expected {
				t.Errorf("expected at least %d connections, got %d", tc.expected, actual)
			}
			trackingListener.Reset()

			// Submit 10 more parallel requests (should reuse connections)
			wg = &sync.WaitGroup{}
			for j := 0; j < 10; j++ {
				wg.Add(1)
				go func() {
					defer wg.Done()
					if _, err := client.CoreV1().Pods(ns).Create(context.TODO(), podFactory(), metav1.CreateOptions{}); err != nil {
						t.Error(err)
					}
				}()
			}
			wg.Wait()

			if a := atomic.LoadInt64(&trackingListener.connections); a > 0 {
				t.Errorf("expected no additional connections (reusing kept-alive connections), got %d", a)
			}
		})
	}
	fmt.Println(ctestglobals.EndSeparator)
}

// ----- dynamic configuration helpers -----

func getHardCodedConfigInfoLoadBalance() ctestglobals.HardcodedConfig {
	return ctestglobals.HardcodedConfig{
		{
			FixtureFileName: "test_fixture.json",
			TestInfo:        []string{"marker pod"},
			Field:           "spec",
			K8sObjects:      []string{"pods"},
			HardcodedConfig: corev1.PodSpec{
				Containers: []corev1.Container{{
					Name:  "fake-name",
					Image: "fakeimage",
				}},
			},
		},
		{
			FixtureFileName: "test_fixture.json",
			TestInfo:        []string{"test pod"},
			Field:           "spec",
			K8sObjects:      []string{"pods"},
			HardcodedConfig: corev1.PodSpec{
				Containers: []corev1.Container{{
					Name:  "fake-name",
					Image: "fakeimage",
				}},
			},
		},
	}
}

// getPodSpecFromFixture returns a PodSpec generated from the hardcoded config using ExtendOnly mode.
func getPodSpecFromFixture(testInfo string) (*corev1.PodSpec, error) {
	hc := getHardCodedConfigInfoLoadBalance()
	item, found := ctestutils.GetItemByExactTestInfo(hc, testInfo)
	if !found {
		return nil, fmt.Errorf("hardcoded config for %s not found", testInfo)
	}
	objs, cfgJSON, err := ctest.GenerateEffectiveConfigReturnType[corev1.PodSpec](item, ctest.ExtendOnly)
	if err != nil {
		return nil, fmt.Errorf("failed to generate config for %s: %w, json: %s", testInfo, err, string(cfgJSON))
	}
	if len(objs) == 0 {
		return nil, fmt.Errorf("no config objects generated for %s", testInfo)
	}
	return &objs[0], nil
}
