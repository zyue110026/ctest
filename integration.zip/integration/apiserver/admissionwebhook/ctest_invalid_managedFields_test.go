package admissionwebhook

import (
	"bytes"
	"context"
	"crypto/tls"
	"crypto/x509"
	// "encoding/json"
	"fmt"
	// "io"
	// "net/http"
	"net/http/httptest"
	"strings"
	"testing"
	"time"

	admissionv1 "k8s.io/api/admissionregistration/v1"
	corev1 "k8s.io/api/core/v1"
	metav1 "k8s.io/apimachinery/pkg/apis/meta/v1"
	"k8s.io/apimachinery/pkg/types"
	"k8s.io/apimachinery/pkg/util/uuid"
	"k8s.io/apimachinery/pkg/util/wait"
	"k8s.io/apiserver/pkg/endpoints/handlers/fieldmanager"
	"k8s.io/client-go/kubernetes"
	"k8s.io/client-go/rest"
	kubeapiservertesting "k8s.io/kubernetes/cmd/kube-apiserver/app/testing"
	"k8s.io/kubernetes/test/ctest"
	ctestglobals "k8s.io/kubernetes/test/ctest/ctestglobals"
	ctestutils "k8s.io/kubernetes/test/ctest/utils"
	"k8s.io/kubernetes/test/integration/framework"
)

func TestCtestMutatingWebhookResetsInvalidManagedFields(t *testing.T) {
	// Setup TLS certs
	roots := x509.NewCertPool()
	if !roots.AppendCertsFromPEM(localhostCert) {
		t.Fatal("Failed to append Cert from PEM")
	}
	cert, err := tls.X509KeyPair(localhostCert, localhostKey)
	if err != nil {
		t.Fatalf("Failed to build cert with error: %+v", err)
	}

	// Start webhook server
	webhookServer := httptest.NewUnstartedServer(newInvalidManagedFieldsWebhookHandler(t))
	webhookServer.TLS = &tls.Config{
		RootCAs:      roots,
		Certificates: []tls.Certificate{cert},
	}
	webhookServer.StartTLS()
	defer webhookServer.Close()

	// Start API server
	s := kubeapiservertesting.StartTestServerOrDie(t,
		kubeapiservertesting.NewDefaultTestServerOptions(), []string{
			"--disable-admission-plugins=ServiceAccount",
		}, framework.SharedEtcd())
	defer s.TearDownFn()

	// Capture warnings
	recordedWarnings := &bytes.Buffer{}
	warningWriter := rest.NewWarningWriter(recordedWarnings, rest.WarningWriterOptions{})
	s.ClientConfig.WarningHandler = warningWriter
	client := kubernetes.NewForConfigOrDie(s.ClientConfig)

	// Create MutatingWebhookConfiguration
	fail := admissionv1.Fail
	none := admissionv1.SideEffectClassNone
	mutatingCfg, err := client.AdmissionregistrationV1().MutatingWebhookConfigurations().Create(context.TODO(), &admissionv1.MutatingWebhookConfiguration{
		ObjectMeta: metav1.ObjectMeta{Name: "invalid-managedfields.admission.integration.test"},
		Webhooks: []admissionv1.MutatingWebhook{{
			Name: "invalid-managedfields.admission.integration.test",
			ClientConfig: admissionv1.WebhookClientConfig{
				URL:      &webhookServer.URL,
				CABundle: localhostCert,
			},
			Rules: []admissionv1.RuleWithOperations{{
				Operations: []admissionv1.OperationType{admissionv1.Create, admissionv1.Update},
				Rule:       admissionv1.Rule{APIGroups: []string{""}, APIVersions: []string{"v1"}, Resources: []string{"pods"}},
			}},
			FailurePolicy:           &fail,
			AdmissionReviewVersions: []string{"v1", "v1beta1"},
			SideEffects:             &none,
		}},
	}, metav1.CreateOptions{})
	if err != nil {
		t.Fatal(err)
	}
	defer func() {
		if err := client.AdmissionregistrationV1().MutatingWebhookConfigurations().Delete(context.TODO(), mutatingCfg.GetName(), metav1.DeleteOptions{}); err != nil {
			t.Fatal(err)
		}
	}()

	// Load hardcoded pod spec configurations
	fmt.Println(ctestglobals.StartSeparator)
	configs := getHardCodedConfigInfoInvalidManagedFields()
	item, found := ctestutils.GetItemByExactTestInfo(configs, "default pod marker")
	if !found {
		t.Fatalf("hardcoded config not found")
	}
	fmt.Println(ctestglobals.DebugPrefix(), "get default configs:", item)
	fmt.Println(ctestglobals.StartExtendModeSeparator)
	configObjs, configJson, err := ctest.GenerateEffectiveConfigReturnType[corev1.PodSpec](item, ctest.ExtendOnly)
	if err != nil {
		t.Fatalf("GenerateEffectiveConfigReturnType error: %v", err)
	}
	if configObjs == nil {
		fmt.Println(ctestglobals.DebugPrefix(), "Skipping test execution. No new config objs found.")
		return
	}
	fmt.Println(ctestglobals.DebugPrefix(), "New Json Test Configs:", string(configJson))
	fmt.Println(ctestglobals.DebugPrefix(), "Number of Test Cases:", len(configObjs))

	for i, podSpec := range configObjs {
		fmt.Printf("Running %d th test case.\n", i)
		fmt.Println(podSpec)

		// Ensure a unique pod name each iteration
		markerName := "invalid-managedfields-test-marker-" + string(uuid.NewUUID())
		podSpec.Containers[0].Name = "fake-name-" + string(uuid.NewUUID())
		pod := &corev1.Pod{
			ObjectMeta: metav1.ObjectMeta{
				Namespace: "default",
				Name:      markerName,
			},
			Spec: podSpec,
		}

		// Create the marker pod
		if _, err := client.CoreV1().Pods("default").Create(context.TODO(), pod, metav1.CreateOptions{}); err != nil {
			t.Fatalf("failed to create marker pod: %v", err)
		}
		// Ensure deletion after test
		defer func(name string) {
			if err := client.CoreV1().Pods("default").Delete(context.TODO(), name, metav1.DeleteOptions{}); err != nil {
				t.Fatalf("failed to delete marker pod: %v", err)
			}
		}(markerName)

		expectedWarning := fmt.Sprintf(fieldmanager.InvalidManagedFieldsAfterMutatingAdmissionWarningFormat, "")

		// Verify reset on patch request
		var podResult *corev1.Pod
		var lastErr error
		if err := wait.PollImmediate(time.Millisecond*5, wait.ForeverTestTimeout, func() (bool, error) {
			recordedWarnings.Reset()
			podResult, err = client.CoreV1().Pods("default").Patch(context.TODO(), markerName, types.JSONPatchType, []byte("[]"), metav1.PatchOptions{})
			if err != nil {
				return false, err
			}
			if err := validateManagedFieldsAndDecode(podResult.ManagedFields); err != nil {
				lastErr = err
				return false, nil
			}
			if warningWriter.WarningCount() != 1 {
				lastErr = fmt.Errorf("expected one warning, got: %v", warningWriter.WarningCount())
				return false, nil
			}
			if !strings.Contains(recordedWarnings.String(), expectedWarning) {
				lastErr = fmt.Errorf("unexpected warning, expected: \n%v\n, got: \n%v", expectedWarning, recordedWarnings.String())
				return false, nil
			}
			lastErr = nil
			return true, nil
		}); err != nil || lastErr != nil {
			t.Fatalf("failed patch validation: %v, last error: %v", err, lastErr)
		}

		// Verify reset on update request
		updatedPod, err := client.CoreV1().Pods("default").Update(context.TODO(), podResult, metav1.UpdateOptions{})
		if err != nil {
			t.Fatalf("failed to update pod: %v", err)
		}
		if err := validateManagedFieldsAndDecode(updatedPod.ManagedFields); err != nil {
			t.Fatalf("validation after update failed: %v", err)
		}
		if warningWriter.WarningCount() != 2 {
			t.Fatalf("expected two warnings, got: %v", warningWriter.WarningCount())
		}
		if !strings.Contains(recordedWarnings.String(), expectedWarning) {
			t.Fatalf("unexpected warning after update, expected: \n%v\n, got: \n%v", expectedWarning, recordedWarnings.String())
		}
	}
	fmt.Println(ctestglobals.EndSeparator)
}

// getHardCodedConfigInfoInvalidManagedFields returns the minimal pod spec used as a marker for the test.
func getHardCodedConfigInfoInvalidManagedFields() ctestglobals.HardcodedConfig {
	return ctestglobals.HardcodedConfig{
		{
			FixtureFileName: "test_fixture.json",
			TestInfo:        []string{"default pod marker"},
			Field:           "spec",
			K8sObjects:      []string{"pods"},
			HardcodedConfig: corev1.PodSpec{
				Containers: []corev1.Container{
					{
						Name:  "fake-name",
						Image: "fakeimage",
					},
				},
				RestartPolicy: corev1.RestartPolicyNever,
			},
		},
	}
}
