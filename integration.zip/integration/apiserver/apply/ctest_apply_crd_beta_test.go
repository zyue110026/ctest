package apiserver

import (
	"context"
	"fmt"
	"reflect"
	"testing"

	metav1 "k8s.io/apimachinery/pkg/apis/meta/v1"

	apiextensionsv1beta1 "k8s.io/apiextensions-apiserver/pkg/apis/apiextensions/v1beta1"
	"k8s.io/apiextensions-apiserver/pkg/client/clientset/clientset"
	"k8s.io/apiextensions-apiserver/test/integration/fixtures"
	apierrors "k8s.io/apimachinery/pkg/api/errors"
	"k8s.io/apimachinery/pkg/types"
	"k8s.io/client-go/dynamic"
	apiservertesting "k8s.io/kubernetes/cmd/kube-apiserver/app/testing"
	"k8s.io/kubernetes/test/integration/framework"

	ctest "k8s.io/kubernetes/test/ctest"
	ctestglobals "k8s.io/kubernetes/test/ctest/ctestglobals"
	ctestutils "k8s.io/kubernetes/test/ctest/utils"
	"k8s.io/apimachinery/pkg/util/uuid"
)

func TestCtestApplyCRDNoSchema(t *testing.T) {
	fmt.Println(ctestglobals.StartSeparator)

	// Retrieve hard‑coded CRD spec configuration
	hc := getHardCodedConfigInfoApplyCRDNoSchema()
	item, found := ctestutils.GetItemByExactTestInfo(hc, "default crd spec")
	if !found {
		t.Fatalf("hard‑coded config not found")
	}
	fmt.Println(ctestglobals.DebugPrefix(), "get default configs:", item)
	fmt.Println(ctestglobals.StartOverrideModeSeparator)

	// Generate effective configurations (override mode)
	configObjs, configJson, err := ctest.GenerateEffectiveConfigReturnType[apiextensionsv1beta1.CustomResourceDefinitionSpec](item, ctest.OverrideOnly)
	if err != nil {
		t.Fatalf("failed to generate configs: %v", err)
	}
	if configObjs == nil {
		fmt.Println(ctestglobals.DebugPrefix(), "Skipping test execution. No new configurations generated.")
		fmt.Println(ctestglobals.EndSeparator)
		return
	}
	fmt.Println(ctestglobals.DebugPrefix(), "New Json Test Configs:", string(configJson))
	fmt.Println(ctestglobals.DebugPrefix(), "Number of test cases:", len(configObjs))

	// Edge / invalid configurations
	edgeConfigs := []apiextensionsv1beta1.CustomResourceDefinitionSpec{
		{}, // completely empty spec
		{
			Group:   "mygroup.example.com",
			Version: "v1beta1",
			Names: apiextensionsv1beta1.CustomResourceDefinitionNames{
				Plural: "invalids",
				Kind:   "", // empty kind
			},
			Scope: apiextensionsv1beta1.ClusterScoped,
			Versions: []apiextensionsv1beta1.CustomResourceDefinitionVersion{
				{Name: "v1beta1", Served: true, Storage: true},
			},
		},
	}
	configObjs = append(configObjs, edgeConfigs...)

	for i, spec := range configObjs {
		fmt.Printf("Running %d th test cases.\n", i)
		fmt.Println(ctestglobals.DebugPrefix(), "spec:", spec)

		// ---------- test setup ----------
		server, err := apiservertesting.StartTestServer(t, apiservertesting.NewDefaultTestServerOptions(), nil, framework.SharedEtcd())
		if err != nil {
			t.Fatalf("failed to start test server: %v", err)
		}
		defer server.TearDownFn()
		config := server.ClientConfig

		apiExtensionClient, err := clientset.NewForConfig(config)
		if err != nil {
			t.Fatalf("failed to create apiExtension client: %v", err)
		}
		dynamicClient, err := dynamic.NewForConfig(config)
		if err != nil {
			t.Fatalf("failed to create dynamic client: %v", err)
		}

		// Create CRD from the generated spec
		crdName := fmt.Sprintf("noxu-%s.mygroup.example.com", string(uuid.NewUUID()))
		crd := &apiextensionsv1beta1.CustomResourceDefinition{
			ObjectMeta: metav1.ObjectMeta{Name: crdName},
			Spec:       spec,
		}
		// Ensure the CRD has the same essential fields the original test expects
		if crd.Spec.Names.Plural == "" {
			crd.Spec.Names.Plural = "noxus"
		}
		if crd.Spec.Names.Kind == "" {
			crd.Spec.Names.Kind = "WishIHadChosenNoxu"
		}
		if crd.Spec.Group == "" {
			crd.Spec.Group = "mygroup.example.com"
		}
		if crd.Spec.Version == "" {
			crd.Spec.Version = "v1beta1"
		}
		if len(crd.Spec.Versions) == 0 {
			crd.Spec.Versions = []apiextensionsv1beta1.CustomResourceDefinitionVersion{
				{Name: "v1beta1", Served: true, Storage: false},
				{Name: "v1beta2", Served: true, Storage: true},
				{Name: "v0", Served: false, Storage: false},
			}
		}
		if crd.Spec.Subresources == nil {
			crd.Spec.Subresources = &apiextensionsv1beta1.CustomResourceSubresources{
				Status: &apiextensionsv1beta1.CustomResourceSubresourceStatus{},
			}
		}
		// ---------- end of setup ----------

		noxuDefinition, err := fixtures.CreateCRDUsingRemovedAPI(server.EtcdClient, server.EtcdStoragePrefix, crd, apiExtensionClient, dynamicClient)
		if err != nil {
			t.Fatalf("failed to create CRD: %v", err)
		}

		kind := noxuDefinition.Spec.Names.Kind
		apiVersion := noxuDefinition.Spec.Group + "/" + noxuDefinition.Spec.Versions[0].Name
		name := "mytest"

		rest := apiExtensionClient.Discovery().RESTClient()
		yamlBody := []byte(fmt.Sprintf(`
apiVersion: %s
kind: %s
metadata:
  name: %s
spec:
  replicas: 1`, apiVersion, kind, name))
		result, err := rest.Patch(types.ApplyPatchType).
			AbsPath("/apis", noxuDefinition.Spec.Group, noxuDefinition.Spec.Versions[0].Name, noxuDefinition.Spec.Names.Plural).
			Name(name).
			Param("fieldManager", "apply_test").
			Body(yamlBody).
			DoRaw(context.TODO())
		if err != nil {
			t.Fatalf("failed to create custom resource with apply: %v:\n%v", err, string(result))
		}
		verifyReplicas(t, result, 1)

		// Patch object to change the number of replicas
		result, err = rest.Patch(types.MergePatchType).
			AbsPath("/apis", noxuDefinition.Spec.Group, noxuDefinition.Spec.Versions[0].Name, noxuDefinition.Spec.Names.Plural).
			Name(name).
			Body([]byte(`{"spec":{"replicas": 5}}`)).
			DoRaw(context.TODO())
		if err != nil {
			t.Fatalf("failed to update number of replicas with merge patch: %v:\n%v", err, string(result))
		}
		verifyReplicas(t, result, 5)

		// Re‑apply, should get conflicts now
		result, err = rest.Patch(types.ApplyPatchType).
			AbsPath("/apis", noxuDefinition.Spec.Group, noxuDefinition.Spec.Versions[0].Name, noxuDefinition.Spec.Names.Plural).
			Name(name).
			Param("fieldManager", "apply_test").
			Body(yamlBody).
			DoRaw(context.TODO())
		if err == nil {
			t.Fatalf("Expecting to get conflicts when applying object after updating replicas, got no error: %s", result)
		}
		status, ok := err.(*apierrors.StatusError)
		if !ok {
			t.Fatalf("Expecting to get conflicts as API error")
		}
		if len(status.Status().Details.Causes) != 1 {
			t.Fatalf("Expecting to get one conflict when applying object after updating replicas, got: %v", status.Status().Details.Causes)
		}

		// Re‑apply with force, should succeed
		result, err = rest.Patch(types.ApplyPatchType).
			AbsPath("/apis", noxuDefinition.Spec.Group, noxuDefinition.Spec.Versions[0].Name, noxuDefinition.Spec.Names.Plural).
			Name(name).
			Param("force", "true").
			Param("fieldManager", "apply_test").
			Body(yamlBody).
			DoRaw(context.TODO())
		if err != nil {
			t.Fatalf("failed to apply object with force after updating replicas: %v:\n%v", err, string(result))
		}
		verifyReplicas(t, result, 1)

		// Try to set managed fields via subresource – should have no effect
		existingManagedFields, err := getManagedFields(result)
		if err != nil {
			t.Fatalf("failed to get managedFields from response: %v", err)
		}
		updateBytes := []byte(`{
		"metadata": {
			"managedFields": [{
				"manager":"testing",
				"operation":"Update",
				"apiVersion":"v1",
				"fieldsType":"FieldsV1",
				"fieldsV1":{
					"f:spec":{
						"f:containers":{
							"k:{\"name\":\"testing\"}":{
								".":{},
								"f:image":{},
								"f:name":{}
							}
						}
					}
				}
			}]
		}
	}`)
		result, err = rest.Patch(types.MergePatchType).
			AbsPath("/apis", noxuDefinition.Spec.Group, noxuDefinition.Spec.Versions[0].Name, noxuDefinition.Spec.Names.Plural).
			SubResource("status").
			Name(name).
			Param("fieldManager", "subresource_test").
			Body(updateBytes).
			DoRaw(context.TODO())
		if err != nil {
			t.Fatalf("Error updating subresource: %v ", err)
		}
		newManagedFields, err := getManagedFields(result)
		if err != nil {
			t.Fatalf("failed to get managedFields from response: %v", err)
		}
		if !reflect.DeepEqual(existingManagedFields, newManagedFields) {
			t.Fatalf("Expected managed fields to not have changed when trying manually setting them via subresoures.\n\nExpected: %#v\n\nGot: %#v", existingManagedFields, newManagedFields)
		}

		// Modify managed fields via main resource – should reset them
		result, err = rest.Patch(types.MergePatchType).
			AbsPath("/apis", noxuDefinition.Spec.Group, noxuDefinition.Spec.Versions[0].Name, noxuDefinition.Spec.Names.Plural).
			Name(name).
			Param("fieldManager", "subresource_test").
			Body([]byte(`{"metadata":{"managedFields":[{}]}}`)).
			DoRaw(context.TODO())
		if err != nil {
			t.Fatalf("Error updating managed fields of the main resource: %v ", err)
		}
		newManagedFields, err = getManagedFields(result)
		if err != nil {
			t.Fatalf("failed to get managedFields from response: %v", err)
		}
		if len(newManagedFields) != 0 {
			t.Fatalf("Expected managed fields to have been reset, but got: %v", newManagedFields)
		}
	}
	fmt.Println(ctestglobals.EndSeparator)
}

// getHardCodedConfigInfoApplyCRDNoSchema returns the minimal hard‑coded CRD spec used by the test.
func getHardCodedConfigInfoApplyCRDNoSchema() ctestglobals.HardcodedConfig {
	return ctestglobals.HardcodedConfig{
		{
			FixtureFileName: "test_fixture.json",
			TestInfo:        []string{"default crd spec"},
			Field:           "spec",
			K8sObjects:      []string{"customresourcedefinitions"},
			HardcodedConfig: apiextensionsv1beta1.CustomResourceDefinitionSpec{
				Group:   "mygroup.example.com",
				Version: "v1beta1",
				Names: apiextensionsv1beta1.CustomResourceDefinitionNames{
					Plural:     "noxus",
					Singular:   "nonenglishnoxu",
					Kind:       "WishIHadChosenNoxu",
					ShortNames: []string{"foo", "bar", "abc", "def"},
					ListKind:   "NoxuItemList",
					Categories: []string{"all"},
				},
				Scope: apiextensionsv1beta1.ClusterScoped,
				Versions: []apiextensionsv1beta1.CustomResourceDefinitionVersion{
					{Name: "v1beta1", Served: true, Storage: false},
					{Name: "v1beta2", Served: true, Storage: true},
					{Name: "v0", Served: false, Storage: false},
				},
				Subresources: &apiextensionsv1beta1.CustomResourceSubresources{
					Status: &apiextensionsv1beta1.CustomResourceSubresourceStatus{},
				},
			},
		},
	}
}