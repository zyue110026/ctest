package peerproxy

import (
	"context"
	"fmt"
	"strings"
	"testing"
	"time"

	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"

	v1 "k8s.io/api/batch/v1"
	corev1 "k8s.io/api/core/v1"
	metav1 "k8s.io/apimachinery/pkg/apis/meta/v1"
	"k8s.io/apimachinery/pkg/util/uuid"
	"k8s.io/apimachinery/pkg/util/wait"
	"k8s.io/apiserver/pkg/features"
	"k8s.io/apiserver/pkg/server"
	utilfeature "k8s.io/apiserver/pkg/util/feature"
	"k8s.io/client-go/kubernetes"
	"k8s.io/client-go/transport"
	// "k8s.io/client-go/util/cert"
	featuregatetesting "k8s.io/component-base/featuregate/testing"
	"k8s.io/klog/v2"
	kastesting "k8s.io/kubernetes/cmd/kube-apiserver/app/testing"
	controlplaneapiserver "k8s.io/kubernetes/pkg/controlplane/apiserver"
	kubefeatures "k8s.io/kubernetes/pkg/features"

	"k8s.io/kubernetes/test/integration/framework"
	// testutil "k8s.io/kubernetes/test/utils"
	"k8s.io/kubernetes/test/utils/ktesting"

	ctest "k8s.io/kubernetes/test/ctest"
	ctestglobals "k8s.io/kubernetes/test/ctest/ctestglobals"
	ctestutils "k8s.io/kubernetes/test/ctest/utils"
)

func TestCtestPeerProxiedRequest(t *testing.T) {
	ktesting.SetDefaultVerbosity(1)
	ctx, cancel := context.WithTimeout(context.Background(), 5*time.Minute)
	defer func() {
		t.Cleanup(cancel)
	}()

	transport.DialerStopCh = ctx.Done()

	featuregatetesting.SetFeatureGateDuringTest(t, utilfeature.DefaultFeatureGate, features.APIServerIdentity, true)
	featuregatetesting.SetFeatureGateDuringTest(t, utilfeature.DefaultFeatureGate, kubefeatures.UnknownVersionInteroperabilityProxy, true)

	etcd := framework.SharedEtcd()

	proxyCA, err := createProxyCertContent()
	require.NoError(t, err)

	server.SetHostnameFuncForTests("test-server-a")
	serverA := kastesting.StartTestServerOrDie(t,
		&kastesting.TestServerInstanceOptions{
			EnableCertAuth: true,
			ProxyCA:        &proxyCA,
		},
		[]string{"--runtime-config=api/all=true"},
		etcd,
	)
	t.Cleanup(serverA.TearDownFn)

	server.SetHostnameFuncForTests("test-server-b")
	serverB := kastesting.StartTestServerOrDie(t,
		&kastesting.TestServerInstanceOptions{
			EnableCertAuth: true,
			ProxyCA:        &proxyCA,
		},
		[]string{"--runtime-config=api/all=true,batch/v1=false"},
		etcd,
	)
	t.Cleanup(serverB.TearDownFn)

	kubeClientSetA, err := kubernetes.NewForConfig(serverA.ClientConfig)
	require.NoError(t, err)

	kubeClientSetB, err := kubernetes.NewForConfig(serverB.ClientConfig)
	require.NoError(t, err)

	// ==== Dynamic Job Spec Generation ====
	fmt.Println(ctestglobals.StartExtendModeSeparator)
	hardcoded := getHardCodedConfigInfoJobResource()
	item, found := ctestutils.GetItemByExactTestInfo(hardcoded, "default job spec")
	if !found {
		fmt.Println(ctestglobals.DebugPrefix(), "Failed to find config item by TestInfo")
		t.Fatalf("hardcoded config not found")
	}
	fmt.Println(ctestglobals.DebugPrefix(), "matched config item:", item)

	configObjs, configJson, err := ctest.GenerateEffectiveConfigReturnType[corev1.PodSpec](item, ctest.ExtendOnly)
	if err != nil {
		fmt.Println(ctestglobals.DebugPrefix(), "GenerateEffectiveConfigReturnType error:", err)
		t.Fatalf("config generation failed")
	}
	if configObjs == nil {
		fmt.Println(ctestglobals.DebugPrefix(), "Skipping test execution. No new configurations generated.")
	} else {
		fmt.Println(ctestglobals.DebugPrefix(), "New Json Test Configs:", string(configJson))
		fmt.Println(ctestglobals.DebugPrefix(), "Number of test cases:", len(configObjs))
		// edge cases additional to generated ones
		edgeConfigs := []corev1.PodSpec{
			{Containers: []corev1.Container{{Name: "", Image: "test"}}, RestartPolicy: corev1.RestartPolicyNever},
			{Containers: []corev1.Container{{Name: "test", Image: ""}}, RestartPolicy: corev1.RestartPolicyNever},
			{Containers: nil, RestartPolicy: corev1.RestartPolicyNever},
			{
				Containers:    []corev1.Container{{Name: "test", Image: "verylongimagename" + strings.Repeat("a", 200)}},
				RestartPolicy: corev1.RestartPolicyNever,
			},
		}
		allConfigs := append(configObjs, edgeConfigs...)
		for i, podSpec := range allConfigs {
			fmt.Printf("Running %d th test case.\n", i)
			fmt.Println(podSpec)

			jobName := "test-job-" + string(uuid.NewUUID())
			job := &v1.Job{
				ObjectMeta: metav1.ObjectMeta{
					Name:      jobName,
					Namespace: "default",
				},
				Spec: v1.JobSpec{
					Template: corev1.PodTemplateSpec{
						Spec: podSpec,
					},
				},
			}
			_, err = kubeClientSetA.BatchV1().Jobs("default").Create(context.Background(), job, metav1.CreateOptions{})
			require.NoError(t, err)

			klog.Infof("\nServerA has created job %s\n", jobName)

			jobsB, err := kubeClientSetB.BatchV1().Jobs("default").List(context.Background(), metav1.ListOptions{})
			require.NoError(t, err)
			assert.NotEmpty(t, jobsB)
			assert.Equal(t, jobName, jobsB.Items[0].Name)
		}
	}
	fmt.Println(ctestglobals.EndSeparator)
}

func TestCtestPeerProxiedRequestToThirdServerAfterFirstDies(t *testing.T) {
	ktesting.SetDefaultVerbosity(1)
	ctx, cancel := context.WithTimeout(context.Background(), 5*time.Minute)
	defer func() {
		t.Cleanup(cancel)
	}()

	transport.DialerStopCh = ctx.Done()

	featuregatetesting.SetFeatureGateDuringTest(t, utilfeature.DefaultFeatureGate, features.APIServerIdentity, true)
	featuregatetesting.SetFeatureGateDuringTest(t, utilfeature.DefaultFeatureGate, kubefeatures.UnknownVersionInteroperabilityProxy, true)

	etcd := framework.SharedEtcd()

	proxyCA, err := createProxyCertContent()
	require.NoError(t, err)

	controlplaneapiserver.IdentityLeaseDurationSeconds = 10
	controlplaneapiserver.IdentityLeaseGCPeriod = 2 * time.Second
	controlplaneapiserver.IdentityLeaseRenewIntervalPeriod = time.Second

	server.SetHostnameFuncForTests("test-server-a")
	t.Log("starting apiserver for ServerA")
	serverA := kastesting.StartTestServerOrDie(t,
		&kastesting.TestServerInstanceOptions{EnableCertAuth: true, ProxyCA: &proxyCA},
		[]string{"--runtime-config=api/all=true"},
		etcd,
	)
	kubeClientSetA, err := kubernetes.NewForConfig(serverA.ClientConfig)
	require.NoError(t, err)

	controlplaneapiserver.IdentityLeaseDurationSeconds = 3600

	server.SetHostnameFuncForTests("test-server-b")
	t.Log("starting apiserver for ServerB")
	serverB := kastesting.StartTestServerOrDie(t,
		&kastesting.TestServerInstanceOptions{EnableCertAuth: true, ProxyCA: &proxyCA},
		[]string{"--runtime-config=api/all=true,batch/v1=false"},
		etcd,
	)
	t.Cleanup(serverB.TearDownFn)
	kubeClientSetB, err := kubernetes.NewForConfig(serverB.ClientConfig)
	require.NoError(t, err)

	server.SetHostnameFuncForTests("test-server-c")
	t.Log("starting apiserver for ServerC")
	serverC := kastesting.StartTestServerOrDie(t,
		&kastesting.TestServerInstanceOptions{EnableCertAuth: true, ProxyCA: &proxyCA},
		[]string{"--runtime-config=api/all=true"},
		etcd,
	)
	t.Cleanup(serverC.TearDownFn)

	// ==== Dynamic Job Spec Generation for ServerA ====
	fmt.Println(ctestglobals.StartExtendModeSeparator)
	hc := getHardCodedConfigInfoJobResource()
	item, found := ctestutils.GetItemByExactTestInfo(hc, "default job spec")
	if !found {
		fmt.Println(ctestglobals.DebugPrefix(), "Failed to find config item by TestInfo")
		t.Fatalf("hardcoded config not found")
	}
	cfgObjs, cfgJson, err := ctest.GenerateEffectiveConfigReturnType[corev1.PodSpec](item, ctest.ExtendOnly)
	if err != nil {
		fmt.Println(ctestglobals.DebugPrefix(), "GenerateEffectiveConfigReturnType error:", err)
		t.Fatalf("config generation failed")
	}
	if cfgObjs == nil {
		fmt.Println(ctestglobals.DebugPrefix(), "Skipping test execution. No new configurations generated.")
	} else {
		fmt.Println(ctestglobals.DebugPrefix(), "New Json Test Configs:", string(cfgJson))
		fmt.Println(ctestglobals.DebugPrefix(), "Number of test cases:", len(cfgObjs))
		for i, podSpec := range cfgObjs {
			fmt.Printf("Running %d th test case.\n", i)
			jobName := "test-job-" + string(uuid.NewUUID())
			job := &v1.Job{
				ObjectMeta: metav1.ObjectMeta{
					Name:      jobName,
					Namespace: "default",
				},
				Spec: v1.JobSpec{
					Template: corev1.PodTemplateSpec{
						Spec: podSpec,
					},
				},
			}
			_, err := kubeClientSetA.BatchV1().Jobs("default").Create(context.Background(), job, metav1.CreateOptions{})
			require.NoError(t, err)

			// shutdown serverA
			serverA.TearDownFn()

			var jobsB *v1.JobList
			err = wait.PollUntilContextTimeout(ctx, 1*time.Second, 1*time.Minute, false, func(ctx context.Context) (bool, error) {
				select {
				case <-ctx.Done():
					return false, ctx.Err()
				default:
				}
				t.Log("retrieving jobs from ServerB")
				jobsB, err = kubeClientSetB.BatchV1().Jobs("default").List(context.Background(), metav1.ListOptions{})
				if err != nil {
					t.Logf("error trying to list jobs from ServerB: %v", err)
					return false, nil
				}
				if jobsB != nil && len(jobsB.Items) > 0 {
					return true, nil
				}
				t.Log("retrieved nil or empty jobs from ServerB")
				return false, nil
			})
			require.NoError(t, err)
			assert.NotEmpty(t, jobsB)
			assert.Equal(t, jobName, jobsB.Items[0].Name)
		}
	}
	fmt.Println(ctestglobals.EndSeparator)
}

func getHardCodedConfigInfoJobResource() ctestglobals.HardcodedConfig {
	return ctestglobals.HardcodedConfig{
		{
			FixtureFileName: "test_fixture.json",
			TestInfo:        []string{"default job spec"},
			Field:           "spec.template.spec",
			K8sObjects:      []string{"jobs"},
			HardcodedConfig: corev1.PodSpec{
				Containers: []corev1.Container{
					{
						Name:  "test",
						Image: "test",
					},
				},
				RestartPolicy: corev1.RestartPolicyNever,
			},
		},
	}
}
