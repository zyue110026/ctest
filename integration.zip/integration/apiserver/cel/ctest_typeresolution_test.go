package cel

import (
	"context"
	"fmt"
	"reflect"
	"strings"
	"testing"
	"time"

	// "github.com/google/cel-go/cel"
	// "github.com/google/cel-go/interpreter"

	// "k8s.io/apiserver/pkg/cel/environment"

	// admissionregistrationv1 "k8s.io/api/admissionregistration/v1"
	appsv1 "k8s.io/api/apps/v1"
	// apiv1 "k8s.io/api/core/v1"
	// networkingv1 "k8s.io/api/networking/v1"
	// nodev1 "k8s.io/api/node/v1"
	// storagev1 "k8s.io/api/storage/v1"
	apiextensionsv1 "k8s.io/apiextensions-apiserver/pkg/apis/apiextensions/v1"
	extclientset "k8s.io/apiextensions-apiserver/pkg/client/clientset/clientset"
	apiextensionsscheme "k8s.io/apiextensions-apiserver/pkg/client/clientset/clientset/scheme"
	metav1 "k8s.io/apimachinery/pkg/apis/meta/v1"
	"k8s.io/apimachinery/pkg/apis/meta/v1/unstructured"
	"k8s.io/apimachinery/pkg/runtime"
	"k8s.io/apimachinery/pkg/util/intstr"
	"k8s.io/apimachinery/pkg/util/wait"
	// commoncel "k8s.io/apiserver/pkg/cel"
	celopenapi "k8s.io/apiserver/pkg/cel/openapi"
	"k8s.io/apiserver/pkg/cel/openapi/resolver"
	k8sscheme "k8s.io/client-go/kubernetes/scheme"
	"k8s.io/kube-openapi/pkg/validation/spec"
	// "k8s.io/utils/ptr"

	apiservertesting "k8s.io/kubernetes/cmd/kube-apiserver/app/testing"
	// corev1 "k8s.io/kubernetes/pkg/apis/core/v1"
	"k8s.io/kubernetes/pkg/generated/openapi"
	ctest "k8s.io/kubernetes/test/ctest"
	ctestglobals "k8s.io/kubernetes/test/ctest/ctestglobals"
	ctestutils "k8s.io/kubernetes/test/ctest/utils"
	"k8s.io/kubernetes/test/integration/framework"
)

func TestCtestTypeResolver(t *testing.T) {
	server, err := apiservertesting.StartTestServer(t, nil, nil, framework.SharedEtcd())
	if err != nil {
		t.Fatal(err)
	}
	defer server.TearDownFn()

	cfg := server.ClientConfig
	extClient, err := extclientset.NewForConfig(cfg)
	if err != nil {
		t.Fatal(err)
	}
	crd, err := installCRD(extClient)
	if err != nil {
		t.Fatal(err)
	}
	defer func(crd *apiextensionsv1.CustomResourceDefinition) {
		_ = extClient.ApiextensionsV1().CustomResourceDefinitions().Delete(context.Background(), crd.Name, metav1.DeleteOptions{})
	}(crd)

	discoveryResolver := &resolver.ClientDiscoveryResolver{Discovery: extClient.Discovery()}
	definitionsResolver := resolver.NewDefinitionsSchemaResolver(openapi.GetOpenAPIDefinitions, k8sscheme.Scheme, apiextensionsscheme.Scheme)

	// wait for CRD schema publication
	if err = wait.PollImmediate(time.Second, time.Minute, func() (bool, error) {
		p, err := extClient.OpenAPIV3().Paths()
		if err != nil {
			return false, err
		}
		_, ok := p["apis/apis.example.com/v1beta1"]
		return ok, nil
	}); err != nil {
		t.Fatalf("timeout waiting for CRD schema: %v", err)
	}

	// Load hard‑coded configs for the various test cases.
	fmt.Println(ctestglobals.StartSeparator)
	hardCfg := getHardCodedConfigInfoTypeResolver()
	fmt.Println(ctestglobals.DebugPrefix(), "Loaded hard‑coded configs:", len(hardCfg))
	fmt.Println(ctestglobals.EndSeparator)

	testCases := []struct {
		name                string
		testInfoKey         string // matches TestInfo in hardCfg
		expression          string
		expectResolutionErr bool
		expectCompileErr    bool
		expectEvalErr       bool
		expectedResult      any
		resolvers           []resolver.SchemaResolver
	}{
		{
			name:                "unknown type",
			testInfoKey:         "unknown type",
			expectResolutionErr: true,
			resolvers:           []resolver.SchemaResolver{definitionsResolver, discoveryResolver},
		},
		{
			name:           "deployment",
			testInfoKey:    "deployment",
			expression:     "self.spec.replicas > 1",
			expectedResult: true,
			resolvers:      []resolver.SchemaResolver{definitionsResolver, discoveryResolver},
		},
		{
			name:             "missing field",
			testInfoKey:      "deployment",
			expression:       "self.spec.missing > 1",
			expectCompileErr: true,
			resolvers:        []resolver.SchemaResolver{definitionsResolver, discoveryResolver},
		},
		{
			name:             "mistyped expression",
			testInfoKey:      "deployment",
			expression:       "self.spec.replicas == '1'",
			expectCompileErr: true,
			resolvers:        []resolver.SchemaResolver{definitionsResolver, discoveryResolver},
		},
		{
			name:           "crd valid",
			testInfoKey:    "crd valid",
			expression:     "self.spec.replicas > 1",
			expectedResult: true,
			resolvers:      []resolver.SchemaResolver{discoveryResolver},
		},
		{
			name:             "crd missing field",
			testInfoKey:      "crd valid",
			expression:       "self.spec.missing > 1",
			expectCompileErr: true,
			resolvers:        []resolver.SchemaResolver{discoveryResolver},
		},
		{
			name:             "crd mistyped",
			testInfoKey:      "crd valid",
			expression:       "self.spec.replica == '1'",
			expectCompileErr: true,
			resolvers:        []resolver.SchemaResolver{discoveryResolver},
		},
		{
			name:           "items population",
			testInfoKey:    "deployment",
			expression:     "size(self.spec.template.spec.containers) > 0 && self.spec.template.spec.containers.all(c, c.ports.all(p, p.containerPort < 1024))",
			expectedResult: true,
			resolvers:      []resolver.SchemaResolver{definitionsResolver, discoveryResolver},
		},
		{
			name:           "int-or-string int",
			testInfoKey:    "int-or-string int",
			expression:     "has(self.spec.strategy.rollingUpdate) && type(self.spec.strategy.rollingUpdate.maxSurge) == int && self.spec.strategy.rollingUpdate.maxSurge > 1",
			expectedResult: true,
			resolvers:      []resolver.SchemaResolver{definitionsResolver, discoveryResolver},
		},
		{
			name:           "int-or-string string",
			testInfoKey:    "int-or-string string",
			expression:     "has(self.spec.strategy.rollingUpdate) && type(self.spec.strategy.rollingUpdate.maxSurge) == string && self.spec.strategy.rollingUpdate.maxSurge == '10%'",
			expectedResult: true,
			resolvers:      []resolver.SchemaResolver{definitionsResolver, discoveryResolver},
		},
		// Edge cases
		{
			name:             "empty expression",
			testInfoKey:      "deployment",
			expression:       "",
			expectCompileErr: true,
			resolvers:        []resolver.SchemaResolver{definitionsResolver, discoveryResolver},
		},
		{
			name:                "nil object",
			testInfoKey:         "nil object",
			expression:          "self == null",
			expectResolutionErr: true,
			resolvers:           []resolver.SchemaResolver{definitionsResolver, discoveryResolver},
		},
	}

	for _, tc := range testCases {
		tc := tc // capture range variable
		t.Run(tc.name, func(t *testing.T) {
			// Resolve object from hard‑coded config if available.
			var obj runtime.Object
			if entry, found := ctestutils.GetItemByExactTestInfo(hardCfg, tc.testInfoKey); found {
				fmt.Println(ctestglobals.DebugPrefix(), "Using hard‑coded config for", tc.name)
				// Use Union mode to allow overrides/extension.
				configObjs, configJSON, err := ctest.GenerateEffectiveConfigReturnType[runtime.Object](entry, ctest.Union)
				if err != nil {
					fmt.Println(ctestglobals.DebugPrefix(), "GenerateEffectiveConfig error:", err)
					t.Fatalf("failed to generate config: %v", err)
				}
				if len(configObjs) == 0 {
					t.Fatalf("no config objects generated for %s", tc.name)
				}
				obj = configObjs[0]
				fmt.Println(ctestglobals.DebugPrefix(), "Generated config JSON:", string(configJSON))
			} else {
				// Fallback to original inline definitions.
				switch tc.testInfoKey {
				case "unknown type":
					obj = &unstructured.Unstructured{Object: map[string]any{
						"kind":       "Bad",
						"apiVersion": "bad.example.com/v1",
					}}
				case "deployment":
					obj = sampleReplicatedDeployment()
				case "crd valid":
					obj = &unstructured.Unstructured{Object: map[string]any{
						"kind":       "CronTab",
						"apiVersion": "apis.example.com/v1beta1",
						"spec": map[string]any{
							"cronSpec": "* * * * *",
							"image":    "foo-image",
							"replicas": 2,
						},
					}}
				case "int-or-string int":
					obj = &appsv1.Deployment{
						TypeMeta: metav1.TypeMeta{Kind: "Deployment", APIVersion: "apps/v1"},
						Spec: appsv1.DeploymentSpec{
							Strategy: appsv1.DeploymentStrategy{
								Type: appsv1.RollingUpdateDeploymentStrategyType,
								RollingUpdate: &appsv1.RollingUpdateDeployment{
									MaxSurge: &intstr.IntOrString{Type: intstr.Int, IntVal: 5},
								},
							},
						},
					}
				case "int-or-string string":
					obj = &appsv1.Deployment{
						TypeMeta: metav1.TypeMeta{Kind: "Deployment", APIVersion: "apps/v1"},
						Spec: appsv1.DeploymentSpec{
							Strategy: appsv1.DeploymentStrategy{
								Type: appsv1.RollingUpdateDeploymentStrategyType,
								RollingUpdate: &appsv1.RollingUpdateDeployment{
									MaxSurge: &intstr.IntOrString{Type: intstr.String, StrVal: "10%"},
								},
							},
						},
					}
				case "nil object":
					obj = nil
				default:
					t.Fatalf("no object defined for testInfoKey %s", tc.testInfoKey)
				}
			}

			if obj == nil && !tc.expectResolutionErr {
				t.Fatalf("object is nil for test %s but resolution error not expected", tc.name)
			}

			// Resolve schema
			gvk := obj.GetObjectKind().GroupVersionKind()
			var s *spec.Schema
			for _, r := range tc.resolvers {
				var err error
				s, err = r.ResolveSchema(gvk)
				if err != nil {
					if tc.expectResolutionErr {
						return
					}
					t.Fatalf("cannot resolve type: %v", err)
				}
				if tc.expectResolutionErr {
					t.Fatalf("expected resolution error but got none")
				}
			}

			// Compile CEL expression
			prog, err := simpleCompileCEL(s, tc.expression)
			if err != nil {
				if tc.expectCompileErr {
					return
				}
				t.Fatalf("cannot compile: %v", err)
			}
			if tc.expectCompileErr {
				t.Fatalf("expected compilation error but got none")
			}

			unstr, err := runtime.DefaultUnstructuredConverter.ToUnstructured(obj)
			if err != nil {
				t.Fatalf("cannot convert to unstructured: %v", err)
			}
			ret, _, err := prog.Eval(&simpleActivation{self: celopenapi.UnstructuredToVal(unstr, s)})
			if err != nil {
				if tc.expectEvalErr {
					return
				}
				t.Fatalf("cannot eval: %v", err)
			}
			if tc.expectEvalErr {
				t.Fatalf("expected eval error but got none")
			}
			if !reflect.DeepEqual(ret.Value(), tc.expectedResult) {
				t.Errorf("wrong result, expected %v but got %v", tc.expectedResult, ret.Value())
			}
		})
	}
}

// TestCtestBuiltinResolution validates resolver implementations using dynamically generated
// configuration. Edge cases (empty scheme, nil resolver) are also exercised.
func TestCtestBuiltinResolution(t *testing.T) {
	server, err := apiservertesting.StartTestServer(t, nil, nil, framework.SharedEtcd())
	if err != nil {
		t.Fatal(err)
	}
	defer server.TearDownFn()

	cfg := server.ClientConfig
	client, err := extclientset.NewForConfig(cfg)
	if err != nil {
		t.Fatal(err)
	}

	// Load fixture for built‑in resolver tests.
	fmt.Println(ctestglobals.StartSeparator)
	builtinHardCfg := getHardCodedConfigInfoBuiltinResolution()
	fmt.Println(ctestglobals.DebugPrefix(), "Builtin hard‑coded configs loaded:", len(builtinHardCfg))
	fmt.Println(ctestglobals.EndSeparator)

	testResolverCases := []struct {
		name     string
		mode     ctest.Mode
		scheme   *runtime.Scheme
		resolver resolver.SchemaResolver
	}{
		{
			name:     "definitions extend",
			mode:     ctest.ExtendOnly,
			scheme:   buildTestScheme(),
			resolver: resolver.NewDefinitionsSchemaResolver(openapi.GetOpenAPIDefinitions, k8sscheme.Scheme, apiextensionsscheme.Scheme),
		},
		{
			name:     "discovery override",
			mode:     ctest.OverrideOnly,
			scheme:   buildTestScheme(),
			resolver: &resolver.ClientDiscoveryResolver{Discovery: client.Discovery()},
		},
		// Edge case: empty scheme
		{
			name:     "empty scheme",
			mode:     ctest.Union,
			scheme:   runtime.NewScheme(),
			resolver: resolver.NewDefinitionsSchemaResolver(openapi.GetOpenAPIDefinitions, k8sscheme.Scheme, apiextensionsscheme.Scheme),
		},
		// Edge case: nil resolver (should be handled gracefully)
		{
			name:     "nil resolver",
			mode:     ctest.Union,
			scheme:   buildTestScheme(),
			resolver: nil,
		},
	}

	for _, tc := range testResolverCases {
		tc := tc
		t.Run(tc.name, func(t *testing.T) {
			if tc.resolver == nil {
				t.Skip("resolver is nil, skipping")
			}
			// Generate config objects for the scheme if needed.
			// In this context we don't need per‑test objects; we just verify that the resolver
			// can handle the scheme without error.
			for gvk := range tc.scheme.AllKnownTypes() {
				// Apply same skippable criteria as upstream.
				if gvk.Kind == "APIGroup" || gvk.Kind == "APIGroupList" || gvk.Kind == "APIVersions" ||
					strings.HasSuffix(gvk.Kind, "Options") || strings.HasSuffix(gvk.Kind, "Event") ||
					gvk.Kind == "SerializedReference" || gvk.Kind == "List" ||
					gvk.Kind == "RangeAllocation" || gvk.Kind == "PodStatusResult" ||
					gvk.Version == "__internal" {
					continue
				}
				if tc.name == "discovery" && gvk.Group == "apiextensions.k8s.io" && (gvk.Version == "v1beta1" ||
					(gvk.Version == "v1" && gvk.Kind == "ConversionReview")) {
					continue
				}
				_, err := tc.resolver.ResolveSchema(gvk)
				if err != nil {
					t.Errorf("resolver %q cannot resolve %v: %v", tc.name, gvk, err)
				}
			}
		})
	}
}

// ---------------------------------------------------------------------------
// Hard‑coded configuration helpers
// ---------------------------------------------------------------------------

func getHardCodedConfigInfoTypeResolver() ctestglobals.HardcodedConfig {
	return ctestglobals.HardcodedConfig{
		{
			FixtureFileName: "test_fixture.json",
			TestInfo:        []string{"unknown type"},
			Field:           "kind",
			K8sObjects:      []string{"customresourcedefinitions"},
			HardcodedConfig: &unstructured.Unstructured{Object: map[string]any{
				"kind":       "Bad",
				"apiVersion": "bad.example.com/v1",
			}},
		},
		{
			FixtureFileName: "test_fixture.json",
			TestInfo:        []string{"deployment"},
			Field:           "spec",
			K8sObjects:      []string{"deployments", "pods", "statefulsets", "daemonsets", "replicasets"},
			HardcodedConfig: sampleReplicatedDeployment(),
		},
		{
			FixtureFileName: "test_fixture.json",
			TestInfo:        []string{"crd valid"},
			Field:           "spec",
			K8sObjects:      []string{"customresourcedefinitions"},
			HardcodedConfig: &unstructured.Unstructured{Object: map[string]any{
				"kind":       "CronTab",
				"apiVersion": "apis.example.com/v1beta1",
				"spec": map[string]any{
					"cronSpec": "* * * * *",
					"image":    "foo-image",
					"replicas": 2,
				},
			}},
		},
		{
			FixtureFileName: "test_fixture.json",
			TestInfo:        []string{"int-or-string int"},
			Field:           "spec",
			K8sObjects:      []string{"deployments"},
			HardcodedConfig: &appsv1.Deployment{
				TypeMeta: metav1.TypeMeta{Kind: "Deployment", APIVersion: "apps/v1"},
				Spec: appsv1.DeploymentSpec{
					Strategy: appsv1.DeploymentStrategy{
						Type: appsv1.RollingUpdateDeploymentStrategyType,
						RollingUpdate: &appsv1.RollingUpdateDeployment{
							MaxSurge: &intstr.IntOrString{Type: intstr.Int, IntVal: 5},
						},
					},
				},
			},
		},
		{
			FixtureFileName: "test_fixture.json",
			TestInfo:        []string{"int-or-string string"},
			Field:           "spec",
			K8sObjects:      []string{"deployments"},
			HardcodedConfig: &appsv1.Deployment{
				TypeMeta: metav1.TypeMeta{Kind: "Deployment", APIVersion: "apps/v1"},
				Spec: appsv1.DeploymentSpec{
					Strategy: appsv1.DeploymentStrategy{
						Type: appsv1.RollingUpdateDeploymentStrategyType,
						RollingUpdate: &appsv1.RollingUpdateDeployment{
							MaxSurge: &intstr.IntOrString{Type: intstr.String, StrVal: "10%"},
						},
					},
				},
			},
		},
		{
			FixtureFileName: "test_fixture.json",
			TestInfo:        []string{"nil object"},
			Field:           "",
			K8sObjects:      []string{},
			HardcodedConfig: nil,
		},
	}
}

func getHardCodedConfigInfoBuiltinResolution() ctestglobals.HardcodedConfig {
	return ctestglobals.HardcodedConfig{
		{
			FixtureFileName: "test_fixture.json",
			TestInfo:        []string{"builtin scheme"},
			Field:           "objects",
			K8sObjects:      []string{"deployments", "services", "configmaps", "pods", "customresourcedefinitions"},
			HardcodedConfig: buildTestScheme(),
		},
	}
}

// ---------------------------------------------------------------------------
// Utility functions (unchanged from upstream)
// ---------------------------------------------------------------------------
