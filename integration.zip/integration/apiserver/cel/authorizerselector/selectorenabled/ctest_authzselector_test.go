package selectorenabled

import (
	"fmt"
	"testing"

	"k8s.io/kubernetes/test/integration/apiserver/cel/authorizerselector"

	ctest "k8s.io/kubernetes/test/ctest"
	ctestglobals "k8s.io/kubernetes/test/ctest/ctestglobals"
	ctestutils "k8s.io/kubernetes/test/ctest/utils"
)

func TestCtestAuthzSelectorsLibraryEnabled(t *testing.T) {
	fmt.Println(ctestglobals.StartSeparator)

	// Retrieve hardcoded config info for this test
	hardcodedConfig := getHardCodedConfigInfoAuthzSelectors()
	// Find the config item using its unique test info description
	item, found := ctestutils.GetItemByExactTestInfo(hardcodedConfig, "authz selectors library enabled")
	if !found {
		fmt.Println(ctestglobals.DebugPrefix(), "Failed to find config item by TestInfo")
		t.Fatalf("hardcoded config not found")
	}
	fmt.Println(ctestglobals.DebugPrefix(), "get default configs:", item)

	fmt.Println(ctestglobals.StartOverrideModeSeparator)
	// Generate effective configuration using OverrideOnly mode (boolean flag)
	configObjs, configJson, err := ctest.GenerateEffectiveConfigReturnType[bool](item, ctest.OverrideOnly)
	if err != nil {
		fmt.Println(ctestglobals.DebugPrefix(), "Failed to generate config: %v", err)
		t.Fatalf("GenerateEffectiveConfigReturnType failed: %v", err)
	}
	if configObjs == nil {
		fmt.Println(ctestglobals.DebugPrefix(), "Skipping test execution. No new configurations generated.")
		fmt.Println(ctestglobals.EndSeparator)
		return
	}
	fmt.Println(ctestglobals.DebugPrefix(), "New Json Test Configs:", string(configJson))
	fmt.Println(ctestglobals.DebugPrefix(), "Number of test cases:", len(configObjs))

	// Iterate over generated config objects (expected to contain a single `true` value)
	for i, cfg := range configObjs {
		fmt.Printf("Running %d th test case.\n", i)
		fmt.Println(ctestglobals.DebugPrefix(), "Config value:", cfg)

		// Execute the original test logic with the dynamic configuration
		authorizerselector.RunAuthzSelectorsLibraryTests(t, cfg)
	}

	fmt.Println(ctestglobals.EndSeparator)
}

// getHardCodedConfigInfoAuthzSelectors returns the minimum hardcoded configuration needed
// for TestAuthzSelectorsLibraryEnabled. The field being tested is the library enablement flag.
func getHardCodedConfigInfoAuthzSelectors() ctestglobals.HardcodedConfig {
	return ctestglobals.HardcodedConfig{
		{
			FixtureFileName: "test_fixture.json",
			TestInfo:        []string{"authz selectors library enabled"},
			Field:           "libraryEnabled",
			// No specific Kubernetes objects are required for this boolean flag,
			// but we include pods as a generic placeholder.
			K8sObjects: []string{"pods"},
			HardcodedConfig: true,
		},
	}
}