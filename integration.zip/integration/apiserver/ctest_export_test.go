package apiserver

import (
	"fmt"
	"net/http"
	"testing"

	"k8s.io/apimachinery/pkg/util/uuid"
	corev1 "k8s.io/api/core/v1"
	metav1 "k8s.io/apimachinery/pkg/apis/meta/v1"

	ctest "k8s.io/kubernetes/test/ctest"
	ctestglobals "k8s.io/kubernetes/test/ctest/ctestglobals"
	ctestutils "k8s.io/kubernetes/test/ctest/utils"
)

func TestCtestExportRejection(t *testing.T) {
	fmt.Println(ctestglobals.StartSeparator)

	// 1. Load hard‑coded config for the Namespace object
	hardcoded := getHardCodedConfigInfoExportRejection()
	item, found := ctestutils.GetItemByExactTestInfo(hardcoded, "default namespace")
	if !found {
		t.Fatalf("hard‑coded config not found")
	}
	fmt.Println(ctestglobals.DebugPrefix(), "got hard‑coded config:", item)

	// 2. Generate dynamic configs (override mode – we want to replace the name)
	configObjs, configJson, err := ctest.GenerateEffectiveConfigReturnType[corev1.Namespace](item, ctest.OverrideOnly)
	if err != nil {
		t.Fatalf("failed to generate config objects: %v", err)
	}
	fmt.Println(ctestglobals.DebugPrefix(), "New Json Test Configs:", string(configJson))
	fmt.Println(ctestglobals.DebugPrefix(), "Number of test cases from fixture:", len(configObjs))

	// 3. Add edge‑case configs manually
	edgeCases := []corev1.Namespace{
		{ObjectMeta: metav1.ObjectMeta{Name: ""}}, // empty name (invalid)
		{ObjectMeta: metav1.ObjectMeta{Name: string(uuid.NewUUID()) + string(make([]byte, 250))}}, // very long name
		{ObjectMeta: metav1.ObjectMeta{Name: "Invalid_Name!"}}, // invalid characters
	}
	configObjs = append(configObjs, edgeCases...)
	fmt.Println(ctestglobals.DebugPrefix(), "Total test cases after adding edges:", len(configObjs))

	if len(configObjs) == 0 {
		fmt.Println(ctestglobals.DebugPrefix(), "Skipping test execution. No configurations generated.")
		fmt.Println(ctestglobals.EndSeparator)
		return
	}

	for i, ns := range configObjs {
		fmt.Printf("Running %d th test case.\n", i)
		fmt.Println("Namespace config:", ns)

		ctx, clientSet, _, tearDownFn := setup(t)
		defer tearDownFn()

		// Attempt to create the namespace; if creation fails we log and continue.
		created, err := clientSet.CoreV1().Namespaces().Create(ctx, &ns, metav1.CreateOptions{})
		if err != nil {
			t.Logf("namespace creation failed (expected for some edge cases): %v", err)
			// No need to test export param on a non‑existent namespace.
			continue
		}
		// Ensure cleanup.
		defer func(name string) {
			if err := clientSet.CoreV1().Namespaces().Delete(ctx, name, metav1.DeleteOptions{}); err != nil {
				t.Errorf("error while deleting the namespace %s: %v", name, err)
			}
		}(created.Name)

		// Export param = true should be rejected.
		result := clientSet.Discovery().RESTClient().Get().
			AbsPath("/api/v1/namespaces", created.Name).
			Param("export", "true").
			Do(ctx)
		statusCode := 0
		result.StatusCode(&statusCode)
		if statusCode != http.StatusBadRequest {
			t.Errorf("expected %v for export=true, got %v", http.StatusBadRequest, statusCode)
		}

		// Export param = false should be accepted.
		result = clientSet.Discovery().RESTClient().Get().
			AbsPath("/api/v1/namespaces", created.Name).
			Param("export", "false").
			Do(ctx)
		statusCode = 0
		result.StatusCode(&statusCode)
		if statusCode != http.StatusOK {
			t.Errorf("expected %v for export=false, got %v", http.StatusOK, statusCode)
		}
	}
	fmt.Println(ctestglobals.EndSeparator)
}

func getHardCodedConfigInfoExportRejection() ctestglobals.HardcodedConfig {
	return ctestglobals.HardcodedConfig{{
		FixtureFileName: "test_fixture.json",
		TestInfo:        []string{"default namespace"},
		Field:           "metadata.name",
		K8sObjects:      []string{"namespaces"},
		HardcodedConfig: corev1.Namespace{
			ObjectMeta: metav1.ObjectMeta{
				Name: "export-fail",
			},
		},
	}}
}