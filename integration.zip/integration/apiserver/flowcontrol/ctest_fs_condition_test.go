package flowcontrol

import (
	"context"
	// "encoding/json"
	"fmt"
	"testing"
	"time"

	flowcontrol "k8s.io/api/flowcontrol/v1"
	metav1 "k8s.io/apimachinery/pkg/apis/meta/v1"
	machinerytypes "k8s.io/apimachinery/pkg/types"
	"k8s.io/apimachinery/pkg/util/wait"
	flowcontrolapply "k8s.io/client-go/applyconfigurations/flowcontrol/v1"
	clientset "k8s.io/client-go/kubernetes"
	"k8s.io/klog/v2"

	// "github.com/onsi/ginkgo/v2"
	"k8s.io/apimachinery/pkg/util/uuid"

	ctest "k8s.io/kubernetes/test/ctest"
	ctestglobals "k8s.io/kubernetes/test/ctest/ctestglobals"
	ctestutils "k8s.io/kubernetes/test/ctest/utils"
)

func TestCtestConditionIsolation(t *testing.T) {
	fmt.Println(ctestglobals.StartSeparator)

	hardcodedConfig := getHardCodedConfigInfoFlowSchema()
	item, found := ctestutils.GetItemByExactTestInfo(hardcodedConfig, "default flow schema")
	if !found {
		fmt.Println(ctestglobals.DebugPrefix(), "Failed to find config item by TestInfo")
		t.Skip("no hardcoded config")
		return
	}
	fmt.Println(ctestglobals.DebugPrefix(), "get default configs:", item)

	fmt.Println(ctestglobals.StartExtendModeSeparator)
	configObjs, configJson, err := ctest.GenerateEffectiveConfigReturnType[*flowcontrol.FlowSchema](item, ctest.ExtendOnly)
	if err != nil {
		fmt.Println(ctestglobals.DebugPrefix(), "Failed to get matched fixtures:", err)
		t.Fatalf("GenerateEffectiveConfigReturnType error: %v", err)
	}
	if configObjs == nil {
		fmt.Println(ctestglobals.DebugPrefix(), "Skipping test execution. No new config objs found.")
		fmt.Println(ctestglobals.EndSeparator)
		return
	}
	fmt.Println(ctestglobals.DebugPrefix(), "New Json Test Configs:", string(configJson))
	fmt.Println(ctestglobals.DebugPrefix(), "Number of Test Cases:", len(configObjs))

	for i, cfg := range configObjs {
		fmt.Printf("Running %d th test cases.\n", i)
		fmt.Println(cfg)

		ctx, kubeConfig, closeFn := setup(t, 10, 10)
		defer closeFn()

		loopbackClient := clientset.NewForConfigOrDie(kubeConfig)
		fsClient := loopbackClient.FlowcontrolV1().FlowSchemas()

		// Ensure a unique name for each generated FlowSchema.
		cfg.Name = "fs-" + string(uuid.NewUUID())

		// Create the FlowSchema in the cluster.
		_, err := fsClient.Create(ctx, cfg, metav1.CreateOptions{})
		if err != nil {
			t.Fatalf("Failed to create FlowSchema: %v", err)
		}

		// Wait for the dangling condition to appear.
		var dangleOrig *flowcontrol.FlowSchemaCondition
		err = wait.PollUntilContextCancel(ctx, time.Second, false, func(ctx context.Context) (bool, error) {
			fsGot, err := fsClient.Get(ctx, cfg.Name, metav1.GetOptions{})
			if err != nil {
				klog.Errorf("Failed to fetch FlowSchema %q: %v", cfg.Name, err)
				return false, nil
			}
			dangleOrig = getCondition(fsGot.Status.Conditions, flowcontrol.FlowSchemaConditionDangling)
			return dangleOrig != nil, nil
		})
		if err != nil {
			t.Error(err)
		}

		// Apply SSA patch.
		ssaType := flowcontrol.FlowSchemaConditionType("test-ssa")
		patchSSA := flowcontrolapply.FlowSchema(cfg.Name).
			WithStatus(flowcontrolapply.FlowSchemaStatus().
				WithConditions(flowcontrolapply.FlowSchemaCondition().
					WithType(ssaType).
					WithStatus(flowcontrol.ConditionTrue).
					WithReason("SSA test").
					WithMessage("for testing").
					WithLastTransitionTime(metav1.Now()),
				))
		postSSA, err := fsClient.ApplyStatus(ctx, patchSSA, metav1.ApplyOptions{FieldManager: "ssa-test"})
		if err != nil {
			t.Fatalf("ApplyStatus error: %v", err)
		}
		danglePostSSA := getCondition(postSSA.Status.Conditions, flowcontrol.FlowSchemaConditionDangling)
		if danglePostSSA == nil || danglePostSSA.Status != dangleOrig.Status {
			t.Errorf("Bad dangle condition after SSA, the FS is now %s", fmtFS(t, postSSA))
		}
		ssaPostSSA := getCondition(postSSA.Status.Conditions, ssaType)
		if ssaPostSSA == nil || ssaPostSSA.Status != flowcontrol.ConditionTrue {
			t.Errorf("Bad SSA condition after SSA, the FS is now %s", fmtFS(t, postSSA))
		}

		// Apply SMP patch.
		smpType := flowcontrol.FlowSchemaConditionType("test-smp")
		smpCond := flowcontrol.FlowSchemaCondition{
			Type:               smpType,
			Status:             flowcontrol.ConditionFalse,
			Reason:             "SMP test",
			Message:            "for testing too",
			LastTransitionTime: metav1.Now(),
		}
		smpBytes, err := makeFlowSchemaConditionPatch(smpCond)
		if err != nil {
			t.Fatalf("makeFlowSchemaConditionPatch error: %v", err)
		}
		postSMP, err := fsClient.Patch(ctx, cfg.Name, machinerytypes.StrategicMergePatchType, smpBytes,
			metav1.PatchOptions{FieldManager: "smp-test"}, "status")
		if err != nil {
			t.Fatalf("Patch error: %v", err)
		}
		smpPostSMP := getCondition(postSMP.Status.Conditions, smpType)
		if smpPostSMP == nil || smpPostSMP.Status != flowcontrol.ConditionFalse {
			t.Errorf("Bad SMP condition after SMP, the FS is now %s", fmtFS(t, postSMP))
		}
	}
	fmt.Println(ctestglobals.EndSeparator)
}

func getHardCodedConfigInfoFlowSchema() ctestglobals.HardcodedConfig {
	return ctestglobals.HardcodedConfig{
		{
			FixtureFileName: "test_fixture.json",
			TestInfo:        []string{"default flow schema"},
			Field:           "status.conditions",
			K8sObjects:      []string{},
			HardcodedConfig: &flowcontrol.FlowSchema{
				ObjectMeta: metav1.ObjectMeta{
					Name: "placeholder-fs",
				},
				Spec: flowcontrol.FlowSchemaSpec{},
				Status: flowcontrol.FlowSchemaStatus{
					Conditions: []flowcontrol.FlowSchemaCondition{
						{
							Type:               flowcontrol.FlowSchemaConditionDangling,
							Status:             flowcontrol.ConditionTrue,
							Reason:             "Initial",
							Message:            "dangling condition",
							LastTransitionTime: metav1.Now(),
						},
					},
				},
			},
		},
	}
}
