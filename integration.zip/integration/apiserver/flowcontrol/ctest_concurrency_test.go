package flowcontrol

import (
	// "context"
	"fmt"
	// "io"
	// "strings"
	"sync"
	"testing"
	"time"

	// "github.com/prometheus/common/expfmt"
	// "github.com/prometheus/common/model"

	flowcontrol "k8s.io/api/flowcontrol/v1"
	metav1 "k8s.io/apimachinery/pkg/apis/meta/v1"
	// "k8s.io/apimachinery/pkg/util/wait"
	clientset "k8s.io/client-go/kubernetes"
	// "k8s.io/client-go/rest"
	// "k8s.io/kubernetes/cmd/kube-apiserver/app/options"
	// "k8s.io/kubernetes/test/integration/framework"
	// "k8s.io/kubernetes/test/utils/ktesting"
	"k8s.io/utils/ptr"

	ctest "k8s.io/kubernetes/test/ctest"
	ctestglobals "k8s.io/kubernetes/test/ctest/ctestglobals"
	ctestutils "k8s.io/kubernetes/test/ctest/utils"
	// "github.com/google/uuid"
)

// TestCtestPriorityLevelIsolation rewrites the original TestPriorityLevelIsolation,
// adding edge‑case parameters and dynamic configuration handling.
func TestCtestPriorityLevelIsolation(t *testing.T) {
	edgeTestCases := []struct {
		name                string
		concurrencyShares   int
		queueLength         int
		expectCreateFailure bool
	}{
		{
			name:                "baseline – shares=1, queue=50",
			concurrencyShares:   1,
			queueLength:         50,
			expectCreateFailure: false,
		},
		{
			name:                "zero concurrency shares",
			concurrencyShares:   0,
			queueLength:         10,
			expectCreateFailure: false, // API accepts 0 and yields nominal concurrency 0
		},
		{
			name:                "negative concurrency shares",
			concurrencyShares:   -1,
			queueLength:         10,
			expectCreateFailure: true,
		},
		{
			name:                "zero queue length",
			concurrencyShares:   1,
			queueLength:         0,
			expectCreateFailure: false, // QueueLengthLimit can be zero (means no limit)
		},
		{
			name:                "excessively large queue length",
			concurrencyShares:   1,
			queueLength:         1000000,
			expectCreateFailure: false,
		},
	}

	fmt.Println(ctestglobals.StartSeparator)
	fmt.Println(ctestglobals.DebugPrefix(), "Running edge test cases for priority level isolation")
	fmt.Println(ctestglobals.DebugPrefix(), "Number of edge cases:", len(edgeTestCases))

	for i, tc := range edgeTestCases {
		fmt.Printf("Running edge case #%d: %s\n", i, tc.name)
		t.Run(tc.name, func(t *testing.T) {
			// Dynamically obtain any hard‑coded config (currently none needed for this test)
			hardcodedConfig := getHardCodedConfigInfoPriorityLevel()
			item, found := ctestutils.GetItemByExactTestInfo(hardcodedConfig, "priority level baseline")
			if !found {
				fmt.Println(ctestglobals.DebugPrefix(), "No hard‑coded config found, proceeding without fixture")
			} else {
				fmt.Println(ctestglobals.DebugPrefix(), "found hard‑coded config:", item)
				// Example of generating config objects – not used further in this test
				_, configJSON, err := ctest.GenerateEffectiveConfigReturnType[flowcontrol.PriorityLevelConfigurationSpec](item, ctest.ExtendOnly)
				if err != nil {
					fmt.Println(ctestglobals.DebugPrefix(), "GenerateEffectiveConfigReturnType error:", err)
				} else {
					fmt.Println(ctestglobals.DebugPrefix(), "Generated config JSON:", string(configJSON))
				}
			}

			ctx, kubeConfig, closeFn := setup(t, 1, 1)
			defer closeFn()

			loopbackClient := clientset.NewForConfigOrDie(kubeConfig)
			noxu1Client := getClientFor(kubeConfig, "noxu1")
			noxu2Client := getClientFor(kubeConfig, "noxu2")

			priorityLevelNoxu1, _, err := createPriorityLevelAndBindingFlowSchemaForUser(
				loopbackClient, "noxu1", tc.concurrencyShares, tc.queueLength)
			if err != nil {
				if tc.expectCreateFailure {
					// Expected failure – test passes for this edge case.
					return
				}
				t.Fatalf("unexpected error creating priority level for noxu1: %v", err)
			}
			if tc.expectCreateFailure {
				t.Fatalf("expected creation failure for noxu1 but succeeded")
			}
			priorityLevelNoxu2, _, err := createPriorityLevelAndBindingFlowSchemaForUser(
				loopbackClient, "noxu2", tc.concurrencyShares, tc.queueLength)
			if err != nil {
				t.Fatalf("unexpected error creating priority level for noxu2: %v", err)
			}

			nominalConcurrency, err := getNominalConcurrencyOfPriorityLevel(loopbackClient)
			if err != nil {
				t.Fatalf("failed to get nominal concurrency: %v", err)
			}
			expected := tc.concurrencyShares
			if nom, ok := nominalConcurrency[priorityLevelNoxu1.Name]; !ok || nom != expected {
				t.Errorf("unexpected nominal concurrency for %s: got %d, want %d", priorityLevelNoxu1.Name, nom, expected)
			}
			if nom, ok := nominalConcurrency[priorityLevelNoxu2.Name]; !ok || nom != expected {
				t.Errorf("unexpected nominal concurrency for %s: got %d, want %d", priorityLevelNoxu2.Name, nom, expected)
			}

			stopCh := make(chan struct{})
			wg := sync.WaitGroup{}
			defer func() {
				close(stopCh)
				wg.Wait()
			}()

			// "elephant" stream
			wg.Add(tc.concurrencyShares + tc.queueLength)
			streamRequests(tc.concurrencyShares+tc.queueLength, func() {
				_, err := noxu1Client.CoreV1().Namespaces().List(ctx, metav1.ListOptions{})
				if err != nil {
					t.Error(err)
				}
			}, &wg, stopCh)

			// "mouse" stream
			wg.Add(3)
			streamRequests(3, func() {
				_, err := noxu2Client.CoreV1().Namespaces().List(ctx, metav1.ListOptions{})
				if err != nil {
					t.Error(err)
				}
			}, &wg, stopCh)

			time.Sleep(10 * time.Second)

			allDispatchedReqCounts, rejectedReqCounts, err := getRequestCountOfPriorityLevel(loopbackClient)
			if err != nil {
				t.Fatalf("failed to get request counts: %v", err)
			}

			noxu1RequestCount := allDispatchedReqCounts[priorityLevelNoxu1.Name]
			noxu2RequestCount := allDispatchedReqCounts[priorityLevelNoxu2.Name]

			if rejectedReqCounts[priorityLevelNoxu1.Name] > 0 {
				t.Errorf(`%v requests from the "elephant" stream were rejected unexpectedly`, rejectedReqCounts[priorityLevelNoxu1.Name])
			}
			if rejectedReqCounts[priorityLevelNoxu2.Name] > 0 {
				t.Errorf(`%v requests from the "mouse" stream were rejected unexpectedly`, rejectedReqCounts[priorityLevelNoxu2.Name])
			}

			if (noxu1RequestCount/2) > noxu2RequestCount || (noxu2RequestCount/2) > noxu1RequestCount {
				t.Errorf("imbalanced requests made by noxu1/2: (%d:%d)", noxu1RequestCount, noxu2RequestCount)
			}
		})
	}
	fmt.Println(ctestglobals.EndSeparator)
}

// getHardCodedConfigInfoPriorityLevel provides a minimal hard‑coded fixture for
// a PriorityLevelConfiguration used as a baseline in the rewritten test.
func getHardCodedConfigInfoPriorityLevel() ctestglobals.HardcodedConfig {
	return ctestglobals.HardcodedConfig{
		{
			FixtureFileName: "test_fixture.json",
			TestInfo:        []string{"priority level baseline"},
			Field:           "spec.limited.nominalConcurrencyShares",
			K8sObjects: []string{
				"prioritylevelconfigurations", // fixture include object name
			},
			HardcodedConfig: flowcontrol.PriorityLevelConfigurationSpec{
				Type: flowcontrol.PriorityLevelEnablementLimited,
				Limited: &flowcontrol.LimitedPriorityLevelConfiguration{
					NominalConcurrencyShares: ptr.To(int32(1)),
					BorrowingLimitPercent:    ptr.To(int32(0)),
					LimitResponse: flowcontrol.LimitResponse{
						Type: flowcontrol.LimitResponseTypeQueue,
						Queuing: &flowcontrol.QueuingConfiguration{
							Queues:           100,
							HandSize:         1,
							QueueLengthLimit: int32(50),
						},
					},
				},
			},
		},
	}
}
