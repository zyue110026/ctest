package apiserver

import (
	"context"
	"encoding/json"
	"fmt"
	"testing"

	metav1 "k8s.io/apimachinery/pkg/apis/meta/v1"
	"k8s.io/apimachinery/pkg/apis/meta/v1/unstructured"
	"k8s.io/apimachinery/pkg/runtime/schema"
	"k8s.io/client-go/dynamic"
	clientset "k8s.io/client-go/kubernetes"
	kubeapiservertesting "k8s.io/kubernetes/cmd/kube-apiserver/app/testing"
	"k8s.io/kubernetes/test/integration/framework"

	ctest "k8s.io/kubernetes/test/ctest"
	ctestglobals "k8s.io/kubernetes/test/ctest/ctestglobals"
	// ctestutils "k8s.io/kubernetes/test/ctest/utils"
)

func gvrForInfo(info string) schema.GroupVersionResource {
	switch info {
	case "node":
		return gvr("", "v1", "nodes")
	case "pod":
		return gvr("", "v1", "pods")
	case "service":
		return gvr("", "v1", "services")
	case "endpoint":
		return gvr("", "v1", "endpoints")
	case "endpointslice":
		return gvr("discovery.k8s.io", "v1", "endpointslices")
	case "ingress":
		return gvr("networking.k8s.io", "v1", "ingresses")
	case "networkpolicy":
		return gvr("networking.k8s.io", "v1", "networkpolicies")
	default:
		return schema.GroupVersionResource{}
	}
}

// TestCtestCanaryCVE_2021_29923 validates that the API server accepts resources
// containing IPv4 addresses with leading zeros and also with alternative
// representations (edge cases).
func TestCtestCanaryCVE_2021_29923(t *testing.T) {
	// Disable ServiceAccount admission plugin as we don't have serviceaccount controller running.
	server := kubeapiservertesting.StartTestServerOrDie(t, nil, framework.DefaultTestServerFlags(), framework.SharedEtcd())
	defer server.TearDownFn()

	client, err := clientset.NewForConfig(server.ClientConfig)
	if err != nil {
		t.Fatalf("unexpected error creating client: %v", err)
	}

	ns := framework.CreateNamespaceOrDie(client, "test-cve-2021-29923", t)
	defer framework.DeleteNamespaceOrDie(client, ns, t)

	dynamicClient, err := dynamic.NewForConfig(server.ClientConfig)
	if err != nil {
		t.Fatalf("unexpected error creating dynamic client: %v", err)
	}

	// Load hard‑coded configurations.
	hc := getHardCodedConfigInfoCVE2021_29923()
	fmt.Println(ctestglobals.StartSeparator)

	for _, cfgItem := range hc {
		fmt.Println(ctestglobals.DebugPrefix(), "matched config item:", cfgItem.TestInfo)

		// Generate the effective configuration (union of defaults and possible overrides).
		configObjs, configJson, err := ctest.GenerateEffectiveConfigReturnType[map[string]interface{}](cfgItem, ctest.Union)
		if err != nil {
			fmt.Println(ctestglobals.DebugPrefix(), "failed to generate config:", err)
			t.Fatalf("GenerateEffectiveConfigReturnType failed: %v", err)
		}
		if configObjs == nil {
			fmt.Println(ctestglobals.DebugPrefix(), "Skipping test execution. No new configurations generated.")
			continue
		}
		fmt.Println(ctestglobals.DebugPrefix(), "New Json Test Configs:", string(configJson))
		fmt.Println(ctestglobals.DebugPrefix(), "Number of base test cases:", len(configObjs))

		// Build edge‑case variations (remove leading zeros).
		var allConfigs []map[string]interface{}
		allConfigs = append(allConfigs, configObjs...)
		for _, base := range configObjs {
			edge := cloneMap(base)
			applyEdgeIPTransform(edge, cfgItem.TestInfo[0])
			allConfigs = append(allConfigs, edge)
		}
		fmt.Println(ctestglobals.DebugPrefix(), "Total test cases after adding edge cases:", len(allConfigs))

		for i, cfg := range allConfigs {
			fmt.Printf("Running %d th test case for %s.\n", i, cfgItem.TestInfo[0])
			fmt.Println(ctestglobals.DebugPrefix(), "config object:", cfg)

			unstr := &unstructured.Unstructured{Object: cfg}
			gvr := gvrForInfo(cfgItem.TestInfo[0])
			if !gvr.Empty() {
				_, err = dynamicClient.Resource(gvr).Namespace(unstr.GetNamespace()).Create(context.TODO(), unstr, metav1.CreateOptions{})
				if err != nil {
					t.Errorf("error creating resource %s (case %d): %v", gvr.String(), i, err)
				}
			}
		}
	}
	fmt.Println(ctestglobals.EndSeparator)
}

// cloneMap creates a deep copy of a map[string]interface{} via JSON round‑trip.
func cloneMap(in map[string]interface{}) map[string]interface{} {
	b, _ := json.Marshal(in)
	var out map[string]interface{}
	_ = json.Unmarshal(b, &out)
	return out
}

// applyEdgeIPTransform removes leading zeros from known IP fields for a given resource type.
func applyEdgeIPTransform(obj map[string]interface{}, kind string) {
	// Helper to replace a specific path if it exists.
	replace := func(path []string, newVal string) {
		m := obj
		for i, p := range path {
			if i == len(path)-1 {
				if _, ok := m[p]; ok {
					m[p] = newVal
				}
				return
			}
			if nxt, ok := m[p].(map[string]interface{}); ok {
				m = nxt
			} else {
				return
			}
		}
	}
	switch kind {
	case "node":
		replace([]string{"status", "addresses", "0", "address"}, "172.18.0.12")
	case "pod":
		replace([]string{"status", "podIP"}, "10.244.0.5")
		replace([]string{"status", "podIPs", "0", "ip"}, "10.244.0.5")
	case "service":
		replace([]string{"spec", "clusterIP"}, "10.0.0.11")
		replace([]string{"spec", "externalIP"}, "192.168.0.12")
	case "endpoint":
		replace([]string{"subsets", "0", "addresses", "0", "ip"}, "192.168.3.11")
	case "endpointslice":
		replace([]string{"endpoints", "0", "addresses", "0"}, "10.244.0.11")
	case "ingress":
		replace([]string{"status", "loadBalancer", "ingress", "0", "ip"}, "10.0.0.13")
	case "networkpolicy":
		replace([]string{"spec", "egress", "0", "to", "0", "ipBlock", "cidr"}, "10.0.12.0/24")
		replace([]string{"spec", "ingress", "0", "from", "0", "ipBlock", "cidr"}, "172.17.0.0/16")
		replace([]string{"spec", "ingress", "0", "from", "0", "ipBlock", "except", "0"}, "172.17.1.0/24")
	}
}

// getHardCodedConfigInfoCVE2021_29923 returns the baseline hard‑coded configurations for each resource.
func getHardCodedConfigInfoCVE2021_29923() ctestglobals.HardcodedConfig {
	return ctestglobals.HardcodedConfig{
		{
			FixtureFileName: "test_fixture.json",
			TestInfo:        []string{"node"},
			Field:           "object",
			K8sObjects:      []string{"nodes"},
			HardcodedConfig: map[string]interface{}{
				"kind":       "Node",
				"apiVersion": "v1",
				"metadata": map[string]interface{}{
					"name": "node1",
				},
				"spec": map[string]interface{}{
					"unschedulable": true,
				},
				"status": map[string]interface{}{
					"addresses": []interface{}{
						map[string]interface{}{
							"address": "172.18.0.012",
							"type":    "InternalIP",
						},
					},
				},
			},
		},
		{
			FixtureFileName: "test_fixture.json",
			TestInfo:        []string{"pod"},
			Field:           "object",
			K8sObjects:      []string{"pods"},
			HardcodedConfig: map[string]interface{}{
				"kind":       "Pod",
				"apiVersion": "v1",
				"metadata": map[string]interface{}{
					"name":      "pod1",
					"namespace": "test-cve-2021-29923",
				},
				"spec": map[string]interface{}{
					"containers": []interface{}{
						map[string]interface{}{
							"name":  "container7",
							"image": "image",
							"resources": map[string]interface{}{
								"limits": map[string]interface{}{
									"cpu": "1M",
								},
								"requests": map[string]interface{}{
									"cpu": "1M",
								},
							},
						},
					},
				},
				"status": map[string]interface{}{
					"podIP": "10.244.0.05",
					"podIPs": []interface{}{
						map[string]interface{}{
							"ip": "10.244.0.05",
						},
					},
				},
			},
		},
		{
			FixtureFileName: "test_fixture.json",
			TestInfo:        []string{"service"},
			Field:           "object",
			K8sObjects:      []string{"services"},
			HardcodedConfig: map[string]interface{}{
				"kind":       "Service",
				"apiVersion": "v1",
				"metadata": map[string]interface{}{
					"name":      "service1",
					"namespace": "test-cve-2021-29923",
				},
				"spec": map[string]interface{}{
					"clusterIP":    "10.0.0.011",
					"externalIP":   "192.168.0.012",
					"externalName": "service1name",
					"ports": []interface{}{
						map[string]interface{}{
							"port":       int64(10000),
							"targetPort": int64(11000),
						},
					},
					"selector": map[string]interface{}{
						"test": "data",
					},
				},
			},
		},
		{
			FixtureFileName: "test_fixture.json",
			TestInfo:        []string{"endpoint"},
			Field:           "object",
			K8sObjects:      []string{"endpoints"},
			HardcodedConfig: map[string]interface{}{
				"kind":       "Endpoints",
				"apiVersion": "v1",
				"metadata": map[string]interface{}{
					"name":      "ep1name",
					"namespace": "test-cve-2021-29923",
				},
				"subsets": []interface{}{
					map[string]interface{}{
						"addresses": []interface{}{
							map[string]interface{}{
								"hostname": "bar-001",
								"ip":       "192.168.3.011",
							},
						},
						"ports": []interface{}{
							map[string]interface{}{
								"port": int64(8000),
							},
						},
					},
				},
			},
		},
		{
			FixtureFileName: "test_fixture.json",
			TestInfo:        []string{"endpointslice"},
			Field:           "object",
			K8sObjects:      []string{"endpointslices"},
			HardcodedConfig: map[string]interface{}{
				"kind":       "EndpointSlice",
				"apiVersion": "discovery.k8s.io/v1",
				"metadata": map[string]interface{}{
					"name":      "slicev1",
					"namespace": "test-cve-2021-29923",
				},
				"addressType": "IPv4",
				"protocol":    "TCP",
				"ports":       []interface{}{},
				"endpoints": []interface{}{
					map[string]interface{}{
						"addresses": []interface{}{"10.244.0.011"},
						"conditions": map[string]interface{}{
							"ready":       true,
							"serving":     true,
							"terminating": false,
						},
						"nodeName": "control-plane",
					},
				},
			},
		},
		{
			FixtureFileName: "test_fixture.json",
			TestInfo:        []string{"ingress"},
			Field:           "object",
			K8sObjects:      []string{"ingresses"},
			HardcodedConfig: map[string]interface{}{
				"kind":       "Ingress",
				"apiVersion": "networking.k8s.io/v1",
				"metadata": map[string]interface{}{
					"name":      "ingress3",
					"namespace": "test-cve-2021-29923",
				},
				"spec": map[string]interface{}{
					"defaultBackend": map[string]interface{}{
						"service": map[string]interface{}{
							"name": "service",
							"port": map[string]interface{}{
								"number": int64(5000),
							},
						},
					},
				},
				"status": map[string]interface{}{
					"loadBalancer": map[string]interface{}{
						"ingress": []interface{}{
							map[string]interface{}{
								"ip": "10.0.0.013",
							},
						},
					},
				},
			},
		},
		{
			FixtureFileName: "test_fixture.json",
			TestInfo:        []string{"networkpolicy"},
			Field:           "object",
			K8sObjects:      []string{"networkpolicies"},
			HardcodedConfig: map[string]interface{}{
				"kind":       "NetworkPolicy",
				"apiVersion": "networking.k8s.io/v1",
				"metadata": map[string]interface{}{
					"name":      "np2",
					"namespace": "test-cve-2021-29923",
				},
				"spec": map[string]interface{}{
					"egress": []interface{}{
						map[string]interface{}{
							"ports": []interface{}{
								map[string]interface{}{
									"port":     int64(5978),
									"protocol": "TCP",
								},
							},
							"to": []interface{}{
								map[string]interface{}{
									"ipBlock": map[string]interface{}{
										"cidr": "10.0.012.0/24",
									},
								},
							},
						},
					},
					"ingress": []interface{}{
						map[string]interface{}{
							"from": []interface{}{
								map[string]interface{}{
									"ipBlock": map[string]interface{}{
										"cidr":   "172.017.0.0/16",
										"except": []interface{}{"172.17.001.0/24"},
									},
								},
								map[string]interface{}{
									"podSelector": map[string]interface{}{
										"matchLabels": map[string]interface{}{
											"role": "frontend",
										},
									},
								},
							},
							"ports": []interface{}{
								map[string]interface{}{
									"port":     int64(6379),
									"protocol": "TCP",
								},
							},
						},
					},
					"podSelector": map[string]interface{}{
						"matchLabels": map[string]interface{}{
							"role": "db",
						},
					},
					"policyTypes": []interface{}{"Ingress", "Egress"},
				},
			},
		},
	}
}
