package podlogs

import (
	"context"
	"crypto/tls"
	"encoding/pem"
	"fmt"
	corev1 "k8s.io/api/core/v1"
	"k8s.io/apimachinery/pkg/api/errors"
	metav1 "k8s.io/apimachinery/pkg/apis/meta/v1"
	"k8s.io/apimachinery/pkg/util/uuid"
	"k8s.io/apimachinery/pkg/util/wait"
	"k8s.io/apiserver/pkg/authentication/authenticatorfactory"
	"k8s.io/client-go/kubernetes"
	"k8s.io/client-go/transport"
	"k8s.io/kubernetes/cmd/kube-apiserver/app/options"
	"net"
	"net/http"
	"net/http/httptest"
	"net/url"
	"os"
	"strconv"
	"strings"
	"testing"
	"time"
	// "k8s.io/kubernetes/test/e2e/framework"
	"k8s.io/apiserver/pkg/endpoints/filters"
	"k8s.io/apiserver/pkg/server/dynamiccertificates"
	"k8s.io/kubernetes/test/integration/framework"
	"k8s.io/kubernetes/test/utils/ktesting"

	ctest "k8s.io/kubernetes/test/ctest"
	ctestglobals "k8s.io/kubernetes/test/ctest/ctestglobals"
	ctestutils "k8s.io/kubernetes/test/ctest/utils"
)

// -----------------------------------------------------------------------------
// Dynamic configuration for PodSpec used in insecure pod‑logs test
// -----------------------------------------------------------------------------
func getHardCodedConfigInfoPodSpec() ctestglobals.HardcodedConfig {
	return ctestglobals.HardcodedConfig{
		{
			FixtureFileName: "test_fixture.json",
			TestInfo:        []string{"default pod spec"},
			Field:           "spec",
			K8sObjects: []string{
				"pods",
			},
			HardcodedConfig: corev1.PodSpec{
				Containers: []corev1.Container{
					{
						Name:  "env-test",
						Image: "busybox",
						Command: []string{
							"sh",
							"-c",
							"env",
						},
					},
				},
				RestartPolicy: corev1.RestartPolicyNever,
			},
		},
		{
			FixtureFileName: "test_fixture.json",
			TestInfo:        []string{"pod spec with AutomountServiceAccountToken true"},
			Field:           "spec",
			K8sObjects: []string{
				"pods",
			},
			HardcodedConfig: corev1.PodSpec{
				Containers: []corev1.Container{
					{
						Name:  "env-test",
						Image: "busybox",
						Command: []string{
							"sh",
							"-c",
							"env",
						},
					},
				},
				RestartPolicy:                corev1.RestartPolicyNever,
				AutomountServiceAccountToken: func() *bool { b := true; return &b }(),
			},
		},
		{
			FixtureFileName: "test_fixture.json",
			TestInfo:        []string{"pod spec with nil AutomountServiceAccountToken"},
			Field:           "spec",
			K8sObjects: []string{
				"pods",
			},
			HardcodedConfig: corev1.PodSpec{
				Containers: []corev1.Container{
					{
						Name:  "env-test",
						Image: "busybox",
						Command: []string{
							"sh",
							"-c",
							"env",
						},
					},
				},
				RestartPolicy:                corev1.RestartPolicyNever,
				AutomountServiceAccountToken: nil,
			},
		},
	}
}

// -----------------------------------------------------------------------------
// Helper that creates a node and a pod using the supplied PodSpec
// -----------------------------------------------------------------------------
func prepareFakeNodeAndPodWithSpec(ctx context.Context, t *testing.T, clientSet kubernetes.Interface, fakeKubeletServer *httptest.Server, podSpec corev1.PodSpec) *corev1.Pod {
	t.Helper()

	// node creation (static name)
	node, err := clientSet.CoreV1().Nodes().Create(ctx, &corev1.Node{
		ObjectMeta: metav1.ObjectMeta{Name: "fake"},
	}, metav1.CreateOptions{})
	if err != nil {
		t.Fatal(err)
	}
	fakeURL, _ := url.Parse(fakeKubeletServer.URL)
	host, portStr, _ := net.SplitHostPort(fakeURL.Host)
	port, _ := strconv.ParseUint(portStr, 10, 32)
	node.Status = corev1.NodeStatus{
		Addresses: []corev1.NodeAddress{
			{
				Type:    corev1.NodeExternalIP,
				Address: host,
			},
		},
		DaemonEndpoints: corev1.NodeDaemonEndpoints{
			KubeletEndpoint: corev1.DaemonEndpoint{
				Port: int32(port),
			},
		},
	}
	node, err = clientSet.CoreV1().Nodes().UpdateStatus(ctx, node, metav1.UpdateOptions{})
	if err != nil {
		t.Fatal(err)
	}

	// namespace & serviceaccount (static)
	_, err = clientSet.CoreV1().Namespaces().Create(ctx, &corev1.Namespace{
		ObjectMeta: metav1.ObjectMeta{Name: "ns"},
	}, metav1.CreateOptions{})
	if err != nil {
		t.Fatal(err)
	}
	_, err = clientSet.CoreV1().ServiceAccounts("ns").Create(ctx, &corev1.ServiceAccount{
		ObjectMeta: metav1.ObjectMeta{Name: "default", Namespace: "ns"},
	}, metav1.CreateOptions{})
	if err != nil {
		t.Fatal(err)
	}

	// inject node name & SA token flag into supplied spec
	podSpec.NodeName = node.Name
	falseRef := false
	if podSpec.AutomountServiceAccountToken == nil {
		podSpec.AutomountServiceAccountToken = &falseRef
	}
	pod, err := clientSet.CoreV1().Pods("ns").Create(ctx, &corev1.Pod{
		ObjectMeta: metav1.ObjectMeta{
			Name:      "test-pod-" + string(uuid.NewUUID()),
			Namespace: "ns",
		},
		Spec: podSpec,
	}, metav1.CreateOptions{})
	if err != nil {
		t.Fatal(err)
	}
	return pod
}

// -----------------------------------------------------------------------------
// Rewritten insecure‑pod‑logs test using dynamic configuration and edge cases
// -----------------------------------------------------------------------------
func TestCtestInsecurePodLogs(t *testing.T) {
	fmt.Println(ctestglobals.StartExtendModeSeparator)

	// fetch dynamic pod specs
	item, found := ctestutils.GetItemByExactTestInfo(getHardCodedConfigInfoPodSpec(), "default pod spec")
	if !found {
		fmt.Println(ctestglobals.DebugPrefix(), "No default pod spec config found, skipping test")
		fmt.Println(ctestglobals.EndSeparator)
		return
	}
	fmt.Println(ctestglobals.DebugPrefix(), "get default configs:", item)

	configObjs, configJSON, err := ctest.GenerateEffectiveConfigReturnType[corev1.PodSpec](item, ctest.ExtendOnly)
	if err != nil {
		t.Fatalf("failed to generate config: %v", err)
	}
	if configObjs == nil {
		fmt.Println(ctestglobals.DebugPrefix(), "Skipping test execution. No new configurations generated.")
		fmt.Println(ctestglobals.EndSeparator)
		return
	}
	fmt.Println(ctestglobals.DebugPrefix(), "New Json Test Configs:", string(configJSON))
	fmt.Println(ctestglobals.DebugPrefix(), "Number of test cases:", len(configObjs))

	for i, cfg := range configObjs {
		fmt.Printf("Running %d th test case.\n", i)
		fmt.Println(cfg)

		// setup test server (same as original)
		fakeKubeletServer := httptest.NewTLSServer(http.HandlerFunc(func(w http.ResponseWriter, req *http.Request) {
			_, _ = w.Write([]byte("fake-log"))
			w.WriteHeader(http.StatusOK)
		}))
		defer fakeKubeletServer.Close()

		// start apiserver with insecure CA (same as original)
		tCtx := ktesting.Init(t)
		clientSet, _, tearDownFn := framework.StartTestServer(tCtx, t, framework.TestServerSetup{
			ModifyServerRunOptions: func(opts *options.ServerRunOptions) {
				opts.GenericServerRunOptions.MaxRequestBodyBytes = 1024 * 1024
				opts.KubeletConfig.TLSClientConfig.CAFile = writeDataToTempFile(t, []byte("invalid-ca"))
			},
		})
		defer tearDownFn()

		// create pod using dynamic spec
		pod := prepareFakeNodeAndPodWithSpec(tCtx, t, clientSet, fakeKubeletServer, cfg)

		// insecure request – should succeed
		insecureResult := clientSet.CoreV1().Pods("ns").GetLogs(pod.Name, &corev1.PodLogOptions{InsecureSkipTLSVerifyBackend: true}).Do(context.TODO())
		if err := insecureResult.Error(); err != nil {
			t.Fatalf("insecure request failed: %v", err)
		}
		var insecureStatusCode int
		insecureResult.StatusCode(&insecureStatusCode)
		if insecureStatusCode != http.StatusOK {
			t.Fatalf("unexpected insecure status code: %d", insecureStatusCode)
		}

		// secure request – should fail with unknown CA
		secureResult := clientSet.CoreV1().Pods("ns").GetLogs(pod.Name, &corev1.PodLogOptions{}).Do(tCtx)
		if err := secureResult.Error(); err == nil || !strings.Contains(err.Error(), "x509: certificate signed by unknown authority") {
			t.Fatalf("expected TLS error, got: %v", err)
		}
		var secureStatusCode int
		secureResult.StatusCode(&secureStatusCode)
		if secureStatusCode == http.StatusOK {
			t.Fatalf("secure request unexpectedly succeeded with status %d", secureStatusCode)
		}
	}
	fmt.Println(ctestglobals.EndSeparator)
}

// -----------------------------------------------------------------------------
// Dynamic configuration for PodSpec used in client‑cert‑reload test
// -----------------------------------------------------------------------------
func getHardCodedConfigInfoPodSpecReload() ctestglobals.HardcodedConfig {
	return ctestglobals.HardcodedConfig{
		{
			FixtureFileName: "test_fixture.json",
			TestInfo:        []string{"default pod spec for reload test"},
			Field:           "spec",
			K8sObjects: []string{
				"pods",
			},
			HardcodedConfig: corev1.PodSpec{
				Containers: []corev1.Container{
					{
						Name:  "foo",
						Image: "some/image:latest",
					},
				},
				RestartPolicy: corev1.RestartPolicyNever,
			},
		},
	}
}

// -----------------------------------------------------------------------------
// Rewritten client‑cert‑reload test using dynamic configuration
// -----------------------------------------------------------------------------
func TestCtestPodLogsKubeletClientCertReload(t *testing.T) {
	fmt.Println(ctestglobals.StartExtendModeSeparator)

	item, found := ctestutils.GetItemByExactTestInfo(getHardCodedConfigInfoPodSpecReload(), "default pod spec for reload test")
	if !found {
		fmt.Println(ctestglobals.DebugPrefix(), "No pod spec config for reload test, skipping")
		fmt.Println(ctestglobals.EndSeparator)
		return
	}
	fmt.Println(ctestglobals.DebugPrefix(), "get default configs:", item)

	configObjs, configJSON, err := ctest.GenerateEffectiveConfigReturnType[corev1.PodSpec](item, ctest.ExtendOnly)
	if err != nil {
		t.Fatalf("failed to generate pod spec config: %v", err)
	}
	if configObjs == nil {
		fmt.Println(ctestglobals.DebugPrefix(), "Skipping test execution. No new configurations generated.")
		fmt.Println(ctestglobals.EndSeparator)
		return
	}
	fmt.Println(ctestglobals.DebugPrefix(), "New Json Test Configs:", string(configJSON))
	fmt.Println(ctestglobals.DebugPrefix(), "Number of test cases:", len(configObjs))

	for i, podSpec := range configObjs {
		fmt.Printf("Running %d th test case.\n", i)
		fmt.Println(podSpec)

		ctx, cancel := context.WithTimeout(context.Background(), 3*time.Minute)
		t.Cleanup(cancel)

		origCertCallbackRefreshDuration := transport.CertCallbackRefreshDuration
		origDialerStopCh := transport.DialerStopCh
		transport.CertCallbackRefreshDuration = time.Second
		transport.DialerStopCh = ctx.Done()
		t.Cleanup(func() {
			transport.CertCallbackRefreshDuration = origCertCallbackRefreshDuration
			transport.DialerStopCh = origDialerStopCh
		})

		// generate initial client certs
		startingCerts := generateClientCert(t)

		dynamicCA, err := dynamiccertificates.NewDynamicCAContentFromFile("client-ca-bundle", startingCerts.caFile)
		if err != nil {
			t.Fatal(err)
		}
		if err := dynamicCA.RunOnce(ctx); err != nil {
			t.Fatal(err)
		}
		go dynamicCA.Run(ctx, 1)

		authConfig := authenticatorfactory.DelegatingAuthenticatorConfig{
			ClientCertificateCAContentProvider: dynamicCA,
		}
		authenticator, _, err := authConfig.New()
		if err != nil {
			t.Fatal(err)
		}

		// fake kubelet that requires client cert auth
		fakeKubeletServer := httptest.NewUnstartedServer(
			filters.WithAuthentication(
				http.HandlerFunc(func(w http.ResponseWriter, _ *http.Request) {
					_, _ = w.Write([]byte("pod-logs-here"))
				}),
				authenticator,
				http.HandlerFunc(func(w http.ResponseWriter, _ *http.Request) {
					w.WriteHeader(http.StatusUnauthorized)
				}),
				nil,
				nil,
			),
		)
		fakeKubeletServer.TLS = &tls.Config{ClientAuth: tls.RequestClientCert}
		fakeKubeletServer.StartTLS()
		t.Cleanup(fakeKubeletServer.Close)

		kubeletCA := writeDataToTempFile(t, pem.EncodeToMemory(&pem.Block{
			Type:  "CERTIFICATE",
			Bytes: fakeKubeletServer.Certificate().Raw,
		}))

		clientSet, _, tearDownFn := framework.StartTestServer(ctx, t, framework.TestServerSetup{
			ModifyServerRunOptions: func(opts *options.ServerRunOptions) {
				opts.GenericServerRunOptions.MaxRequestBodyBytes = 1024 * 1024
				opts.KubeletConfig.TLSClientConfig.CAFile = kubeletCA
				opts.KubeletConfig.TLSClientConfig.CertFile = startingCerts.clientCertFile
				opts.KubeletConfig.TLSClientConfig.KeyFile = startingCerts.clientCertKeyFile
			},
		})
		t.Cleanup(tearDownFn)

		// create pod with dynamic spec
		pod := prepareFakeNodeAndPodWithSpec(ctx, t, clientSet, fakeKubeletServer, podSpec)

		// initial successful log fetch
		initialLogs, err := clientSet.CoreV1().Pods("ns").GetLogs(pod.Name, &corev1.PodLogOptions{}).DoRaw(ctx)
		if err != nil {
			t.Fatalf("initial log fetch failed: %v", err)
		}
		if string(initialLogs) != "pod-logs-here" {
			t.Fatalf("unexpected initial pod logs: %s", string(initialLogs))
		}

		// rotate CA and client certs
		newCerts := generateClientCert(t)
		if err := os.Rename(newCerts.caFile, startingCerts.caFile); err != nil {
			t.Fatal(err)
		}
		if err := wait.PollUntilContextCancel(ctx, time.Second, true, func(ctx context.Context) (bool, error) {
			_, errLog := clientSet.CoreV1().Pods("ns").GetLogs(pod.Name, &corev1.PodLogOptions{}).DoRaw(ctx)
			if errors.IsUnauthorized(errLog) {
				return true, nil
			}
			return false, errLog
		}); err != nil {
			t.Fatal(err)
		}
		if err := os.Rename(newCerts.clientCertFile, startingCerts.clientCertFile); err != nil {
			t.Fatal(err)
		}
		if err := os.Rename(newCerts.clientCertKeyFile, startingCerts.clientCertKeyFile); err != nil {
			t.Fatal(err)
		}

		// verify API server now accepts new cert
		if err := wait.PollUntilContextCancel(ctx, time.Second, true, func(ctx context.Context) (bool, error) {
			fixedLogs, errLog := clientSet.CoreV1().Pods("ns").GetLogs(pod.Name, &corev1.PodLogOptions{}).DoRaw(ctx)
			if errors.IsUnauthorized(errLog) {
				t.Log("api server has not observed new client cert")
				return false, nil
			}
			if errLog != nil {
				return false, errLog
			}
			if string(fixedLogs) != "pod-logs-here" {
				return false, fmt.Errorf("unexpected pod logs: %s", string(fixedLogs))
			}
			return true, nil
		}); err != nil {
			t.Fatal(err)
		}
	}
	fmt.Println(ctestglobals.EndSeparator)
}
