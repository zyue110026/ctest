package apiserver

import (
	"context"
	"fmt"
	"testing"
	"time"

	apiextensionsv1 "k8s.io/apiextensions-apiserver/pkg/apis/apiextensions/v1"
	"k8s.io/apiextensions-apiserver/pkg/client/clientset/clientset"
	"k8s.io/apimachinery/pkg/apis/meta/v1/unstructured"
	metav1 "k8s.io/apimachinery/pkg/apis/meta/v1"
	"k8s.io/apimachinery/pkg/runtime/schema"
	"k8s.io/apimachinery/pkg/util/wait"
	"k8s.io/client-go/dynamic"
	apiservertesting "k8s.io/kubernetes/cmd/kube-apiserver/app/testing"
	"k8s.io/kubernetes/test/integration/framework"
	"k8s.io/utils/ptr"

	ctest "k8s.io/kubernetes/test/ctest"
	ctestglobals "k8s.io/kubernetes/test/ctest/ctestglobals"
	ctestutils "k8s.io/kubernetes/test/ctest/utils"
)

func TestCtestCRDExponentialRecursionBug(t *testing.T) {
	fmt.Println(ctestglobals.StartSeparator)

	// Retrieve dynamic CRD spec configurations
	hardcodedConfig := getHardCodedConfigInfoCRDExponentialRecursionBug()
	item, found := ctestutils.GetItemByExactTestInfo(hardcodedConfig, "default crd spec")
	if !found {
		fmt.Println(ctestglobals.DebugPrefix(), "Failed to find config item by TestInfo")
		t.Fatalf("Get default hardcoded config failed.")
	}
	fmt.Println(ctestglobals.DebugPrefix(), "get default configs:", item)

	fmt.Println(ctestglobals.StartExtendModeSeparator)
	configObjs, configJson, err := ctest.GenerateEffectiveConfigReturnType[apiextensionsv1.CustomResourceDefinitionSpec](item, ctest.ExtendOnly)
	if err != nil {
		fmt.Println(ctestglobals.DebugPrefix(), "Failed to generate config:", err)
		t.Fatalf("Failed to generate config: %v", err)
	}
	if configObjs == nil {
		fmt.Println(ctestglobals.DebugPrefix(), "Skipping test execution. No new configurations generated.")
		return
	}
	fmt.Println(ctestglobals.DebugPrefix(), "New Json Test Configs:", string(configJson))
	fmt.Println(ctestglobals.DebugPrefix(), "Number of test cases:", len(configObjs))

	for i, crdSpec := range configObjs {
		fmt.Printf("Running %d th test case.\n", i)
		fmt.Println(ctestglobals.DebugPrefix(), "CRD Spec:", crdSpec)

		// Start test API server
		server, err := apiservertesting.StartTestServer(t, apiservertesting.NewDefaultTestServerOptions(), nil, framework.SharedEtcd())
		if err != nil {
			t.Fatal(err)
		}
		defer server.TearDownFn()
		config := server.ClientConfig

		apiExtensionClient, err := clientset.NewForConfig(config)
		if err != nil {
			t.Fatal(err)
		}
		dynamicClient, err := dynamic.NewForConfig(config)
		if err != nil {
			t.Fatal(err)
		}

		crdName := fmt.Sprintf("crontabs.%s", crdSpec.Group)
		crd := &apiextensionsv1.CustomResourceDefinition{
			ObjectMeta: metav1.ObjectMeta{
				Name: crdName,
			},
			Spec: crdSpec,
		}

		crd, err = apiExtensionClient.ApiextensionsV1().CustomResourceDefinitions().Create(context.TODO(), crd, metav1.CreateOptions{})
		if err != nil {
			t.Fatalf("Failed to create CRD: %v", err)
		}

		// Wait until the CRD exists in discovery
		err = wait.PollImmediate(100*time.Millisecond, 15*time.Second, func() (bool, error) {
			groupResource, err := apiExtensionClient.Discovery().ServerResourcesForGroupVersion(crd.Spec.Group + "/" + crd.Spec.Versions[0].Name)
			if err != nil {
				return false, nil
			}
			for _, g := range groupResource.APIResources {
				if g.Name == crd.Spec.Names.Plural {
					return true, nil
				}
			}
			return false, nil
		})
		if err != nil {
			t.Fatalf("CRD discovery failed: %v", err)
		}

		gvr := schema.GroupVersionResource{
			Group:    crd.Spec.Group,
			Version:  crd.Spec.Versions[0].Name,
			Resource: crd.Spec.Names.Plural,
		}
		crClient := dynamicClient.Resource(gvr)

		// Edge case depths for nested fields
		depths := []int{0, 1, 10, 50, 100}
		for _, depth := range depths {
			fmt.Printf("Testing instance with nested depth %d\n", depth)
			instance := &unstructured.Unstructured{
				Object: map[string]interface{}{
					"apiVersion": gvr.Group + "/" + gvr.Version,
					"kind":       crd.Spec.Names.Kind,
					"metadata": map[string]interface{}{
						"name": fmt.Sprintf("instance-depth-%d", depth),
					},
					"spec": map[string]interface{}{},
				},
			}

			// Build nested maps according to depth
			m := instance.Object["spec"].(map[string]interface{})
			for i := 0; i < depth; i++ {
				key := fmt.Sprintf("field%d", i)
				m[key] = map[string]interface{}{}
				m = m[key].(map[string]interface{})
			}

			_, err = crClient.Create(context.TODO(), instance, metav1.CreateOptions{})
			if err != nil {
				t.Errorf("Failed to create custom resource at depth %d: %v", depth, err)
			}
		}
	}
	fmt.Println(ctestglobals.EndSeparator)
}

// getHardCodedConfigInfoCRDExponentialRecursionBug returns the minimal hard‑coded CRD spec
// needed for the recursion‑bug test.
func getHardCodedConfigInfoCRDExponentialRecursionBug() ctestglobals.HardcodedConfig {
	return ctestglobals.HardcodedConfig{
		{
			FixtureFileName: "test_fixture.json",
			TestInfo:        []string{"default crd spec"},
			Field:           "spec",
			K8sObjects:      []string{"customresourcedefinitions"},
			HardcodedConfig: apiextensionsv1.CustomResourceDefinitionSpec{
				Group: "stable.example.com",
				Scope: apiextensionsv1.ClusterScoped,
				Names: apiextensionsv1.CustomResourceDefinitionNames{
					Plural:   "crontabs",
					Singular: "crontab",
					Kind:     "CronTab",
					ListKind: "CronTabList",
				},
				Versions: []apiextensionsv1.CustomResourceDefinitionVersion{
					{
						Name:    "v1beta1",
						Served:  true,
						Storage: true,
						Schema: &apiextensionsv1.CustomResourceValidation{
							OpenAPIV3Schema: &apiextensionsv1.JSONSchemaProps{
								XPreserveUnknownFields: ptr.To(true),
								Type:                   "object",
								Properties:             map[string]apiextensionsv1.JSONSchemaProps{},
							},
						},
					},
				},
			},
		},
	}
}