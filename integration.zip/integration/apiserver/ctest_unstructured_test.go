package apiserver

import (
	"context"
	"encoding/json"
	"errors"
	"fmt"
	"testing"

	"golang.org/x/net/http2"

	appsv1 "k8s.io/api/apps/v1"
	metav1 "k8s.io/apimachinery/pkg/apis/meta/v1"
	"k8s.io/apimachinery/pkg/runtime"
	"k8s.io/apimachinery/pkg/util/uuid"
	appsv1applyconfigurations "k8s.io/client-go/applyconfigurations/apps/v1"
	clientset "k8s.io/client-go/kubernetes"
	kubeapiservertesting "k8s.io/kubernetes/cmd/kube-apiserver/app/testing"
	"k8s.io/kubernetes/test/integration/framework"

	ctest "k8s.io/kubernetes/test/ctest"
	ctestglobals "k8s.io/kubernetes/test/ctest/ctestglobals"
	ctestutils "k8s.io/kubernetes/test/ctest/utils"
)

func TestCtestRequestObjectConvertibleToUnstructured(t *testing.T) {
	// Start test server
	server := kubeapiservertesting.StartTestServerOrDie(t, nil, []string{}, framework.SharedEtcd())
	defer server.TearDownFn()

	// Hardcoded config for a valid ControllerRevision
	hardcodedConfigs := getHardCodedConfigInfoControllerRevision()
	item, found := ctestutils.GetItemByExactTestInfo(hardcodedConfigs, "default controllerrevision")
	if !found {
		fmt.Println(ctestglobals.DebugPrefix(), "Failed to find config item by TestInfo")
		t.Skip("no hardcoded config found")
	}
	fmt.Println(ctestglobals.DebugPrefix(), "get default configs:", item)
	fmt.Println(ctestglobals.StartOverrideModeSeparator)
	configObjs, configJson, err := ctest.GenerateEffectiveConfigReturnType[appsv1.ControllerRevision](item, ctest.OverrideOnly)
	if err != nil {
		fmt.Println(ctestglobals.DebugPrefix(), "Failed to get matched fixtures: %v", err)
		t.Fatalf("Failed to generate configs: %v", err)
	}
	if configObjs == nil || len(configObjs) == 0 {
		fmt.Println(ctestglobals.DebugPrefix(), "Skipping test execution. No new configurations generated.")
		return
	}
	fmt.Println(ctestglobals.DebugPrefix(), "New Json Test Configs:", string(configJson))
	fmt.Println(ctestglobals.DebugPrefix(), "Number of test cases:", len(configObjs))

	// original raw strings plus edge cases
	rawStrings := []string{
		``,
		`"`,
		`{`,
		`[`,
		`1z`,
		`z`,
		// edge cases
		`null`,
		string([]byte(nil)),
		`{` + string(make([]byte, 1024*1024)) + `}`,
	}

	for i, raw := range rawStrings {
		fmt.Printf("Running raw test case #%d with raw: %q\n", i, raw)
		// Configure protobuf client
		protoConfig := server.ClientConfig
		protoConfig.ContentConfig.ContentType = runtime.ContentTypeProtobuf
		protoConfig.ContentConfig.AcceptContentTypes = runtime.ContentTypeProtobuf
		protoClient, err := clientset.NewForConfig(protoConfig)
		if err != nil {
			t.Fatalf("unexpected error creating proto client: %v", err)
		}

		// -------- CREATE with invalid data ----------
		createCR := configObjs[0].DeepCopy()
		createCR.Name = fmt.Sprintf("test-revision-create-%d-%s", i, string(uuid.NewUUID()))
		createCR.Data = runtime.RawExtension{Raw: []byte(raw)}
		createError := new(http2.StreamError)
		if _, err := protoClient.AppsV1().ControllerRevisions("default").
			Create(context.TODO(), createCR, metav1.CreateOptions{}); errors.As(err, createError) && createError.Code == http2.ErrCodeInternal {
			t.Logf("create returned internal error as expected with rawextension %#v: %v", raw, err)
		} else {
			t.Errorf("create returned unexpected error: %#v", err)
		}

		// -------- APPLY with invalid data ----------
		var marshalerError *json.MarshalerError
		if _, err := protoClient.AppsV1().ControllerRevisions("default").
			Apply(context.TODO(),
				appsv1applyconfigurations.ControllerRevision(fmt.Sprintf("test-revision-apply-%d-%s", i, string(uuid.NewUUID())), "default").
					WithData(runtime.RawExtension{Raw: []byte(raw)}),
				metav1.ApplyOptions{}); errors.As(err, &marshalerError) {
			t.Logf("apply returned client-side marshaler error as expected with rawextension %#v: %v", raw, err)
		} else {
			t.Errorf("apply returned unexpected error: %#v", err)
		}

		// -------- UPDATE with invalid data ----------
		// create a valid object first
		existingCR := configObjs[0].DeepCopy()
		existingCR.Name = fmt.Sprintf("test-revision-update-%d-%s", i, string(uuid.NewUUID()))
		existingCR.Data = runtime.RawExtension{Raw: []byte(`{}`)}
		existing, err := protoClient.AppsV1().ControllerRevisions("default").
			Create(context.TODO(), existingCR, metav1.CreateOptions{})
		if err != nil {
			t.Errorf("expected nil create error, got: %v", err)
			continue
		}
		// now update with invalid data
		existing.Data = runtime.RawExtension{Raw: []byte(raw)}
		updateError := new(http2.StreamError)
		if _, err := protoClient.AppsV1().ControllerRevisions(existing.Namespace).
			Update(context.TODO(), existing, metav1.UpdateOptions{}); errors.As(err, updateError) && updateError.Code == http2.ErrCodeInternal {
			t.Logf("update returned internal error as expected with rawextension %#v: %v", raw, err)
		} else {
			t.Errorf("update returned unexpected error: %#v", err)
		}
	}
}

// getHardCodedConfigInfoControllerRevision returns a minimal hardcoded
// configuration for a ControllerRevision used in the test.
func getHardCodedConfigInfoControllerRevision() ctestglobals.HardcodedConfig {
	return ctestglobals.HardcodedConfig{
		{
			FixtureFileName: "test_fixture.json",
			TestInfo:        []string{"default controllerrevision"},
			Field:           "data",
			K8sObjects:      []string{"pods"},
			HardcodedConfig: &appsv1.ControllerRevision{
				ObjectMeta: metav1.ObjectMeta{
					Name: "placeholder",
				},
				Data: runtime.RawExtension{Raw: []byte(`{}`)},
			},
		},
	}
}