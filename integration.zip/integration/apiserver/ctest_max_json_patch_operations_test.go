package apiserver

import (
	"fmt"
	"strings"
	"testing"

	"github.com/google/uuid"
	v1 "k8s.io/api/core/v1"
	apierrors "k8s.io/apimachinery/pkg/api/errors"
	metav1 "k8s.io/apimachinery/pkg/apis/meta/v1"
	"k8s.io/apimachinery/pkg/types"
	"k8s.io/kubernetes/cmd/kube-apiserver/app/options"
	"k8s.io/kubernetes/test/integration/framework"
	"k8s.io/kubernetes/test/utils/ktesting"

	ctest "k8s.io/kubernetes/test/ctest"
	ctestglobals "k8s.io/kubernetes/test/ctest/ctestglobals"
	ctestutils "k8s.io/kubernetes/test/ctest/utils"
)

func TestCtestMaxJSONPatchOperations(t *testing.T) {
	fmt.Println(ctestglobals.StartSeparator)

	// Load hard‑coded configuration (default number of JSON‑patch ops)
	hardcodedConfig := getHardCodedConfigInfoMaxJSONPatchOperations()
	item, found := ctestutils.GetItemByExactTestInfo(hardcodedConfig, "default json patch config")
	if !found {
		fmt.Println(ctestglobals.DebugPrefix(), "Failed to find config item by TestInfo")
		t.Fatalf("hard‑coded config not found")
	}
	fmt.Println(ctestglobals.DebugPrefix(), "get default configs:", item)

	// Generate effective config (override mode – allows us to replace the default ops count)
	configObjs, configJSON, err := ctest.GenerateEffectiveConfigReturnType[int](item, ctest.OverrideOnly)
	if err != nil {
		fmt.Println(ctestglobals.DebugPrefix(), "Failed to generate config:", err)
		t.Fatalf("config generation error: %v", err)
	}
	if configObjs == nil {
		fmt.Println(ctestglobals.DebugPrefix(), "Skipping test execution. No new configurations generated.")
		fmt.Println(ctestglobals.EndSeparator)
		return
	}
	fmt.Println(ctestglobals.DebugPrefix(), "New Json Test Configs:", string(configJSON))
	fmt.Println(ctestglobals.DebugPrefix(), "Number of test cases:", len(configObjs))

	// Edge‑case overrides (additional ops counts we want to test)
	edgeOps := []int{0, 5, 10001} // 0 & small ops (no error), 10001 (exceeds default limit)
	// Append edge cases to the configObjs slice
	for _, e := range edgeOps {
		configObjs = append(configObjs, e)
	}

	// Start API server with a reasonable max request body size
	tCtx := ktesting.Init(t)
	clientSet, _, tearDownFn := framework.StartTestServer(tCtx, t, framework.TestServerSetup{
		ModifyServerRunOptions: func(opts *options.ServerRunOptions) {
			opts.GenericServerRunOptions.MaxRequestBodyBytes = 1024 * 1024
		},
	})
	defer tearDownFn()

	// Helper to create a secret with a random name
	createSecret := func() (*v1.Secret, error) {
		secretName := "test-" + uuid.New().String()
		secret := &v1.Secret{
			ObjectMeta: metav1.ObjectMeta{
				Name: secretName,
			},
		}
		return clientSet.CoreV1().Secrets("default").Create(tCtx, secret, metav1.CreateOptions{})
	}

	// Assume the default maximum number of JSON‑patch operations is 10000
	const defaultMaxOps = 10000

	// Execute test for each generated config (ops count)
	for i, ops := range configObjs {
		fmt.Printf("Running test case #%d with %d ops\n", i, ops)
		secret, err := createSecret()
		if err != nil {
			t.Fatalf("failed to create secret: %v", err)
		}

		// Build a JSON‑patch with the requested number of ops
		patchOp := `{"op":"add","path":"/x","value":"y"}`
		hugePatch := []byte("[" + strings.Repeat(patchOp+",", ops-1) + patchOp + "]")

		c := clientSet.CoreV1().RESTClient()
		err = c.Patch(types.JSONPatchType).AbsPath(fmt.Sprintf("/api/v1/namespaces/default/secrets/%s", secret.Name)).
			Body(hugePatch).Do(tCtx).Error()
		if ops > defaultMaxOps {
			// Expect an error about too many operations
			if err == nil {
				t.Fatalf("expected error for ops=%d, got none", ops)
			}
			if !apierrors.IsRequestEntityTooLargeError(err) {
				t.Errorf("expected RequestEntityTooLarge error for ops=%d, got %v", ops, err)
			}
			if !strings.Contains(err.Error(), "The allowed maximum operations in a JSON patch is") {
				t.Errorf("expected max‑operations message for ops=%d, got %v", ops, err)
			}
		} else {
			// Expect no error
			if err != nil {
				t.Fatalf("unexpected error for ops=%d: %v", ops, err)
			}
		}
	}
	fmt.Println(ctestglobals.EndSeparator)
}

// getHardCodedConfigInfoMaxJSONPatchOperations returns the minimal hard‑coded configuration
// needed for the TestCtestMaxJSONPatchOperations test.
// It provides the default number of JSON‑patch operations (10000) that the original test
// relied on.
func getHardCodedConfigInfoMaxJSONPatchOperations() ctestglobals.HardcodedConfig {
	return ctestglobals.HardcodedConfig{
		{
			FixtureFileName: "test_fixture.json",
			TestInfo:        []string{"default json patch config"},
			Field:           "opsCount",
			K8sObjects:      []string{"secrets"},
			HardcodedConfig: 10000,
		},
	}
}