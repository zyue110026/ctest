package pvc

import (
	"context"
	"fmt"
	"testing"

	"k8s.io/apimachinery/pkg/api/resource"
	metav1 "k8s.io/apimachinery/pkg/apis/meta/v1"
	"k8s.io/apimachinery/pkg/runtime"
	"k8s.io/apimachinery/pkg/types"
	"k8s.io/apimachinery/pkg/util/uuid"
	"k8s.io/client-go/kubernetes"
	kubeapiservertesting "k8s.io/kubernetes/cmd/kube-apiserver/app/testing"
	"k8s.io/kubernetes/pkg/api/legacyscheme"
	"k8s.io/kubernetes/test/integration/framework"

	v1 "k8s.io/api/core/v1"

	ctest "k8s.io/kubernetes/test/ctest"
	ctestglobals "k8s.io/kubernetes/test/ctest/ctestglobals"
	ctestutils "k8s.io/kubernetes/test/ctest/utils"
)

func TestCtestUpgradePVC(t *testing.T) {
	t.Run("feature_enabled", func(t *testing.T) { testCtestUpgradePVC(t, true) })
	t.Run("feature_disabled", func(t *testing.T) { testCtestUpgradePVC(t, false) })
}

func testCtestUpgradePVC(t *testing.T, featureEnabled bool) {
	fmt.Println(ctestglobals.StartSeparator)
	hardcodedConfig := getHardCodedConfigInfoUpgradePVC()
	item, found := ctestutils.GetItemByExactTestInfo(hardcodedConfig, "default pvc spec")
	if !found {
		fmt.Println(ctestglobals.DebugPrefix(), "Failed to find config item by TestInfo")
		t.Fatalf("Get default hardcoded config failed.")
	}
	fmt.Println(ctestglobals.DebugPrefix(), "get default configs:", item)

	fmt.Println(ctestglobals.StartOverrideModeSeparator)
	configObjs, configJSON, err := ctest.GenerateEffectiveConfigReturnType[v1.PersistentVolumeClaimSpec](item, ctest.OverrideOnly)
	if err != nil {
		fmt.Println(ctestglobals.DebugPrefix(), "Failed to get matched fixtures:", err)
		t.Fatalf("Failed to get matched fixtures: %v", err)
	}
	if configObjs == nil {
		fmt.Println(ctestglobals.DebugPrefix(), "Skipping test execution. No new configurations generated.")
		fmt.Println(ctestglobals.EndSeparator)
		return
	}
	fmt.Println(ctestglobals.DebugPrefix(), "New Json Test Configs:", string(configJSON))
	fmt.Println(ctestglobals.DebugPrefix(), "Number of test cases:", len(configObjs))

	edgeTestCases := []struct {
		name       string
		modifySpec func(*v1.PersistentVolumeClaimSpec)
	}{
		{
			name: "original spec (no modification)",
			modifySpec: func(s *v1.PersistentVolumeClaimSpec) {
				// no changes
			},
		},
		{
			name: "empty DataSource",
			modifySpec: func(s *v1.PersistentVolumeClaimSpec) {
				s.DataSource = nil
			},
		},
		{
			name: "zero storage request",
			modifySpec: func(s *v1.PersistentVolumeClaimSpec) {
				s.Resources.Requests[v1.ResourceStorage] = resource.MustParse("0")
			},
		},
		{
			name: "missing AccessModes",
			modifySpec: func(s *v1.PersistentVolumeClaimSpec) {
				s.AccessModes = nil
			},
		},
		{
			name: "negative storage request (invalid)",
			modifySpec: func(s *v1.PersistentVolumeClaimSpec) {
				s.Resources.Requests[v1.ResourceStorage] = resource.MustParse("-1")
			},
		},
	}

	for i, tc := range edgeTestCases {
		fmt.Printf("Running %d th test case.\n", i)
		fmt.Println("Test case:", tc.name)

		etcdOptions := framework.SharedEtcd()
		apiServerOptions := kubeapiservertesting.NewDefaultTestServerOptions()
		s := kubeapiservertesting.StartTestServerOrDie(t, apiServerOptions, nil, etcdOptions)
		defer s.TearDownFn()

		pvcName := "test-pvc-" + string(uuid.NewUUID())
		ns := "ns-" + string(uuid.NewUUID())

		kubeclient, err := kubernetes.NewForConfig(s.ClientConfig)
		if err != nil {
			t.Fatalf("Unexpected error: %v", err)
		}
		if _, err := kubeclient.CoreV1().Namespaces().Create(context.TODO(),
			&v1.Namespace{ObjectMeta: metav1.ObjectMeta{Name: ns}}, metav1.CreateOptions{}); err != nil {
			t.Fatalf("Failed to create namespace: %v", err)
		}

		// Use the first generated spec as base and apply edge modifications
		baseSpec := configObjs[0]
		tc.modifySpec(&baseSpec)

		pvc := &v1.PersistentVolumeClaim{
			ObjectMeta: metav1.ObjectMeta{
				Name:              pvcName,
				Namespace:         ns,
				CreationTimestamp: metav1.Now(),
				UID:               types.UID("08675309-9376-9376-9376-086753099999"),
			},
			Spec: baseSpec,
		}

		pvcJSON, err := runtime.Encode(legacyscheme.Codecs.LegacyCodec(v1.SchemeGroupVersion), pvc)
		if err != nil {
			t.Fatalf("Failed creating pvc JSON: %v", err)
		}
		key := "/" + etcdOptions.Prefix + "/persistentvolumeclaims/" + ns + "/" + pvcName
		if _, err := s.EtcdClient.Put(context.Background(), key, string(pvcJSON)); err != nil {
			t.Fatalf("Failed to store pvc in etcd: %v", err)
		}
		t.Logf("PVC stored in etcd %v", string(pvcJSON))

		// No-op update dry-run
		if _, err := kubeclient.CoreV1().PersistentVolumeClaims(ns).Update(context.TODO(),
			pvc, metav1.UpdateOptions{DryRun: []string{"All"}}); err != nil {
			t.Errorf("write of original content failed (%s): %v", tc.name, err)
		}

		// No-op patch dry-run
		if _, err := kubeclient.CoreV1().PersistentVolumeClaims(ns).Patch(context.TODO(),
			pvc.Name, types.MergePatchType, []byte(`{}`), metav1.PatchOptions{DryRun: []string{"All"}}); err != nil {
			t.Errorf("no-op patch failed (%s): %v", tc.name, err)
		}

		// Get and update dry-run
		getPVC, err := kubeclient.CoreV1().PersistentVolumeClaims(ns).Get(context.TODO(),
			pvc.Name, metav1.GetOptions{})
		if err != nil {
			t.Fatalf("Get pvc failed (%s): %v", tc.name, err)
		}
		if _, err := kubeclient.CoreV1().PersistentVolumeClaims(ns).Update(context.TODO(),
			getPVC, metav1.UpdateOptions{DryRun: []string{"All"}}); err != nil {
			t.Errorf("no-op get/put failed (%s): %v", tc.name, err)
		}
	}
	fmt.Println(ctestglobals.EndSeparator)
}

func getHardCodedConfigInfoUpgradePVC() ctestglobals.HardcodedConfig {
	return ctestglobals.HardcodedConfig{
		{
			FixtureFileName: "test_fixture.json",
			TestInfo:        []string{"default pvc spec"},
			Field:           "spec",
			K8sObjects:      []string{"persistentvolumeclaims"},
			HardcodedConfig: v1.PersistentVolumeClaimSpec{
				Resources: v1.VolumeResourceRequirements{
					Requests: v1.ResourceList{
						v1.ResourceStorage: resource.MustParse("10G"),
					},
				},
				DataSource: &v1.TypedLocalObjectReference{
					APIGroup: nil,
					Kind:     "PersistentVolumeClaim",
					Name:     "foo",
				},
				AccessModes: []v1.PersistentVolumeAccessMode{v1.ReadWriteOnce},
			},
		},
	}
}
